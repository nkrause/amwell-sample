//
//  AWSDKSampleTests.m
//  AWSDKSampleTests
//
//  Created by Steven Uy on 2/12/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#pragma GCC diagnostic ignored "-Wincompatible-pointer-types"
#pragma GCC diagnostic ignored "-Wnonnull"

#import <XCTest/XCTest.h>

@interface AWSDKSampleTests : XCTestCase

@end

@implementation AWSDKSampleTests

/**
 *  Setup method clears AWSDKService to a new instance
 */
- (void)setUp {
    [super setUp];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
