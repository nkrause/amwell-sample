//
//  AWSDKSystemConfigurationPrivate.h
//  AWSDK
//
//  Created by Steven Uy on 7/14/16.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKSystemConfiguration.h>
#import <AWSDK/AWSDKBiologicalSex.h>

@class AWSDKLanguage, AWSDKHealthTrackerType, AWSDKICEServer;

@interface AWSDKSystemConfiguration ()

@property (nonatomic, assign, readonly, getter=isConsumerMiddleInitialCollected) BOOL consumerMiddleInitialCollected;
@property (nonatomic, assign, readonly, getter=isConsumerAddressRequired) BOOL consumerAddressRequired;
@property (nonatomic, assign, readonly, getter=isMultiWayVideoAllowed) BOOL multiWayVideoAllowed;
@property (nonatomic, assign, readonly, getter=isMultiCountry) BOOL multiCountry;
@property (nonatomic, assign, readonly, getter=areEndVisitRatingsOptional) BOOL endVisitRatingsOptional;
@property (nonatomic, assign, readonly, getter=showProviderRatings) BOOL showProviderRatings;
@property (nonatomic, assign, readonly, getter=isServiceKeyCollected) BOOL serviceKeyCollected;
@property (nonatomic, assign, readonly, getter=isMemberHealthInsuranceCollected) BOOL memberHealthInsuranceCollected;
@property (nonatomic, assign, readonly, getter=isCancelAppointmentEnabled) BOOL cancelAppointmentEnabled;
@property (nonatomic, assign, readwrite, getter=isCallbackViaPhoneEnabled) BOOL callbackViaPhoneEnabled;
@property (nonatomic, assign, readwrite, getter=isOtherTopicEnabled) BOOL otherTopicEnabled;
@property (nonatomic, assign, readwrite, getter=isVibrateOnVisitJoinEnabled) BOOL vibrateOnVisitJoinEnabled;
@property (nonatomic, assign, readwrite, getter=isSoundOnVisitJoinEnabled) BOOL soundOnVisitJoinEnabled;
@property (nonatomic, assign, readwrite, getter=isRefreshAndGuestButtonHiddenWhenDisabled) BOOL refreshAndGuestButtonHiddenWhenDisabled;
@property (nonatomic, assign, readonly, getter=isAppointmentReadinessCheckEnabled) BOOL appointmentReadinessCheckEnabled;
@property (nonatomic, assign, readonly, getter=isExtensibleGenderSupportEnabled) BOOL extensibleGenderSupportEnabled;
@property (nonatomic, readwrite, nonnull) NSArray<id<AWSDKGenderIdentity> > *genderIdentities;
@property (nonatomic, assign, readonly) NSInteger scheduledEngagementMarginMs;
@property (nonatomic, assign, readonly) NSInteger maxVideoInvites;
@property (nonatomic, readonly, nullable) NSString *cancelAppointmentDisabledText;
@property (nonatomic, readonly, nullable) NSString *currencyCode;
@property (nonatomic, readonly, nullable) NSArray *extensionBlacklist;
@property (nonatomic, readonly, nullable) NSSet *mimeWhitelist;
@property (nonatomic, readonly, nonnull) NSArray *supportedLocales;
@property (nonatomic, readonly, nullable) NSArray *healthTrackerTypes;
@property (nonatomic, readonly, nonnull) NSSet *mimeBlacklist;
@property (nonatomic, assign, readonly) NSInteger messageAttachmentMax;
@property (nonatomic, assign, readonly) NSInteger appointmentMarginMS;
@property (nonatomic, readonly, nullable) NSArray<AWSDKICEServer *> *iceServers;
@property (nonatomic, readwrite, nullable) NSArray<AWSDKLanguage *> *validLanguages;
@property (nonatomic, readwrite, nullable) NSString *pathToVisitJoinSound;
@property (nonatomic, readwrite, nullable) NSSet<NSString *> *protectedFields;
@property (nonatomic) AWSDKConsumerMiddleNameHandling middleNameHandling;

- (BOOL)isProtectedField:(NSString *_Nonnull)key;
- (BOOL)validateBiologicalSex:(AWSDKBiologicalSex)sex;
- (BOOL)validateGenderIdentity:(id<AWSDKGenderIdentity>_Nonnull)genderIdentity;

#pragma mark - Private Static

+ (BOOL)isConsumerAddressRequired;

+ (BOOL)isConsumerMiddleInitialCollected;

+ (BOOL)areEndVisitRatingsOptional;

+ (NSArray *_Nullable)extensionBlacklist;

+ (NSSet *_Nonnull)mimeBlacklist;

+ (NSSet *_Nullable)mimeWhitelist;

+ (NSString *_Nonnull)mimeTypeForExtension:(NSString *_Nonnull)ext;

+ (NSInteger)appointmentMarginMS;

+ (NSArray<AWSDKICEServer *> *_Nullable)iceServers;

+ (void)logVisitConfiguration;

@end
