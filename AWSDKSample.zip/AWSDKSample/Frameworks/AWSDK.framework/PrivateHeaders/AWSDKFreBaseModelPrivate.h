//
//  AWSDKFreBaseModelPrivate.h
//  AWSDK
//
//  Created by Ofir Mantsur on 04/12/2019.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKFreBaseModel.h"

@interface AWSDKFreBaseModel ()

/**
 Initialize a new instance of this class with the given dictionary.

 @param dict    A dictionary representing the object
 
 @return the object
 
 @since 5.3.0
 */
- (nonnull instancetype)initWithDictionary:(nullable NSDictionary *)dict;

/**
 Populate this object with the given JSON.

 @param json    The json received from the server

 @since 5.3.0
 */
- (void)populate:(nullable NSDictionary *)json;

@end
