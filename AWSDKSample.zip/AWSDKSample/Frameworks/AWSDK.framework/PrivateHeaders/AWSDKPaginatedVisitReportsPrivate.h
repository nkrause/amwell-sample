//
//  AWSDKPaginatedVisitReportsPrivate.h
//  AWSDK
//
//  Created by Caleb Lindsey on 5/14/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKPaginatedPrivate.h"

#import <AWSDK/AWSDKPaginatedVisitReports.h>

/**
 Represents a page of AWSDKVisitReports.

 @since 6.2.0
 */
@interface AWSDKPaginatedVisitReports : AWSDKPaginated <AWSDKPaginatedVisitReports>

- (nullable instancetype)initWithDictionary:(nonnull NSDictionary *)dict;

@end
