//
//  AWSDKPastProvidersSearchRequestPrivate.h
//  AWSDK
//
//  Created by Caleb Lindsey on 8/18/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKDataObjectPrivate.h"

#import <AWSDK/AWSDKPastProvidersSearchRequest.h>

/**
 Represents a search request for fetching AWSDKProviders.

 @since 6.4.0
 */
@interface AWSDKPastProvidersSearchRequest ()

- (nonnull NSDictionary *)toParams;

@end
