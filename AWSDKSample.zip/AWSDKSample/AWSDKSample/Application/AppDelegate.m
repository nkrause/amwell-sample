//
//  AppDelegate.m
//  AWSDKSample
//
//  Created by Steven Uy on 2/12/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AppDelegate.h"

#import "ConsumerService.h"
#import "HomeViewController.h"
#import "LoginViewController.h"

#import <AWSDK/AWSDKAuthenticationService.h>
#import <AWSDK/AWSDKLaunchParamKeys.h>
#import <AWSDK/AWSDKLocale.h>
#import <AWSDK/AWSDKLogService.h>
#import <AWSDK/AWSDKService.h>
#import <AWSDK/AWSDKURLFeature.h>
#import <AWSDK/NSError+AWSDKError.h>
#import <UserNotifications/UserNotifications.h>

#ifdef USE_CRASHLYTICS
#    import <Crashlytics/Crashlytics.h>
#    import <Fabric/Fabric.h>
#endif

@interface AppDelegate () <AWSDKLogServiceDelegate>
@property (weak, nonatomic) UIViewController *splashScreen;
@property (nonatomic) NSDictionary *launchOptions;
@property (nonatomic) BOOL handlingExpiredAuth;
@end

@implementation AppDelegate

#pragma mark - UIApplication Delegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    /**
     * The first thing that must be done is initialize the SDK
     * No SDK methods will be successful until this has completed
     * If your app's core functions depend on the SDK we advise
     * initializing the SDK in your AppDelegate when the app launches
     * Otherwise you could initialize the SDK when entering the section
     * of your app that deals with the SDK
     */

#ifdef USE_CRASHLYTICS
    [Fabric with:@ [[Crashlytics class]]];
#endif

    [self initializeSDKWithOptions:launchOptions];
    /**
     * Register for Notifications
     */
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    [center requestAuthorizationWithOptions:(UNAuthorizationOptionAlert + UNAuthorizationOptionSound + UNAuthorizationOptionBadge) completionHandler:^(BOOL granted, NSError * _Nullable error) {
        if (!granted) {
            AWSDKLogInfo(@"Local notification authorization denied.");
        }
    }];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    [self showSecureSnapshot:YES];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    [self showSecureSnapshot:NO];
    [self setupLogging];
}

/**
 If the SDK is not initialize upon return from background (i.e. settings screen) initialize SDK

 @param application UIApplication proccess
 */
- (void)applicationWillEnterForeground:(UIApplication *)application {
    if (![AWSDKService isInitialized]) {
        [self initializeSDKWithOptions:self.launchOptions];
    }
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options {
    /**
     Verify the url is a supportedFeatureURL and update AWSDKServices's launchURL
     */
    AWSDKURLFeature feature = [AWSDKService supportedFeatureForUrl:url];
    if (feature != AWSDKFeatureNone) {
        [AWSDKService updateLaunchUrl:url];
        /**
         If the application is open currently and logged in, logout the current user and reauthenticate
         consumer
         */
        [[ConsumerService sharedInstance] setConsumer:nil];
        [self fadeoutSplashScreenWithCompletion:^{
            if (feature == AWSDKFeatureAppointment || feature == AWSDKFeatureGuestInvite) {
                [self presentLoginViewControllerWithCompletion:^{
                    if (feature == AWSDKFeatureGuestInvite) {
                        [UIViewController.topController performSegueWithIdentifier:@"guestLoginSegue" sender:nil];
                    }
                }];
            }
        }];
    }
    return YES;
}

#pragma mark - Private Methods

/**
 Handles Displaying the correct VC depending on autologin
 */
- (void)handleSuccesfulInit {
    // Set the preferred locale
    NSLocale *locale = self.defaultLocale ?: [NSLocale autoupdatingCurrentLocale];
    [AWSDKLocale setPreferredLocale:locale];

    [self setupAuthExpirationHandler];
    // Determine if autologin is enabled and a user is saved
    NSString *authKey = [[ConsumerService sharedInstance] fetchAuthenticationKey];
    // Authenticate with the auth key
    if (authKey) {
        [AWSDKAuthenticationService authenticateConsumerWithAuthKey:authKey
                                                         completion:^(id _Nullable consumer, NSError *error) {
                                                             if (error) {
                                                                 // Clear auth key and continue to login page
                                                                 [[ConsumerService sharedInstance] clearAuthenticationKey];

                                                                 // An incorrect authKey should fail silently since it can be resolved by logging in again
                                                                 if (error.domain != AWSDKErrorDomainSDK) {
                                                                     [[UIViewController topMostAlertVC] presentAlertWithError:error okHandler:nil];
                                                                 }
                                                                 [MBProgressHUD hide];
                                                             } else if (consumer) {
                                                                 // Set consumer
                                                                 [[ConsumerService sharedInstance] setConsumer:consumer];

                                                                 // Dismiss login view controller
                                                                 [self.window.rootViewController dismissViewControllerAnimated:YES
                                                                                                                    completion:^{
                                                                                                                        [MBProgressHUD hide];
                                                                                                                    }];
                                                             }
                                                         }];
        // Continue to login page
    } else {
        // Remove activity Window
        [MBProgressHUD hide];
    }
}

- (void)setupAuthExpirationHandler {
    AWSDKService.authenticationInvalidatedBlock = ^(NSString *_Nonnull consumerAuthKey) {
        if (!self.handlingExpiredAuth && ConsumerService.sharedInstance.isloggedIn) {
            self.handlingExpiredAuth = YES;
            dispatch_async(dispatch_get_main_queue(), ^{
                UINavigationController *navController = [UIStoryboard storyboardWithName:@"Main" bundle:nil].instantiateInitialViewController;
                ((UINavigationController *)self.window.rootViewController).viewControllers = navController.viewControllers;
                [ConsumerService.sharedInstance deauthenticateConsumer];
                self.handlingExpiredAuth = NO;
                [MBProgressHUD hide];
            });
        }
    };
}

- (void)presentLoginViewControllerWithCompletion:(CompletionBlock)completion {
    UIViewController *top = [UIViewController topController];
    if ([top isKindOfClass:[HomeViewController class]]) {
        [(HomeViewController *)top logout:self withCompletion:completion];
    } else if ([top isKindOfClass:[LoginViewController class]]){
        if (completion) {
            completion();
        }
    } else {
        __weak typeof(self) weakSelf = self;
        [self returnToLoginVCWithCompletion:^{
            [weakSelf presentLoginViewControllerWithCompletion:completion];
        }];
    }
}

/**
 Don't forget to be HIPAA compliant!

 @param shouldShow States whether or not you would like to show the secure screen
 */
- (void)showSecureSnapshot:(BOOL)shouldShow {
    // Make sure the splash screen isn't already being shown
    if (shouldShow && !self.splashScreen) {
        __block UIApplication *application = [UIApplication sharedApplication];

        // This is the proper way to execute short tasks when the application goes to the background
        __block UIBackgroundTaskIdentifier task = [application beginBackgroundTaskWithName:@"SecureSnapshot"
                                                                         expirationHandler:^{
                                                                             [application endBackgroundTask:task];
                                                                             task = UIBackgroundTaskInvalid;
                                                                         }];

        // We don't want to flash the splash screen at the user as the application is going into the background, so we delay it by sending it to a default priority async queue
        dispatch_async(dispatch_get_main_queue(), ^{
            // Have to check again since this is all async
            if (!self.splashScreen) {
                self.splashScreen = [[UIStoryboard storyboardWithName:@"LaunchScreen" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"launchScreen"];
                self.splashScreen.view.alpha = 0.0;
                self.securityWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
                // Set level to the highest level (AlertLevel) + 100 so that the security window appears on top of all windows
                self.securityWindow.windowLevel = UIWindowLevelAlert + 100;
                self.securityWindow.rootViewController = self.splashScreen;
                [self.securityWindow makeKeyAndVisible];

                // Fade in, and end task
                __weak typeof(self) weakSelf = self;
                [UIView animateWithDuration:0.75
                    animations:^{
                        weakSelf.splashScreen.view.alpha = 1.0;
                    }
                    completion:^(BOOL finished) {
                        [application endBackgroundTask:task];
                        task = UIBackgroundTaskInvalid;
                    }];
            }
        });
    } else {
        [self fadeoutSplashScreenWithCompletion:nil];
    }
}

- (void)fadeoutSplashScreenWithCompletion:(CompletionBlock)completion {
    // Fade out, then dismiss
    if (self.splashScreen) {
        __weak typeof(self) weakSelf = self;
        [UIView animateWithDuration:0.75
            animations:^{
                weakSelf.splashScreen.view.alpha = 0.0;
            }
            completion:^(BOOL finished) {
                [weakSelf.splashScreen dismissViewControllerAnimated:NO completion:nil];
                weakSelf.securityWindow = nil;
                UIWindow *mainWindow = ((AppDelegate *)UIApplication.sharedApplication.delegate).window;
                [mainWindow makeKeyAndVisible];
                if (completion) {
                    completion();
                }
            }];
    } else {
        if (completion) {
            completion();
        }
    }
}

- (void)returnToLoginVCWithCompletion:(CompletionBlock)completion {
    __block UIViewController *top = [UIViewController topMostMainVC];
    if (top.presentingViewController) {
        [top dismissViewControllerAnimated:NO completion:completion];
    } else {
        if (completion) {
            completion();
        }
    }
}

- (void)applyUserDefaults {
    [AWSDKService setCertificatePinningEnabled:[NSUserDefaults.standardUserDefaults boolForKey:@"certificate_pinning"]];
}

/**
 * NSUserDefaults Registration
 */
- (NSDictionary *)registerDefaults {
    NSString *bundle = [[NSBundle mainBundle] pathForResource:@"Settings" ofType:@"bundle"];
    NSDictionary *settings = [NSDictionary dictionaryWithContentsOfFile:[bundle stringByAppendingPathComponent:@"Root.plist"]];
    NSArray *preferences = [settings objectForKey:@"PreferenceSpecifiers"];

    NSMutableDictionary *toRegister = [[NSMutableDictionary alloc] initWithCapacity:[preferences count]];
    for (NSDictionary *preference in preferences) {
        NSString *key = [preference objectForKey:@"Key"];
        if (key) {
            [toRegister setObject:[preference objectForKey:@"DefaultValue"] forKey:key];
        }
    }
    [[NSUserDefaults standardUserDefaults] registerDefaults:toRegister];
    return toRegister;
}

- (void)initializeSDKWithOptions:(NSDictionary *)launchOptions {
    // Save launchOption in case SDK needs to be re-initialized after being background
    self.launchOptions = launchOptions;
    // Register Defaults
    NSMutableDictionary *registeredDefaults = [self registerDefaults].mutableCopy;

    [self applyUserDefaults];

    // Settings
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];

    NSDictionary<NSString *, NSString *> *preset;
    if ([[defaults objectForKey:@"preset_environment"] isKindOfClass:[NSDictionary class]]) {
        preset = [defaults objectForKey:@"preset_environment"];
    }

    NSInteger visitTimeout = [defaults integerForKey:@"visit_timeout"];
    [AWSDKService setAutomaticVisitEndWithTimeout:visitTimeout];

    NSInteger backgroundVisitTimeout = [defaults integerForKey:@"visit_background_timeout"];
    [AWSDKService setAutomaticBackgroundVisitEndWithTimeout:backgroundVisitTimeout];

    AWSDKService.backgroundVisitsEnabled = [defaults boolForKey:@"background_visits"];
    
    AWSDKService.accountPropagationDisabled = [defaults boolForKey:@"ignore_propagation"];

    if ([defaults boolForKey:@"overrideLocalization"]) {
        // no-op
    }

    /**
     Example of configuring the logging service
     */
    [self setupLogging];

    /**
     Example of injecting log messages into AWSDK's logs
     */
    AWSDKLogDebug(@"Test Debug");

    /**
     * The base URL and Api Key can be either hard coded into your app
     * or stored in a single location where they can be changed when needed
     * like a server
     *
     * For this app they are changed within the Settings.bundle. Their default values are listed in
     * Root.plist.
     */

    /**
     * Override these values to change url and key manually and not from settings
     */

    NSString *url = preset[@"url"] ?: [defaults objectForKey:@"url"];
    NSString *key = preset[@"key"] ?: [defaults objectForKey:@"key"];
    if (!url || !key) {
        url = [registeredDefaults objectForKey:@"url"];
        key = [registeredDefaults objectForKey:@"key"];
    }

#ifdef USE_CRASHLYTICS
    [CrashlyticsKit setObjectValue:url forKey:@"Endpoint URL"];
    [CrashlyticsKit setObjectValue:key forKey:@"SDK Key"];
    [registeredDefaults removeObjectForKey:@"jiraPassword"];
    [CrashlyticsKit setObjectValue:registeredDefaults.description forKey:@"Settings"];
#endif

    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *bundleId = [mainBundle bundleIdentifier];
    NSMutableDictionary *launchParams = [@{ kAWSDKUrl : url, kAWSDKKey : key, kAWSDKBundleID : bundleId } mutableCopy];
    /**
     * Pass the SDK the launch url to store if it's relevent to the SDK
     */
    NSURL *optionsURL = launchOptions[UIApplicationLaunchOptionsURLKey];
    if (optionsURL) {
        if ([AWSDKService supportedFeatureForUrl:optionsURL] != AWSDKFeatureNone) {
            [launchParams setObject:[optionsURL absoluteString] forKey:kAWSDKLaunchURL];
        }
    }

    /**
     * The GenericCompletionBlock will always return a boolean success
     * value and may return an NSError with vital information about the
     * failure case.
     * If the call succeeded we do nothing and allow the app to be used
     * as normal. Note that if this call fails the app will not function
     * so the error message shown should explain this failure to the user
     */
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD show];
    // Only leave debug mode enabled for debug builds of your application. This flag will cause the AWSDK to use insecure networking and will notify the appication server of the debug state of the AWSDK client.
    [AWSDKService enableDebugMode];
    [AWSDKService initializeWithLaunchParams:launchParams
                                  completion:^void(BOOL success, NSError *error) {
                                      [MBProgressHUD hide];
                                      if (error) {
                                          // Since there is no cancel API to the SDKService, ensure that a retry wasn't succesful
                                          //  before displaying an error message
                                          if (![AWSDKService isInitialized]) {
                                              // Display error and force user to reload try again later
                                              [[UIViewController topMostAlertVC] presentAlertWithError:error okHandler:nil];
                                          }
                                      } else {
                                          [weakSelf handleSuccesfulInit];
                                      }
                                  }];
}

- (void)setupLogging {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    AWSDKLogService.numberOfFilesSaved = 10;
    AWSDKLogService.synchronousLogging = [defaults boolForKey:@"syncLogging"];
        
    #ifdef USE_CRASHLYTICS
        [AWSDKLogService setConsoleLogLevel:AWSDKLogLevelVerbose];
        AWSDKLogService.logDelegate = self;
    #endif

    // Enabling the network logging to both the console and log file
    if ([defaults boolForKey:@"networkLogging"]) {
        [AWSDKLogService enableNetworkLogs];
    } else {
        [AWSDKLogService disableNetworkLogs];
    }
}

#pragma mark - Locale Handling

- (NSLocale *)defaultLocale {
    NSLocale *locale = nil;
    NSString *localeIdentifier = [NSUserDefaults.standardUserDefaults objectForKey:APP_LOCALE_OVERRIDE];
    if (localeIdentifier) {
        locale = [NSLocale localeWithLocaleIdentifier:localeIdentifier];
    }
    return locale;
}

- (NSString *)currentLanguageCode {
    NSLocale *locale = self.defaultLocale ?: [NSLocale currentLocale];
    return locale.languageCode;
}



#pragma mark - Crashlytics

- (void)didReceiveLogMessage:(NSString *)message {
#ifdef USE_CRASHLYTICS
    CLSLog(@"%@", message);
#endif
}

@end
