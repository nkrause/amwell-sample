//
//  AppDelegate.h
//  AWSDKSample
//
//  Created by Steven Uy on 2/12/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

// clang-format off
#define APP_LOCALE_OVERRIDE     @"app_locale_override"
#define APP_LOCALE_OVERRIDDEN   @"locale_overriden"
#define APP_APPLE_LANGUAGES     @"AppleLanguages"
#define APP_LOCALE_RESTORE_POS  @"restore_locale_pos"
// clang-format on

@interface AppDelegate : UIResponder <UIApplicationDelegate>

// Used to display the application's regular view controllers
@property (nonatomic) UIWindow *window;

// Used to display the activity indicator view
@property (nonatomic) UIWindow *activityWindow;

// Used to display the security splash screen
@property (nonatomic) UIWindow *securityWindow;

// Used to display all alerts
@property (nonatomic) UIWindow *alertWindow;

- (NSLocale *)defaultLocale;
- (NSString *)currentLanguageCode;

@end
