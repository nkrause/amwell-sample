//
//  SortedSelectableTableViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 5/11/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.

/**
 SortedSelectableTableViewController is used by Conditions, Allergies, and Medications
 It calls fetch when loaded or refreshed and update upon exit
 */
@interface SortedSelectableTableViewController : UITableViewController

// List will always sort according to these descriptors
@property (nonatomic) NSMutableArray<NSSortDescriptor *> *sortDescriptors;

// DataSource
@property (nonatomic) NSMutableArray *allData;
@property (nonatomic) NSMutableArray *selectedData;

#pragma mark - Required override methods
/**
 Called when retriving and populating the data source
 */
- (void)fetch;

/**
 Called when applying the data source upon exit
 */
- (void)update;

#pragma mark - Convience methods
/**
 Sorts the tableView based upon the sortDescriptors

 @param tableView self.tableView
 */
- (void)sortTableView:(UITableView *)tableView;

@end
