//
//  BaseViewController.h
//  AWSDKSample
//
//  Created by steven.uy on 2/16/16.
//  Copyright © 2016 American Well. All rights reserved.
//

#import <AWSDK/AWSDKConsumer.h>
#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@property (strong, nonatomic) AWSDKConsumer *consumer;
@property (strong, nonatomic) NSString *consumerAuthKey;

- (void)fetchAWSDKConsumer;

- (id)handleResult:(id)result withError:(NSError *)error;

- (void)handleError:(NSError *)error;

- (void)showActivityAlert;
- (void)showActivityAlertWithTitle:(NSString *)title;
- (void)hideActivityAlert;

+ (UIViewController *)topMostController;
@end