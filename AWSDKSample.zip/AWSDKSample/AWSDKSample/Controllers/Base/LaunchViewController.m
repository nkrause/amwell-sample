//
//  LaunchViewController.m
//  AWSDKSample
//
//  Created by steven.uy on 10/14/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "LaunchViewController.h"

#import <AWSDK/AWSDK.h>

@interface LaunchViewController ()

@property (weak, nonatomic) IBOutlet UILabel *versionLabel;

@end

@implementation LaunchViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dismiss) name:@"init" object:nil];
    [self.versionLabel setText:[NSString stringWithFormat:@"Version %.02f", AWSDKVersionNumber]];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    [MBProgressHUD showLoadingOn:self.view];
}

- (void)dismiss {
    [self dismissViewControllerAnimated:YES
                             completion:^{
                                 [MBProgressHUD hideHUDForView:self.view];
                             }];
}

@end
