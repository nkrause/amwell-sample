//
//  LaunchViewController.h
//  AWSDKSample
//
//  Created by steven.uy on 10/14/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

@interface LaunchViewController : UIViewController

@end
