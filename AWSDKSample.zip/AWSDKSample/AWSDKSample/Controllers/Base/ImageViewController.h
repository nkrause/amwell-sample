//
//  ImageViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 9/7/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.

/**
 Displays an image in a scroll view
 */
@interface ImageViewController : UIViewController

/**
 Imageview outlet
 */
@property (nonatomic) IBOutlet UIImageView *imageView;

/**
 Image to be displayed
 */
@property (nonatomic) UIImage *image;

@end
