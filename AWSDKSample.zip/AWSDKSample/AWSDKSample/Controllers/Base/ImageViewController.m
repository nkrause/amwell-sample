//
//  ImageViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 9/7/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.

#import "ImageViewController.h"

#import <AVFoundation/AVFoundation.h>

@interface ImageViewController ()

@end

@implementation ImageViewController

//-----------------------------------------------------------------------------------------------------//
//----------------------Everything here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

- (void)viewDidLoad {
    [super viewDidLoad];

    [self.imageView setImage:self.image];
}

- (CGSize)preferredContentSize {
    return AVMakeRectWithAspectRatioInsideRect(self.image.size, self.imageView.frame).size;
}

- (IBAction)closeButtonTapped:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
