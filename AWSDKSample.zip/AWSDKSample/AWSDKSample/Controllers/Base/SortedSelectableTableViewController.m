//
//  SortedSelectableTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/11/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "SortedSelectableTableViewController.h"

#import "RefreshControl.h"

/**
 *  SortedSelectableTableViewController is used by Conditions, Allergies, and Medications
 *  It calls fetch when loaded or refreshed and update upon exit
 */
@implementation SortedSelectableTableViewController

#pragma mark Forced Overrides
- (void)fetch {
    NSAssert(NO, @"Please override this method in the subclass to populate all and selected data");
}

- (void)update {
    NSAssert(NO, @"Please override this method in the subclass to update data");
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything here is UI for the sample app, no more API calls here -------------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    [self.tableView setDelegate:self];
    [self.tableView setDataSource:self];

    self.sortDescriptors = [NSMutableArray new];
    self.selectedData = [NSMutableArray new];

    [self.refreshControl addTarget:self action:@selector(update) forControlEvents:UIControlEventValueChanged];

    [self fetch];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];

    [self update];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [(RefreshControl *)self.refreshControl scrollViewDidScroll:scrollView];
}

#pragma mark - Sort
- (void)sortTableView:(UITableView *)tableView {
    NSArray *unsortedData = [self.allData copy];

    [self.allData sortUsingDescriptors:self.sortDescriptors];

    [tableView beginUpdates];

    NSInteger sourceRow = 0;
    for (id object in unsortedData) {
        NSInteger destRow = [self.allData indexOfObject:object];

        if (destRow != sourceRow) {
            NSIndexPath *sourceIndexPath = [NSIndexPath indexPathForItem:sourceRow inSection:0];
            NSIndexPath *destIndexPath = [NSIndexPath indexPathForItem:destRow inSection:0];
            [tableView moveRowAtIndexPath:sourceIndexPath toIndexPath:destIndexPath];
        }
        sourceRow++;
    }
    [tableView endUpdates];
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.allData && self.allData.count > 0 ? self.allData.count : 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    [cell setAccessoryType:UITableViewCellAccessoryNone];

    if (self.allData == nil) {
        [cell.textLabel setText:NSLocalizedString(@"alert.loading", @"Loading text")];
    } else if (self.allData && self.allData.count == 0) {
        [cell.textLabel setText:NSLocalizedString(@"misc.none", @"None label")];
    } else {
        [cell.textLabel setText:[self.allData[indexPath.row] displayName]];

        if ([self.selectedData containsObject:self.allData[indexPath.row]]) {
            [cell setAccessoryType:UITableViewCellAccessoryCheckmark];
            [tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        } else {
            [cell setAccessoryType:UITableViewCellAccessoryNone];
        }
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.allData.count > 0) {
        id data = self.allData[indexPath.row];
        AWSDKLogInfo(@"Selected %@", [data displayName]);
        [self.selectedData addObject:data];
        [tableView reloadRowsAtIndexPaths:@[ indexPath ] withRowAnimation:UITableViewRowAnimationFade];
        [self sortTableView:tableView];
    }
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.allData.count > 0) {
        id data = self.allData[indexPath.row];
        AWSDKLogInfo(@"Deselected %@", [data displayName]);
        [self.selectedData removeObject:data];
        [tableView reloadRowsAtIndexPaths:@[ indexPath ] withRowAnimation:UITableViewRowAnimationFade];
        [self sortTableView:tableView];
    }
}

@end
