//
//  AppointmentsController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/14/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AppointmentsTableViewController.h"

#import "NSPersonNameComponents+Localizing.h"
#import "ProviderDetailViewController.h"
#import "ProviderTableViewCell.h"
#import "RefreshControl.h"
#import "UITableView+Sample.h"
#import "VisitContextTableViewController.h"

#import <AWSDK/AWSDKAppointment.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKPractice.h>
#import <AWSDK/AWSDKProvider.h>
#import <AWSDK/AWSDKSchedule.h>
#import <AWSDK/AWSDKVisitContext.h>

@interface AppointmentsTableViewController () <ProviderDetailDelegate, UIPopoverPresentationControllerDelegate>

@property (nonatomic) NSArray<NSArray<id<AWSDKAppointment>> *> *appointments;
@property (nonatomic) NSString *noAppointmentsTitle;
@property (assign, nonatomic) NSUInteger providerImageCount;

@end
/**
 *  AppointmentsController handles showing consumer's upcoming appointments
 */
@implementation AppointmentsTableViewController

#pragma mark - AWSDK Method Calls
/**
 *  Fetches all appointments for  the current consumer
 */
- (void)fetchAppointments {
    /*
     * Here you could specify a start date for the appointment fetch.
     * If no date is specified the system will use the current date
     */
    if (![self.refreshControl isRefreshing]) {
        [MBProgressHUD showLoadingOn:self.view];
    }

    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    [consumer getAppointmentsSinceDate:nil
                        withCompletion:^(NSArray *results, NSError *error) {
                            [MBProgressHUD hideHUDForView:self.view];
                            if (error) {
                                [self.refreshControl endRefreshing];
                                [self presentAlertWithError:error okHandler:nil];
                            } else {
                                // Separate appointments by name
                                NSMutableDictionary *appointmentByName = [NSMutableDictionary new];
                                for (id<AWSDKAppointment> appointment in results) {
                                    NSString *key = appointment.consumer.nameComponents.localizedFullName;

                                    if (appointmentByName[key]) {
                                        [appointmentByName[key] addObject:appointment];
                                    } else {
                                        appointmentByName[key] = [@[ appointment ] mutableCopy];
                                    }

                                    self.providerImageCount++;
                                }

                                // Set the appointments now seperated by name
                                self.appointments = [appointmentByName allValues];

                                if (results.count > 0) {
                                    [self fetchProvidersImages];
                                } else {
                                    // No Appointments
                                    self.noAppointmentsTitle = NSLocalizedString(@"appointments.none", @"Appointments None Title");

                                    [self.refreshControl endRefreshing];
                                    [self.tableView reloadDataAnimated:YES];
                                }
                            }
                        }];
}

/**
 *  Fetches provider images given the array of appointments and sets their image object
 */
- (void)fetchProvidersImages {
    if (self.appointments.count == 0) {
        return;
    }

    void (^completion)(BOOL success, NSError *error) = ^void(BOOL success, NSError *error) {
        self.providerImageCount--;

        if (self.providerImageCount == 0) {
            [self.tableView reloadDataAnimated:YES];

            [MBProgressHUD hideHUDForView:self.view];
            [self.refreshControl endRefreshing];
        }
    };

    [MBProgressHUD showLoadingOn:self.view];
    for (NSArray *appointmentArray in self.appointments) {
        for (id<AWSDKAppointment> appointment in appointmentArray) {
            if (appointment.provider) {
                [appointment.provider fetchProviderImage:completion];
            } else {
                completion(YES, nil);
            }
        }
    }
}

- (void)cancelAppointment:(id<AWSDKAppointment>)appointment {
    [appointment cancelAppointmentWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            [self fetchAppointments];
        } else if (error) {
            [self presentAlertWithError:error okHandler:nil];
        }
    }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    self.appointments = [NSArray new];
    self.noAppointmentsTitle = NSLocalizedString(@"alert.loading", @"Appointments Loading Title");
    self.providerImageCount = 0;

    [self setTitle:NSLocalizedString(@"appointments.title", @"Appointments Title")];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self fetchAppointments];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [(RefreshControl *)self.refreshControl scrollViewDidScroll:scrollView];
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return MAX(1, self.appointments.count);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.appointments.count == 0) {
        return 1;
    }

    NSArray *appointments = self.appointments[section];
    return appointments.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.appointments.count) {
        ProviderTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"providerCell"];

        if (self.appointments.count >= indexPath.section) {
            NSArray<id<AWSDKAppointment>> *appointmentSection = self.appointments[indexPath.section];
            if (appointmentSection.count && appointmentSection.count >= indexPath.row) {
                id<AWSDKAppointment> appointment = appointmentSection[indexPath.row];
                [cell setAppointment:appointment];
            }
        }

        return cell;
    }

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"none"];
    [cell.textLabel setText:self.noAppointmentsTitle];
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.appointments.count) {
        NSArray<id<AWSDKAppointment>> *appointmentsSection = self.appointments[indexPath.section];
        id<AWSDKAppointment> appointment = appointmentsSection[indexPath.row];
        return !appointment.provider.practice.hideCancelAppointmentLink;
    }
    return NO;
}

#pragma mark - UITableViewDelegate
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (self.appointments.count) {
        id<AWSDKAppointment> appointment = self.appointments[section][0];
        return appointment.consumer.nameComponents.localizedFullName;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.appointments.count) {
        // Provider available in appointment

        id<AWSDKAppointment> appointment = nil;
        if (self.appointments.count >= indexPath.section) {
            NSArray<id<AWSDKAppointment>> *appointmentSection = self.appointments[indexPath.section];
            if (appointmentSection.count && appointmentSection.count >= indexPath.row) {
                appointment = appointmentSection[indexPath.row];
            }
        }

        if (appointment != nil) {
            if (appointment.provider) {
                [self performSegueWithIdentifier:@"providerDetailSegue" sender:appointment];
            } else {
                // First Available, check status to display messages
                // In the case that first available is on time, there should be a provider object
                // Otherwise the status is NoProvider
                NSString *messageKey;
                if (appointment.status == Early) {
                    // If early, present an alert stating so
                    messageKey = @"thn.early.message";
                } else if (appointment.status == Late) {
                    // If Late, present an alert stating so
                    messageKey = @"thn.late.message";
                } else if (appointment.status == NoProvider) {
                    // No Providers
                    messageKey = @"thn.noProvider.message";
                }
                if (messageKey) {
                    [self presentAlertWithMessageKey:messageKey
                                           okHandler:^(UIAlertAction *action) {
                                               [MBProgressHUD hideHUDForView:self.view];
                                           }];
                }
            }
        }
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete && self.appointments.count) {
        id<AWSDKAppointment> appointment = self.appointments[indexPath.section][indexPath.row];
        [self cancelAppointment:appointment];
    }
}

#pragma mark - IBActions
- (IBAction)refresh:(id)sender {
    [self fetchAppointments];
}

#pragma mark - ProviderDetailDelegate
- (void)didStartVisit:(id)sender {
    if ([sender conformsToProtocol:@protocol(AWSDKAppointment)]) {
        [self performSegueWithIdentifier:@"startAppointmentSegue" sender:sender];
    }
}

#pragma mark - UIPopoverPresentationControllerDelegate
- (UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"startAppointmentSegue"]) {
        VisitContextTableViewController *visitViewController = (VisitContextTableViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0];
        [visitViewController setAppointment:sender];
    } else if ([segue.identifier isEqualToString:@"providerDetailSegue"]) {
        id<AWSDKAppointment> appointment = sender;
        AWSDKLogInfo(@"Tapped appointment cell with %@ on %@", appointment.provider.nameComponents.localizedFullName, appointment.schedule.scheduledStartTime);
        ProviderDetailViewController *providerController = (ProviderDetailViewController *)segue.destinationViewController;

        providerController.preferredContentSize = CGSizeMake(self.view.frame.size.width * 0.95, self.view.frame.size.height * 0.95);

        UIPopoverPresentationController *presentationController = segue.destinationViewController.popoverPresentationController;
        [presentationController setDelegate:self];
        presentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 0, 0);
        presentationController.sourceView = self.view;

        [providerController setAppointment:sender];
        [providerController setDelegate:self];
    }
}

#pragma mark - UpdatePhoneNumberDelegate
- (void)phoneNumberDidUpdate {
    [self fetchAppointments];
}

@end
