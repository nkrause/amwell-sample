//
//  EditPhoneNumberViewController.h
//
//
//  Created by Ed Chianese on 12/17/18.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKAppointment.h>
#import <UIKit/UIKit.h>
@protocol UpdatePhoneNumberDelegate
- (void)phoneNumberDidUpdate;
@end

@interface EditPhoneNumberViewController : UIViewController <UITextFieldDelegate>

@property (nonatomic) id<AWSDKAppointment> appointment;
@property (nonatomic) id<UpdatePhoneNumberDelegate> delegate;
@end
