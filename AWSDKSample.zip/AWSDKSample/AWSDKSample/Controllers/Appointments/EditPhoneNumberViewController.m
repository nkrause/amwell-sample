//
//  EditPhoneNumberViewController.m
//
//
//  Created by Ed Chianese on 12/17/18.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "EditPhoneNumberViewController.h"

#import <AWSDK/AWSDKAppointment.h>
#import <AWSDK/AWSDKAppointmentRecordForm.h>
#import <AWSDK/AWSDKCompletionBlock.h>
#import <AWSDK/AWSDKService.h>

@interface EditPhoneNumberViewController ()
@property (nonatomic, weak) IBOutlet UILabel *headerLabel;
@property (nonatomic, weak) IBOutlet UITextField *phoneField;
@property (nonatomic, strong) ErrorService *errorService;

@end

@implementation EditPhoneNumberViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.headerLabel.text = NSLocalizedString(@"appointment.editPhoneNumber.header", @"Header text for phone number edit view");
    self.title = NSLocalizedString(@"appointment.editPhoneNumber.title", @"Title text for phone number edit view");
    self.phoneField.placeholder = NSLocalizedString(@"cartPatientInfo.Phone.placeholder", @"Phone placeholder");
    self.phoneField.text = self.appointment.initiatorEngagementOverridePhone;
    self.errorService = [[ErrorService alloc] initWithSender:self];
}

- (IBAction)cancelTapped {
    AWSDKLogInfo(@"Cancel tapped");
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)saveTapped {
    AWSDKLogInfo(@"Save tapped");
    [MBProgressHUD showUpdatingOn:self.view];
    AWSDKAppointmentRecordForm *form = [AWSDKAppointmentRecordForm new];

    form.initiatorOverridePhoneNumber = self.phoneField.text;

    [self.appointment updateAppointmentWithForm:form
                                     completion:^(BOOL success, NSError *error) {
                                         [MBProgressHUD hideHUDForView:self.view];
                                         if (!success) {
                                             // put up error
                                             [self presentAlertWithError:error
                                                               okHandler:^(UIAlertAction *action) {
                                                                   [self dismissViewControllerAnimated:YES completion:nil];
                                                               }];
                                         } else {
                                             [self.delegate phoneNumberDidUpdate];
                                             [self dismissViewControllerAnimated:YES completion:nil];
                                         }
                                     }];
}

#pragma mark - UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    [textField becomeFirstResponder];
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    textField.text = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    AWSDKLogInfo(@"'%@' textField editing ended with value: %@", textField.placeholder, textField.text);
}

@end
