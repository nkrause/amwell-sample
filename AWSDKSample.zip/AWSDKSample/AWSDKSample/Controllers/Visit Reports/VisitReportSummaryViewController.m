//
//  VisitReportSummaryViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 9/12/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "VisitReportSummaryViewController.h"

#import "ChatItemCell.h"
#import "NSDateFormatter+CommonFormats.h"
#import "NSPersonNameComponents+Localizing.h"
#import "NSString+Sample.h"
#import "PharmacyResultTableViewCell.h"
#import "ProviderDetailViewController.h"
#import "ScheduleReconnectViewController.h"
#import "SubtitleHtmlTableViewCell.h"
#import "SubtitleTableViewCell.h"
#import "TTTAttributedLabel+Additions.h"
#import "UILabel+Size.h"
#import "UITableView+Sample.h"
#import "VisitReportPDFViewController.h"
#import "WebviewCell.h"

#import <AWSDK/AWSDKAddress.h>
#import <AWSDK/AWSDKChatItem.h>
#import <AWSDK/AWSDKChatReport.h>
#import <AWSDK/AWSDKCost.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKFollowUpItem.h>
#import <AWSDK/AWSDKPharmacy.h>
#import <AWSDK/AWSDKPrescription.h>
#import <AWSDK/AWSDKProviderType.h>
#import <AWSDK/AWSDKSchedule.h>
#import <AWSDK/AWSDKSubscription.h>
#import <AWSDK/AWSDKModality.h>
#import <AWSDK/AWSDKModalityCode.h>
#import <AWSDK/AWSDKHealthPlan.h>
#import <AWSDK/AWSDKVisitReportSummary.h>
#import <AWSDK/AWSDKSystemConfiguration.h>
#import <AWSDK/AWSDKUser.h>
#import <AWSDK/AWSDKVisitDiagnosis.h>
#import <AWSDK/AWSDKVisitDisposition.h>
#import <AWSDK/AWSDKVisitProcedure.h>
#import <AWSDK/AWSDKVisitReportSummary.h>
#import <AWSDK/AWSDKVisitTopic.h>
#import <AWSDK/NSNumberFormatter+Extensions.h>

/**
 *  Displays a AWSDKVisitReport andi ts meta data
 */
@interface VisitReportSummaryViewController () <UIWebViewDelegate, UIPopoverPresentationControllerDelegate, ProviderDetailDelegate, UpdatePhoneNumberDelegate>

@property CGFloat webviewHeight;
@property (weak, nonatomic) IBOutlet UILabel *patientLabel;
@property (weak, nonatomic) IBOutlet UILabel *costLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *dateLabelHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *costLabelHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *providerLabelHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *practiceLabelHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *reconnectButtonHeightConstraint;
@property (weak, nonatomic) IBOutlet UIButton *reconnectButton;
@property (weak, nonatomic) IBOutlet UIButton *pdfButton;
@property (assign, nonatomic, readonly) BOOL suppressCharge;
@property (assign, nonatomic, readonly) BOOL isSchedulingReconnect;
@end

@implementation VisitReportSummaryViewController

- (void)fetchReportPDF {
    AWSDKLogInfo(@"Fetch PDF button tapped");
    [MBProgressHUD showLoadingOn:self.view];

    [self.summary fetchReportAsData:^(id result, NSError *error) {
         __weak typeof(self) weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view];

            if (error) {
                [weakSelf presentAlertWithError:error okHandler:nil];
            } else if (result) {
                [weakSelf performSegueWithIdentifier:@"pDFSegue" sender:result];
            }
        });
    }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    // Add target to PDF button
    [self.pdfButton addTarget:self action:@selector(fetchReportPDF) forControlEvents:UIControlEventTouchUpInside];

    // Title
    [self setTitle:NSLocalizedString(@"visitSummary.title", @"Visit Summary Title")];

    // Setup header view
    [self setupHeaderView];

    // WebView Height
    self.webviewHeight = 0.0;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    /**
     Since we need to size these before the view has appeared we can't rely on the label's
     width since it isn't set yet. Instead we create a CGSize based on the screens width
     minus the padding needed on either side of the label and use that to get the label's
     height and set it's constraints accordingly. This is needed so we can correctly size
     the tableviews header.
     */
    CGSize size = CGSizeMake([UIScreen mainScreen].bounds.size.width - 20, CGFLOAT_MAX);
    self.costLabelHeightConstraint.constant = [self.costLabel heightForLabelWithSize:size];
    self.providerLabelHeightConstraint.constant = [self.providerLabel heightForLabelWithSize:size];
    self.practiceLabelHeightConstraint.constant = [self.practiceLabel heightForLabelWithSize:size];
    [self hideObscuredItems];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];

    UIView *headerView = self.tableView.tableHeaderView;
    if (headerView != nil) {
        CGFloat height = [headerView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize].height;
        CGRect frame = headerView.frame;

        if (height != frame.size.height) {
            frame.size.height = height;
            headerView.frame = frame;
            self.tableView.tableHeaderView = headerView;
        }
    }
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [self numberOfSections];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == [self transferSection]) {
        return [self transferSectionNumberOfRows];

    } else if (section == [self topicsSection]) {
        return [self topicsSectionNumberOfRows];

    } else if (section == [self triageSection]) {
        return [self triageSectionNumberOfRows];

    } else if (section == [self providerNotesSection]) {
        return [self providerNotesSectionNumberOfRows];

    } else if (section == [self diagnosesSection]) {
        return [self diagnosesSectionNumberOfRows];

    } else if (section == [self proceduresSection]) {
        return [self proceduresSectionNumberOfRows];

    } else if (section == [self prescriptionsSection]) {
        return [self prescriptionsSectionNumberOfRows];

    } else if (section == [self followUpSection]) {
        return [self followUpSectionNumberOfRows];

    } else if (section == [self additionalItemsSection]) {
        return [self additionalItemsSectionNumberOfRows];

    } else if (section == [self chatSection]) {
        return [self chatSectionNumberOfRows];
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == [self providerNotesSection]) {
        return self.webviewHeight;
    }
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 85.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == [self transferSection]) {
        return [self transferSectionCellForRow:indexPath.row];

    } else if (indexPath.section == [self topicsSection]) {
        return [self topicsSectionCellForRow:indexPath.row];

    } else if (indexPath.section == [self triageSection]) {
        return [self triageSectionCellForRow:indexPath.row];

    } else if (indexPath.section == [self providerNotesSection]) {
        return [self providerNotesSectionCellForRow:indexPath.row];

    } else if (indexPath.section == [self diagnosesSection]) {
        return [self diagnosesSectionCellForRow:indexPath.row];

    } else if (indexPath.section == [self proceduresSection]) {
        return [self proceduresSectionCellForRow:indexPath.row];

    } else if (indexPath.section == [self prescriptionsSection]) {
        return [self prescriptionsSectionCellForRow:indexPath.row];

    } else if (indexPath.section == [self followUpSection]) {
        return [self followUpSectionCellForRow:indexPath.row];

    } else if (indexPath.section == [self additionalItemsSection]) {
        return [self additionalItemsSectionCellForRow:indexPath.row];

    } else if (indexPath.section == [self chatSection]) {
        return [self chatSectionCellForRow:indexPath.row];
    }
    return [UITableViewCell new];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == [self transferSection]) {
        return NSLocalizedString(@"visitSummary.transfer", @"Visit Summary Transfer Title");

    } else if (section == [self topicsSection]) {
        return NSLocalizedString(@"visitSummary.topics", @"Visit Summary Topics Title");

    } else if (section == [self triageSection]) {
        return NSLocalizedString(@"visitSummary.triage", @"Visit Summary Triage Title");

    } else if (section == [self providerNotesSection]) {
        return NSLocalizedString(@"visitSummary.notes", @"Visit Summary Notes Title");

    } else if (section == [self diagnosesSection]) {
        return NSLocalizedString(@"visitSummary.diagnoses", @"Visit Summary Diagnoses Title");

    } else if (section == [self proceduresSection]) {
        return NSLocalizedString(@"visitSummary.procedures", @"Visit Summary Procedure Title");

    } else if (section == [self prescriptionsSection]) {
        return NSLocalizedString(@"visitSummary.prescriptions", @"Visit Summary Prescriptions Title");

    } else if (section == [self followUpSection]) {
        return NSLocalizedString(@"visitSummary.followup", @"Visit Summary FollowUp Title");

    } else if (section == [self additionalItemsSection]) {
        return NSLocalizedString(@"visitSummary.additionalItems", @"Visit Summary Additional Items Title");

    } else if (section == [self chatSection]) {
        return NSLocalizedString(@"visitSummary.chat", @"Visit Summary Chat Title");
    }
    return nil;
}

#pragma mark - Getters for Sections
- (NSUInteger)numberOfSections;
{
    // Consumer Provider sections
    return ([self transferSection] >= 0) + ([self topicsSection] >= 0) + ([self triageSection] >= 0) + ([self providerNotesSection] >= 0) + ([self diagnosesSection] >= 0)
        + ([self proceduresSection] >= 0) + ([self prescriptionsSection] >= 0) + ([self followUpSection] >= 0) + ([self additionalItemsSection] >= 0) + ([self chatSection] >= 0);
}

/**
 *  Section getters
 *
 *  @return section integer if applicable, -1 if section is hidden
 */
- (NSInteger)transferSection {
    return (self.summary.transferNote || self.summary.transferredFromProviderName || self.summary.transferredFromProviderSpecialty) ? 0 : -1;
}

- (NSInteger)topicsSection {
    return (self.summary.intake.topics.count || self.summary.consumerSummaryTopics.count) ? 0 + ([self transferSection] >= 0) : -1;
}

- (NSInteger)triageSection {
    return (self.summary.triageQuestions.count) ? 0 + ([self transferSection] >= 0) + ([self topicsSection] >= 0) : -1;
}

- (NSInteger)providerNotesSection {
    if (self.summary.providerNotes) {
        return 0 + ([self transferSection] >= 0) + ([self topicsSection] >= 0) + ([self triageSection] >= 0);
    }
    return -1;
}

- (NSInteger)diagnosesSection {
    if (self.summary.diagnoses.count) {
        return 0 + ([self transferSection] >= 0) + ([self topicsSection] >= 0) + ([self triageSection] >= 0) + ([self providerNotesSection] >= 0);
    }
    return -1;
}

- (NSInteger)proceduresSection {
    if (self.summary.procedures.count) {
        return 0 + ([self transferSection] >= 0) + ([self topicsSection] >= 0) + ([self triageSection] >= 0) + ([self providerNotesSection] >= 0) + ([self diagnosesSection] >= 0);
    }
    return -1;
}

- (NSInteger)prescriptionsSection {
    if (self.summary.prescriptions.count) {
        return 0 + ([self transferSection] >= 0) + ([self topicsSection] >= 0) + ([self triageSection] >= 0) + ([self providerNotesSection] >= 0) + ([self diagnosesSection] >= 0)
            + ([self proceduresSection] >= 0);
    }
    return -1;
}

- (NSInteger)followUpSection {
    if (self.summary.followUpItems.count) {
        return 0 + ([self transferSection] >= 0) + ([self topicsSection] >= 0) + ([self triageSection] >= 0) + ([self providerNotesSection] >= 0) + ([self diagnosesSection] >= 0)
            + ([self proceduresSection] >= 0) + ([self prescriptionsSection] >= 0);
    }
    return -1;
}

- (NSInteger)additionalItemsSection {
    if (self.summary.postVisitFollowUpItems.count) {
        return 0 + ([self transferSection] >= 0) + ([self topicsSection] >= 0) + ([self triageSection] >= 0) + ([self providerNotesSection] >= 0) + ([self diagnosesSection] >= 0)
            + ([self proceduresSection] >= 0) + ([self prescriptionsSection] >= 0) + ([self followUpSection] >= 0);
    }
    return -1;
}

- (NSInteger)chatSection {
    if (self.summary.chatReport) {
        return 0 + ([self transferSection] >= 0) + ([self topicsSection] >= 0) + ([self triageSection] >= 0) + ([self providerNotesSection] >= 0) + ([self diagnosesSection] >= 0)
            + ([self proceduresSection] >= 0) + ([self prescriptionsSection] >= 0) + ([self followUpSection] >= 0) + ([self additionalItemsSection] >= 0);
    }
    return -1;
}

#pragma mark - Transfer Section Getters
- (NSInteger)transferSectionNameRow {
    return 0;
}

- (NSInteger)transferSectionNoteRow {
    return self.summary.transferNote ? 1 : -1;
}

- (NSUInteger)transferSectionNumberOfRows {
    return 1 + ([self transferSectionNoteRow] > 0);
}

- (UITableViewCell *)transferSectionCellForRow:(NSUInteger)row {
    if (row == [self transferSectionNameRow]) {
        SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"basicCell"];
        [cell.headerLabel setText:[NSString stringWithFormat:NSLocalizedString(@"visitSummary.transfer.note", @"Visit Summary Transfer Note Title"),
                                            self.summary.transferredFromProviderName,
                                            self.summary.transferredFromProviderSpecialty]];
        return cell;
    } else if (row == [self transferSectionNoteRow]) {
        SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"subtitleCell"];
        [cell.headerLabel setText:NSLocalizedString(@"visitSummary.transfer.note", @"Visit Summary Transfer Note Title")];
        [cell.detailLabel setText:self.summary.transferNote];
        return cell;
    }
    return nil;
}

#pragma mark - Topics Section
- (NSUInteger)topicsSectionNumberOfRows {
    return self.summary.intake.topics.count;
}

- (UITableViewCell *)topicsSectionCellForRow:(NSUInteger)row {
    SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"subtitleCell"];

    id<AWSDKVisitTopic> topic = (row < self.summary.intake.topics.count ? self.summary.intake.topics[row] : self.summary.consumerSummaryTopics[row - self.summary.intake.topics.count]);

    [cell.headerLabel setText:topic.title];
    [cell.detailLabel setText:topic.topicDescription];

    return cell;
}

#pragma mark - Triage Section
- (NSUInteger)triageSectionNumberOfRows {
    return self.summary.triageQuestions.count;
}

- (UITableViewCell *)triageSectionCellForRow:(NSUInteger)row {
    SubtitleHtmlTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"subtitleHtmlCell"];
    UIColor *foregroundColor = [UIColor toggletxtTealColor];
    UIFont *textFont = [UIFont systemFontOfSize:19.0f weight:UIFontWeightLight];
    NSDictionary *attributes = @{
        NSFontAttributeName : textFont,
        NSKernAttributeName : [NSNull null],
        (id)kCTForegroundColorAttributeName : foregroundColor,
        (id)kTTTBackgroundFillColorAttributeName : (id)[UIColor clearColor].CGColor
    };

    cell.headerLabel.enabledTextCheckingTypes = NSTextCheckingTypeLink;
    cell.headerLabel.lineBreakMode = NSLineBreakByWordWrapping;
    cell.headerLabel.numberOfLines = 0;

    // Sample triage questions with html links that is handled by code below
    // Click <a href="https://www.apple.com">here</a> to go to Apple. Click <a href="https://www.google.com">there</a> to go to Google.
    NSString *htmlString = self.summary.triageQuestions[row];
    if ([htmlString localizedCaseInsensitiveContainsString:HTTP_LINK]) {
        [cell.headerLabel mapHTMLLinksForString:htmlString withAttributes:attributes];
    } else {
        NSAttributedString *triageQuestion = [[NSAttributedString alloc] initWithString:htmlString attributes:attributes];
        cell.headerLabel.text = triageQuestion;
    }

    // Guard against triage answers not coming back with same size as triage questions
    [cell.detailLabel setText:row < self.summary.triageAnswers.count ? self.summary.triageAnswers[row] : @""];
    return cell;
}

#pragma mark - ProviderNotes Section
- (NSUInteger)providerNotesSectionNumberOfRows {
    return 1;
}

- (UITableViewCell *)providerNotesSectionCellForRow:(NSUInteger)row {
    WebviewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"webCell"];

    if (self.webviewHeight == 0.0) {
        [cell.webView loadHTMLString:self.summary.providerNotes baseURL:nil];
    }

    return cell;
}

#pragma mark - Diagnoses Section
- (NSUInteger)diagnosesSectionNumberOfRows {
    return self.summary.diagnoses.count;
}

- (UITableViewCell *)diagnosesSectionCellForRow:(NSUInteger)row {
    SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"subtitleCell"];

    [cell.headerLabel setText:self.summary.diagnoses[row].displayName];
    if (self.summary.diagnoses[row].code) {
        [cell.detailLabel setText:[NSString stringWithFormat:@"%ld", (long)self.summary.diagnoses[row].code]];
    }

    return cell;
}

#pragma mark - Procedures Section
- (NSUInteger)proceduresSectionNumberOfRows {
    return self.summary.procedures.count;
}

- (UITableViewCell *)proceduresSectionCellForRow:(NSUInteger)row {
    SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"subtitleCell"];

    [cell.headerLabel setText:self.summary.procedures[row].displayName];
    if (self.summary.procedures[row].code) {
        [cell.detailLabel setText:[NSString stringWithFormat:@"%ld", (long)self.summary.procedures[row].code]];
    }

    return cell;
}

#pragma mark - Prescriptions Section
- (NSUInteger)prescriptionsSectionNumberOfRows {
    if (self.summary.prescriptions.count) {
        return self.summary.prescriptions.count + 2 * (self.summary.pharmacy != nil) + 2 * (self.summary.pharmacy.isMailOrder && self.summary.shippingAddress);
    }
    return 0;
}

- (UITableViewCell *)prescriptionsSectionCellForRow:(NSUInteger)row {
    // Prescriptions
    if (row < self.summary.prescriptions.count) {
        SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"subtitleCell"];

        [cell.headerLabel setText:self.summary.prescriptions[row].displayName];
        if (self.summary.prescriptions[row].code) {
            [cell.detailLabel setText:[NSString stringWithFormat:@"%ld", (long)self.summary.prescriptions[row].code]];
        }

        return cell;
    } else if (row == self.summary.prescriptions.count) {
        // Pharmacy prompt
        SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"blackBasicCell"];

        [cell.headerLabel setText:NSLocalizedString(@"visitSummary.prescriptions.pharmacy.retail", @"Visit Summary Prescription Pharmacy Retail Title")];

        return cell;
    } else if (row == self.summary.prescriptions.count + 1) {
        // Pharmacy
        PharmacyResultTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"pharmacyCell"];

        [cell handlePharmacy:self.summary.pharmacy];

        return cell;
    } else if (row == self.summary.prescriptions.count + 2) {
        // Mail order prompt
        SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"blackBasicCell"];

        [cell.headerLabel setText:NSLocalizedString(@"visitSummary.prescriptions.pharmacy.mailOrder", @"Visit Summary Prescription Pharmacy Mail Order Title")];

        return cell;
    } else if (row == self.summary.prescriptions.count + 3) {
        // Shipping address
        SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"blackBasicCell"];

        [cell.headerLabel setText:self.summary.shippingAddress.displayString];

        return cell;
    }
    return nil;
}

#pragma mark - FollowUp Section
- (NSUInteger)followUpSectionNumberOfRows {
    return self.summary.followUpItems.count;
}

- (UITableViewCell *)followUpSectionCellForRow:(NSUInteger)row {
    SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"subtitleCell"];

    id<AWSDKFollowUpItem> item = self.summary.followUpItems[row];
    [cell.headerLabel setText:item.itemDescription];
    if (item.frequency && item.duration) {
        [cell.detailLabel setText:[item.frequency stringByAppendingFormat:@", %@", item.duration]];
    } else {
        [cell.detailLabel setText:item.frequency ? item.frequency : item.duration];
    }

    return cell;
}

#pragma mark - Additional Items Section
- (NSUInteger)additionalItemsSectionNumberOfRows {
    return self.summary.postVisitFollowUpItems.count;
}

- (UITableViewCell *)additionalItemsSectionCellForRow:(NSUInteger)row {
    SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"basicCell"];

    [cell.headerLabel setText:self.summary.postVisitFollowUpItems[row].itemDescription];

    return cell;
}
#pragma mark - UIWebviewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [webView.scrollView setScrollEnabled:NO];
    CGRect frame = webView.frame;
    frame.size.height = 1;

    // Force layout
    [webView setFrame:frame];

    self.webviewHeight = webView.scrollView.contentSize.height + 10;

    frame.size.height = self.webviewHeight;

    // Apply new height
    [webView setFrame:frame];

    [self.tableView reloadDataAnimated:YES];
}

#pragma mark - ProviderDetailDelegate
- (void)didSelectSchedule:(id<AWSDKSchedule>)schedule forProvider:(id<AWSDKProvider>)provider forVisitReportSummary:(id<AWSDKVisitReportSummary>)summary {
    if (summary) {
        [self performSegueWithIdentifier:@"scheduleReconnectSegue" sender:@{ @"schedule" : schedule, @"provider" : provider, @"summary" : summary }];
    } else {
        [self performSegueWithIdentifier:@"scheduleSegue" sender:@{ @"schedule" : schedule, @"provider" : provider }];
    }
}

- (void)didSelectDate:(NSDate *)date forProvider:(id<AWSDKProvider>)provider forVisitReportSummary:(id<AWSDKVisitReportSummary>)summary {
    if (summary) {
        [self performSegueWithIdentifier:@"scheduleReconnectSegue" sender:@{ @"date" : date, @"provider" : provider, @"summary" : summary }];
    } else {
        [self performSegueWithIdentifier:@"scheduleSegue" sender:@{ @"date" : date, @"provider" : provider }];
    }
}

#pragma mark - UpdatePhoneNumberDelegate
- (void)phoneNumberDidUpdate {
    // No-op
}

#pragma mark - Chat Items Section
- (NSUInteger)chatSectionNumberOfRows {
    return self.summary.chatReport.chatItems.count;
}

- (UITableViewCell *)chatSectionCellForRow:(NSUInteger)row {
    id<AWSDKChatItem> item = self.summary.chatReport.chatItems[row];

    if (item.messageType.length || !item.user) {
        SubtitleTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"centerItalicCell"];

        [cell.headerLabel setText:item.message];

        return cell;

    } else if ([item.user isEqual:self.summary.consumer] || [item.user isEqual:self.summary.consumerProxy]) {
        ChatItemCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"rightChatCell"];

        [cell.nameLabel setText:item.user.nameComponents.localizedFullName];
        [cell.chatLabel setText:item.message];

        return cell;
    } else {
        ChatItemCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"leftChatCell"];

        [cell.nameLabel setText:item.user.nameComponents.localizedFullName];
        [cell.chatLabel setText:item.message];

        return cell;
    }

    return nil;
}

#pragma mark - Action Methods
- (IBAction)reconnectButtonTapped:(id)sender {
    [self performSegueWithIdentifier:@"providerDetailSegue" sender:@{ @"summary" : self.summary }];
}

#pragma mark - UIPopoverPresentationControllerDelegate
- (UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    // Reduce alpha
    [UIView animateWithDuration:0.3
                     animations:^{
                         [self.view setAlpha:1.0];
                         [self.navigationController.navigationBar setAlpha:1.0];
                     }];

    return YES;
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"pDFSegue"]) {
        // Pass the PDF data to show
        VisitReportPDFViewController *controller = segue.destinationViewController;
        [controller setPDFData:sender];
    } else if ([segue.identifier isEqualToString:@"scheduleReconnectSegue"]) {
        ScheduleReconnectViewController *controller = (ScheduleReconnectViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0];
        id<AWSDKProvider> provider = sender[@"provider"];
        id<AWSDKPractice> practice = provider.practice;
        controller.practice = practice;
        controller.provider = provider;
        controller.openDate = sender[@"date"];
        controller.summary = sender[@"summary"];
    } else if ([segue.identifier isEqualToString:@"providerDetailSegue"]) {
        UIPopoverPresentationController *presentationController = segue.destinationViewController.popoverPresentationController;
        [presentationController setDelegate:self];
        presentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 0, 0);
        presentationController.sourceView = self.view;

        ProviderDetailViewController *providerController = (ProviderDetailViewController *)segue.destinationViewController;
        providerController.preferredContentSize = CGSizeMake(self.view.frame.size.width * 0.95, self.view.frame.size.height * 0.95);
        providerController.isSchedulingAppointment = YES;
        providerController.isSchedulingReconnect = YES;
        providerController.provider = self.summary.assignedProvider;
        providerController.delegate = self;
        providerController.summary = sender[@"summary"];
    }
}

#pragma mark - TTTAttributedLabelDelegate
- (void)attributedLabel:(TTTAttributedLabel *)label didSelectLinkWithURL:(NSURL *)linkURL {
    NSURL *url = (linkURL.scheme.length) ? linkURL : [[NSURL alloc] initWithString:[@"https://" stringByAppendingString:linkURL.absoluteString]];
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        [[UIApplication sharedApplication] openURL:url
                                           options:@{}
                                 completionHandler:^(BOOL success) {
                                     AWSDKLogInfo(@"Opened URL ->%@<", url.absoluteString);
                                 }];
    }
}

#pragma mark - Private Method

- (BOOL)suppressCharge {
    return self.summary.cost.eligibilityRequestError.code == AWSDKErrorCodeTimeout && self.summary.consumer.subscription.healthPlan.suppressCharge;
}

- (BOOL)isSchedulingReconnect {
    return ![self shouldHideReconnectForSummary:self.summary];
}

- (void)hideReconnectForSummary:(id<AWSDKVisitReportSummary>)summary {
    self.reconnectButton.hidden = [self shouldHideReconnectForSummary:summary];
}

- (BOOL)shouldHideReconnectForSummary:(id<AWSDKVisitReportSummary>)summary {
    return !(summary.disposition &
        (AWSDKVisitDispositionConsumerDisconnected |
         AWSDKVisitDispositionConsumerCanceled |
         AWSDKVisitDispositionDeleted |
         AWSDKVisitDispositionProviderResponseTimeout |
         AWSDKVisitDispositionProviderDisconnected |
         AWSDKVisitDispositionProviderCanceled |
         AWSDKVisitDispositionExpired));
}

- (void)hideObscuredItems {
    if (!self.isSchedulingReconnect){
        self.reconnectButton.hidden = YES;
        self.reconnectButtonHeightConstraint.constant = 0;
    }

    if (!self.summary.providerPractice.length) {
        self.practiceLabel.hidden = YES;
        self.practiceLabelHeightConstraint.constant = 0;
    }

    if (!self.providerLabel.text.length) {
        self.providerLabel.hidden = YES;
        self.providerLabelHeightConstraint.constant = 0;
    }

    if (!self.costLabel.text.length) {
        self.costLabel.hidden = YES;
        self.costLabelHeightConstraint.constant = 0;
    }
}

- (void)setupHeaderView
{
    [self setProviderTitle];
    [self setDateTitle];
    [self setPatientTitle];
    [self setPracticeTitle];
    [self setCostTitle];
    [self hideReconnectForSummary:self.summary];

    [self.reconnectButton setTitle:NSLocalizedString(@"visitReportSummary.reconnectButtonTitle", @"Reconnect Visit") forState:UIControlStateNormal];
}

- (void)setProviderTitle
{
    if (self.summary.providerSpecialty) {
        self.providerLabel.text = [NSString stringWithFormat:NSLocalizedString(@"visitSummary.visitWith.titleAndSpecialty", @"Visit Summary Visit with Title and Specialty"), self.summary.providerFullName, self.summary.providerSpecialty.name];
    } else {
        self.providerLabel.text = [NSString stringWithFormat:NSLocalizedString(@"visitSummary.visitWith.noVisitType", @"Visit Summary Visit with Title no Visit Type"), self.summary.providerFullName];
    }
}

- (void)setDateTitle
{
    NSDate *date = self.summary.schedule.startTime ?: (self.summary.schedule.scheduledStartTime ?: (self.summary.schedule.cancelTime ?: nil));
    NSNumber *duration = self.summary.schedule.duration;

    if (date) {
        NSString *dateHeader = [[NSDateFormatter longDateNoTimeZoneFormatter] stringFromDate:date];

        if (duration) {
            NSInteger seconds = [duration intValue] / 1000;

            if (seconds < 60) {
                NSString * durationHeader = [NSString stringWithFormat:NSLocalizedString(@"visitSummary.durationHeader.seconds", @"Visit Summary Duration in Seconds Header"), (long)seconds];
                dateHeader = [dateHeader stringByAppendingFormat:@" | %@", durationHeader];
            } else {
                NSInteger minutes = seconds / 60;
                NSString *durationHeader = nil;

                if (minutes == 1) {
                    durationHeader = [NSString stringWithFormat:NSLocalizedString(@"visitSummary.durationHeader.oneMinute", @"Visit Summary Duration One Minute Header"), (long)minutes];
                } else {
                    durationHeader = [NSString stringWithFormat:NSLocalizedString(@"visitSummary.durationHeader.minutes", @"Visit Summary Duration in Minutes Header"), (long)minutes];
                }

                dateHeader = [dateHeader stringByAppendingFormat:@" | %@", durationHeader];
            }
        }

        self.dateLabel.text = dateHeader;
    } else {
        self.dateLabel.hidden = YES;
        self.dateLabelHeightConstraint.constant = 0.0;
    }
}

- (void)setPatientTitle
{
    id<AWSDKConsumer> consumer = self.summary.consumer;
    NSString *patientInfo = consumer.nameComponents.localizedFullName;

    NSString *biologicalSex = AWSDKSystemConfiguration.sexes[@(consumer.gender)];
    id<AWSDKGenderIdentity> genderIdentity = consumer.genderIdentity;
    if (genderIdentity != nil && genderIdentity.representedBiologicalSex != consumer.gender) {
        patientInfo = [patientInfo stringByAppendingFormat:@" | %@ (%@)", genderIdentity.name, biologicalSex];
    } else {
        patientInfo = [patientInfo stringByAppendingFormat:@" | %@", biologicalSex];
    }

    NSString *ageTitle = NSLocalizedString(@"visitSummary.ageHeader", @"Visit Summary Age Header");
    patientInfo = [patientInfo stringByAppendingString:[NSString stringWithFormat:@" | %@ %@", ageTitle, consumer.age]];

    NSString *date = [NSDateFormatter.shortDateFormatter stringFromDate:consumer.dateOfBirth];
    NSString *dobTitle = NSLocalizedString(@"visitSummary.dobHeader", @"Visit Summary DOB Header");
    patientInfo = [patientInfo stringByAppendingString:[NSString stringWithFormat:@" | %@ %@", dobTitle, date]];

    NSString *patientHeader = [NSString stringWithFormat:@"%@: ", NSLocalizedString(@"visitSummary.patientHeader", @"Visit Summary Patient Header")];
    NSMutableAttributedString *attributedHeader = [[NSMutableAttributedString alloc] initWithString:patientHeader attributes:@{NSFontAttributeName: [UIFont boldSystemFontOfSize:14]}];

    NSAttributedString *attributedInfo = [[NSAttributedString alloc] initWithString:patientInfo];
    [attributedHeader appendAttributedString:attributedInfo];

    self.patientLabel.attributedText = attributedHeader;
}

- (void)setPracticeTitle
{
    NSString *practiceHeader = [NSString stringWithFormat:@"%@: ", NSLocalizedString(@"visitSummary.practiceHeader", @"Visit Summary Practice Header")];
    NSMutableAttributedString *attributedHeader = [[NSMutableAttributedString alloc] initWithString:practiceHeader attributes:@{NSFontAttributeName: [UIFont boldSystemFontOfSize:14]}];

    NSAttributedString *practiceName = [[NSAttributedString alloc] initWithString:self.summary.providerPractice];
    [attributedHeader appendAttributedString: practiceName];

    self.practiceLabel.attributedText = attributedHeader;
}

- (void)setCostTitle
{
    NSNumberFormatter *currencyFormatter = [NSNumberFormatter localizedCurrencyFormatter];
    NSMutableAttributedString *costHeader = [[NSMutableAttributedString alloc] initWithString:NSLocalizedString(@"visitSummary.costHeader", @"Visit Summary Cost Header") attributes:@{NSFontAttributeName: [UIFont boldSystemFontOfSize:14]}];
    [costHeader appendAttributedString:[[NSAttributedString alloc] initWithString:@" "]];

    // Cost was waived
    if (self.summary.cost.totalCostWaived) {
        [self.costLabel setText:NSLocalizedString(@"visitSummary.cost.waived", @"Visit Summary Cost Waived Title")];
        // Coupon was applied
    } else if (self.summary.cost.couponCode && !self.summary.cost.isFree && self.summary.paymentAmount) {
        NSString *paymentAmount = [currencyFormatter stringFromNumber:[NSNumber numberWithFloat:self.summary.paymentAmount]];
        NSString *couponTitle = [NSString stringWithFormat:NSLocalizedString(@"visitSummary.cost.coupon", @"Visit Summary Cost Coupon Title"), paymentAmount, self.summary.cost.couponCode, self.summary.paymentType];
        [costHeader appendAttributedString:[[NSAttributedString alloc] initWithString:couponTitle]];
        self.costLabel.attributedText = costHeader;
        // Is deferred billing and no payment applied?
    } else if (self.summary.cost.isBillingDeferred && self.summary.paymentAmount == 0.00) {
        [self.costLabel setText:self.summary.cost.deferredBillingWrapUpText];
        // Visit was free
    } else if (self.summary.cost.isFree || self.summary.paymentAmount == 0.00) {
        [self.costLabel setText:NSLocalizedString(@"visitSummary.cost.free", @"Visit Summary Cost Free Title")];
        // Visit has a cost without a coupon
    } else {
        NSString *paymentAmount = [currencyFormatter stringFromNumber:[NSNumber numberWithFloat:self.summary.paymentAmount]];

        NSString *paymentMessage = self.suppressCharge
            ? [NSString stringWithFormat:NSLocalizedString(@"visitReports.cost.suppressPayment", @"Max payment without insurance"), paymentAmount]
            : [NSString stringWithFormat:NSLocalizedString(@"visitSummary.cost.noCoupon", @"Visit Summary No Coupon Title"), paymentAmount, self.summary.paymentType];

        [costHeader appendAttributedString:[[NSAttributedString alloc] initWithString:paymentMessage]];

        self.costLabel.attributedText = costHeader;
    }
}

@end
