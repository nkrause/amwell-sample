//
//  VisitReportSummaryViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 9/12/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKVisitReportSummary;

@interface VisitReportSummaryViewController : UITableViewController

@property (weak, nonatomic) IBOutlet UILabel *practiceLabel;
@property (weak, nonatomic) IBOutlet UILabel *providerLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;

@property (nonatomic) id<AWSDKVisitReportSummary> summary;

@end
