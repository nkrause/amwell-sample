//
//  VisitReportPDFViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 4/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "VisitReportPDFViewController.h"

/**
 *  VisitReportPDFViewController loads PDF as NSData set by VisitReportSummaryViewController
 */
@implementation VisitReportPDFViewController

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Load into webView
    [self.webView loadData:self.pDFData MIMEType:@"application/pdf" textEncodingName:@"UTF-8" baseURL:[[NSURL alloc] initWithString:@""]];
}

@end
