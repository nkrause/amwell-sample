//
//  VisitReportsController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 4/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "VisitReportsController.h"

#import "NSDateFormatter+CommonFormats.h"
#import "ProviderDetailViewController.h"
#import "ScheduleReconnectViewController.h"
#import "UITableView+Sample.h"
#import "VisitReportSummaryViewController.h"
#import "VisitSummaryTableViewCell.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKPractice.h>
#import <AWSDK/AWSDKProvider.h>
#import <AWSDK/AWSDKVisitReport.h>
#import <AWSDK/AWSDKVisitReportSummary.h>


typedef void (^GenericCompletionBlock)(BOOL success, NSError *_Nullable error);

/**
 *  VisitReportsController displays multiple previous reports in a tableView to be selected and
 *  displayed by VisitReportViewController
 */
@interface VisitReportsController () <UIPopoverPresentationControllerDelegate, ProviderDetailDelegate, UpdatePhoneNumberDelegate>

/**
 *  Set by fetchVisitSummaries
 */
@property (nonatomic) NSArray<id<AWSDKVisitReport>> *completedReports;
@property (nonatomic) NSArray<id<AWSDKVisitReport>> *expiredReports;
@property (nonatomic) NSArray<id<AWSDKVisitReport>> *deletedReports;

@property (nonatomic) NSDateFormatter *dateFormatter;
@property (nonatomic) IBOutlet UISegmentedControl *segmentedControl;
@property (nonatomic) NSMutableDictionary *reconnectCache;

@end


@implementation VisitReportsController

#pragma mark AWSDK Method Calls
/**
 *  Fetches an array of AWSDKVisitSummaryReports
 */
- (void)fetchVisitSummaries {
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD showLoadingOn:self.navigationController.view];

    [[[ConsumerService sharedInstance] consumer] fetchVisitReportsSinceDate:nil
                                                              completedOnly:NO
                                                              scheduledOnly:NO
                                                                 completion:^(NSArray<id<AWSDKVisitReport>> *results, NSError *error) {
                                                                     [MBProgressHUD hideHUDForView:self.navigationController.view];

                                                                     if (results) {
                                                                         weakSelf.completedReports = [self filterReports:results disposition:AWSDKVisitDispositionCompleted];
                                                                         weakSelf.completedReports = [self reverseSortReports:weakSelf.completedReports];

                                                                         weakSelf.expiredReports = [self filterReports:results disposition:AWSDKVisitDispositionExpired];
                                                                         weakSelf.expiredReports = [self reverseSortReports:weakSelf.expiredReports];

                                                                         weakSelf.deletedReports = [self filterReports:results disposition:AWSDKVisitDispositionDeleted];
                                                                         weakSelf.deletedReports = [self reverseSortReports:weakSelf.deletedReports];

                                                                         [weakSelf.tableView reloadDataAnimated:YES];
                                                                     } else {
                                                                         // Error handling
                                                                         [weakSelf presentAlertWithError:error okHandler:nil];
                                                                     }
                                                                 }];
}

/**
 *  Fetches a report as a AWSDKVisitReportSummary object containing all the details
 */
- (void)fetchReportSummaryForReport:(id<AWSDKVisitReport>)report forReconnect:(BOOL)isReconnect {
    [MBProgressHUD showLoadingOn:self.navigationController.view];
    [report fetchReportSummary:^(id<AWSDKVisitReportSummary> summary, NSError *error) {
        [MBProgressHUD hideHUDForView:self.navigationController.view];
        if (error) {
            [self presentAlertWithError:error okHandler:nil];
        } else if (summary) {
            NSString *segueIdentifier = isReconnect ? @"providerDetailSegue" : @"reportSegue";
            [self performSegueWithIdentifier:segueIdentifier sender:@{@"summary" : summary}];
        }
    }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 70;
    self.dateFormatter = [NSDateFormatter new];
    self.dateFormatter.dateStyle = NSDateFormatterShortStyle;
    self.dateFormatter.timeStyle = NSDateFormatterLongStyle;

    [self setTitle:NSLocalizedString(@"visitReports.title", @"Visit Report Title")];

    [self fetchVisitSummaries];
    self.reconnectCache = [NSMutableDictionary new];
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return (self.segmentedControl.selectedSegmentIndex > 0 || self.totalReports == 0) ? 1 : 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSArray<id<AWSDKVisitReport>> *reportArray
        = (self.segmentedControl.selectedSegmentIndex) ? [self reportsForSegmentIndex:self.segmentedControl.selectedSegmentIndex] : [self reportsForSegmentIndex:section + 1];
    return (self.totalReports == 0 || reportArray.count == 0) ? 1 : reportArray.count;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return (self.segmentedControl.selectedSegmentIndex > 0 || self.totalReports == 0) ? nil : [self.segmentedControl titleForSegmentAtIndex:section + 1];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.totalReports == 0) {
        UITableViewCell *cell = [[UITableViewCell alloc] initWithFrame:CGRectZero];
        cell.textLabel.text = NSLocalizedString(@"visitSummary.noVisits.message", @"Visit Report None Message");
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.backgroundColor = [UIColor clearColor];
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        return cell;
    } else {
        NSArray<id<AWSDKVisitReport>> *reportArray
            = (self.segmentedControl.selectedSegmentIndex) ? [self reportsForSegmentIndex:self.segmentedControl.selectedSegmentIndex] : [self reportsForSegmentIndex:indexPath.section + 1];
        if (reportArray.count > 0) {
            id<AWSDKVisitReport> report = reportArray[indexPath.row];
            VisitSummaryTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            cell.dateLabel.text = [self labelStringFor:report];
            cell.providerLabel.text = report.providerName;
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.userInteractionEnabled = YES;
            cell.reconnectButton.hidden = YES;
            [self shouldHideReconnectForReport:report indexPath:indexPath completion:^(BOOL shouldHide, NSError *error) {
                cell.reconnectButton.hidden = shouldHide;
            }];
            return cell;
        } else {
            UITableViewCell *cell = [[UITableViewCell alloc] initWithFrame:CGRectZero];
            cell.textLabel.text = NSLocalizedString(@"misc.none", @"Visit Report None Title");
            cell.accessoryType = UITableViewCellAccessoryNone;
            cell.userInteractionEnabled = NO;
            return cell;
        }
    }
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    id<AWSDKVisitReport> report;
    NSArray<id<AWSDKVisitReport>> *reportArray = (self.segmentedControl.selectedSegmentIndex) ? [self reportsForSegmentIndex:self.segmentedControl.selectedSegmentIndex] : [self reportsForSegmentIndex:indexPath.section + 1];
    report = reportArray[indexPath.row];
    AWSDKLogInfo(@"Selected visit report with %@ on %@", report.providerName, report.visitDate);
    if (reportArray.count > 0) {
        [self fetchReportSummaryForReport:report forReconnect:NO];
    }
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"Row tapped : %ld", (long)indexPath.row);
    NSArray<id<AWSDKVisitReport>> *reportArray = (self.segmentedControl.selectedSegmentIndex) ? [self reportsForSegmentIndex:self.segmentedControl.selectedSegmentIndex] : [self reportsForSegmentIndex:indexPath.section + 1];
    id<AWSDKVisitReport> report = reportArray[indexPath.row];
    AWSDKLogInfo(@"Selected visit report with %@ on %@", report.providerName, report.visitDate);
    if (reportArray.count > 0) {
        [self fetchReportSummaryForReport:report forReconnect:YES];
    }
}

#pragma mark - UIPopoverPresentationControllerDelegate
- (UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    // Reduce alpha
    [UIView animateWithDuration:0.3
                     animations:^{
                         [self.view setAlpha:1.0];
                         [self.navigationController.navigationBar setAlpha:1.0];
                     }];

    return YES;
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"reportSegue"]) {
        // Sets report for which report summary
        [(VisitReportSummaryViewController *)segue.destinationViewController setSummary:sender[@"summary"]];
    } else if ([segue.identifier isEqualToString:@"providerDetailSegue"]) {
        id<AWSDKVisitReportSummary> summary = sender[@"summary"];
        UIPopoverPresentationController *presentationController = segue.destinationViewController.popoverPresentationController;
        [presentationController setDelegate:self];
        presentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 0, 0);
        presentationController.sourceView = self.view;

        ProviderDetailViewController *providerController = (ProviderDetailViewController *)segue.destinationViewController;
        providerController.preferredContentSize = CGSizeMake(self.view.frame.size.width * 0.95, self.view.frame.size.height * 0.95);
        providerController.isSchedulingAppointment = YES;
        providerController.isSchedulingReconnect = YES;
        providerController.provider = summary.assignedProvider;
        providerController.delegate = self;
        providerController.summary = summary;
    } else if ([segue.identifier isEqualToString:@"scheduleReconnectSegue"]) {
        ScheduleReconnectViewController *controller = (ScheduleReconnectViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0];
        id<AWSDKProvider> provider = sender[@"provider"];
        id<AWSDKPractice> practice = provider.practice;
        controller.practice = practice;
        controller.provider = provider;
        controller.openDate = sender[@"date"];
        controller.summary = sender[@"summary"];
    }
}

#pragma mark - UISegmentedControl Delegate
- (IBAction)segmentedControlValueChanged:(UISegmentedControl *)control {
    [self.tableView reloadData];
}

#pragma mark - ProviderDetailDelegate
- (void)didSelectSchedule:(id<AWSDKSchedule>)schedule forProvider:(id<AWSDKProvider>)provider forVisitReportSummary:(id<AWSDKVisitReportSummary>)summary {
    if (summary) {
        [self performSegueWithIdentifier:@"scheduleReconnectSegue" sender:@{ @"schedule" : schedule, @"provider" : provider, @"summary" : summary }];
    } else {
        [self performSegueWithIdentifier:@"scheduleSegue" sender:@{ @"schedule" : schedule, @"provider" : provider }];
    }
}

- (void)didSelectDate:(NSDate *)date forProvider:(id<AWSDKProvider>)provider forVisitReportSummary:(id<AWSDKVisitReportSummary>)summary {
    if (summary) {
        [self performSegueWithIdentifier:@"scheduleReconnectSegue" sender:@{ @"date" : date, @"provider" : provider, @"summary" : summary }];
    } else {
        [self performSegueWithIdentifier:@"scheduleSegue" sender:@{ @"date" : date, @"provider" : provider }];
    }
}

#pragma mark - UpdatePhoneNumberDelegate
- (void)phoneNumberDidUpdate {
    // No-op
}

#pragma mark - Action Methods
- (IBAction)reconnectButtonTapped:(id)sender event:(id)event {
    NSSet *touches = [event allTouches];
    UITouch *touch = [touches anyObject];
    CGPoint currentTouchPosition = [touch locationInView:self.tableView];
    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:currentTouchPosition];
    if (indexPath) {
        [self tableView:self.tableView accessoryButtonTappedForRowWithIndexPath:indexPath];
    }
}

#pragma mark - Private Methods
- (NSArray<id<AWSDKVisitReport>> *)reportsForSegmentIndex:(NSInteger)index {
    switch (index) {
        case 0:
            return [[self.completedReports arrayByAddingObjectsFromArray:self.expiredReports] arrayByAddingObjectsFromArray:self.deletedReports];
        case 1:
            // Completed
            return self.completedReports;
        case 2:
            // Missed
            return self.expiredReports;
        case 3:
            // Cancelled
            return self.deletedReports;
        default:
            // Unexpected
            return @[];
    }
}

- (NSInteger)totalReports {
    return [self reportsForSegmentIndex:0].count;
}

- (NSString *)labelStringFor:(id<AWSDKVisitReport>)visitReport {
    NSDate *displayDate = [self displayDateFor:visitReport];
    if (displayDate) {
        if (visitReport.disposition == AWSDKVisitDispositionDeleted) {
            return [[self.dateFormatter stringFromDate:displayDate] stringByAppendingString:[NSString stringWithFormat:@" (%@)", NSLocalizedString(@"Cancelled", @"Cancelled visit")]];
        } else {
            return [self.dateFormatter stringFromDate:displayDate];
        }
    } else {
        return NSLocalizedString(@"Cancelled", @"Cancelled visit");
    }
}

- (NSDate *)displayDateFor:(id<AWSDKVisitReport>)visitReport {
    if (visitReport.disposition == AWSDKVisitDispositionCompleted) {
        return visitReport.visitDate;
    } else if (visitReport.disposition == AWSDKVisitDispositionExpired) {
        return visitReport.schedule.scheduledStartTime;
    } else if (visitReport.disposition == AWSDKVisitDispositionDeleted) {
        return visitReport.schedule.cancelTime;
    }
    return visitReport.visitDate;
}

- (NSArray<id<AWSDKVisitReport>> *)reverseSortReports:(NSArray<id<AWSDKVisitReport>> *)reports {
    __weak typeof(self) weakSelf = self;
    return [[[reports sortedArrayUsingComparator:^NSComparisonResult(id<AWSDKVisitReport> report1, id<AWSDKVisitReport> report2) {
        NSDate *date1ToCompare = [weakSelf displayDateFor:report1];
        NSDate *date2ToCompare = [weakSelf displayDateFor:report2];
        return [date1ToCompare compare:date2ToCompare];
    }] reverseObjectEnumerator] allObjects];
}

- (NSArray<id<AWSDKVisitReport>> *)filterReports:(NSArray<id<AWSDKVisitReport>> *)reports disposition:(AWSDKVisitDisposition)disposition {
    return [reports filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(id<AWSDKVisitReport> _Nullable evaluatedObject, NSDictionary<NSString *, id> *bindings) {
        return evaluatedObject.disposition == disposition;
    }]];
}

#pragma mark - Private Method

- (void)shouldHideReconnectForReport:(id<AWSDKVisitReport>)report indexPath:(NSIndexPath *)indexPath completion:(GenericCompletionBlock)completion {
    __block NSString *reportKey = [self keyForReport:report];
    if (self.reconnectCache[reportKey]) {
        BOOL shouldHide = [self.reconnectCache[reportKey] boolValue];
        if (completion) {
            completion(shouldHide, nil);
        }
    } else {
        [MBProgressHUD showLoadingOn:self.navigationController.view];
        [report fetchReportSummary:^(id<AWSDKVisitReportSummary> summary, NSError *error) {
            [MBProgressHUD hideHUDForView:self.navigationController.view];
            if (error) {
                [self presentAlertWithError:error okHandler:nil];
            } else if (summary) {
                BOOL shouldHide = [self shouldHideReconnectForSummary:summary];
                self.reconnectCache[reportKey] = [NSNumber numberWithBool:shouldHide];
                if (completion) {
                    completion(shouldHide, nil);
                }
            }
        }];
    }
}

- (BOOL)shouldHideReconnectForSummary:(id<AWSDKVisitReportSummary>)summary {
    return !(summary.disposition &
        (AWSDKVisitDispositionConsumerDisconnected |
         AWSDKVisitDispositionConsumerCanceled |
         AWSDKVisitDispositionDeleted |
         AWSDKVisitDispositionProviderResponseTimeout |
         AWSDKVisitDispositionProviderDisconnected |
         AWSDKVisitDispositionProviderCanceled |
         AWSDKVisitDispositionExpired));
}

- (NSString *)keyForReport:(id<AWSDKVisitReport>)report {
    NSString *key = [NSString stringWithFormat:@"%@.%@.%ld", [self labelStringFor:report], report.providerName, report.disposition];
    return key;
}

@end
