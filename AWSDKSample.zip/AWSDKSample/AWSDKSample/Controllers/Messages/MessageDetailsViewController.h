//
//  MessageDetailsViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/9/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

// clang-format off
@protocol AWSDKInboxMessageDetails, AWSDKSentMessageDetails;
// clang-format on

// View Controller to display message details
@interface MessageDetailsViewController : UIViewController

- (void)clearMessage;

// Updates UI to deal with either Inbox or Sent messages
- (void)loadInboxMessage:(id<AWSDKInboxMessageDetails>)message;
- (void)loadSentMessage:(id<AWSDKSentMessageDetails>)message;

@property (weak, nonatomic) IBOutlet UIView *noMessageView;
@property (weak, nonatomic) IBOutlet UILabel *noMessageLabel;

@property (weak, nonatomic) IBOutlet UIScrollView *messageView;
@property (weak, nonatomic) IBOutlet UILabel *fromLabel;
@property (weak, nonatomic) IBOutlet UILabel *toLabel;
@property (weak, nonatomic) IBOutlet UILabel *subjectLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *topicLabel;
@property (weak, nonatomic) IBOutlet UIWebView *contentView;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *deleteButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *replyButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *attachmentButton;

- (IBAction)deleteTapped:(id)sender;
- (IBAction)replyTapped:(id)sender;
- (IBAction)composeTapped:(id)sender;
- (IBAction)attachmentTapped:(id)sender;

@end
