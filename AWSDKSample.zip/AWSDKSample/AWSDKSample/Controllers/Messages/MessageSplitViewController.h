//
//  MessageSplitViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/9/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKConsumer;

/**
 Split view controller for message flow
 */
@interface MessageSplitViewController : UISplitViewController <UISplitViewControllerDelegate>

@end
