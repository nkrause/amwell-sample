//
//  MessageAttachmentsViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/29/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MessageAttachmentsViewController.h"

#import "AttachmentViewController.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKAttachment.h>
#import <AWSDK/AWSDKMessageDraft.h>

/**
 *  MessageAttachmentsViewController shows a list of attachments
 */
@implementation MessageAttachmentsViewController

- (void)clearDraftAttachment {
    [self.draft clearAttachment];
    [self.addButton setEnabled:YES];
    [self.tableView reloadDataAnimated:YES];
}

- (void)addDraftAttachmentData:(NSData *)data withFilename:(NSString *)filename withType:(NSString *)type {
    __block MessageAttachmentsViewController *weakSelf = self;

    // Adds the data with the JPEG mime type to the message draft
    [self.draft addAttachmentData:data
                     withMimeType:type
                     withFilename:filename
                       completion:^(BOOL success, NSError *error) {
                           [weakSelf dismissViewControllerAnimated:YES completion:nil];
                           if (error) {
                               // Handle error
                               [weakSelf presentAlertWithError:error okHandler:nil];
                           } else {
                               [weakSelf.addButton setEnabled:NO];
                               [weakSelf.tableView reloadDataAnimated:YES];
                           }
                       }];
}

//-----------------------------------------------------------------------------------------------------//
//----------------------Everything here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    if (self.draft) {
        self.sourceAttachments = self.draft.sourceAttachments;
        [self.addButton setEnabled:!self.draft.draftAttachment];
    } else {
        self.navigationItem.rightBarButtonItem = nil;
    }

    [self setTitle:NSLocalizedString(@"attachments.title", @"Message Attachments Title")];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.draft && section == 0 ? 1 : self.sourceAttachments.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return (self.draft != nil) + (self.sourceAttachments.count > 0);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];

    if (self.draft && indexPath.section == 0) {
        [cell.textLabel setText:self.draft.draftAttachment ? self.draft.draftAttachment.name : NSLocalizedString(@"misc.none", @"Message Attachments Draft Attachment Name")];
    } else {
        [cell.textLabel setText:self.sourceAttachments[indexPath.row].name];
    }
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return self.draft.draftAttachment && indexPath.section == 0;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (UITableViewCellEditingStyleDelete) {
        [self clearDraftAttachment];
    }
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return (self.draft.draftAttachment && indexPath.section == 0 ? UITableViewCellEditingStyleDelete : UITableViewCellEditingStyleNone);
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (!self.draft) {
        return nil;
    } else if (section == 0) {
        return NSLocalizedString(@"attachments.draft", @"Message Attachments Attachment Draft");
    } else {
        return NSLocalizedString(@"attachments.source", @"Message Attachments Attachment Source");
    }
    return nil;
}
#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    id<AWSDKAttachment> attachment;
    if (self.draft.draftAttachment && indexPath.section == 0) {
        attachment = self.draft.draftAttachment;
    } else if (indexPath.section == (self.draft != nil) && self.sourceAttachments.count) {
        attachment = self.sourceAttachments[indexPath.row];
    }

    if (attachment) {
        AWSDKLogInfo(@"Attachment named %@ tapped", attachment.name);
        [self performSegueWithIdentifier:@"showAttachment" sender:attachment];
    } else {
        AWSDKLogInfo(@"Empty attachment cell tapped");
    }
}

#pragma mark - UIImagePickerControllerDelegate
// Method called when consumer selects or takes a photo to use as the message attachment
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *, id> *)info {
    UIImage *selectedImage = [info objectForKey:UIImagePickerControllerEditedImage];

    if (!selectedImage) {
        selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    }

    // Retrieves the image as a JPEG representation of NSData
    NSData *data = UIImageJPEGRepresentation(selectedImage, 1.0);

    NSURL *imagePath = [info objectForKey:@"UIImagePickerControllerReferenceURL"];

    NSString *imageName = imagePath ? [imagePath lastPathComponent] : @"image";

    NSString *type;

    uint8_t c;
    [data getBytes:&c length:1];

    switch (c) {
        case 0xFF:
            type = @"image/jpeg";
            break;
        case 0x89:
            type = @"image/png";
            break;
        case 0x47:
            type = @"image/gif";
            break;
        case 0x49:
        case 0x4D:
            type = @"image/tiff";
            break;
    }
    if (type) {
        [self addDraftAttachmentData:data withFilename:imageName withType:type];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - IBAction
- (IBAction)addTapped:(id)sender {
    AWSDKLogInfo(@"Add attatchment button tapped");
    UIAlertController *photoAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"message.compose.addMedia.title", @"Message Attachments Compose Media Title")
                                                                        message:NSLocalizedString(@"message.compose.addMedia.message", @"Message Attachments Compose Media Message")
                                                                 preferredStyle:UIAlertControllerStyleActionSheet];

    __block MessageAttachmentsViewController *weakSelf = self;

    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        [photoAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"message.compose.addMedia.camera", @"Message Attachments Compose Media Camera")
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction *_Nonnull action) {
                                                         AWSDKLogInfo(@"Add attachment from camera selected");
                                                         UIImagePickerController *image = [[UIImagePickerController alloc] init];

                                                         [image setDelegate:weakSelf];

                                                         [image setSourceType:UIImagePickerControllerSourceTypeCamera];

                                                         [self presentViewController:image animated:YES completion:nil];
                                                     }]];
    }

    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        [photoAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"message.compose.addMedia.photo", @"Message Attachments Compose Media Photo")
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction *_Nonnull action) {
                                                         AWSDKLogInfo(@"Add attachment from library selected");
                                                         UIImagePickerController *image = [[UIImagePickerController alloc] init];

                                                         [image setDelegate:weakSelf];

                                                         [image setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];

                                                         [self presentViewController:image animated:YES completion:nil];
                                                     }]];
    }

    [photoAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.cancel", @"Message Attachments Compose Media Cancel")
                                                   style:UIAlertActionStyleCancel
                                                 handler:^(UIAlertAction *_Nonnull action) {
                                                     AWSDKLogInfo(@"Add attachment cancelled");
                                                 }]];

    [photoAlert.popoverPresentationController setBarButtonItem:self.addButton];

    [self presentViewController:photoAlert animated:YES completion:nil];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showAttachment"]) {
        [(AttachmentViewController *)segue.destinationViewController setAttachment:sender];
    }
}

@end
