//
//  SentTableViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "SentTableViewController.h"

#import "ComposeMessageViewController.h"
#import "MessageDetailsViewController.h"
#import "RefreshControl.h"
#import "SentTableViewCell.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKMessageDraft.h>
#import <AWSDK/AWSDKMessageFolderSent.h>
#import <AWSDK/AWSDKSentMessage.h>

/**
 *  Displays current sent messages
 */
@implementation SentTableViewController

#pragma mark - AWSDKMethod Calls

/**
 *   Method fetches any new messages received since the message folder's
 *  lastUpdated time and reloads the table in the completion block
 */
- (void)fetchSentMessages {
    [MBProgressHUD showLoadingOn:self.view];
    [self.sent fetchNewMessagesWithCompletion:^(id result, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        [self.tableView reloadDataAnimated:YES];
    }];
}

/**
 *  Fetches SentMessage details for a SentMessage and shows them
 */
- (void)fetchMessageDetails:(id<AWSDKSentMessage>)message {
    // When a consumer selects a message load the message details object
    [MBProgressHUD showLoadingOn:self.view];
    [message fetchMessageWithCompletion:^(id result, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (error) {
            // Handle error
            [self presentAlertWithError:error okHandler:nil];
        } else {
            // Once the message has loaded show the details controller
            [self performSegueWithIdentifier:@"showDetails" sender:result];
        }
    }];
}

/**
 *  Deletes a sentMessage at an indexPath and updates the tableView
 */
- (void)deleteMessageAtIndexPath:(NSIndexPath *)indexPath {
    id<AWSDKSentMessage> message = (id<AWSDKSentMessage>)[self.sent.messages objectAtIndex:indexPath.row];
    [MBProgressHUD showLoadingOn:self.view];
    [message deleteMessageWithCompletion:^(BOOL success, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (success) {
            [self.tableView beginUpdates];
            [self.tableView deleteRowsAtIndexPaths:@[ indexPath ] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
        }
    }];
}

/**
 *  Creates a messageDraft and presents the compose
 */
- (void)createMessageDraft {
    // Creates new message draft for the consumer and shows the compose message controller
    [AWSDKMessageDraft createMessageDraftFromConsumer:[[ConsumerService sharedInstance] consumer]
                                           completion:^(id result, NSError *error) {
                                               if (error) {
                                                   // Error handling
                                                   [self presentAlertWithError:error okHandler:nil];
                                               } else {
                                                   [self performSegueWithIdentifier:@"composeSegue" sender:result];
                                               }
                                           }];
}

/**
 *  Refreshes the table with sent messages
 */
- (void)refresh {
    // Refreshes the message folder and reloads the table
    [self.sent fetchNewMessagesWithCompletion:^(id result, NSError *error) {
        [self.refreshControl endRefreshing];
        [self.tableView reloadDataAnimated:YES];
    }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    [self.tableView setRowHeight:UITableViewAutomaticDimension];
    [self.tableView setEstimatedRowHeight:133.0];

    self.refreshControl = [[RefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(refresh) forControlEvents:UIControlEventValueChanged];
    [self.tableView addSubview:self.refreshControl];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    [self fetchSentMessages];

    // Adds notification observer to see when a message has been deleted and refresh the folder
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refresh) name:@"sentMessageDeleted" object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] removeObserver:self];

    [super viewWillDisappear:animated];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [(RefreshControl *)self.refreshControl scrollViewDidScroll:scrollView];
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    id<AWSDKMessage> message = self.sent.messages[indexPath.row];
    AWSDKLogInfo(@"Message from %@ sent %@ with subject %@ tapped", message.senderName, message.sent, message.subject);

    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    [self fetchMessageDetails:(id<AWSDKSentMessage>)[self.sent.messages objectAtIndex:indexPath.row]];
}

// Create edit actions for rows
- (NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath {
    id<AWSDKMessage> message = self.sent.messages[indexPath.row];
    AWSDKLogInfo(@"Message from %@ sent %@ with subject %@ swiped to display 'Delete' action.", message.senderName, message.sent, message.subject);

    NSArray *ret = @[];

    UITableViewRowAction *delete = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDestructive
                                                                      title:NSLocalizedString(@"message.delete", @"Sent Message Delete")
                                                                    handler:^(UITableViewRowAction *_Nonnull action, NSIndexPath *_Nonnull indexPath) {
                                                                        // Deletes the message and reloads the cell
                                                                        [self deleteMessageAtIndexPath:indexPath];
                                                                    }];
    ret = [ret arrayByAddingObject:delete];

    return ret;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.sent.messages.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"sentCell"];

    // Configures cell to display the current message
    [cell handleMessage:(id<AWSDKSentMessage>)self.sent.messages[indexPath.row]];

    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

#pragma mark - IBAction
- (IBAction)composeTapped:(id)sender {
    AWSDKLogInfo(@"Compose tapped");
    [self createMessageDraft];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showDetails"]) {
        [(MessageDetailsViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0] loadSentMessage:sender];
    }
    if ([segue.identifier isEqualToString:@"composeSegue"]) {
        [(ComposeMessageViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0] setDraft:sender];
    }
}

@end
