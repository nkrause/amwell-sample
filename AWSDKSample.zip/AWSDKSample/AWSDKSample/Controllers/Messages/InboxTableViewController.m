//
//  InboxTableViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "InboxTableViewController.h"

#import "ComposeMessageViewController.h"
#import "InboxTableViewCell.h"
#import "MessageDetailsViewController.h"
#import "RefreshControl.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKInboxMessageDetails.h>
#import <AWSDK/AWSDKMessageDraft.h>
#import <AWSDK/AWSDKMessageFolderInbox.h>

/**
 *  Displays messages in the current Inbox
 */
@implementation InboxTableViewController

#pragma mark - AWSDKMethod Calls
/**
 * Method fetches any new messages received since the message folder's lastUpdated time and
 * reloads the table in the completion block
 */
- (void)fetchNewMessages {
    [MBProgressHUD showLoadingOn:self.view];
    [self.inbox fetchNewMessagesWithCompletion:^(id result, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        [self.tableView reloadDataAnimated:YES];
    }];
}

- (void)showMessageDetails:(id<AWSDKMessage>)message atIndexPath:(NSIndexPath *)indexPath {
    // When a consumer selects a message load the message details object
    if (![self.refreshControl isRefreshing]) {
        [MBProgressHUD showLoadingOn:self.view];
    }
    [message fetchMessageWithCompletion:^(id result, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (error) {
            // Handle error
            [self presentAlertWithError:error okHandler:nil];
        } else {
            // Once the message has loaded show the details controller and mark the message as read. If the message is already read this will do nothing
            [result markMessageRead:^(BOOL success, NSError *error) {
                if (success) {
                    // Reload the cell to get the new state of the message
                    [self.tableView reloadRowsAtIndexPaths:@[ indexPath ] withRowAnimation:UITableViewRowAnimationNone];
                }
            }];
            [self performSegueWithIdentifier:@"showDetails" sender:result];
        }
    }];
}

- (void)deleteMessage:(id<AWSDKMessage>)message atIndexPath:(NSIndexPath *)indexPath {
    [MBProgressHUD showDeletingOn:self.view];
    [message deleteMessageWithCompletion:^(BOOL success, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (success) {
            [self.tableView beginUpdates];
            [self.tableView deleteRowsAtIndexPaths:@[ indexPath ] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
        }
    }];
}

- (void)markMessageRead:(id<AWSDKInboxMessage>)message atIndexPath:(NSIndexPath *)indexPath {
    [MBProgressHUD showUpdatingOn:self.view];
    [message markMessageRead:^(BOOL success, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (success) {
            [self.tableView reloadRowsAtIndexPaths:@[ indexPath ] withRowAnimation:UITableViewRowAnimationNone];
        }
    }];
}

- (void)refresh {
    // Refreshes the inbox folder and reloads the table
    [self.inbox fetchNewMessagesWithCompletion:^(id result, NSError *error) {
        [self.refreshControl endRefreshing];
        [self.tableView reloadDataAnimated:YES];
    }];
}

- (void)createMessageDraft {
    __weak typeof(self) weakSelf = self;
    // Creates new message draft for the consumer and shows the compose message controller
    [AWSDKMessageDraft createMessageDraftFromConsumer:[[ConsumerService sharedInstance] consumer]
                                           completion:^(id result, NSError *error) {
                                               if (error) {
                                                   // Error handling here
                                               } else {
                                                   [weakSelf performSegueWithIdentifier:@"composeSegue" sender:result];
                                               }
                                           }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    [self.tableView setRowHeight:UITableViewAutomaticDimension];
    [self.tableView setEstimatedRowHeight:133.0];

    self.refreshControl = [[RefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(refresh) forControlEvents:UIControlEventValueChanged];
    [self.tableView addSubview:self.refreshControl];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    [self fetchNewMessages];

    // Adds notification observer to see when a message has been deleted and refresh the folder
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refresh) name:@"inboxMessageDeleted" object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] removeObserver:self];

    [super viewWillDisappear:animated];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [(RefreshControl *)self.refreshControl scrollViewDidScroll:scrollView];
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    id<AWSDKMessage> message = self.inbox.messages[indexPath.row];
    AWSDKLogInfo(@"Message from %@ sent %@ with subject %@ tapped", message.senderName, message.sent, message.subject);
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    [self showMessageDetails:[self.inbox.messages objectAtIndex:indexPath.row] atIndexPath:indexPath];
}

// Create edit actions for rows
- (NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath {
    id<AWSDKInboxMessage> message = (id<AWSDKInboxMessage>)[self.inbox.messages objectAtIndex:indexPath.row];
    AWSDKLogInfo(@"Message from %@ sent %@ with subject %@ swiped to display 'Delete' %@action%@.",
        message.senderName,
        message.sent,
        message.subject,
        message.isUnread ? @"and 'mark as read' " : @"",
        message.isUnread ? @"s" : @"");
    NSArray *ret = @[];

    UITableViewRowAction *delete = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDestructive
                                                                      title:NSLocalizedString(@"message.delete", @"Inbox Table Delete")
                                                                    handler:^(UITableViewRowAction *_Nonnull action, NSIndexPath *_Nonnull indexPath) {
                                                                        AWSDKLogInfo(@"Deleted message");
                                                                        // Deletes the message and reloads the cell
                                                                        [self deleteMessage:message atIndexPath:indexPath];
                                                                    }];
    ret = [ret arrayByAddingObject:delete];

    // Only show this action for unread messages
    if (message.isUnread) {
        UITableViewRowAction *markRead = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal
                                                                            title:NSLocalizedString(@"message.markRead", @"Inbox Table Mark As Read")
                                                                          handler:^(UITableViewRowAction *_Nonnull action, NSIndexPath *_Nonnull indexPath) {
                                                                              AWSDKLogInfo(@"Marked message as read");
                                                                              // Marks the message as read and reloads the cell
                                                                              [self markMessageRead:message atIndexPath:indexPath];
                                                                          }];

        [markRead setBackgroundColor:[UIColor linkBlueColor]];
        ret = [ret arrayByAddingObject:markRead];
    }

    return ret;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.inbox.messages.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    InboxTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"inboxCell"];

    // Configures cell to display the current message
    [cell handleMessage:(id<AWSDKInboxMessage>)self.inbox.messages[indexPath.row]];

    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

#pragma mark - IBActions
- (IBAction)composeTapped:(id)sender {
    AWSDKLogInfo(@"Compose button tapped");
    [self createMessageDraft];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showDetails"]) {
        [(MessageDetailsViewController *)segue.destinationViewController clearMessage];
        [(MessageDetailsViewController *)segue.destinationViewController loadInboxMessage:sender];
    }
    if ([segue.identifier isEqualToString:@"composeSegue"]) {
        [(ComposeMessageViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0] setDraft:sender];
    }
}

@end
