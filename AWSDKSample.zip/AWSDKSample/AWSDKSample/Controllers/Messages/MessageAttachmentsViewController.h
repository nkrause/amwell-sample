//
//  MessageAttachmentsViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/29/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

// clang-format off
@protocol AWSDKAttachment, AWSDKMessageDraft;
// clang-format on

/**
 Message attachments view controller displays a list of attachments, adds an attachment
 or clears if one is set for a draft.
 */
@interface MessageAttachmentsViewController : UITableViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>

/**
 When set, shows, adds, clears the message draft's awsdkattachment
 */
@property (nonatomic) id<AWSDKMessageDraft> draft;

/**
 Shows a list of source attachments if populated
 */
@property (nonatomic) NSArray<id<AWSDKAttachment>> *sourceAttachments;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *addButton;

@end
