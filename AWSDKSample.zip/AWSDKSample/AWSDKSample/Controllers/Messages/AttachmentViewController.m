//
//  AttachmentViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/29/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AttachmentViewController.h"

#import <AWSDK/AWSDKAttachment.h>

/**
 *  Displays a selected attachment in a webview
 */
@implementation AttachmentViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self setTitle:self.attachment.name];

    // Load attachment data
    [self.attachment fetchAttachmentAsData:^(id result, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view];

            if (error) {
                [self presentAlertWithError:error okHandler:nil];
            } else {
                // Loads the loaded data into the webview with the given MIME type
                [self.webView loadData:result MIMEType:self.attachment.type textEncodingName:@"" baseURL:[[NSURL alloc] init]];
            }
        });
    }];
}

#pragma mark - UIWebViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [MBProgressHUD hideHUDForView:self.view];
}
@end
