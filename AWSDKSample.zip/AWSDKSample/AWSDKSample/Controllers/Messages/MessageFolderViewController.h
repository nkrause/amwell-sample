//
//  MessageFolderViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

// clang-format off
@protocol AWSDKConsumer, AWSDKMessageFolderSent, AWSDKMessageFolderInbox;
// clang-format on

/**
 View Controller allows selecting which message folder to view
 */
@interface MessageFolderViewController : UITableViewController

/**
 Consumer's message inbox
 */
@property (nonatomic) id<AWSDKMessageFolderInbox> inbox;
@property (nonatomic) BOOL showInbox;

/**
 Consumer's sent message folder
 */
@property (nonatomic) id<AWSDKMessageFolderSent> sent;

// UI Labels
@property (weak, nonatomic) IBOutlet UILabel *inboxLabel;
@property (weak, nonatomic) IBOutlet UILabel *sentLabel;

@end
