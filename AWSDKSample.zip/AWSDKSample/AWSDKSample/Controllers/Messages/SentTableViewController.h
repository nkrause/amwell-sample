//
//  SentTableViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKMessageFolderSent;

// Controller shows a table of the consumer's sent messages
@interface SentTableViewController : UITableViewController

// Consumer's sent folder object
@property (nonatomic) id<AWSDKMessageFolderSent> sent;

@end
