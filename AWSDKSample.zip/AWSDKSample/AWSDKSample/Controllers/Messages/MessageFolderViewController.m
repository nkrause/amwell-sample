//
//  MessageFolderViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MessageFolderViewController.h"

#import "ComposeMessageViewController.h"
#import "InboxTableViewController.h"
#import "LoginViewController.h"
#import "MessageSplitViewController.h"
#import "SentTableViewController.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKMessageDraft.h>

/**
 *  View Controller allows selecting which message folder to view
 */
@interface MessageFolderViewController ()

@property (nonatomic) id<AWSDKConsumer> consumer;

@end

@implementation MessageFolderViewController

#pragma mark - AWSDK Method Calls
/**
 *  Fetches inbox folder and set result
 */
- (void)fetchInbox {
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD showLoadingOn:self.view];
    [self.consumer fetchMessageInboxWithOptions:nil
                                     completion:^(id result, NSError *error) {
                                         [MBProgressHUD hideHUDForView:self.view];
                                         if (error) {
                                             [weakSelf presentAlertWithError:error okHandler:nil];

                                         } else {
                                             // Retain inbox
                                             weakSelf.inbox = result;
                                         }
                                     }];
}

/**
 *  Fetches sent folder and set result
 */
- (void)fetchSentFolder {
    [MBProgressHUD showLoadingOn:self.view];
    [self.consumer fetchSentMessageFolderWithOptions:nil
                                          completion:^(id result, NSError *error) {
                                              [MBProgressHUD hideHUDForView:self.view];
                                              if (error) {
                                                  [self presentAlertWithError:error okHandler:nil];
                                              } else {
                                                  // Retain sent folder
                                                  self.sent = result;
                                              }
                                          }];
}

//-----------------------------------------------------------------------------------------------------//
//---------------------Everything below is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    self.consumer = [[ConsumerService sharedInstance] consumer];

    [self fetchInbox];
    [self fetchSentFolder];

    // Update UI Labels
    self.title = NSLocalizedString(@"message.title", @"Message Folder Title");
    self.inboxLabel.text = NSLocalizedString(@"message.inbox", @"Message Folder Inbox");
    self.sentLabel.text = NSLocalizedString(@"message.sent", @"Message Folder Sent");
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if (self.showInbox) {
        self.showInbox = NO;
        [self performSegueWithIdentifier:@"showInbox" sender:self];
    }
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (self.consumer) {
        if (indexPath.row == 0) {
            [self performSegueWithIdentifier:@"showInbox" sender:self];
        } else if (indexPath.row == 1) {
            [self performSegueWithIdentifier:@"showSent" sender:self];
        }
    }
}

#pragma mark - IBActions
- (IBAction)composeTapped:(id)sender {
    __weak typeof(self) weakSelf = self;
    AWSDKLogInfo(@"Compose button tapped");
    // Creates new draft and presents compose message controller
    [AWSDKMessageDraft createMessageDraftFromConsumer:[[ConsumerService sharedInstance] consumer]
                                           completion:^(id result, NSError *error) {
                                               if (error) {
                                                   // Error handling here
                                               } else {
                                                   [weakSelf performSegueWithIdentifier:@"composeSegue" sender:result];
                                               }
                                           }];
}

- (IBAction)doneTapped:(id)sender {
    AWSDKLogInfo(@"Done button tapped");
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Set the variables on the next controller
    if ([segue.identifier isEqualToString:@"showInbox"]) {
        AWSDKLogInfo(@"Inbox cell tapped");
        [(InboxTableViewController *)segue.destinationViewController setInbox:self.inbox];
    } else if ([segue.identifier isEqualToString:@"showSent"]) {
        AWSDKLogInfo(@"Sent cell tapped");
        [(SentTableViewController *)segue.destinationViewController setSent:self.sent];
    } else if ([segue.identifier isEqualToString:@"composeSegue"]) {
        [(ComposeMessageViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0] setDraft:sender];
    }
}

@end
