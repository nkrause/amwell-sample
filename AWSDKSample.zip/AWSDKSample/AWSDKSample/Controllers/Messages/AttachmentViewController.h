//
//  AttachmentViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/29/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKAttachment;

// Displays a selected message attachment's data in a web view
@interface AttachmentViewController : UIViewController <UIWebViewDelegate>

// The attachment to display
@property (nonatomic) id<AWSDKAttachment> attachment;

@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end
