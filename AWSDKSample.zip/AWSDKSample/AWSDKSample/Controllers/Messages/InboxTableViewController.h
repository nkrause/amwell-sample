//
//  InboxTableViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKMessageFolderInbox;

// Class shows a table of the consumer's inbox messages
@interface InboxTableViewController : UITableViewController

// Consumer's inbox object
@property (nonatomic) id<AWSDKMessageFolderInbox> inbox;

@end
