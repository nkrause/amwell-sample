//
//  MessageDetailsViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/9/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MessageDetailsViewController.h"

#import "ComposeMessageViewController.h"
#import "LoginViewController.h"
#import "MessageAttachmentsViewController.h"
#import "NSDateFormatter+CommonFormats.h"

#import <AWSDK/AWSDKContact.h>
#import <AWSDK/AWSDKInboxMessageDetails.h>
#import <AWSDK/AWSDKMessageDraft.h>
#import <AWSDK/AWSDKMessageTopic.h>
#import <AWSDK/AWSDKSentMessageDetails.h>

/**
 *  MessageDetailsViewController shows a message's details
 */
@interface MessageDetailsViewController ()

@property (nonatomic) id<AWSDKInboxMessageDetails> inboxMessage;
@property (nonatomic) id<AWSDKSentMessageDetails> sentMessage;

@end

@implementation MessageDetailsViewController

#pragma mark - AWSDK Method Calls

- (IBAction)deleteTapped:(id)sender {
    AWSDKLogInfo(@"Trash can tapped");
    UIAlertController *confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"message.delete.title", @"Message Details Delete Title")
                                                                     message:NSLocalizedString(@"message.delete.message", @"Message Details Delete Message")
                                                              preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.confirm", @"Message Details Confirm")
                                                            style:UIAlertActionStyleDestructive
                                                          handler:^(UIAlertAction *_Nonnull action) {
                                                              AWSDKLogInfo(@"Delete message confirmed");
                                                              // Check which message type is loaded, and call deleteMessage on that class
                                                              if (self.inboxMessage) {
                                                                  // Deletes inbox message and sends notification to the InboxTableViewController on success
                                                                  [self.inboxMessage deleteMessageWithCompletion:^(BOOL success, NSError *error) {
                                                                      if (success) {
                                                                          [[NSNotificationCenter defaultCenter] postNotificationName:@"inboxMessageDeleted" object:nil];
                                                                          [self.navigationController popViewControllerAnimated:YES];
                                                                      }
                                                                  }];
                                                              } else if (self.sentMessage) {
                                                                  // Deletes sent message and sends notification to the SentTableViewController on success
                                                                  [self.sentMessage deleteMessageWithCompletion:^(BOOL success, NSError *error) {
                                                                      if (success) {
                                                                          [[NSNotificationCenter defaultCenter] postNotificationName:@"sentMessageDeleted" object:nil];
                                                                          [self.navigationController popViewControllerAnimated:YES];
                                                                      }
                                                                  }];
                                                              }
                                                          }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.cancel", @"Message Details Cancel")
                                                           style:UIAlertActionStyleCancel
                                                         handler:^(UIAlertAction *_Nonnull action) {
                                                             AWSDKLogInfo(@"Delete message cancelled");
                                                         }];

    [confirm addAction:confirmAction];
    [confirm addAction:cancelAction];

    [self presentViewController:confirm animated:YES completion:nil];
}

- (IBAction)composeTapped:(id)sender {
    __weak typeof(self) weakSelf = self;
    AWSDKLogInfo(@"Compose button tapped");
    // Creates new message draft for the consumer and shows the compose message controller
    [AWSDKMessageDraft createMessageDraftFromConsumer:[[ConsumerService sharedInstance] consumer]
                                           completion:^(id result, NSError *error) {
                                               if (error) {
                                                   // Handle error
                                                   [weakSelf presentAlertWithError:error okHandler:nil];
                                               } else {
                                                   [weakSelf performSegueWithIdentifier:@"composeSegue" sender:result];
                                               }
                                           }];
}

- (IBAction)replyTapped:(id)sender {
    AWSDKLogInfo(@"Reply button tapped");
    UIAlertAction *replyAction;
    __weak typeof(self) weakSelf = self;

    // Check if replies are allowed for this message. Note that replies are only allowed on inbox messages and forwards are always allowed
    // The sender may or may not be accepting secure messages
    if (self.inboxMessage.canReply) {
        replyAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"message.action.reply", @"Message Details Reply")
                                               style:UIAlertActionStyleDefault
                                             handler:^(UIAlertAction *_Nonnull action) {
                                                 AWSDKLogInfo(@"Reply action selected");

                                                 // Creates a new message draft as a reply to the source message
                                                 [AWSDKMessageDraft createReplyDraftForMessage:self.inboxMessage
                                                                                  fromConsumer:[[ConsumerService sharedInstance] consumer]
                                                                                    completion:^(id result, NSError *error) {
                                                                                        if (error) {
                                                                                            // Handle error
                                                                                            [weakSelf presentAlertWithError:error okHandler:nil];
                                                                                        } else {
                                                                                            id<AWSDKMessageDraft> draft = result;
                                                                                            [weakSelf performSegueWithIdentifier:@"composeSegue" sender:draft];
                                                                                        }
                                                                                    }];
                                             }];
    }
    UIAlertAction *forwardAction =
        [UIAlertAction actionWithTitle:NSLocalizedString(@"message.action.forward", @"Message Details Forward")
                                 style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *_Nonnull action) {
                                   AWSDKLogInfo(@"Forward action selected");
                                   // Creates a new message draft as a forward of the source message
                                   [AWSDKMessageDraft createForwardDraftForMessage:self.sentMessage ? (id<AWSDKMessage>)self.sentMessage : (id<AWSDKMessage>)self.inboxMessage
                                                                      fromConsumer:[[ConsumerService sharedInstance] consumer]
                                                                        completion:^(id result, NSError *error) {
                                                                            if (error) {
                                                                                // Handle error
                                                                                [weakSelf presentAlertWithError:error okHandler:nil];
                                                                            } else {
                                                                                id<AWSDKMessageDraft> draft = result;
                                                                                [weakSelf performSegueWithIdentifier:@"composeSegue" sender:draft];
                                                                            }
                                                                        }];
                               }];

    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.cancel", @"Message Details Cancel") style:UIAlertActionStyleCancel handler:nil];

    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];

    if (replyAction) {
        [alertController addAction:replyAction];
    }
    [alertController addAction:forwardAction];
    [alertController addAction:cancelAction];

    [alertController.popoverPresentationController setBarButtonItem:self.replyButton];

    [self presentViewController:alertController animated:YES completion:nil];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.noMessageLabel setText:NSLocalizedString(@"message.noMessage", @"Message Details No Message Title")];

    if (!self.inboxMessage && !self.sentMessage) {
        [self clearMessage];
    } else if (self.inboxMessage) {
        [self loadInboxMessage:self.inboxMessage];
    } else if (self.sentMessage) {
        [self loadSentMessage:self.sentMessage];
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Helper Methods
- (void)clearMessage {
    [self.messageView setHidden:YES];
    [self.noMessageView setHidden:NO];

    [self.deleteButton setEnabled:NO];
    [self.replyButton setEnabled:NO];
    [self.attachmentButton setEnabled:NO];
}

// Preps UI for an Inbox Message
- (void)loadInboxMessage:(id<AWSDKInboxMessageDetails>)message {
    self.inboxMessage = nil;
    self.sentMessage = nil;

    self.inboxMessage = message;

    [self.messageView setHidden:NO];
    [self.noMessageView setHidden:YES];

    [self.fromLabel setText:[NSLocalizedString(@"message.from", @"Message Details From Title") stringByAppendingString:message.sender.name]];
    [self.toLabel setText:[NSLocalizedString(@"message.to", @"Message Details To Title") stringByAppendingString:message.recipient.name]];

    [self.subjectLabel setText:message.subject];
    [self.timeLabel setText:[[NSDateFormatter longDateTimeFormatter] stringFromDate:message.sent]];

    // Set message topic if a topic was selected
    if (![message.topic.name isEqualToString:@"None"]) {
        [self.topicLabel setText:[NSLocalizedString(@"message.topic", @"Message Details Topic Title") stringByAppendingString:message.topic.name]];
    }

    [self.replyButton setEnabled:YES];
    [self.deleteButton setEnabled:YES];

    [self.attachmentButton setEnabled:message.attachments.count];

    // Note that the message body is an HTML formatted string and so should be shown in a view that can render HTML like UIWebView or UITextField
    [self.contentView loadHTMLString:[message messageBody] baseURL:nil];
}

- (void)loadSentMessage:(id<AWSDKSentMessageDetails>)message {
    self.inboxMessage = nil;
    self.sentMessage = nil;

    self.sentMessage = message;

    [self.messageView setHidden:NO];
    [self.noMessageView setHidden:YES];

    [self.fromLabel setText:[NSLocalizedString(@"message.from", @"Message Details From Title") stringByAppendingString:message.sender.name]];

    NSString *recipientList = @"";
    for (id<AWSDKContact> recipient in message.allRecipients) {
        recipientList = [recipientList stringByAppendingString:recipient.name];
        if (recipient != message.allRecipients.lastObject) {
            recipientList = [recipientList stringByAppendingString:@", "];
        }
    }
    [self.toLabel setText:[NSLocalizedString(@"message.to", @"Message Details To Title") stringByAppendingString:recipientList]];

    [self.subjectLabel setText:message.subject];
    [self.timeLabel setText:[[NSDateFormatter longDateTimeFormatter] stringFromDate:message.sent]];
    // Set message topic if a topic was selected
    if (![message.topic.name isEqualToString:@"None"]) {
        [self.topicLabel setText:[NSLocalizedString(@"message.topic", @"Message Details Topic Title") stringByAppendingString:message.topic.name]];
    }

    [self.replyButton setEnabled:YES];
    [self.deleteButton setEnabled:YES];

    [self.attachmentButton setEnabled:message.attachments.count];

    // Note that the message body is an HTML formatted string and so should be shown in a view that can render HTML like UIWebView or UITextField
    [self.contentView loadHTMLString:[message messageBody] baseURL:nil];
}

#pragma mark - IBAction
- (IBAction)attachmentTapped:(id)sender {
    AWSDKLogInfo(@"Attachment button selected");
    [self performSegueWithIdentifier:@"attachmentsSegue" sender:self.inboxMessage ? self.inboxMessage.attachments : self.sentMessage.attachments];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"composeSegue"]) {
        [(ComposeMessageViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0] setDraft:sender];
    } else if ([segue.identifier isEqualToString:@"attachmentsSegue"]) {
        [(MessageAttachmentsViewController *)segue.destinationViewController setSourceAttachments:sender];
    }
}

@end
