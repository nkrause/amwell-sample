//
//  MessageSplitViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/9/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MessageSplitViewController.h"

#import "MessageDetailsViewController.h"

/**
 *  Split view controller for message flow
 */
@implementation MessageSplitViewController

//-----------------------------------------------------------------------------------------------------//
//----------------------Everything here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//
- (void)viewDidLoad {
    [super viewDidLoad];

    self.preferredDisplayMode = UISplitViewControllerDisplayModeAllVisible;
    self.delegate = self;
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
}

- (BOOL)splitViewController:(UISplitViewController *)splitViewController
    collapseSecondaryViewController:(UIViewController *)secondaryViewController
          ontoPrimaryViewController:(UIViewController *)primaryViewController {
    return YES;
}

@end
