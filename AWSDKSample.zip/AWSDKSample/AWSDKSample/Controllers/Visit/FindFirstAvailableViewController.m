//
//  FindFirstAvailableViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/18/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "FindFirstAvailableViewController.h"

#import "ProviderDetailViewController.h"
#import "SpinnerControl.h"
#import "VisitContextTableViewController.h"
#import "WaitingRoomViewController.h"

#import <AWSDK/AWSDKProvider.h>
#import <AWSDK/AWSDKVisitContext.h>
#import <AWSDK/AWSDKVisitService.h>

/**
 *  Handles performing a Find First Available search request
 */
@interface FindFirstAvailableViewController () <ProviderDetailDelegate, UIPopoverPresentationControllerDelegate, AWSDKFindFirstAvailableDelegate, UpdatePhoneNumberDelegate>

@end

@implementation FindFirstAvailableViewController

#pragma mark - AWSDKMethod Calls
/*
 * A Find First Available request pages any providers of a certain specialty within a practice who are listed
 * as 'On Call' but may not be available. They will be given the option to take the visit request.
 * Starting the Find First Available service will start this process and will report updates to the
 * findFirstAvailableDelegate.
 * The success block here indicates that the Find First Available request was successfully started.
 */
- (void)startFindFirstAvailableService {
    [MBProgressHUD showLoadingOn:self.view];
    [AWSDKVisitService startFindFirstAvailableServiceWithVisit:self.visit
                                                      delegate:self
                                                    completion:^(BOOL success, NSError *error) {
                                                        [MBProgressHUD hideHUDForView:self.view];
                                                        if (error) {
                                                            // Error handling
                                                            [self presentAlertWithError:error
                                                                              okHandler:^(UIAlertAction *_Nonnull action) {
                                                                                  [self dismissViewControllerAnimated:YES completion:nil];
                                                                              }];
                                                        }
                                                    }];
}

#pragma mark - FindFirstAvailable Delegate
/**
 *  This method is called by the Find First Available service when a provider has accepted the visit request
 *  and the visit is ready to be created. The selected provider will be populated on the
 *  AWSDKVisitContext instance
 */
- (void)providerFound {
    [self.visit.provider fetchProviderImage:^(BOOL success, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self performSegueWithIdentifier:@"providerDetailSegue" sender:self.visit.provider];
        });
    }];
}

/**
 *  This method is called when the system is out of providers to request and none have accepted
 *  At this point the visit can not move forward
 */
- (void)providerListExhausted {
    [self presentAlertWithTitle:NSLocalizedString(@"findFirstAvailable.listExhausted.title", @"First Available List Exhausted Title")
                        message:NSLocalizedString(@"findFirstAvailable.listExhausted.message", @"First Available List Exhausted Message")
                      okHandler:^(UIAlertAction *_Nonnull action) {
                          [self dismissViewControllerAnimated:YES completion:nil];
                      }];
}

/**
 *  Called in cases where the Find First Available service fails on the telehealth platform for an unexpected
 *  reason. At this point the visit cannot move forward
 */
- (void)findFirstAvailableFailedWithError:(NSError *)error {
    [self presentAlertWithTitle:NSLocalizedString(@"findFirstAvailable.failed.title", @"First Available Failed Title")
                        message:NSLocalizedString(@"findFirstAvailable.failed.message", @"First Available Failed Message")
                      okHandler:^(UIAlertAction *action) {
                          [self dismissViewControllerAnimated:YES completion:nil];
                      }];
}

#pragma mark - ProviderDetailDelegate
- (void)didCancel {
    /*
     * This handles actually canceling the Find First Available request. If this request fails we don't bother handling the error
     * because the server will automatically cancel the Find First Available request after a time out period.
     */
    [MBProgressHUD showCancelingOn:self.view];
    [self.visit.consumer cancelFindFirstAvailableRequest:^(BOOL success, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
}

/**
 *   Called when the user selects start visit on the provider detail controller
 *
 *  @param provider Provider returned from Find First Available
 */
- (void)didStartVisit:(id<AWSDKProvider>)provider {
    [self.cancelButton setEnabled:NO];
    [self.label setText:NSLocalizedString(@"findFirstAvailable.found", @"First Available Found Title")];

    /**
     *   Send context back to visit context view controller to finish updating the intake
     */
    [self performSegueWithIdentifier:@"waitingRoomSegue" sender:self.visit];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    [self setTitle:NSLocalizedString(@"findFirstAvailable.title", @"First Available Title")];

    [self.label setText:NSLocalizedString(@"findFirstAvailable.searching", @"First Available Searching Title")];

    [self startFindFirstAvailableService];

    [self.spinner rotateSpinner];
}

#pragma mark - IBAction
- (IBAction)cancelTapped:(id)sender {
    [self presentAlertWithMessageKey:@"findFirstAvailable.cancel.message"
                          yesHandler:^(UIAlertAction *action) {
                              [self didCancel];
                          }];
}

#pragma mark - UIPopoverPresentationControllerDelegate
- (UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    UIAlertController *alert = [UIAlertController alertControllerWithMessageKey:@"findFirstAvailable.cancel.message"
                                                                     yesHandler:^(UIAlertAction *action) {
                                                                         [self dismissViewControllerAnimated:YES
                                                                                                  completion:^{
                                                                                                      [self didCancel];
                                                                                                  }];
                                                                     }];

    [popoverPresentationController.presentedViewController presentViewController:alert animated:YES completion:nil];

    return NO;
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"providerDetailSegue"]) {
        ProviderDetailViewController *providerController = (ProviderDetailViewController *)segue.destinationViewController;

        providerController.preferredContentSize = CGSizeMake(self.view.frame.size.width * 0.95, self.view.frame.size.height * 0.95);

        UIPopoverPresentationController *presentationController = segue.destinationViewController.popoverPresentationController;
        [presentationController setDelegate:self];
        presentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 0, 0);
        presentationController.sourceView = self.view;

        providerController.preferredContentSize = CGSizeMake(self.view.frame.size.width * 0.95, self.view.frame.size.height * 0.95);

        [providerController setProvider:sender];
        [providerController setDelegate:self];
        [providerController setIsFromFindFirstAvailable:YES];
    } else if ([segue.identifier isEqualToString:@"waitingRoomSegue"]) {
        // Set Visit
        ((WaitingRoomViewController *)segue.destinationViewController).visit = self.visit;
        // Set the delegate as WaitingRoomViewController
        self.visit.delegate = (WaitingRoomViewController *)segue.destinationViewController;
    }
};

#pragma mark UpdatePhoneNumberDelegate
- (void)phoneNumberDidUpdate {
    //  Not Needed
}
@end
