//
//  VisitContextTableViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 7/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKVisitContext;
@protocol AWSDKPractice;
/**
 VisitContextTableViewController handles the initial pre visit screen questionaire. The visit context
 must be created and set, and if the questionaire flow is succcesful, a visit object will be created.
 */
@interface VisitContextTableViewController : UITableViewController 

/**
 Context must be created and set before VisitContextTableViewController loads, this contains
 all the information about the visit
 */
@property (nonatomic) id<AWSDKVisitContext> context;

/**
 If set, context is created and set by an appointment
 */
@property (nonatomic) id<AWSDKAppointment> appointment;

/**
 If set, view controller will only show disclaimers, share health summmary options, and adding guests for multiway video
 */
@property (assign, nonatomic) BOOL isFromFindFirstAvailable;

/**
 Will be set if we are starting intake from a transfer.
 */
@property (assign, nonatomic) BOOL isTransfer;

/**
 The practice the provider is in.
 */
@property (assign, nonatomic) id<AWSDKPractice> practice;

@end
