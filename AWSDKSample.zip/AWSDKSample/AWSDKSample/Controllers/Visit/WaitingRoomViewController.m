//
//  WaitingRoomViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/18/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "WaitingRoomViewController.h"

#import "AppDelegate.h"
#import "CallbackViewController.h"
#import "ChatTableViewController.h"
#import "CostTableViewController.h"
#import "EditPhoneNumberViewController.h"
#import "GradientButton.h"
#import "NSPersonNameComponents+Localizing.h"
#import "ProviderDetailViewController.h"
#import "SpinnerControl.h"
#import "UIApplication+AVAuthorization.h"
#import "VisitContextTableViewController.h"
#import "VisitSummaryTableViewController.h"
#import "WarmTransferViewController.h"

#import <AWSDK/AWCoreVisitConsoleController.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKCost.h>
#import <AWSDK/AWSDKForcedVisitTransfer.h>
#import <AWSDK/AWSDKProvider.h>
#import <AWSDK/AWSDKProviderType.h>
#import <AWSDK/AWSDKSuggestedVisitTransfer.h>
#import <AWSDK/AWSDKSystemConfiguration.h>
#import <AWSDK/AWSDKVisit.h>
#import <AWSDK/AWSDKVisitContext.h>
#import <AWSDK/AWSDKModality.h>
#import <AWSDK/AWSDKModalityCode.h>
#import <AWSDK/AWSDKVisitService.h>
#import <Foundation/Foundation.h>
#import <UserNotifications/UserNotifications.h>

// Interval to check for timeouts
static const NSTimeInterval kPollingFailureTimeout = 60.0;

typedef void (^UIAlertActionBlock)(UIAlertAction *_Nonnull action);

/**
 *  WaitingRoomViewController starts the visit and creates the visitConsole
 */
@interface WaitingRoomViewController () <ProviderDetailDelegate, UIPopoverPresentationControllerDelegate, WarmTransferDelegate, UpdatePhoneNumberDelegate>
// Console to present the visit
@property (weak, nonatomic) AWCoreVisitConsoleController *console;

// Popover controller
@property (weak, nonatomic) ChatTableViewController *chatController;

// Reason visit ended
@property AWCoreVisitEndReason endReason;

@property (weak, nonatomic) NSTimer *backgroundTimeoutTimer;
@property (nonatomic) UIBackgroundTaskIdentifier taskIdentifier;

@property (nonatomic) BOOL acceptTransferTapped;
@property (nonatomic) BOOL declineTransferTapped;
@property (nonatomic) BOOL visitStarted;
@property (nonatomic, readonly) BOOL isPhoneVisit;
@property (weak, nonatomic) IBOutlet SpinnerControl *spinner;

@property (weak, nonatomic) IBOutlet UIView *firstAvailableSuggestionStatusView;
@property (weak, nonatomic) IBOutlet UIImageView *firstAvailableSpinnerView;
@property (weak, nonatomic) IBOutlet UIImageView *providerImageView;
@property (weak, nonatomic) IBOutlet UILabel *providerLabel;
@property (weak, nonatomic) IBOutlet GradientButton *returnHomeButton;

/**
 *  Transfer that is being displayed and handled
 */
@property (nonatomic) id<AWSDKVisitTransfer> transfer;
@property (nonatomic) id<AWSDKVisitContext> transferContext;

/**
 Array of scheduled local notifications for background timeout
 */
@property (nonatomic, nullable) NSArray<NSString *> *scheduledBackgroundTimeoutNotificationIDs;
@property (assign, nonatomic) BOOL visitFailureBeingHandled;
@property (nonatomic) NSDate *failureExpireDate;
@property (assign, nonatomic) BOOL sendTextMessageOnQueueChanges;

@end

@implementation WaitingRoomViewController

#pragma mark - AWSDK Method Calls

- (void)setVisitConfigurations {
    // Enable or Disable callback depending on setting
    [AWSDKSystemConfiguration setCallbackViaPhoneEnabled:[[[NSUserDefaults standardUserDefaults] objectForKey:@"enableIVR"] boolValue]];
    AWSDKLogDebug(@"IVR Configuration set to %@", [AWSDKSystemConfiguration isCallbackViaPhoneEnabled] ? @"Enabled" : @"Disabled");

    // Hide or just disable the refresh and guest button
    [AWSDKSystemConfiguration setRefreshAndGuestButtonHiddenWhenDisabled:[[[NSUserDefaults standardUserDefaults] objectForKey:@"hideRefreshAndGuestButtonsWhenDisabled"] boolValue]];
    AWSDKLogDebug(@"Hide refresh button when disabled set to %@", [AWSDKSystemConfiguration isRefreshAndGuestButtonHiddenWhenDisabled] ? @"Enabled" : @"Disabled");

    // Enable or Disable vibration when joining a visit
    [AWSDKSystemConfiguration setVibrateOnVisitJoinEnabled:[[[NSUserDefaults standardUserDefaults] objectForKey:@"enabledVibrateOnVisitJoin"] boolValue]];
    AWSDKLogDebug(@"Vibrate when joining visit configuration set to %@", [AWSDKSystemConfiguration isVibrateOnVisitJoinEnabled] ? @"Enabled" : @"Disabled");

    // Enable or Disable sound when joining a visit
    [AWSDKSystemConfiguration setSoundOnVisitJoinEnabled:[[[NSUserDefaults standardUserDefaults] objectForKey:@"enabledSoundOnVisitJoin"] boolValue]];
    AWSDKLogDebug(@"Play sound when joining visit configuration set to %@", [AWSDKSystemConfiguration isSoundOnVisitJoinEnabled] ? @"Enabled" : @"Disabled");

    if ([AWSDKSystemConfiguration isSoundOnVisitJoinEnabled]) {
        // In order to play a sound we need to set the path to the sound file we want to play.
        // If this path is not set no sound will play, even if the configuration is set to YES
        NSString *path = [[NSBundle mainBundle] pathForResource:@"electron-echo" ofType:@"wav"];
        if (path != nil) {
            [AWSDKSystemConfiguration setPathToVisitJoinSound:path];
            AWSDKLogDebug(@"Path to sound file to play when joining a visit set to %@", path);
        } else {
            AWSDKLogDebug(@"Invalid sounds file");
        }
    }
}
- (BOOL)isPhoneVisit {
    return self.visit.modality.code == AWSDKModalityCodePhone;
}

/**
 *  When Phone Visit is connected the user might want to go back to provider list instead of waiting for the provider to end the visit (which would seque to the wrap up page).
 */
- (IBAction)returnHomeFromPhoneVisit {
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
/**
 *  Starts the visit. Requires the provider to still enter the visit
 */
- (void)startVisit {
    // Set up any configurations.
    [self setVisitConfigurations];
    [self updateViewFromContext];

    __weak typeof(self) weakSelf = self;
    GenericCompletionBlock completion = ^(BOOL success, NSError *error) {
        if (error) {
            // Error handling
            [weakSelf presentAlertWithError:error
                                  okHandler:^(UIAlertAction *_Nonnull action) {
                                      if (error.code == AWSDKErrorCodePaymentMethodCreditCardDeclined) {
                                          AWSDKLogInfo(@"Payment authorization failure");
                                          [self performSegueWithIdentifier:@"visitCost" sender:self];
                                      } else {
                                          [weakSelf dismissViewControllerAnimated:YES completion:nil];
                                      }
                                  }];
        }
    };

    // Start the visit.
    if (self.visit.createdForFirstAvailableFlow && self.context.provider) {
        [AWSDKVisitService startVisit:self.visit withProvider:self.context.provider completion:completion];
    } else {
        [AWSDKVisitService startVisit:self.visit completion:completion];
    }
}

/**
 *  Cancels a currently pending visit to let the provider know
 */
- (void)cancelPendingVisit {
    [AWSDKVisitService cancelPendingVisit:self.visit
                           withCompletion:^(BOOL success, NSError *error) {
                               [self.navigationController dismissViewControllerAnimated:YES completion:nil];
                           }];
}

/**
 *  Cancels a currently pending visit after a timeout to let the provider know
 */
- (void)cancelPendingVisitAfterTimeout {
    [AWSDKVisitService cancelPendingVisit:self.visit
                           withCompletion:^(BOOL success, NSError *error) {
                               [self presentAlertWithMessageKey:@"visitEnd.visitBackgroundTimeout"
                                                      okHandler:^(UIAlertAction *action) {
                                                          [self.navigationController dismissViewControllerAnimated:YES completion:nil];
                                                      }];
                            }];
}

/**
 *  Creates the visit console to present to the user
 */
- (void)createVisitConsole {
    BOOL webRTCAppearanceManagerOverride = [[NSUserDefaults standardUserDefaults] boolForKey:@"overrideWebRTCColors"];
    [AWSDKVisitService createVisitConsoleForVisit:self.visit
                            withAppearanceManager:webRTCAppearanceManagerOverride ? [self randomColorAppearanceManager] : nil
                                   withCompletion:^(id result, NSError *error) {
                                       if (error) {
                                           [self presentAlertWithError:error];
                                       } else {
                                           AWCoreVisitConsoleController *console = (AWCoreVisitConsoleController *)result;
                                           self.console = console;

                                           if (self.presentedViewController) {
                                               [self.presentedViewController dismissViewControllerAnimated:YES
                                                                                                completion:^{
                                                                                                    [self presentViewController:console animated:YES completion:nil];
                                                                                                }];
                                           } else {
                                               [self presentViewController:console animated:YES completion:nil];
                                           }
                                       }
                                   }];
}

/**
 *  Called to accept the transfer offered and handle the response
 */
- (void)acceptTransferWithCompletion:(CompletionBlock)completion {
    AWSDKLogDebug(@"Accepted transfer with transfer class %@ to provider %@", [self.transfer class], self.transfer.provider.nameComponents.localizedFullName);
    self.acceptTransferTapped = YES;

    [self toggleFirstAvailableSearchBannerEnabled:NO];

    // Reset chat button and waiting room label
    self.patientsWaitingLabel.text = @"";
    self.chatButton.hidden = YES;
    [self.chatButton setTitle:NSLocalizedString(@"chat.assistant", @"Waiting Room Chat Assistant Title") forState:UIControlStateNormal];
    [self.chatController dismissViewControllerAnimated:YES completion:nil];

    [self.transfer acceptTransfer:^(id _Nullable result, NSError *error) {
        if (error && !result) {
            // Handle error
            [self presentAlertWithError:error okHandler:nil];

        } else if ([result conformsToProtocol:@protocol(AWSDKVisitContext)]) {
            AWSDKLogDebug(@"Visit Context returned from transfer, starting intake");
            // If we get a visit context back we need to go back to the beginning of the visit flow
            self.transferContext = result;
            [self startVisitTransfer:self.transferContext];

        } else if ([result conformsToProtocol:@protocol(AWSDKVisit)]) {
            AWSDKLogDebug(@"Visit returned from transfer, re-starting visit");
            // If we get a visit back we can enter the waiting room again

            // If the Warm Transfer screen is visible, pop it to get back to the waiting room.
            // Otherwise, do nothing, as we can get here during a decline and transfer as well
            // which doesn't push/present any screens.
            if ([self.navigationController.topViewController isKindOfClass:WarmTransferViewController.class]) {
                [self.navigationController popViewControllerAnimated:YES];
            }

            self.context = nil;
            id<AWSDKVisit> visit = result;
            self.visit = visit;
            self.visit.delegate = self;
            [self startVisit];

        } else if ([result conformsToProtocol:@protocol(AWSDKVisitTransfer)]) {
            AWSDKLogDebug(@"Transfer returned from transfer, showing new transfer");
            __weak typeof(self) weakSelf = self;
            // If we get a new transfer back we need to show transfer details again
            self.transfer = result;

            UIAlertController *transferAlert = [UIAlertController alertControllerWithMessageKey:@"transfer.redirected.message"];

            UIAlertActionBlock declineBlock = ^(UIAlertAction *_Nonnull action) {
                [weakSelf declineTransfer];
            };
            UIAlertActionBlock showBlock = ^(UIAlertAction *_Nonnull action) {
                [weakSelf.transfer.provider fetchProviderImage:^(BOOL success, NSError *error) {
                    [weakSelf performSegueWithIdentifier:@"providerDetailSegue" sender:weakSelf.transfer.provider];
                }];
            };
            UIAlertActionBlock suppressBlock = ^(UIAlertAction *_Nonnull action) {
                weakSelf.visit.suggestedTransfer.dontSuggestTransferAgain = YES;
                [weakSelf declineTransfer];
            };

            UIAlertAction *decline = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.decline", @"Waiting Room Decline Title")
                                                              style:UIAlertActionStyleDestructive
                                                            handler:[transferAlert defaultAlertHandler:declineBlock]];
            UIAlertAction *showDetails = [UIAlertAction actionWithTitle:NSLocalizedString(@"transfer.suggested.viewDetailsAction", @"Waiting Room Suggested Action Title")
                                                                  style:UIAlertActionStyleDefault
                                                                handler:[transferAlert defaultAlertHandler:showBlock]];
            UIAlertAction *suppressSuggestions = [UIAlertAction actionWithTitle:NSLocalizedString(@"transfer.suggested.dontSuggestTransferAgain", @"Waiting Room Suggested Transfer Action Title")
                                                                          style:UIAlertActionStyleDestructive
                                                                        handler:[transferAlert defaultAlertHandler:suppressBlock]];
            [transferAlert addAction:showDetails];
            [transferAlert addAction:decline];
            [transferAlert addAction:suppressSuggestions];

            [weakSelf presentAlertController:transferAlert removeOnBackground:NO];
        }

        if (completion) {
            completion();
        }
    }];
}

- (void)declineTransfer;
{
    __weak typeof(self) weakSelf = self;
    self.declineTransferTapped = NO;
    if ([self.transfer conformsToProtocol:@protocol(AWSDKForcedVisitTransfer)]) {
        // Cannot decline transfer, cancel visit
        // Present alert for why the visit ended
        [self presentAlertWithMessageKey:@"visitEnd.providerDeclinedAndTransferDeclined"
                               okHandler:^(UIAlertAction *action) {
                                   [weakSelf.navigationController dismissViewControllerAnimated:YES completion:nil];
                               }];
    } else if ([self.transfer conformsToProtocol:@protocol(AWSDKSuggestedVisitTransfer)]) {
        [self.visit.suggestedTransfer declineTransfer:^(BOOL success, NSError *error) {
            if (error) {
                // Show error
                [weakSelf presentAlertWithError:error okHandler:nil];
            }
        }];
    }
}

- (void)startVisitTransfer:(id<AWSDKVisitContext>)visitContext {
    [self performSegueWithIdentifier:@"startVisitSegue" sender:visitContext];
}

- (void)showPhoneVisitReadyState {
    // present the "We're placing a call" visual
    self.patientsWaitingLabel.text = @"";
    self.phoneVisitWaitLabel.attributedText = [self makeAttributedMessage:NSLocalizedString(@"waitingRoom.placingCall", @"call in progress") phonePart:self.visitFormattedPhoneNumber];
    self.returnHomeButton.hidden = NO;
    self.ifYouCloseLabel.hidden = YES;
    self.patientsWaitingLabel.hidden = YES;
    [self.returnHomeButton setTitle:NSLocalizedString(@"waitingRoom.returnHome", @"Button title") forState:UIControlStateNormal];
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.leftBarButtonItem = nil; // get rid of the cancel backbuttonItem beneath the back button
}

- (void)joinActiveVisit {
    if (self.visitStarted) {
        __weak typeof(self) weakSelf = self;
        [AWSDKVisitService rejoinVisit:self.visit completion:^(BOOL success, NSError * _Nullable error) {
            if (error != nil) {
                // Error handling
                [weakSelf presentAlertWithError:error
                                      okHandler:^(UIAlertAction *_Nonnull action) {
                                          [weakSelf dismissViewControllerAnimated:YES completion:nil];
                                      }];
            }
        }];
    }
}

#pragma mark - AWSDKVisitDelegate
/**
 *  Called when provider enters the visit
 */
- (void)providerDidEnterVisit {
    self.failureExpireDate = nil;

    // Check if currently presenting chat
    if (self.chatController) {
        [self.chatController dismissViewControllerAnimated:YES
                                                completion:^{
                                                    // Create and show console or present wait for callback UI
                                                    [self presentConsoleOrWaitForCallback];
                                                }];
    } else {
        // Create and show console or present wait for callback UI
        [self presentConsoleOrWaitForCallback];
    }
}

- (void)presentConsoleOrWaitForCallback {
    if (self.isPhoneVisit) {
        // present the "We're placing a call" visual
        [self showPhoneVisitReadyState];
    } else {
        // Start the video conversation
        [self createVisitConsole];
    }
}

- (void)visitUpdateDidFail:(NSError *)error {
    // A failure has occurred, perform logic to check if an alert is warranted to allow user to continue or cancel
    // If the video console is currently being presented, don't present this alert.
    if (self.failureExpireDate && !self.console) {
        // Check if a failure is currently being handled, if so, silently disregard new failures from polling
        if (self.visitFailureBeingHandled) {
            return;
        }
        // Failure has exceeded the time limit, present an alert
        if ([self.failureExpireDate compare:[NSDate date]] == NSOrderedAscending) {
            self.visitFailureBeingHandled = YES;
            AWSDKLogDebug(@"visitUpdateDidFail with error =>%@<", error.localizedDescription);

            // Block to be called after console is dismissed
            void (^handleDidComplete)(void) = ^void() {
                NSString *title = NSLocalizedString(@"waitingRoom.title", @"Waiting Room Title");
                NSString *message = NSLocalizedString(@"waitingRoom.pollingFailure.title", @"message");
                if (error) {
                    switch (error.code) {
                        case kCFURLErrorNotConnectedToInternet:
                            title = NSLocalizedString(@"waitingRoom.pollingFailure.title", @"title");
                            message = NSLocalizedString(@"waitingRoom.pollingFailure.disconnect.message", @"message");
                            break;
                        default:
                            break;
                    }
                }

                AWSDKLogInfo(@"Check to see if consumer wants to continue visit or cancel") __weak typeof(self) weakSelf = self;
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message];
                UIAlertAction *cancel = [UIAlertAction actionWithTitle:NSLocalizedString(@"waitingRoom.cancel.title", @"Waiting Room Cancel Title")
                                                                 style:UIAlertActionStyleDestructive
                                                               handler:^(UIAlertAction *action) {
                                                                   AWSDKLogDebug(@"Cancel action");
                                                                   [weakSelf cancelPendingVisit];
                                                               }];
                UIAlertAction *okay = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.ok", @"Waiting Room Okay Title")
                                                               style:UIAlertActionStyleDefault
                                                             handler:^(UIAlertAction *action) {
                                                                 AWSDKLogDebug(@"Okay action");
                                                                 weakSelf.failureExpireDate = [[NSDate date] dateByAddingTimeInterval:kPollingFailureTimeout];
                                                                 weakSelf.visitFailureBeingHandled = NO;
                                                                 [weakSelf.spinner rotateSpinner];
                                                             }];
                [alertController addAction:cancel];
                [alertController addAction:okay];

                [weakSelf presentAlertController:alertController removeOnBackground:NO];
            };

            [self.spinner pauseSpinner];

            // If console still exists, dismiss it
            if (self.console && ![self.console isBeingDismissed]) {
                [self dismissViewControllerAnimated:YES completion:handleDidComplete];
            } else {
                handleDidComplete();
            }
        }
    } else if (self.console) {
        // Don't handle or track failures while console is being presented
        self.failureExpireDate = nil;
    } else {
        self.failureExpireDate = [[NSDate date] dateByAddingTimeInterval:kPollingFailureTimeout];
        self.visitFailureBeingHandled = NO;
    }
}

/**
 *  Visit completed, canceled, or finished for a reason listed in AWCoreVisitEndReasons
 *
 *  @param visitSuccessful True if not canceled early by error, user, or provider
 *  @param reason          AWCoreVisitEndReason for why the visit ended
 */
- (void)visitDidComplete:(BOOL)visitSuccessful withEndReason:(AWCoreVisitEndReason)reason {
    self.failureExpireDate = nil;

    AWSDKLogInfo(@"visitDidCompleteCalled with visitSuccesful %@ and end reason %ld", visitSuccessful ? @"TRUE" : @"FALSE", (long)reason);

    // Block to be called after console is dismissed
    void (^handleDidComplete)(void) = ^void() {
        self.endReason = reason;

        if (self.visit.callbackStatus == AWSDKCallbackStatusRequested || self.visit.callbackStatus == AWSDKCallbackStatusDialingConsumer
            || self.visit.callbackStatus == AWSDKCallbackStatusDialingProvider || self.visit.callbackStatus == AWSDKCallbackStatusQueued) {
            /*
             This case will occur if the video call failed for reasons including the provider or consumer losing
             network connectivity. Upon this situation, if callback is enabled in the app configuration the user will be
             prompted with an option to "Talk via Phone". If tapped, the visit will end, [AWSDKVisit callbackStatus]
             will be set. [AWSDKVisit callbackStatus] will be set to either AWSDKCallbackStatusRequested or AWSDKCallbackStatusDialingConsumer
             at this point indicating to go to the callback waiting screen.
             */

            AWSDKLogInfo(@"Member requested callback");
            // Push Callback View Controller
            [self performSegueWithIdentifier:@"callbackSegue" sender:nil];
        } else if (reason == AWCoreVisitEndReasonProviderDeclineAndTransfer || reason == AWCoreVisitEndReasonAssistantDeclineAndTransfer) {
            AWSDKLogInfo(@"Decline and transfer initiated");
            __weak typeof(self) weakSelf = self;
            self.transfer = self.visit.forcedTransfer;
            // Provider declined and transferred. Show suggested Provider
            UIAlertController *transferAlert = [UIAlertController alertControllerWithMessageKey:@"transfer.providerDeclined.message"];
            UIAlertActionBlock okayBlock = ^(UIAlertAction *_Nonnull action) {
                [weakSelf acceptTransferWithCompletion:nil];
            };
            UIAlertAction *okay = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.ok", @"Waiting Room Okay Title")
                                                           style:UIAlertActionStyleDefault
                                                         handler:[transferAlert defaultAlertHandler:okayBlock]];
            [transferAlert addAction:okay];
            [weakSelf presentAlertController:transferAlert];
        } else if (reason == AWCoreVisitEndReasonPostVisitTransfer) {
            AWSDKLogInfo(@"Post-visit transfer initiated");
            self.transfer = self.visit.forcedTransfer;
            [self performSegueWithIdentifier:@"warmTransferSegue" sender:self];
        } else if (visitSuccessful) {
            AWSDKLogInfo(@"Visit successful!");
            // Push VisitSummaryViewController
            [self performSegueWithIdentifier:@"wrapUpSegue" sender:nil];
        } else {
            // Present alert for why the visit ended
            [self.navigationController presentAlertWithMessageKey:[ErrorService messageKeyForEndReason:reason]
                                                        okHandler:^(UIAlertAction *action) {
                                                            [self.navigationController dismissViewControllerAnimated:YES completion:nil];
                                                        }];
        }
    };

    // If console still exists, dismiss it
    if (self.console && ![self.console isBeingDismissed]) {
        [self dismissViewControllerAnimated:YES completion:handleDidComplete];
    } else {
        handleDidComplete();
    }
}

/**
 *  Patients ahead of consumer changed, update the text label
 */
- (void)patientsAheadOfConsumerDidChange {
    self.failureExpireDate = nil;

    [self.patientsWaitingLabel setHidden:(self.visit.patientsAheadOfConsumer < 0)];

    if (self.visit.patientsAheadOfConsumer == 0) {
        self.patientsWaitingLabel.text = NSLocalizedString(@"waitingRoom.youAreNext", @"Waiting Room You Are Next Title");
    } else if (self.visit.patientsAheadOfConsumer == 1) {
        self.patientsWaitingLabel.text = NSLocalizedString(@"waitingRoom.patientWaiting", @"Waiting Room Patient Waiting Title");
    } else {
        self.patientsWaitingLabel.text = [NSString stringWithFormat:NSLocalizedString(@"waitingRoom.patientsWaiting", @"Waiting Room Patients Waiting Title"), self.visit.patientsAheadOfConsumer];
    }
}

/**
 *  Called when the telehealth platform suggests transfering to a different provider for a shorter wait time
 */
- (void)suggestedTransferDidChange:(id<AWSDKSuggestedVisitTransfer>)transfer {
    self.failureExpireDate = nil;

    // If there's a forcedTransfer, ignore the automated suggested transfer
    if (self.visit.forcedTransfer) {
        return;
    }

    AWSDKLogDebug(@"Suggested transfer found with provider %@", transfer.provider.nameComponents.localizedFullName);

    __weak typeof(self) weakSelf = self;
    self.transfer = transfer;

    UIAlertController *transferAlert = [UIAlertController alertControllerWithMessageKey:@"transfer.suggested.message"];

    UIAlertActionBlock declineBlock = ^(UIAlertAction *_Nonnull action) {
        [weakSelf declineTransfer];
    };
    UIAlertActionBlock detailsBlock = ^(UIAlertAction *_Nonnull action) {
        [transfer.provider fetchProviderImage:^(BOOL success, NSError *error) {
            [weakSelf performSegueWithIdentifier:@"providerDetailSegue" sender:transfer.provider];
        }];
    };
    UIAlertActionBlock suppressBlock = ^(UIAlertAction *_Nonnull action) {
        weakSelf.visit.suggestedTransfer.dontSuggestTransferAgain = YES;
        [weakSelf declineTransfer];
    };
    UIAlertAction *decline = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.decline", @"Waiting Room Decline Title")
                                                      style:UIAlertActionStyleDestructive
                                                    handler:[transferAlert defaultAlertHandler:declineBlock]];
    UIAlertAction *showDetails = [UIAlertAction actionWithTitle:NSLocalizedString(@"transfer.suggested.viewDetailsAction", @"Waiting Room View Details Action Title")
                                                          style:UIAlertActionStyleDefault
                                                        handler:[transferAlert defaultAlertHandler:detailsBlock]];
    UIAlertAction *suppressSuggestions = [UIAlertAction actionWithTitle:NSLocalizedString(@"transfer.suggested.dontSuggestTransferAgain", @"Waiting Room Do Not Suggest Transfer Action Title")
                                                                  style:UIAlertActionStyleDestructive
                                                                handler:[transferAlert defaultAlertHandler:suppressBlock]];

    [transferAlert addAction:showDetails];
    [transferAlert addAction:decline];
    [transferAlert addAction:suppressSuggestions];

    [weakSelf presentAlertController:transferAlert removeOnBackground:NO];
}

/**
 *  Called when the chatReport property detects a change in chatItems, signal ChatTableViewController to reload data
 */
- (void)chatReportDidChange:(id<AWSDKChatReport>)newChatReport {
    self.failureExpireDate = nil;

    [self.chatButton setHidden:(self.visit.chatReport == nil)];
    if ([[self presentedViewController] isKindOfClass:[ChatTableViewController class]] && [self.delegate respondsToSelector:@selector(chatReportDidChange:)]) {
        [self.delegate chatReportDidChange:newChatReport];
    }
}

- (void)visitDidSuggestFirstAvailableSearch {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self performSegueWithIdentifier:@"suggestFirstAvailable" sender:self];
    });
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

- (NSAttributedString *)makeAttributedMessage:(NSString *)firstPart phonePart:(NSString *)phonePart {
    NSString *rawText = [NSString stringWithFormat:@"%@\n%@.", firstPart, phonePart];
    NSMutableDictionary *attr = [NSMutableDictionary new];
    attr[NSFontAttributeName] = [UIFont systemFontOfSize:17.0f weight:UIFontWeightRegular];
    attr[NSForegroundColorAttributeName] = [UIColor blackColor];
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:rawText];
    long lengthBold = attributedText.length - firstPart.length;
    [attributedText addAttributes:attr range:NSMakeRange(0, attributedText.length - lengthBold)];
    [attributedText addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:17.0f weight:UIFontWeightBold] range:NSMakeRange(attributedText.length - lengthBold, lengthBold)];
    return attributedText;
}

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    [self toggleFirstAvailableSearchBannerEnabled:NO];
    if (self.visit.disposition == AWSDKVisitDispositionInVisit || self.visit.disposition == AWSDKVisitDispositionPreVisit) {
        self.visitStarted = YES;
    }

    if (!self.visitStarted) {
        AWSDKLogInfo(@"Sufficient permissions! Starting visit.");
        [self startVisit];
        self.visitStarted = YES;
    }
    // for phone visits
    if (self.isPhoneVisit) {
        [self configureUIForPhoneVisit];
    }

    self.returnHomeButton.hidden = YES;
    if (self.visit.disposition == AWSDKVisitDispositionInVisit || self.visit.disposition == AWSDKVisitDispositionPreVisit) {
        [self joinActiveVisit];
    }
}

- (void)handleDidBecomeActive {
    AWSDKLogInfo(@"Returned to foreground");
    [self.spinner rotateSpinner];
    [self cancelLocalNotificationsForBackgroundVisitTimeout];
    [self.backgroundTimeoutTimer invalidate];
    [self invalidateBackgroundTask];
}

- (void)handleDidResignActive {
    AWSDKLogInfo(@"Resigned active");
    [self scheduleLocalNotificationsForBackgroundVisitTimeout];
    [self startBackgroundVisitTimer];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [self setupObservers];
    // Rotate spinner each time the view appears
    self.spinner.hidden = NO;
    [self.spinner rotateSpinner];
    [self updateViewFromContext];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];

    // This means that we've transitioned to the video console controller which will handle it's own visit timeouts
    [self invalidateBackgroundTask];
    [self.backgroundTimeoutTimer invalidate];
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

#pragma mark - helpers
- (void)configureUIForPhoneVisit {
    NSString *firstPart = NSLocalizedString(@"waitingRoom.phoneVisit.waitingForCall", @"wait for provider to call message");
    self.phoneVisitWaitLabel.attributedText = [self makeAttributedMessage:firstPart phonePart:self.visitFormattedPhoneNumber];
    self.ifYouCloseLabel.hidden = NO;
    self.ifYouCloseLabel.text = NSLocalizedString(@"waitingRoom.phoneVisit.ifYouClose", @"phone visit info");
    self.sendTextMessageLabel.hidden = YES;
    self.sendTextMessageSwitch.hidden = YES;
    self.chatButton.hidden = YES;
    self.sendTextMessageLabel.hidden = YES;
    self.sendTextMessageSwitch.hidden = YES;
    self.spinner.innerImage = [UIImage imageNamed:@"phoneSpinner"];
    self.sendTextMessageLabel.hidden = YES;
    self.sendTextMessageSwitch.hidden = YES;
    self.returnHomeButton.titleLabel.text = NSLocalizedString(@"waitingRoom.returnHome", @"leave phone visit");
}

- (void)setupObservers {
    // Add observer to restart spinner after returning from background
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleDidBecomeActive) name:UIApplicationWillEnterForegroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleDidResignActive) name:UIApplicationDidEnterBackgroundNotification object:nil];
}

- (void)toggleFirstAvailableSearchBannerEnabled:(BOOL)enabled {
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        weakSelf.firstAvailableSuggestionStatusView.hidden = !enabled;
    });
}

- (void)updateViewFromContext {
    // Hide button depending on chatReport being nil or not
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakSelf.chatButton setHidden:(weakSelf.visit.chatReport == nil)];
        weakSelf.providerImageView.image = weakSelf.context.provider.image ?: weakSelf.visit.provider.image;
        weakSelf.providerImageView.layer.cornerRadius = weakSelf.providerImageView.frame.size.height / 2;

        weakSelf.providerLabel.text = [NSString stringWithFormat:@"%@\n%@",
                                                weakSelf.context.provider.nameComponents.localizedFullName ?: weakSelf.visit.provider.nameComponents.localizedFullName,
                                                weakSelf.context.provider.specialty.name ?: weakSelf.visit.provider.specialty.name];

        weakSelf.sendTextMessageLabel.hidden = (weakSelf.isPhoneVisit || !weakSelf.visitFormattedPhoneNumber.length);
        weakSelf.sendTextMessageSwitch.hidden = weakSelf.sendTextMessageLabel.hidden;

        weakSelf.patientsWaitingLabel.hidden = weakSelf.visit.patientsAheadOfConsumer < 0;

        if (weakSelf.visit.patientsAheadOfConsumer == 0) {
            weakSelf.patientsWaitingLabel.text = NSLocalizedString(@"waitingRoom.youAreNext", @"Waiting Room You Are Next Title");
        } else if (weakSelf.visit.patientsAheadOfConsumer == 1) {
            weakSelf.patientsWaitingLabel.text = NSLocalizedString(@"waitingRoom.patientWaiting", @"Waiting Room Patient Waiting Title");
        } else {
            weakSelf.patientsWaitingLabel.text =
                [NSString stringWithFormat:NSLocalizedString(@"waitingRoom.patientsWaiting", @"Waiting Room Patients Waiting Title"), weakSelf.visit.patientsAheadOfConsumer];
        }
        if (!weakSelf.isPhoneVisit) {
            weakSelf.sendTextMessageLabel.text = NSLocalizedString(@"waitingRoom.textMe.title", @"Waiting Room Text Me Title");
        }
    });
}

- (void)presentInsufficientAVPermissionsAlert {
    UIAlertController *alertController =
        [UIAlertController alertControllerWithTitle:NSLocalizedString(@"device.permissions.accessDenied", @"Message expressing alarm, dismay or realization of a difficulty")
                                            message:NSLocalizedString(@"device.permissions.accessDenied.explanation", @"Message explaining that we need camera and mic permissions to start a visit")];
    __weak typeof(self) weakSelf = self;

    UIAlertActionBlock settingsBlock = ^(UIAlertAction *_Nonnull action) {
        AWSDKLogInfo(@"Opening iOS Settings");
        NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
        [UIApplication.sharedApplication openURL:url
                                         options:@{}
                               completionHandler:^(BOOL success) {
                                   AWSDKLogInfo(@"Opened URL ->%@<", url.absoluteString);
                               }];
        [weakSelf dismissViewControllerAnimated:NO completion:nil];
    };

    UIAlertActionBlock cancelBlock = ^(UIAlertAction *_Nonnull action) {
        AWSDKLogInfo(@"Dismissing waiting room");
        [weakSelf dismissViewControllerAnimated:YES completion:nil];
    };

    UIAlertAction *settingsAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.settings", @"Settings button")
                                                             style:UIAlertActionStyleDefault
                                                           handler:[alertController defaultAlertHandler:settingsBlock]];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.no", @"Refusal to change av settings button")
                                                           style:UIAlertActionStyleDestructive
                                                         handler:[alertController defaultAlertHandler:cancelBlock]];
    [alertController addAction:cancelAction];
    [alertController addAction:settingsAction];

    [self presentViewController:alertController
                       animated:YES
                     completion:^{
                         AWSDKLogWarn(@"Presented insufficient AV permissions alert");
                     }];
}

- (void)startBackgroundVisitTimer {
    NSTimeInterval timeoutDuration = [[NSUserDefaults standardUserDefaults] doubleForKey:@"visit_background_timeout"];
    if (timeoutDuration) {
        __weak typeof(self) weakSelf = self;
        self.taskIdentifier = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
            NSLog(@"Task has expired");
            [weakSelf invalidateBackgroundTask];
        }];
        AWSDKLogDebug(@"Starting background timeout timer to execute in %d seconds", (int)timeoutDuration);
        self.backgroundTimeoutTimer = [NSTimer scheduledTimerWithTimeInterval:timeoutDuration target:self selector:@selector(cancelPendingVisitAfterTimeout) userInfo:nil repeats:NO];
    }
}

- (void)invalidateBackgroundTask {
    [[UIApplication sharedApplication] endBackgroundTask:self.taskIdentifier];
    self.taskIdentifier = UIBackgroundTaskInvalid;
}

- (void)scheduleLocalNotificationsForBackgroundVisitTimeout {
    NSTimeInterval timeoutDuration = [[NSUserDefaults standardUserDefaults] doubleForKey:@"visit_background_timeout"];

    if (timeoutDuration) {
        AWSDKLogDebug(@"Scheduling background visit notifications");
        NSMutableArray<NSString *> *notificationsScheduled = @[].mutableCopy;

        // Instant Notification
        UNMutableNotificationContent *instantNotification = [UNMutableNotificationContent new];
        NSString *notificationID = @"waitingRoom.timeout.warning.notification.title";
        instantNotification.title = NSLocalizedString(@"waitingRoom.timeout.warning.notification.title", @"Visit timeout warning title");
        instantNotification.body = [NSString stringWithFormat:NSLocalizedString(@"waitingRoom.timeout.warning.notification.body", @"Visit timeout warning body"), (int)timeoutDuration];
        UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:1 repeats:NO];
        UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:notificationID content:instantNotification trigger:trigger];
        [[UNUserNotificationCenter currentNotificationCenter] addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable error) {
            [notificationsScheduled addObject:notificationID];
        }];

        // 1 minute warning notification
        if (timeoutDuration > 60) {
            UNMutableNotificationContent *oneMinuteWarningNotification = [UNMutableNotificationContent new];
            NSString *notificationID = @"waitingRoom.timeout.warning.notification.title";
            oneMinuteWarningNotification.title = NSLocalizedString(@"waitingRoom.timeout.warning.notification.title", @"Visit timeout warning title");
            oneMinuteWarningNotification.body = [NSString stringWithFormat:NSLocalizedString(@"waitingRoom.timeout.warning.notification.body", @"Visit timeout warning body"), (int)60];
            UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:(timeoutDuration - 60) repeats:NO];
            UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:notificationID content:oneMinuteWarningNotification trigger:trigger];
            [[UNUserNotificationCenter currentNotificationCenter] addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable error) {
                [notificationsScheduled addObject:notificationID];
            }];
        }

        // Visit ended notification
        UNMutableNotificationContent *endedNotification = [UNMutableNotificationContent new];
        notificationID = @"waitingRoom.timeout.reached.notification.title";
        endedNotification.title = NSLocalizedString(@"waitingRoom.timeout.reached.notification.title", @"Visit ended title");
        endedNotification.body = NSLocalizedString(@"waitingRoom.timeout.reached.notification.body", @"Visit ended body");
        trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:timeoutDuration repeats:NO];
        request = [UNNotificationRequest requestWithIdentifier:@"waitingRoom.timeout.warning.notification.title" content:endedNotification trigger:trigger];
        [[UNUserNotificationCenter currentNotificationCenter] addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable error) {
            [notificationsScheduled addObject:notificationID];
        }];

        self.scheduledBackgroundTimeoutNotificationIDs = notificationsScheduled;
    }
}

- (void)cancelLocalNotificationsForBackgroundVisitTimeout {
    AWSDKLogDebug(@"Cancelling background visit notifications");
    [[UNUserNotificationCenter currentNotificationCenter] removePendingNotificationRequestsWithIdentifiers:self.scheduledBackgroundTimeoutNotificationIDs];
    self.scheduledBackgroundTimeoutNotificationIDs = nil;
}

- (NSString *)visitFormattedPhoneNumber {
    NSString *phoneNumber
        = self.visit.overrideFormattedPhoneNumber ?: self.visit.consumer.formattedPhoneNumber ?: self.context.formattedPhoneNumber ?: self.context.consumer.formattedPhoneNumber ?: nil;
    return phoneNumber;
}

#pragma mark - IBAction
- (IBAction)cancelTapped:(id)sender {
    AWSDKLogInfo(@"Cancel nav button tapped");
    NSString *title = NSLocalizedString(@"waitingRoom.cancel.title", @"Waiting Room Cancel Title");
    NSString *message = NSLocalizedString(@"waitingRoom.cancel.message", @"Waiting Room Message Title");
    NSString *confirm = NSLocalizedString(@"waitingRoom.cancel.confirm", @"Waiting Room Confirm Title");
    NSString *cancel = NSLocalizedString(@"waitingRoom.cancel.cancel", @"Waiting Room Cancel Title");
    UIAlertController *cancelAlert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    __weak typeof(self) weakSelf = self;
    UIAlertActionBlock confirmBlock = ^(UIAlertAction *_Nonnull action) {
        [weakSelf cancelPendingVisit];
    };
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:confirm style:UIAlertActionStyleDestructive handler:[cancelAlert defaultAlertHandler:confirmBlock]];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancel style:UIAlertActionStyleDefault handler:[cancelAlert defaultAlertHandler:nil]];
    [cancelAlert addAction:confirmAction];
    [cancelAlert addAction:cancelAction];

    [self presentAlertController:cancelAlert];
}

- (IBAction)sendTextMessageSwitchValueChanged:(id)sender {
    AWSDKLogInfo(@"Text message switch tapped");
    // Setup SMS to the callback number when the provider enters the waiting room and/or consumer has moved up in queue
    if (self.visitFormattedPhoneNumber.length) {
        [MBProgressHUD showSendingOn:self.view];
        [self.visit setupMemberTextToNumber:self.visitFormattedPhoneNumber
                         providerReadyAlert:self.sendTextMessageSwitch.on
                        movedUpInQueueAlert:NO
                                 completion:^(BOOL success, NSError *error) {
                                     [MBProgressHUD hideHUDForView:self.view];
                                 }];
    } else {
        AWSDKLogWarn(@"No phone number available to send text messages");
        [self.sendTextMessageSwitch setOn:NO animated:YES];
    }
}

- (IBAction)unwindFromFirstAvailableSearchSuggestion:(UIStoryboardSegue *)segue {
    __weak typeof(self) weakSelf = self;
    if ([segue.identifier isEqualToString:@"accept"]) {
        [self.visit beginFirstAvailableTransferSearch:^(BOOL success, NSError *error) {
            if (success) {
                [weakSelf toggleFirstAvailableSearchBannerEnabled:YES];
                AWSDKLogDebug(@"Began first available search");
            } else {
                AWSDKLogError(@"There was an error beginning the first available search: %@", error);
            }
        }];
    } else if ([segue.identifier isEqualToString:@"no"]) {
        [self.visit declineFirstAvailableTransferSearch:NO
                                             completion:^(BOOL success, NSError *error) {
                                                 if (success) {
                                                     AWSDKLogDebug(@"Declined first available search");
                                                     [weakSelf toggleFirstAvailableSearchBannerEnabled:NO];
                                                 } else {
                                                     AWSDKLogError(@"There was an error declining the first available search: %@", error);
                                                 }
                                             }];
    } else if ([segue.identifier isEqualToString:@"dontAsk"]) {
        [self.visit declineFirstAvailableTransferSearch:YES
                                             completion:^(BOOL success, NSError *error) {
                                                 if (success) {
                                                     AWSDKLogDebug(@"Declined first available search with don't ask again");
                                                     [weakSelf toggleFirstAvailableSearchBannerEnabled:NO];
                                                 } else {
                                                     AWSDKLogError(@"There was an error declining the first available search with don't ask again: %@", error);
                                                 }
                                             }];
    }
}

#pragma mark - ProviderDetailDelegate
// Called when transfer is accepted
- (void)didStartVisit:(id<AWSDKProvider>)provider {
    [self acceptTransferWithCompletion:nil];
}

- (void)didCancel {
    [self declineTransfer];
}

#pragma mark - UIPopoverPresentationControllerDelegate
- (UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

- (void)popoverPresentationControllerDidDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    if (!self.acceptTransferTapped && !self.declineTransferTapped && (!self.chatController || [self.chatController isBeingDismissed])) {
        [self declineTransfer];
    }

    // Chat text
    [self.chatButton setTitle:NSLocalizedString(@"chat.assistant", @"Waiting Room Chat Assistant Title") forState:UIControlStateNormal];
}

#pragma mark - WarmTransferDelegate

- (void)acceptWarmTransferWithCompletion:(CompletionBlock)completion {
    [self acceptTransferWithCompletion:completion];
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"callbackSegue"]) {
        [(CallbackViewController *)segue.destinationViewController setVisit:self.visit];
    } else if ([segue.identifier isEqualToString:@"wrapUpSegue"]) {
        VisitSummaryTableViewController *temp = (VisitSummaryTableViewController *)segue.destinationViewController;
        temp.showOptionToSendVisitSummary = [AWSDKSystemConfiguration showOptionToSendVisitSummary];
        temp.isEfaxEnabled = [AWSDKSystemConfiguration isEfaxEnabled];
        temp.visit = self.visit;

    } else if ([segue.identifier isEqualToString:@"startVisitSegue"]) {
        [(VisitContextTableViewController *)segue.destinationViewController setContext:sender];
        [(VisitContextTableViewController *)segue.destinationViewController setIsFromFindFirstAvailable:NO];

        if (self.acceptTransferTapped) {
            [(VisitContextTableViewController *)segue.destinationViewController setIsTransfer:YES];
        }

    } else if ([segue.identifier isEqualToString:@"providerDetailSegue"]) {
        ProviderDetailViewController *providerController = (ProviderDetailViewController *)segue.destinationViewController;

        providerController.preferredContentSize = CGSizeMake(self.view.frame.size.width * 0.95, self.view.frame.size.height * 0.95);

        UIPopoverPresentationController *presentationController = segue.destinationViewController.popoverPresentationController;
        [presentationController setDelegate:self];
        presentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 0, 0);
        presentationController.sourceView = self.view;

        [providerController setProvider:sender];
        [providerController setIsTransfer:YES];
        [providerController setDelegate:self];
    } else if ([segue.identifier isEqualToString:@"chatSegue"]) {
        ChatTableViewController *controller = segue.destinationViewController;
        self.chatController = controller;

        UIPopoverPresentationController *presentationController = segue.destinationViewController.popoverPresentationController;
        [presentationController setDelegate:self];

        [controller setVisit:self.visit];
        self.delegate = controller;

        // Adjust chat text
        [self.chatButton setTitle:NSLocalizedString(@"chat.close", @"Chat Close Title") forState:UIControlStateNormal];
    } else if ([segue.identifier isEqualToString:@"warmTransferSegue"]) {
        WarmTransferViewController *warmTransferVC = segue.destinationViewController;
        warmTransferVC.provider = self.transfer.provider;
        warmTransferVC.delegate = self;
    } else if ([segue.identifier isEqualToString:@"visitCost"]) {
        ((CostTableViewController *)segue.destinationViewController).visit = self.visit;
        ((CostTableViewController *)segue.destinationViewController).context = self.context;
    }
}

#pragma mark UpdatePhoneNumberDelegate
- (void)phoneNumberDidUpdate {
    //  Not Needed
}

- (AWSDKAppearanceManager *)randomColorAppearanceManager {
    srand48(time(0));
    AWSDKAppearanceManager *manager = [AWSDKAppearanceManager new];
    manager.cameraOnButtonBackgroundColor = [self randomColor];
    manager.cameraOnButtonTintColor = [self randomColor];
    manager.cameraOffButtonBackgroundColor = [self randomColor];
    manager.cameraOffButtonTintColor = [self randomColor];
    manager.microphoneOnButtonBackgroundColor = [self randomColor];
    manager.microphoneOnButtonTintColor = [self randomColor];
    manager.microphoneOffButtonBackgroundColor = [self randomColor];
    manager.microphoneOffButtonTintColor = [self randomColor];
    manager.cameraSwitchButtonBackgroundColor = [self randomColor];
    manager.cameraSwitchButtonTintColor = [self randomColor];
    manager.buttonsLabelTextColor = [self randomColor];
    manager.demographicsLabelTextColor = [self randomColor];
    manager.drawerItemBackgroundColor = [self randomColor];
    manager.drawerBackgroundColor = [self randomColor];
    manager.drawerInviteButtonBackgroundColor = [self randomColor];
    manager.drawerInviteButtonTintColor = [self randomColor];
    manager.drawerReloadButtonBackgroundColor = [self randomColor];
    manager.drawerReloadButtonTintColor = [self randomColor];
    manager.drawerSpeakerOnButtonBackgroundColor = [self randomColor];
    manager.drawerSpeakerOnButtonTintColor = [self randomColor];
    manager.drawerSpeakerOffButtonBackgroundColor = [self randomColor];
    manager.drawerSpeakerOffButtonTintColor = [self randomColor];
    manager.drawerButtonsLabelTextColor = [self randomColor];
    manager.drawerTytoLiveStreamButtonBackgroundColor = [self randomColor];
    manager.drawerTytoLiveStreamButtonTintColor = [self randomColor];
    manager.sideDrawerBackgroundColor = [self randomColor];
    manager.sideDrawerInviteButtonBackgroundColor = [self randomColor];
    manager.sideDrawerInviteButtonTintColor = [self randomColor];
    manager.sideDrawerReloadButtonBackgroundColor = [self randomColor];
    manager.sideDrawerReloadButtonTintColor = [self randomColor];
    manager.sideDrawerSpeakerOnButtonBackgroundColor = [self randomColor];
    manager.sideDrawerSpeakerOnButtonTintColor = [self randomColor];
    manager.sideDrawerSpeakerOffButtonBackgroundColor = [self randomColor];
    manager.sideDrawerSpeakerOffButtonTintColor = [self randomColor];
    manager.sideDrawerButtonsLabelTextColor = [self randomColor];
    manager.sideDrawerTytoLiveStreamButtonBackgroundColor = [self randomColor];
    manager.sideDrawerTytoLiveStreamButtonTintColor = [self randomColor];
    manager.navigationBarTitleColor = [self randomColor];
    manager.navigationBarTintColor = [self randomColor];
    manager.navigationBarEndButtonBackgroundColor = [self randomColor];
    manager.navigationBarEndButtonTintColor = [self randomColor];
    manager.navigationBarTimerNormalColor = [self randomColor];
    manager.navigationBarTimerEndingColor = [self randomColor];
    manager.guestNavigationBarTitleColor = [self randomColor];
    manager.guestNavigationBarTintColor = [self randomColor];
    manager.guestBadgeTextColor = [self randomColor];
    manager.guestBadgeBackgroundColor = [self randomColor];
    manager.guestAddAnotherButtonTextColor = [self randomColor];
    manager.guestSendInviteButtonTitleColor = [self randomColor];
    manager.guestSendInviteButtonBackgroundColor = [self randomColor];
    manager.deviceLiveStreamPairingButtonBaseColor = [self randomColor];
    manager.deviceLiveStreamPairingButtonHighlightedColor = [self randomColor];
    manager.deviceLiveStreamPairingButtonDisabledColor = [self randomColor];
    manager.deviceLiveStreamPairingSkipButtonBaseColor = [self randomColor];
    manager.deviceLiveStreamPairingSkipButtonHighlightedColor = [self randomColor];
    manager.deviceLiveStreamPairingSkipButtonDisabledColor = [self randomColor];
    return manager;
}

- (UIColor *)randomColor {
    return [[UIColor alloc] initWithRed:drand48() green:drand48() blue:drand48() alpha:drand48()];
}
@end
