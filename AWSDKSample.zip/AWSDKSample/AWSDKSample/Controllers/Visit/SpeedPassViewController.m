//
//  SpeedPassViewController.m
//  AWSDKSample
//
//  Created by Stephen Ciauri on 5/24/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "SpeedPassViewController.h"

#import <AWSDK/AWSDKSpeedPass.h>
#import <AWSDK/AWSDKVisitContext.h>
#import <AWSDK/AWSDKVisitService.h>

@interface SpeedPassViewController ()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@end

@implementation SpeedPassViewController

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.nameLabel.text = [NSString stringWithFormat:NSLocalizedString(@"visit.speedPass.welcomeBack", @"Welcome back, %@!"), self.name];
}

#pragma mark - Actions
- (IBAction)copyInformationTapped:(id)sender {
    AWSDKLogInfo(@"copy information selected");

    typeof(self) __weak weakSelf = self;
    [MBProgressHUD showCreatingOn:self.view];
    [AWSDKVisitService createVisitWithSpeedPass:self.speedPass
                                     completion:^(id<AWSDKVisit> _Nullable visit, NSError *error) {
                                         dispatch_async(dispatch_get_main_queue(), ^{
                                             [MBProgressHUD hideHUDForView:self.view];
                                             if (visit) {
                                                 weakSelf.visit = visit;
                                                 [weakSelf performSegueWithIdentifier:@"acceptedSpeedPass" sender:nil];
                                             } else {
                                                 [weakSelf presentAlertWithError:error okHandler:nil];
                                             }
                                         });
                                     }];
}

@end
