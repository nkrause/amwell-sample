//
//  CallbackViewController.m
//  AWSDKSample
//
//  Created by Jeremiah.Possion on 1/5/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "CallbackViewController.h"

#import "NSPersonNameComponents+Localizing.h"
#import "NSString+Formats.h"
#import "SpinnerControl.h"
#import "VisitSummaryTableViewController.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKLogService.h>
#import <AWSDK/AWSDKVisit.h>
#import <AWSDK/AWSDKVisitService.h>

typedef void (^UIAlertActionBlock)(UIAlertAction *_Nonnull action);

/**
 CallbackViewController is responsible for monitoring the callback process, responding as necessary to the various states returned.
 */
@interface CallbackViewController () <AWSDKCallbackDelegate>

@property (weak, nonatomic) IBOutlet SpinnerControl *spinner;

@property (weak, nonatomic) IBOutlet UILabel *callbackNumberLabel;

@end

@implementation CallbackViewController

#pragma mark - AWSDK Method Calls
/**
 Stop the callback request and clean up any associated processes.
 */
- (void)endCallback {
    [AWSDKVisitService endCallback:self.visit
                    withCompletion:^(BOOL success, NSError *error) {
                        AWSDKLogDebug(@"Callback Request has been stopped. Going to wrapup.");
                        if (!success) {
                            AWSDKLogDebug(@"This will only occur when receving a network error. %@", error.localizedDescription)
                        }

                        [self performSegueWithIdentifier:@"callbackWrapUpSegue" sender:nil];
                    }];
}

/**
 Retry the callback if there was a failure.
 */
- (void)retryCallback {
    [AWSDKVisitService retryCallback:self.visit
                      withCompletion:^(BOOL success, NSError *error) {
                          if (!success) {
                              AWSDKLogDebug(@"An error occured: %@", error.localizedDescription);
                              self.callbackNumberLabel.text = NSLocalizedString(@"callback.start.error", @"Callback Number Title");
                          } else {
                              self.callbackNumberLabel.text = [NSString stringWithFormat:NSLocalizedString(@"callback.monitor.message", @"Callback Monitor Message"),
                                                                        self.visit.overridePhoneNumber.phoneNumberFormat ?: self.visit.consumer.phoneNumber.phoneNumberFormat];
                          }
                      }];
}

#pragma mark - AWSDKCallbackDelegate
/**
 Called when the callback status has been updated.
 */
- (void)callbackStatusDidChange:(AWSDKCallbackStatus)status {
    AWSDKLogDebug(@"Callback status updated to: %@", [self callbackStatusStringRepresentation:status]);
    NSString *alertTitle = NSLocalizedString(@"callback.poll.error.title", @"Alert title - We're sorry");
    NSString *alertMessage;
    switch (status) {
        // Go to wrapup with any of these statuses.
        case AWSDKCallbackStatusProviderFailed:
        case AWSDKCallbackStatusConsumerFailed:
        case AWSDKCallbackStatusConnected:
            [self endCallback];
            break;

        // Failures
        case AWSDKCallbackStatusUnknown:
        case AWSDKCallbackStatusTimeout:
        case AWSDKCallbackStatusConsumerUnreachable: {
            alertMessage = [NSString stringWithFormat:NSLocalizedString(@"callback.poll.error.message", @"Alert message - unable to reach you at %@ (phone number)"),
                                     self.visit.overridePhoneNumber.phoneNumberFormat ?: self.visit.consumer.phoneNumber.phoneNumberFormat];
        }; break;
        case AWSDKCallbackStatusProviderUnreachable: {
            alertMessage = [NSString stringWithFormat:NSLocalizedString(@"callback.poll.error.message.provider", @"Alert message - unable to reach your provider %@ (name)"),
                                     self.visit.provider.nameComponents.localizedFullName];

        }; break;
            // Do nothing on these statuses.
        case AWSDKCallbackStatusRequested:
        case AWSDKCallbackStatusDialingConsumer:
        case AWSDKCallbackStatusDialingProvider:
        case AWSDKCallbackStatusQueued:
        default:
            break;
    }

    if (alertTitle.length && alertMessage.length) {
        UIAlertActionBlock endBlock = ^(UIAlertAction *_Nonnull action) {
            [self endCallback];
        };
        UIAlertActionBlock retryBlock = ^(UIAlertAction *_Nonnull action) {
            [self retryCallback];
        };

        UIAlertController *ac = [UIAlertController alertControllerWithTitle:alertTitle message:alertMessage];
        [ac addAction:[UIAlertAction actionWithTitle:@"End Visit" style:UIAlertActionStyleCancel handler:[ac defaultAlertHandler:endBlock]]];
        [ac addAction:[UIAlertAction actionWithTitle:@"Try Again" style:UIAlertActionStyleDefault handler:[ac defaultAlertHandler:retryBlock]]];

        [self presentAlertController:ac];
    }
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.title = NSLocalizedString(@"callback.navigation.title", @"Callback Title");
    [self.spinner rotateSpinner];
    self.callbackNumberLabel.text = [NSString stringWithFormat:NSLocalizedString(@"callback.monitor.message", @"Callback Phone Number Title"),
                                              self.visit.overridePhoneNumber.phoneNumberFormat ?: self.visit.consumer.phoneNumber.phoneNumberFormat];

    // Add observers for returning from background
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rotateSpinner) name:UIApplicationWillEnterForegroundNotification object:nil];

    self.visit.callbackDelegate = self;
}

- (void)rotateSpinner {
    // used when we observe UIApplicationWillEnterForegroundNotification
    [self.spinner rotateSpinner];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Private methods

/**
 Used for logging purposes only, which is why these strings are not localized.

 @param status AWSDKCallbackStatus enum
 @return Human-readable NSString representation of the callback status
 */
- (NSString *)callbackStatusStringRepresentation:(AWSDKCallbackStatus)status {
    switch (status) {
        case AWSDKCallbackStatusRequested:
            return @"Requested.";
        case AWSDKCallbackStatusDialingConsumer:
            return @"Dialing consumer.";
        case AWSDKCallbackStatusDialingProvider:
            return @"Dialing provider.";
        case AWSDKCallbackStatusProviderFailed:
            return @"Connect to provider failed.";
        case AWSDKCallbackStatusConsumerFailed:
            return @"Connect to consumer failed.";
        case AWSDKCallbackStatusConnected:
            return @"Connected, go to wrap up.";
        case AWSDKCallbackStatusTimeout:
            return @"Timeout.";
        case AWSDKCallbackStatusConsumerUnreachable:
            return @"Consumer unreachable.";
        case AWSDKCallbackStatusProviderUnreachable:
            return @"Provider unreachable.";
        case AWSDKCallbackStatusQueued:
            return @"Callback queued";
        case AWSDKCallbackStatusUnknown:
        default:
            return @"Unknown.";
    }
}

- (IBAction)endVisit:(UIButton *)sender {
    [self presentAlertWithMessageKey:@"callback.end.message"
                          yesHandler:^(UIAlertAction *action) {
                              [self endCallback];
                          }];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"callbackWrapUpSegue"]) {
        VisitSummaryTableViewController *temp = (VisitSummaryTableViewController *)segue.destinationViewController;
        temp.showOptionToSendVisitSummary = [AWSDKSystemConfiguration showOptionToSendVisitSummary];
        temp.isEfaxEnabled = [AWSDKSystemConfiguration isEfaxEnabled];
        temp.visit = self.visit;
    }
}
@end
