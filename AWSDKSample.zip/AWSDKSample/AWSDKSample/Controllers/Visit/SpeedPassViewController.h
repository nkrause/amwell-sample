//
//  SpeedPassViewController.h
//  AWSDKSample
//
//  Created by Stephen Ciauri on 5/24/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

@protocol AWSDKSpeedPass
, AWSDKVisit, AWSDKVisitContext;

@interface SpeedPassViewController : UIViewController

/**
 The name of the user to display in the "welcome" greeting
 */
@property (nonatomic) NSString *name;

/**
 The AWSDKSpeedPass to be used
 */
@property (nonatomic) id<AWSDKSpeedPass> speedPass;

/**
 The AWSDKVisit returned by SpeedPass
 */
@property (nonatomic) id<AWSDKVisit> visit;

/**
 The AWSDKVisitContext from the transfer referenced by SpeedPass

 @discussion This is utilized if the SpeedPass suggestion is declined by the user.
 */
@property (nonatomic) id<AWSDKVisitContext> visitContext;

@end
