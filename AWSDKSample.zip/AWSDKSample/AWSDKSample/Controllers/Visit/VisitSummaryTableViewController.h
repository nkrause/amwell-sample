//
//  VisitSummaryTableViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 6/1/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//
@protocol AWSDKVisit;

@interface VisitSummaryTableViewController : UITableViewController

// Set by WaitingRoomViewController
@property (nonatomic) id<AWSDKVisit> visit;
@property (nonatomic) BOOL showOptionToSendVisitSummary;
@property (nonatomic) BOOL isEfaxEnabled;

@end
