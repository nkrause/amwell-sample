//
//  HIPAAViewController.m
//  AWSDKSample
//
//  Created by Matt Labush on 6/26/17.
//  Copyright © 2017 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "HIPAAViewController.h"

@implementation HIPAAViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    [self.webView loadHTMLString:self.notice baseURL:nil];
}

@end
