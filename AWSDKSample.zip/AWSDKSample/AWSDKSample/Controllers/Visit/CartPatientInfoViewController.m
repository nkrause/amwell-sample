//
//  CartPatientTableViewController.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 10/10/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "CartPatientInfoViewController.h"

#import "CartVisitTopicsViewController.h"
#import "DatePickerCell.h"
#import "NSDateFormatter+CommonFormats.h"
#import "PickerTableViewCell.h"
#import "TitleTextFieldTableViewCell.h"

#import <AWSDK/AWSDKAddress.h>
#import <AWSDK/AWSDKConsumerOverrides.h>
#import <AWSDK/AWSDKCountry.h>
#import <AWSDK/AWSDKState.h>
#import <AWSDK/AWSDKSubscription.h>
#import <AWSDK/AWSDKSystemConfiguration.h>

@interface CartPatientInfoViewController () <UITableViewDelegate, UITableViewDataSource, TextFieldTableViewCellDelegate, UIPickerViewDataSource, UIPickerViewDelegate>

typedef NS_ENUM(NSUInteger, CartPatientRow) {
    MrnRow,
    FirstNameRow,
    LastNameRow,
    GenderRow,
    DOBRow,
    EmailRow,
    PhoneRow,
    Address1Row,
    Address2Row,
    CityRow,
    StateRow,
    ZipCodeRow,
    ROWCOUNT,
};

#pragma mark - IBOutlets
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *submitButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *skipButton;

@property (nonatomic) NSIndexPath *pickerIndexPath;
@property (nonatomic) NSIndexPath *datePickerIndexPath;
@property (nonatomic) NSIndexPath *editingIndexPath;
@property (nonatomic) NSIndexPath *becomeFirstReponderIndexPath;
@property (assign, nonatomic) BOOL pickerVisible;
@property (assign, nonatomic) BOOL genericPickerVisible;
@property (assign, nonatomic) BOOL datePickerVisible;
@property (nonatomic) AWSDKConsumerOverrides *consumerOverrides;
@property (nonatomic) AWSDKAddress *address;
@property (nonatomic) id<AWSDKCountry> selectedAddressCountry;
@property (nonatomic) id<AWSDKState> selectedAddressState;
@property (nonatomic) NSArray<NSString *> *genders;
@property (nonatomic) UIPickerView *genericPicker;
@property (nonatomic) UIDatePicker *datePicker;
@property (nonatomic) NSDateFormatter *dateFormatter;

@end

@implementation CartPatientInfoViewController

#pragma mark - AWSDK Method Calls

#pragma mark - View Lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];

    self.consumerOverrides = [AWSDKConsumerOverrides new];
    self.consumerOverrides.address = [AWSDKAddress address];
    self.consumerOverrides.nameComponents = [NSPersonNameComponents new];
    self.genders = @[ @"", NSLocalizedString(@"enrollment.male", @"Biological Sex - Male"), NSLocalizedString(@"enrollment.female", @"Biological Sex - Female") ];

    [self.skipButton setTitle:NSLocalizedString(@"cartPatientInfo.skip.title", @"Cart Patient Info Skip Title")];

    self.navigationItem.hidesBackButton = NO;
    self.dateFormatter = [NSDateFormatter mediumDateFormatter];
    for (id<AWSDKCountry> country in AWSDKEnrollmentService.countries) {
        if ([country isEqual:self.context.consumer.address.country]) {
            self.selectedAddressCountry = country;
            break;
        }
    }

    [self setupKeyboardNotifications];
}

- (BOOL)pickerVisible {
    return self.genericPickerVisible || self.datePickerVisible;
}

- (BOOL)genericPickerVisible {
    return self.pickerIndexPath != nil;
}

- (BOOL)datePickerVisible {
    return self.datePickerIndexPath != nil;
}

#pragma mark - TableView Data Source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return (self.genericPickerVisible || self.datePickerVisible) ? ROWCOUNT + 1 : ROWCOUNT;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.genericPickerVisible && self.pickerIndexPath == indexPath) {
        PickerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"pickerCell" forIndexPath:indexPath];
        self.genericPicker = cell.picker;
        NSInteger row = [self calculateTagForIndexPath:indexPath];
        NSInteger matchedRow;
        cell.picker.dataSource = self;
        cell.picker.delegate = self;
        cell.picker.tag = row;

        switch (row) {
            case GenderRow:
                cell.label.text = NSLocalizedString(@"cartPatientInfo.Gender.title", @"Gender title");
                break;
            case StateRow:
                cell.label.text = NSLocalizedString(@"cartPatientInfo.State.title", @"State title");
                matchedRow = [self.selectedAddressCountry.states indexOfObject:self.consumerOverrides.address.state];
                [cell.picker selectRow:(matchedRow != NSNotFound) ? matchedRow : 0 inComponent:0 animated:NO];
                break;
            default:
                break;
        }

        return cell;
    } else if (self.datePickerVisible && self.datePickerIndexPath == indexPath) {
        DatePickerCell *cell = [tableView dequeueReusableCellWithIdentifier:@"datePickerCell" forIndexPath:indexPath];
        self.datePicker = cell.datePicker;
        NSInteger row = [self calculateTagForIndexPath:indexPath];

        switch (row) {
            case DOBRow:
                cell.label.text = NSLocalizedString(@"cartPatientInfo.DOB.title", @"DOB title");
                cell.datePicker.date = (self.consumerOverrides.dateOfBirth) ?: [NSDate date];
                cell.datePicker.maximumDate = [NSDate date];
                cell.datePicker.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
                cell.datePicker.tag = row;
                break;
            default:
                break;
        }

        return cell;
    } else {
        TitleTextFieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"titleTextCell" forIndexPath:indexPath];
        cell.tag = [self calculateTagForIndexPath:indexPath];
        cell.delegate = self;
        cell.textField.keyboardType = UIKeyboardTypeDefault;
        cell.textField.returnKeyType = UIReturnKeyNext;
        cell.textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        cell.textField.autocorrectionType = UITextAutocorrectionTypeNo;
        cell.textField.text = @"";
        cell.textField.tag = cell.tag;

        switch (indexPath.row) {
            case MrnRow:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.MRN.title", @"Medical Record Number title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.MRN.placeholder", @"Medical Record Number placeholder");
                cell.textField.text = self.consumerOverrides.mrnId;
                cell.textField.keyboardType = UIKeyboardTypeNumberPad;
                cell.textField.userInteractionEnabled = YES;
                break;
            case FirstNameRow:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.FirstName.title", @"First Name title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.FirstName.placeholder", @"First Name placeholder");
                cell.textField.text = self.consumerOverrides.nameComponents.givenName;
                cell.textField.autocapitalizationType = UITextAutocapitalizationTypeWords;
                cell.textField.textContentType = UITextContentTypeGivenName;
                cell.textField.userInteractionEnabled = YES;
                break;
            case LastNameRow:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.LastName.title", @"Last Name title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.LastName.placeholder", @"Last Name placeholder");
                cell.textField.text = self.consumerOverrides.nameComponents.familyName;
                cell.textField.autocapitalizationType = UITextAutocapitalizationTypeWords;
                cell.textField.textContentType = UITextContentTypeFamilyName;
                cell.textField.userInteractionEnabled = YES;
                break;
            case GenderRow:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.Gender.title", @"Gender title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.Gender.placeholder", @"Gender placeholder");
                if (self.consumerOverrides.gender != AWSDKBiologicalSexNotSet) {
                    cell.textField.text
                        = (self.consumerOverrides.gender == AWSDKBiologicalSexFemale) ? NSLocalizedString(@"enrollment.female", @"Enrollment Female Gender") : NSLocalizedString(@"enrollment.male", @"Enrollment Male Gender");
                }
                cell.textField.userInteractionEnabled = NO;
                break;
            case DOBRow:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.DOB.title", @"DOB title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.DOB.placeholder", @"DOB placeholder");
                cell.textField.userInteractionEnabled = NO;
                if (self.consumerOverrides.dateOfBirth) {
                    cell.textField.text = [self.dateFormatter stringFromDate:self.consumerOverrides.dateOfBirth];
                }
                break;
            case EmailRow:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.Email.title", @"Email title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.Email.placeholder", @"Email placeholder");
                cell.textField.text = self.consumerOverrides.email;
                cell.textField.keyboardType = UIKeyboardTypeEmailAddress;
                cell.textField.textContentType = UITextContentTypeEmailAddress;
                cell.textField.userInteractionEnabled = YES;
                break;
            case PhoneRow:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.Phone.title", @"Phone title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.Phone.placeholder", @"Phone placeholder");
                cell.textField.text = self.consumerOverrides.phoneNumber;
                cell.textField.keyboardType = UIKeyboardTypePhonePad;
                cell.textField.textContentType = UITextContentTypeTelephoneNumber;
                cell.textField.userInteractionEnabled = YES;
                break;
            case Address1Row:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.Address1.title", @"Address1 title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.Address1.placeholder", @"Address1 placeholder");
                cell.textField.text = self.consumerOverrides.address.addressOne;
                cell.textField.autocapitalizationType = UITextAutocapitalizationTypeWords;
                cell.textField.textContentType = UITextContentTypeStreetAddressLine1;
                cell.textField.userInteractionEnabled = YES;
                break;
            case Address2Row:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.Address2.title", @"Address2 title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.Address2.placeholder", @"Address2 placeholder");
                cell.textField.text = self.consumerOverrides.address.addressTwo;
                cell.textField.autocapitalizationType = UITextAutocapitalizationTypeWords;
                cell.textField.textContentType = UITextContentTypeStreetAddressLine2;
                cell.textField.userInteractionEnabled = YES;
                break;
            case CityRow:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.City.title", @"City title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.City.placeholder", @"City placeholder");
                cell.textField.text = self.consumerOverrides.address.city;
                cell.textField.autocapitalizationType = UITextAutocapitalizationTypeWords;
                cell.textField.textContentType = UITextContentTypeAddressCity;
                cell.textField.userInteractionEnabled = YES;
                break;
            case StateRow:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.State.title", @"State title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.State.placeholder", @"State placeholder");
                cell.textField.text = self.consumerOverrides.address.state.name;
                cell.textField.userInteractionEnabled = NO;
                break;
            case ZipCodeRow:
                cell.titleLabel.text = NSLocalizedString(@"cartPatientInfo.ZipCode.title", @"Zip Code title");
                cell.textField.placeholder = NSLocalizedString(@"cartPatientInfo.ZipCode.placeholder", @"Zip Code placeholder");
                cell.textField.text = self.consumerOverrides.address.zip;
                cell.textField.keyboardType = UIKeyboardTypeNamePhonePad;
                cell.textField.textContentType = UITextContentTypePostalCode;
                cell.textField.userInteractionEnabled = YES;
            default:
                break;
        }
        return cell;
    }
}

#pragma mark - TableView Delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];

    if (self.editingIndexPath) {
        [self dismissPickers];
        [self.tableView reloadData];
    } else if ([self pickerShouldAppearForRowSelectionAtIndexPath:indexPath]) {
        self.editingIndexPath = indexPath;
        [self.view endEditing:YES];
        [self.tableView beginUpdates];
        if (self.genericPickerVisible) {
            // Close picker
            [self.tableView deleteRowsAtIndexPaths:@[ self.pickerIndexPath ] withRowAnimation:UITableViewRowAnimationFade];
            NSIndexPath *oldPickerIndexPath = self.pickerIndexPath;
            if ([self pickerIsRightBelowMe:indexPath]) {
                // close picker
                self.pickerIndexPath = nil;
            } else {
                // open it at new location
                NSInteger newRow = (oldPickerIndexPath.row < indexPath.row) ? indexPath.row : indexPath.row + 1;
                self.pickerIndexPath = [NSIndexPath indexPathForRow:newRow inSection:indexPath.section];
                [self.tableView insertRowsAtIndexPaths:@[ self.pickerIndexPath ] withRowAnimation:UITableViewRowAnimationFade];
            }
        } else {
            self.pickerIndexPath = [NSIndexPath indexPathForRow:indexPath.row + 1 inSection:indexPath.section];
            [self.tableView insertRowsAtIndexPaths:@[ self.pickerIndexPath ] withRowAnimation:UITableViewRowAnimationFade];
        }
        [self.tableView endUpdates];
        [self.tableView reloadData];
        [self pickerWillShowOfSize:CGSizeMake(343.0, 200.0)];
    } else if ([self datePickerShouldAppearForRowSelectionAtIndexPath:indexPath]) {
        self.editingIndexPath = indexPath;
        [self.view endEditing:YES];
        [self.tableView beginUpdates];
        if (self.datePickerVisible) {
            // Close datepicker
            [self.tableView deleteRowsAtIndexPaths:@[ self.datePickerIndexPath ] withRowAnimation:UITableViewRowAnimationFade];
            NSIndexPath *oldDatePickerIndexPath = self.datePickerIndexPath;
            if ([self datePickerIsRightBelowMe:indexPath]) {
                // close date picker
                self.datePickerIndexPath = nil;
            } else {
                // open it at new location
                NSInteger newRow = (oldDatePickerIndexPath.row < indexPath.row) ? indexPath.row : indexPath.row + 1;
                self.datePickerIndexPath = [NSIndexPath indexPathForRow:newRow inSection:indexPath.section];
                [self.tableView insertRowsAtIndexPaths:@[ self.datePickerIndexPath ] withRowAnimation:UITableViewRowAnimationFade];
            }
        } else {
            self.datePickerIndexPath = [NSIndexPath indexPathForRow:indexPath.row + 1 inSection:indexPath.section];
            [self.tableView insertRowsAtIndexPaths:@[ self.datePickerIndexPath ] withRowAnimation:UITableViewRowAnimationFade];
        }
        [self.tableView endUpdates];
        [self.tableView reloadData];
        [self pickerWillShowOfSize:CGSizeMake(343.0, 200.0)];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.pickerIndexPath == indexPath) {
        return 200.0f;
    }
    if (self.datePickerIndexPath == indexPath) {
        return 200.0f;
    } else {
        return UITableViewAutomaticDimension;
    }
}

#pragma mark - ScrollViewDelegate
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    CGPoint translation = [scrollView.panGestureRecognizer translationInView:scrollView.superview];
    if (fabs(translation.y) > 2) {
        [self dismissPickers];
        [self dismissKeyboard];
    }
}

#pragma mark - UITextField Delegate
- (void)textDidBeginEditing:(UITextField *)textField {
    AWSDKLogInfo(@"textDidBeginEditing called. text =>%@<", textField.text);

    if (self.pickerVisible) {
        [self dismissPickers];
        [self.tableView reloadData];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    textField.text = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    AWSDKLogInfo(@"textFieldDidEndEditing called. text =>%@<", textField.text);

    [self dismissKeyboard];
}

- (BOOL)textDidReturn:(UITextField *)textField {
    AWSDKLogInfo(@"textFieldDidEndEditing called. text =>%@<", textField.text);

    NSInteger nextIndex = (textField.tag + 1 < ROWCOUNT) ? textField.tag + 1 : 0;
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:nextIndex inSection:0];
    self.becomeFirstReponderIndexPath = indexPath;
    [self.tableView reloadRowsAtIndexPaths:@[ indexPath ] withRowAnimation:UITableViewRowAnimationFade];

    return YES;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    AWSDKLogInfo(@"tableView:willDisplayCell:forRowAtIndexPath called.");

    if (self.becomeFirstReponderIndexPath && [indexPath isEqual:self.becomeFirstReponderIndexPath]) {
        TitleTextFieldTableViewCell *aCell = (TitleTextFieldTableViewCell *)cell;
        AWSDKLogDebug(@"Calling becomeFirstResponder.");
        [aCell.textField becomeFirstResponder];
        [self tableView:self.tableView didSelectRowAtIndexPath:indexPath];
        self.becomeFirstReponderIndexPath = nil;
    }
}

#pragma mark - TextFieldTableViewCell Delegate
- (void)textDidChange:(NSString *)text inCell:(UITableViewCell *)cell {
    AWSDKLogInfo(@"textDidChange:inCell called. text =>%@<", text);

    switch (cell.tag) {
        case MrnRow:
            self.consumerOverrides.mrnId = [text copy];
            break;
        case FirstNameRow:
            self.consumerOverrides.nameComponents.givenName = [text copy];
            break;
        case LastNameRow:
            self.consumerOverrides.nameComponents.familyName = [text copy];
            break;
        case GenderRow:
            self.consumerOverrides.gender = [[text lowercaseString] containsString:@"f"] ? AWSDKBiologicalSexFemale : AWSDKBiologicalSexMale;
            break;
        case DOBRow:
            break;
        case EmailRow:
            self.consumerOverrides.email = [text copy];
            break;
        case PhoneRow:
            self.consumerOverrides.phoneNumber = [text copy];
            break;
        case Address1Row:
            self.consumerOverrides.address.addressOne = [text copy];
            break;
        case Address2Row:
            self.consumerOverrides.address.addressTwo = [text copy];
            break;
        case CityRow:
            self.consumerOverrides.address.city = [text copy];
            break;
        case StateRow:
            break;
        case ZipCodeRow:
            self.consumerOverrides.address.zip = [text copy];
            break;
        default:
            break;
    }
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    switch (pickerView.tag) {
        case GenderRow:
            return self.genders.count;
        case StateRow:
            return self.selectedAddressCountry.states.count;
        default:
            return 0;
    }
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *label = (UILabel *)view;
    if (!label) {
        label = [[UILabel alloc] init];
        [label setFont:[UIFont systemFontOfSize:21.0 weight:UIFontWeightLight]];
        [label setTextAlignment:NSTextAlignmentCenter];
        [label setAdjustsFontSizeToFitWidth:YES];
        [label setNumberOfLines:0];
    }

    NSString *text = nil;
    switch (pickerView.tag) {
        case GenderRow:
            text = self.genders[row];
            break;
        case StateRow:
            text = self.selectedAddressCountry.states[row].name;
            break;
        default:
            text = @"";
    }

    label.text = text;
    return label;
}

#pragma mark - UIPickerViewDelegate
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    NSString *text = nil;
    NSString *pickerName = nil;
    BOOL needsUpdate = NO;
    switch (pickerView.tag) {
        case GenderRow:
            text = self.genders[row];
            self.consumerOverrides.gender =
                [[text lowercaseString] containsString:@"f"] ? AWSDKBiologicalSexFemale : [[text lowercaseString] containsString:@"m"] ? AWSDKBiologicalSexMale : AWSDKBiologicalSexNotSet;
            pickerName = @"gender";
            needsUpdate = YES;
            break;
        case StateRow:
            text = self.selectedAddressCountry.states[row].name;
            pickerName = @"address state";
            if (!self.consumerOverrides.address) {
                self.consumerOverrides.address = [AWSDKAddress address];
            }
            self.selectedAddressState = self.selectedAddressCountry.states[row];
            self.consumerOverrides.address.state = self.selectedAddressState;
            needsUpdate = YES;
            break;
        default:
            text = @"UNKNOWN";
            pickerName = @"UNKNOWN";
    }
    if (needsUpdate && self.editingIndexPath) {
        [self.tableView reloadRowsAtIndexPaths:@[ self.editingIndexPath ] withRowAnimation:UITableViewRowAnimationNone];
    }

    AWSDKLogInfo(@"Selected %@ in %@ picker", text, pickerName);
}

#pragma mark - IBActions
- (IBAction)datePickerChanged:(id)sender {
    UIDatePicker *picker = sender;
    AWSDKLogInfo(@"datePickerChanged: called. date =>%@<", picker.date);

    self.consumerOverrides.dateOfBirth = picker.date;
    [self.tableView reloadData];
}

- (IBAction)cancelButtonTapped:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Handle keyboard Notifications

- (void)keyboardWillShow:(NSNotification *)notification {
    CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;

    UIEdgeInsets contentInsets;
    if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])) {
        contentInsets = UIEdgeInsetsMake(0.0, 0.0, (keyboardSize.height), 0.0);
    } else {
        contentInsets = UIEdgeInsetsMake(0.0, 0.0, (keyboardSize.width), 0.0);
    }

    NSNumber *rate = notification.userInfo[UIKeyboardAnimationDurationUserInfoKey];
    [UIView animateWithDuration:rate.floatValue
                     animations:^{
                         self.tableView.contentInset = contentInsets;
                         self.tableView.scrollIndicatorInsets = contentInsets;
                     }];
    [self.tableView scrollToRowAtIndexPath:self.editingIndexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

- (void)keyboardWillHide:(NSNotification *)notification {
    NSNumber *rate = [NSNumber numberWithFloat:0.3];
    [UIView animateWithDuration:rate.floatValue
                     animations:^{
                         self.tableView.contentInset = UIEdgeInsetsZero;
                         self.tableView.scrollIndicatorInsets = UIEdgeInsetsZero;
                     }];
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"newPatientDetailsSegue"]) {
        ((CartVisitTopicsViewController *)segue.destinationViewController).context = self.context;
        ((CartVisitTopicsViewController *)segue.destinationViewController).consumerOverrideDetails = self.consumerOverrides;
    } else if ([segue.identifier isEqualToString:@"skipPatientDetailsSegue"]) {
        ((CartVisitTopicsViewController *)segue.destinationViewController).context = self.context;
    }
}

#pragma mark - Private Methods

- (void)pickerWillShowOfSize:(CGSize)pickerSize {
    UIEdgeInsets contentInsets;
    if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])) {
        contentInsets = UIEdgeInsetsMake(0.0, 0.0, (pickerSize.height), 0.0);
    } else {
        contentInsets = UIEdgeInsetsMake(0.0, 0.0, (pickerSize.width), 0.0);
    }

    NSNumber *rate = [NSNumber numberWithFloat:0.3];
    [UIView animateWithDuration:rate.floatValue
                     animations:^{
                         self.tableView.contentInset = contentInsets;
                         self.tableView.scrollIndicatorInsets = contentInsets;
                     }];
    [self.tableView scrollToRowAtIndexPath:self.editingIndexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

- (void)pickerWillHide {
    NSNumber *rate = [NSNumber numberWithFloat:0.3];
    [UIView animateWithDuration:rate.floatValue
                     animations:^{
                         self.tableView.contentInset = UIEdgeInsetsZero;
                         self.tableView.scrollIndicatorInsets = UIEdgeInsetsZero;
                     }];
}

- (NSInteger)calculateTagForIndexPath:(NSIndexPath *)indexPath {
    if (self.genericPickerVisible) {
        if (self.pickerIndexPath.row == indexPath.row) {
            return indexPath.row - 1;
        } else if (self.pickerIndexPath.row > indexPath.row) {
            return indexPath.row;
        } else {
            return indexPath.row - 1;
        }
    } else if (self.datePickerVisible) {
        if (self.datePickerIndexPath.row == indexPath.row) {
            return indexPath.row - 1;
        } else if (self.datePickerIndexPath.row > indexPath.row) {
            return indexPath.row;
        } else {
            return indexPath.row - 1;
        }
    } else {
        return indexPath.row;
    }
}

- (BOOL)datePickerShouldAppearForRowSelectionAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger row = [self calculateTagForIndexPath:indexPath];
    switch (row) {
        case DOBRow:
            return YES;
        default:
            return NO;
    }
}

- (BOOL)pickerShouldAppearForRowSelectionAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger row = [self calculateTagForIndexPath:indexPath];
    switch (row) {
        case GenderRow:
        case StateRow:
            return YES;
        default:
            return NO;
    }
}

- (void)dismissPickerRow {
    if (self.genericPickerVisible) {
        [self.tableView beginUpdates];
        [self.tableView deleteRowsAtIndexPaths:@[ self.pickerIndexPath ] withRowAnimation:UITableViewRowAnimationFade];
        self.pickerIndexPath = nil;
        [self.tableView endUpdates];
    }
}

- (BOOL)pickerIsRightAboveMe:(NSIndexPath *)indexPath {
    if (self.genericPickerVisible && self.pickerIndexPath.section == indexPath.section) {
        if (indexPath.section != self.pickerIndexPath.section) {
            return NO;
        }
        return (indexPath.row == self.pickerIndexPath.row + 1);
    }
    return NO;
}

- (BOOL)pickerIsRightBelowMe:(NSIndexPath *)indexPath {
    if (self.genericPickerVisible && self.pickerIndexPath.section == indexPath.section) {
        if (indexPath.section != self.pickerIndexPath.section) {
            return NO;
        }
        return (indexPath.row == self.pickerIndexPath.row - 1);
    }
    return NO;
}

- (void)dismissPickers {
    [self dismissPickerRow];
    [self dismissDatePickerRow];
    [self pickerWillHide];
    self.editingIndexPath = nil;
}

- (void)dismissDatePickerRow {
    if (self.datePickerVisible) {
        [self.tableView beginUpdates];
        [self.tableView deleteRowsAtIndexPaths:@[ self.datePickerIndexPath ] withRowAnimation:UITableViewRowAnimationFade];
        self.datePickerIndexPath = nil;
        [self.tableView endUpdates];
    }
}

- (BOOL)datePickerIsRightAboveMe:(NSIndexPath *)indexPath {
    if (self.datePickerVisible && self.datePickerIndexPath.section == indexPath.section) {
        if (indexPath.section != self.datePickerIndexPath.section) {
            return NO;
        }
        return (indexPath.row == self.datePickerIndexPath.row + 1);
    }
    return NO;
}

- (BOOL)datePickerIsRightBelowMe:(NSIndexPath *)indexPath {
    if (self.datePickerVisible && self.datePickerIndexPath.section == indexPath.section) {
        if (indexPath.section != self.datePickerIndexPath.section) {
            return NO;
        }
        return (indexPath.row == self.datePickerIndexPath.row - 1);
    }
    return NO;
}

- (void)setupKeyboardNotifications {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

@end
