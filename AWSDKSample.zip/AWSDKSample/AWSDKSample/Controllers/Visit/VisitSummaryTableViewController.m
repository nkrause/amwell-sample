//
//  VisitSummaryTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 6/1/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "VisitSummaryTableViewController.h"

#import "HIPAAViewController.h"
#import "KeyboardFieldAndSwitchTableViewCell.h"
#import "NSString+Sample.h"
#import "RatingTableViewCell.h"
#import "SubtitleTableViewCell.h"
#import "SwitchTableViewCell.h"
#import "TitleTextFieldTableViewCell.h"
#import "UITableView+Sample.h"
#import "WebviewCell.h"

#import <AWSDK/AWSDK.h>
#import <AWSDK/AWSDKHealthPlan.h>
#import <AWSDK/NSNumberFormatter+Extensions.h>

typedef NS_ENUM(NSUInteger, VisitSummarySections) {
    HeaderSection,
    CostSection,
    ProviderNotesSection,
    DiagnosesSection,
    ProceduresSection,
    PrescriptionsSection,
    FollowUpItemsSection,
    FeedbackQuestionSection,
    ProviderRatingsSection,
    EmailSummarySection,
    FaxSummarySection,
    ShareDisclaimerSection,
};

typedef NS_ENUM(NSUInteger, HeaderSectionCell) {
    ConcludeMessage,
    VisitSuppressCostMessage,
};

typedef NS_ENUM(NSUInteger, CostSectionCell) {
    VisitCost,
    VisitZeroCostMessage,
};

@interface SharedEmail : NSObject

@property (assign, nonatomic) BOOL shared;
@property (nonatomic) NSString *emailAddress;

@end

@implementation SharedEmail

@end

/*
 * VisitSummaryTableViewController displays any feedback sent by the provider.
 * Also handles ratings and feedback questionaire if available
 */
@interface VisitSummaryTableViewController () <UIWebViewDelegate, KeyboardFieldTableViewCellDelegate, KeyboardFieldAndSwitchTableViewCellDelegate>

@property (nonatomic) id<AWSDKVisitSummary> visitSummary;

@property (nonatomic) NSMutableArray<SharedEmail *> *enteredEmails;
@property (nonatomic) NSMutableArray<NSString *> *sharedFaxNumbers;

@property (nonatomic) UIWebView *notesWebView;

@property (assign, nonatomic) BOOL visitSummarySubmitted;
@property (assign, nonatomic) BOOL acceptHIPAASelected;

@property (assign, nonatomic) CGFloat webviewHeight;
@property (assign, nonatomic) NSInteger selectedFeedbackAnswer;

@property (nonatomic) RatingTableViewCell *providerRatingCell;
@property (nonatomic) RatingTableViewCell *visitRatingCell;
@property (nonatomic) KeyboardFieldTableViewCell *emailSummaryCell;
@property (nonatomic) KeyboardFieldTableViewCell *faxSummaryCell;
@property (assign, nonatomic, readonly) BOOL suppressCharge;

@end

@implementation VisitSummaryTableViewController

#pragma mark AWSDK Methods Calls
/*
 * Fetches visit summary for a given visit
 */
- (void)fetchVisitSummaryWithVisit:(id<AWSDKVisit>)visit {
    [MBProgressHUD showLoadingOn:self.view];

    [visit fetchVisitSummary:^(id result, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (result) {
            // Save visitSummary
            self.visitSummary = result;
            // Set no selection for answer
            if (self.visitSummary.feedbackQuestion) {
                [self.visitSummary.feedbackQuestion setSelectedOption:-1];
            }
            // Email array to send summaries to
            self.enteredEmails = [NSMutableArray new];
            for (NSString *email in self.visitSummary.visitInviteEmails) {
                SharedEmail *sharedEmail = [SharedEmail new];
                sharedEmail.shared = YES;
                sharedEmail.emailAddress = email;
                [self.enteredEmails addObject:sharedEmail];
            }
            // Fax array to send summaries to
            self.sharedFaxNumbers = [NSMutableArray new];
            // Reload the table to display data
            [self.tableView reloadDataAnimated:YES];
        } else if (error) {
            // Error handling
            __weak typeof(self) weakSelf = self;
            [self presentAlertWithError:error
                              okHandler:^(UIAlertAction *action) {
                                  [weakSelf dismissViewControllerAnimated:YES completion:nil];
                              }];
        }
    }];
}

/*
 * Submits the current selected answer for feedback
 */
- (void)submitFeedbackAnswer {
    if (self.visitSummarySubmitted || self.visit.modality.code == AWSDKModalityCodePhone) {
        // if we try to PUT after the summary has been set, the server returns a 409 error status.
        [self submitRating];
    } else if (self.selectedFeedbackAnswer >= 0 && self.selectedFeedbackAnswer < self.visitSummary.feedbackQuestion.responseOptions.count) {
        // check if the selectedFeedbackAnswer has been set.  Its -1 if it isn't set.
        self.visitSummary.feedbackQuestion.selectedOption = self.selectedFeedbackAnswer;
        [MBProgressHUD showSendingOn:self.view];
        [self.visitSummary submitFeedbackQuestion:^(BOOL success, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view];
            if (success) {
                self.visitSummarySubmitted = YES;
                [self submitRating];
            } else {
                [self presentAlertWithError:error okHandler:nil];
            }
        }];
    } else {
        [self presentAlertWithMessageKey:@"visitSummary.feedback.none" okHandler:nil];
    }
}

/*
 * Submits the current ratings
 */
- (void)submitRating {
    // Case where ratings are required
    if (![self endVisitRatingsSatisfied]) {
        [self presentAlertWithMessageKey:@"visitSummary.rating.none" okHandler:nil];
        // Case where no ratings selected, dismiss the view controller
    } else if ([self.visitSummary endVisitRatingsOptional] && (![self.providerRatingCell.rating integerValue] && ![self.visitRatingCell.rating integerValue])) {
        [self sendSummaryToShareEmails];
    } else {
        // Ratings exist, send ratings
        [MBProgressHUD showUpdatingOn:self.view];
        [self.visitSummary rateProvider:[self.providerRatingCell.rating integerValue] > 0 ? self.providerRatingCell.rating : nil
                             engagement:[self.visitRatingCell.rating integerValue] > 0 ? self.visitRatingCell.rating : nil
                         withCompletion:^(BOOL success, NSError *error) {
                             [MBProgressHUD hideHUDForView:self.view];
                             if (success) {
                                 [self sendSummaryToShareEmails];
                             } else if (error) {
                                 [self presentAlertWithError:error okHandler:nil];
                             }
                         }];
    }
}

/*
 * Sends visit summary to the selected emails in self.enteredEmails & faxes in self.sharedFaxNumbers
 */
- (void)sendSummaryToShareEmails {
    NSArray<NSString *> *sharedEmails = [self sharedEmailAddresses];
    if (sharedEmails.count || self.sharedFaxNumbers.count) {
        [MBProgressHUD showSendingOn:self.view];
        [self.visitSummary sendSummaryToEmailAddresses:sharedEmails
                                            faxNumbers:self.sharedFaxNumbers ?: nil
                                        withCompletion:^(BOOL success, NSError *error) {
                                            [MBProgressHUD hideHUDForView:self.view];
                                            if (success) {
                                                [self.navigationController dismissViewControllerAnimated:YES completion:nil];
                                            } else if (error) {
                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                    [self presentAlertWithError:error okHandler:nil];
                                                });
                                            }
                                        }];
    } else {
        [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    }
}

- (NSArray<NSString *> *)sharedEmailAddresses {
    NSMutableArray<NSString *> *addresses = [NSMutableArray new];
    for (SharedEmail *email in self.enteredEmails) {
        if (email.shared && email.emailAddress.length > 0) {
            [addresses addObject:email.emailAddress];
        }
    }
    return [NSArray arrayWithArray:addresses];
}

- (BOOL)endVisitRatingsSatisfied {
    // Check if required end visit ratings conditions are satisfied
    if (![self.visitSummary endVisitRatingsOptional] && ((![self.providerRatingCell.rating integerValue] && [self.visitSummary showProviderRatings]) || ![self.visitRatingCell.rating integerValue])) {
        return NO;
    }
    return YES;
}

- (BOOL)suppressCharge {
    return self.visit.cost.eligibilityRequestError.code == AWSDKErrorCodeTimeout && self.visit.consumer.subscription.healthPlan.suppressCharge;
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.webviewHeight = 0.0;
    self.visitSummarySubmitted = NO;
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return ShareDisclaimerSection + 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Header
    if (section == HeaderSection) {
        return 1;
    } else if (section == CostSection) {
        return (self.visit.cost.isFree || self.visitSummary.cost.totalCostWaived || self.suppressCharge) ? 2 : 1;
    } else if (section == ProviderNotesSection && [self.visitSummary.providerNotes isPopulated]) {
        return 1;
        // Diagnoses
    } else if (section == DiagnosesSection) {
        return self.visitSummary.diagnoses.count;
        // Procedures
    } else if (section == ProceduresSection) {
        return self.visitSummary.procedures.count;
        // Prescriptions
    } else if (section == PrescriptionsSection) {
        return self.visitSummary.prescriptions.count;
        // Follow up Items
    } else if (section == FollowUpItemsSection) {
        return self.visitSummary.followUpItems.count;
        // Feedback Question
    } else if (section == FeedbackQuestionSection) {
        // if phone visit there are no  options
        return self.visit.modality.code == AWSDKModalityCodePhone ? 0 : self.visitSummary.feedbackQuestion.responseOptions.count;
        // Ratings
    } else if (section == ProviderRatingsSection) {
        return 1 + [self.visitSummary showProviderRatings];
        // Send email summary
    } else if (section == EmailSummarySection) {
        return self.showOptionToSendVisitSummary ? self.enteredEmails.count + 1 : 0;
    } else if (section == FaxSummarySection) {
        return (self.isEfaxEnabled) ? self.sharedFaxNumbers.count + 1 : 0;
        // HIPAA notice section has 2 rows - one for the notice link, the other for the acceptance toggle
    } else if (section == ShareDisclaimerSection) {
        return ([self sharedEmailAddresses].count || self.sharedFaxNumbers.count) ? 2 : 0;
    } else {
        return 0;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    // Header
    if (section == HeaderSection) {
        return @"";
        // ProviderNotes
    } else if (section == CostSection && self.visitSummary) {
        return NSLocalizedString(@"visitSummary.cost", @"Visit Summary Cost Title");
        // ProviderNotes
    } else if (section == ProviderNotesSection && self.visitSummary.providerNotes.isPopulated) {
        return NSLocalizedString(@"visitSummary.notes", @"Visit Summary Notes Title");
        // Diagnoses
    } else if (section == DiagnosesSection && self.visitSummary.diagnoses.count) {
        return NSLocalizedString(@"visitSummary.diagnoses", @"Visit Summary Diagnoses Title");
        // Procedures
    } else if (section == ProceduresSection && self.visitSummary.procedures.count) {
        return NSLocalizedString(@"visitSummary.procedures", @"Visit Summary Procedures Title");
        // Prescriptions
    } else if (section == PrescriptionsSection && self.visitSummary.prescriptions.count) {
        return NSLocalizedString(@"visitSummary.prescriptions", @"Visit Summary Prescriptions Title");
        // Follow up Items
    } else if (section == FollowUpItemsSection && self.visitSummary.followUpItems.count) {
        return NSLocalizedString(@"visitSummary.followup", @"Visit Summary FollowUp Title");
        // Feedback Question
    } else if (section == FeedbackQuestionSection && self.visitSummary.feedbackQuestion && self.visit.modality.code != AWSDKModalityCodePhone) {
        return self.visitSummary.feedbackQuestion.questionText;
        // Ratings
    } else if (section == ProviderRatingsSection && self.visitSummary.feedbackQuestion != nil) {
        return NSLocalizedString(@"visitSummary.rating", @"Visit Summary Raiting Title");
        // Send Summary
    } else if (section == EmailSummarySection && self.visitSummary && self.showOptionToSendVisitSummary) {
        return NSLocalizedString(@"visitSummary.sendSummary", @"Visit Summary Send Summary Title");
        // Share Emails
    } else if (section == ShareDisclaimerSection && ([self sharedEmailAddresses].count > 0 || self.sharedFaxNumbers.count > 0)) {
        return NSLocalizedString(@"visitSummary.hipaaReleases.title", @"Visit Summary Hipaa Releases Title");
    } else if (section == FaxSummarySection && self.visitSummary && self.isEfaxEnabled) {
        return NSLocalizedString(@"visitSummary.sendSummary.efax", @"Visit Summary Send eFax Title");
    }
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Header
    if (indexPath.section == HeaderSection) {
        if (self.visitSummary) {
            UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
            cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
            cell.textLabel.numberOfLines = 0;
            cell.backgroundView.hidden = YES;
            cell.backgroundColor = UIColor.clearColor;

            NSString *subTitle = nil;
            NSString *title = self.visitSummary.modality.code == AWSDKModalityCodePhone
                ? [NSString stringWithFormat:NSLocalizedString(@"visitSummary.phoneVisitWith.concludes", @"Visit Summary Visit Concludes Title"), self.visitSummary.providerFullName]
                : [NSString stringWithFormat:NSLocalizedString(@"visitSummary.visitWith.concludes", @"Visit Summary Visit Concludes Title"), self.visitSummary.providerFullName];
            if (self.visitSummary.cost.isBillingDeferred) {
                subTitle = self.visitSummary.cost.deferredBillingWrapUpText;
            } else if (self.visitSummary.cost.totalCostWaived) {
                subTitle = NSLocalizedString(@"visitSummary.cost.waived", @"Visit Summary Cost Waived Title");
            } else if (self.suppressCharge) {
                subTitle = NSLocalizedString(@"visitSummary.cost.suppressed", @"Visit Summary Cost Suppressed Title");
            } else if (!self.visit.cost.isFree) {
                subTitle = NSLocalizedString(@"visitSummary.cost.charged", @"Visit Summary Cost Charged Title");
            }

            cell.textLabel.attributedText = [self formatAttributedHeaderMessageForTitle:title subTitle:subTitle];
            [cell setBackgroundColor:[UIColor clearColor]];
            return cell;
            // Notes in Web format
        }
    } else if (indexPath.section == CostSection) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"blackCell"];
        switch (indexPath.row) {
            case VisitCost:
                // Billing may be deferred, if so show custom message
                cell.textLabel.font = [UIFont systemFontOfSize:19.0 weight:UIFontWeightLight];
                if (self.visit.cost.isBillingDeferred && ([self.visit.cost.deferredBillingText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length > 0)) {
                    cell.textLabel.text = self.visit.cost.deferredBillingText;
                } else {
                    NSNumberFormatter *currencyFormatter = [NSNumberFormatter localizedCurrencyFormatter];
                    float cost = (self.visitSummary.cost.totalCostWaived) ? 0.0 : self.visitSummary.cost.baseCost + self.visitSummary.cost.extensionCost;
                    cell.textLabel.text = [currencyFormatter stringFromNumber:[NSNumber numberWithFloat:cost]];
                }
                break;
            case VisitZeroCostMessage:
                cell.textLabel.font = [UIFont systemFontOfSize:14.0 weight:UIFontWeightLight];
                cell.backgroundColor = [UIColor bkgdGreyColor];
                cell.textLabel.textColor = [UIColor sampleMediumGrayColor];
                if (self.suppressCharge && !self.visitSummary.cost.totalCostWaived) {
                    cell.textLabel.text = NSLocalizedString(@"visitCost.suppressPayment.visitCost.title", @"Visit Summary Suppress Payment Cost Title");
                    cell.textLabel.textAlignment = NSTextAlignmentNatural;
                } else {
                    cell.textLabel.text = NSLocalizedString(@"visitSummary.cost.free", @"Visit Summary Cost Free Title");
                    cell.textLabel.textAlignment = NSTextAlignmentCenter;
                }
                break;
        }
        return cell;
    } else if (indexPath.section == ProviderNotesSection) {
        WebviewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"webCell"];
        if (!self.notesWebView) {
            [cell.webView setDelegate:self];
            [cell.webView loadHTMLString:self.visitSummary.providerNotes baseURL:nil];
            self.notesWebView = cell.webView;
        }
        return cell;
        // Diagnoses
    } else if (indexPath.section == DiagnosesSection) {
        SubtitleTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"subtitleCell"];
        [cell.headerLabel setText:self.visitSummary.diagnoses[indexPath.row].displayName];
        [cell.detailLabel setText:self.visitSummary.diagnoses[indexPath.row].diagnosisDescription];
        return cell;
        // Procedures
    } else if (indexPath.section == ProceduresSection) {
        SubtitleTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"subtitleCell"];
        [cell.headerLabel setText:self.visitSummary.procedures[indexPath.row].displayName];
        [cell.detailLabel setText:self.visitSummary.procedures[indexPath.row].procedureDescription];
        return cell;
        // Prescriptions
    } else if (indexPath.section == PrescriptionsSection) {
        SubtitleTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"subtitleCell"];
        [cell.headerLabel setText:self.visitSummary.prescriptions[indexPath.row].displayName];
        [cell.detailLabel setText:self.visitSummary.prescriptions[indexPath.row].instructions];
        return cell;
        // Follow up Items
    } else if (indexPath.section == FollowUpItemsSection) {
        SubtitleTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"subtitleCell"];
        [cell.headerLabel setText:self.visitSummary.followUpItems[indexPath.row].itemDescription];
        [cell.detailLabel setText:self.visitSummary.followUpItems[indexPath.row].frequency];
        return cell;
        // Feedback Question
    } else if (indexPath.section == FeedbackQuestionSection) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"basicCell"];
        if (self.selectedFeedbackAnswer == indexPath.row) {
            [cell setAccessoryType:UITableViewCellAccessoryCheckmark];
        } else {
            [cell setAccessoryType:UITableViewCellAccessoryNone];
        }
        [cell.textLabel setText:self.visitSummary.feedbackQuestion.responseOptions[indexPath.row]];
        return cell;
        // Ratings
    } else if (indexPath.section == ProviderRatingsSection) {
        if (self.visitSummary.feedbackQuestion) {
            if (indexPath.row == 0) {
                // Visit
                RatingTableViewCell *ratingCell = [tableView dequeueReusableCellWithIdentifier:@"visitRatingCell"];
                [ratingCell.label setText:NSLocalizedString(@"visitSummary.rating.visit", @"Visit Summary Visit Raiting Title")];
                [self setVisitRatingCell:ratingCell];
                return ratingCell;
            } else {
                // Provider
                RatingTableViewCell *ratingCell = [tableView dequeueReusableCellWithIdentifier:@"providerRatingCell"];
                [ratingCell.label setText:NSLocalizedString(@"visitSummary.rating.provider", @"Visit Summary Provider Raiting Title")];
                [self setProviderRatingCell:ratingCell];
                return ratingCell;
            }
        }
        // Send Summary
    } else if (indexPath.section == EmailSummarySection) {
        NSUInteger row = indexPath.row;
        KeyboardFieldAndSwitchTableViewCell *fieldTableViewCell = [tableView dequeueReusableCellWithIdentifier:@"keyboardFieldAndSwitchCell"];
        fieldTableViewCell.textField.placeholder = NSLocalizedString(@"visitSummary.sendSummary.email.textFieldPlaceholder", @"Visit Summary Email Place Holder Title");
        if (row < self.enteredEmails.count) {
            fieldTableViewCell.textField.text = self.enteredEmails[row].emailAddress;
            [fieldTableViewCell.toggle setOn:self.enteredEmails[row].shared];
            [fieldTableViewCell.toggle setHidden:NO];
        } else {
            fieldTableViewCell.textField.text = @"";
            [fieldTableViewCell.toggle setOn:YES];
            [fieldTableViewCell.toggle setHidden:YES];
        }
        fieldTableViewCell.delegate = self;
        fieldTableViewCell.toggleDelegate = self;
        fieldTableViewCell.textField.keyboardType = UIKeyboardTypeEmailAddress;
        fieldTableViewCell.textField.returnKeyType = UIReturnKeyDone;
        fieldTableViewCell.textField.textContentType = UITextContentTypeEmailAddress;
        fieldTableViewCell.separatorLine.hidden = (row == self.enteredEmails.count);
        [self setupDoneButtonOnKeypadForCell:fieldTableViewCell];
        self.emailSummaryCell = fieldTableViewCell;
        return fieldTableViewCell;
        // Share Emails
    } else if (indexPath.section == FaxSummarySection) {
        NSUInteger row = indexPath.row;
        KeyboardFieldTableViewCell *fieldTableViewCell = [tableView dequeueReusableCellWithIdentifier:@"keyboardFieldCell"];
        fieldTableViewCell.textField.placeholder = NSLocalizedString(@"visitSummary.sendSummary.efax.textFieldPlaceholder", @"Visit Summary eFax Place Holder Title");
        fieldTableViewCell.textField.text = (row < self.sharedFaxNumbers.count) ? self.sharedFaxNumbers[row] : @"";
        fieldTableViewCell.delegate = self;
        fieldTableViewCell.textField.keyboardType = UIKeyboardTypePhonePad;
        fieldTableViewCell.textField.returnKeyType = UIReturnKeyDone;
        fieldTableViewCell.textField.textContentType = UITextContentTypeTelephoneNumber;
        fieldTableViewCell.separatorLine.hidden = (row == self.sharedFaxNumbers.count);
        [self setupDoneButtonOnKeypadForCell:fieldTableViewCell];
        self.faxSummaryCell = fieldTableViewCell;
        return fieldTableViewCell;
    } else if (indexPath.section == ShareDisclaimerSection) {
        if (indexPath.row == 0) {
            UITableViewCell *infoViewCell = [tableView dequeueReusableCellWithIdentifier:@"infoViewCell"];
            [infoViewCell.textLabel setText:NSLocalizedString(@"visitSummary.hipaaReleases", @"Visit Summary Hipaa Releases Title")];
            [infoViewCell setAccessoryType:UITableViewCellAccessoryDetailButton];
            return infoViewCell;
        } else if (indexPath.row == 1) {
            SwitchTableViewCell *switchViewCell = [tableView dequeueReusableCellWithIdentifier:@"switchViewCell"];
            [switchViewCell.label setText:NSLocalizedString(@"visitSummary.hipaaReleases.toggleText", @"Visit Summary Hipaa Releases Toggle Text Title")];
            [switchViewCell.toggle setOn:self.acceptHIPAASelected];
            [switchViewCell.toggle addTarget:self action:@selector(acceptHIPAAChanged:) forControlEvents:UIControlEventValueChanged];
            return switchViewCell;
        }
    }
    UITableViewCell *cell = [[UITableViewCell alloc] initWithFrame:CGRectZero];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == ProviderNotesSection && [self.visitSummary.providerNotes isPopulated]) {
        return self.webviewHeight;
    } else {
        return 85.0;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    VisitSummarySections section = indexPath.section;

    if (section == EmailSummarySection) {
        return self.showOptionToSendVisitSummary ? UITableViewAutomaticDimension : CGFLOAT_MIN;
    } else if (section == ProviderNotesSection) {
        return self.webviewHeight;
    } else if (section == FeedbackQuestionSection) {
        return (self.visit.modality.code == AWSDKModalityCodePhone) ? CGFLOAT_MIN : UITableViewAutomaticDimension;
    }
    return UITableViewAutomaticDimension;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    VisitSummarySections section = indexPath.section;
    NSUInteger row = indexPath.row;

    switch (section) {
        case EmailSummarySection: {
            return (row < self.enteredEmails.count);
        };
        case FaxSummarySection: {
            return (row < self.sharedFaxNumbers.count);
        };
        default:
            break;
    }
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    VisitSummarySections section = indexPath.section;
    NSUInteger row = indexPath.row;

    if (editingStyle == UITableViewCellEditingStyleDelete) {
        switch (section) {
            case EmailSummarySection: {
                [self.enteredEmails removeObjectAtIndex:row];
            } break;
            case FaxSummarySection: {
                [self.sharedFaxNumbers removeObjectAtIndex:row];
            } break;
            default:
                break;
        }
        [self reloadEmailFaxSections];
    }
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    CGFloat height = [self heightForHeaderFooterInSection:section];
    if (section == CostSection) {
        height = self.suppressCharge ? 47.0 : 27.0;
    } else if (section == FeedbackQuestionSection && self.visit.modality.code == AWSDKModalityCodePhone) {
        height = CGFLOAT_MIN;
    }
    return height;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    CGFloat height = [self heightForHeaderFooterInSection:section];
    if (section == FeedbackQuestionSection && self.visit.modality.code == AWSDKModalityCodePhone) {
        height = CGFLOAT_MIN;
    }
    return height;
}

- (CGFloat)heightForHeaderFooterInSection:(NSInteger)section {
    CGFloat height = [self tableView:self.tableView numberOfRowsInSection:section] ? UITableViewAutomaticDimension : CGFLOAT_MIN;
    if (section == HeaderSection) {
        height = CGFLOAT_MIN;
    } else if (section == EmailSummarySection) {
        height = self.showOptionToSendVisitSummary ? height : CGFLOAT_MIN;
    }
    return height;
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
    NSString *HIPAANotice = [NSString stringWithFormat:@"%@\n\n%@", self.visitSummary.hipaaNoticeText, self.visitSummary.additionalHipaaNoticeText];

    [self performSegueWithIdentifier:@"showHIPAASegue" sender:HIPAANotice];
}

- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Allow feedback response section to be selected
    if (indexPath.section == FeedbackQuestionSection) {
        return (self.visitSummary.feedbackQuestion) ? indexPath : nil;
    }
    // Allow share emails to be selected
    if (indexPath.section == EmailSummarySection) {
        return indexPath;
    }
    // Allow share faxes to be selected
    if (indexPath.section == FaxSummarySection) {
        return indexPath;
    }
    // Allow HIPAA checkbox to be selected
    if (indexPath.section == ShareDisclaimerSection) {
        return (self.visitSummary.hipaaNoticeText) ? indexPath : nil;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == FeedbackQuestionSection && self.visitSummary.feedbackQuestion) {
        BOOL deselectedAnswer = self.selectedFeedbackAnswer == indexPath.row;
        AWSDKLogInfo(@"%@ feedback answer: %@", deselectedAnswer ? @"Deselected" : @"Selected", self.visitSummary.feedbackQuestion.responseOptions[indexPath.row]);
        self.selectedFeedbackAnswer = deselectedAnswer ? -1 : indexPath.row;
        [self.tableView reloadData];
    }
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
    if (section == CostSection) {
        return;
    }

    if ([view isKindOfClass:[UITableViewHeaderFooterView class]]) {
        UITableViewHeaderFooterView *tableViewHeaderFooterView = (UITableViewHeaderFooterView *)view;
        tableViewHeaderFooterView.textLabel.text = [tableViewHeaderFooterView.textLabel.text sentenceCase];
        [tableViewHeaderFooterView.textLabel setFont:[UIFont systemFontOfSize:17.0 weight:UIFontWeightLight]];
    }
}

#pragma mark - Setters
- (void)setVisit:(id<AWSDKVisit>)visit {
    [self fetchVisitSummaryWithVisit:visit];

    self.selectedFeedbackAnswer = -1;
    self.webviewHeight = 0.0;

    _visit = visit;
}

- (void)acceptHIPAAChanged:(id)sender {
    self.acceptHIPAASelected = [(UISwitch *)sender isOn];
}

#pragma mark - UIWebviewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [webView.scrollView setScrollEnabled:NO];
    CGRect frame = webView.frame;
    frame.size.height = 1;
    webView.frame = frame;
    CGSize fittingSize = [webView sizeThatFits:CGSizeZero];
    fittingSize.height += 10;
    self.webviewHeight = fittingSize.height;
    frame.size = fittingSize;
    webView.frame = frame;
    [self.tableView reloadDataAnimated:YES];
}

#pragma mark - KeyboardFieldTableViewCellDelegate
- (void)textDidEndEditing:(NSString *)text inCell:(KeyboardFieldTableViewCell *)cell {
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    VisitSummarySections section = indexPath.section;
    NSUInteger row = indexPath.row;
    NSString *trimmedText;
    switch (section) {
        case EmailSummarySection: {
            trimmedText = [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            SharedEmail *email = [SharedEmail new];
            email.shared = YES;
            email.emailAddress = trimmedText;
            if ([cell isKindOfClass:[KeyboardFieldAndSwitchTableViewCell class]]) {
                email.shared = ((KeyboardFieldAndSwitchTableViewCell *)cell).toggle.isOn;
            }

            if (self.enteredEmails.count == row) {
                if (trimmedText.length) {
                    [self.enteredEmails addObject:email];
                }
            } else {
                self.enteredEmails[row] = email;
            }
        } break;
        case FaxSummarySection: {
            trimmedText = [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            if (self.sharedFaxNumbers.count == row) {
                if (trimmedText.length) {
                    [self.sharedFaxNumbers addObject:trimmedText];
                }
            } else {
                self.sharedFaxNumbers[row] = trimmedText;
            }
        } break;
        default:
            break;
    }

    // Wait after textDidEndEditing is complete, update table with changes, trim table and reload table after trimming
    __weak VisitSummaryTableViewController *weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [weakSelf reloadEmailFaxSections];
        [weakSelf trimEmailFaxSharedArrays];
        [weakSelf reloadEmailFaxSections];
    });
}

#pragma mark - KeyboardFieldAndSwitchTableViewCellDelegate
- (void)toggleDidChange:(BOOL)setting inCell:(KeyboardFieldAndSwitchTableViewCell *)cell {
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    VisitSummarySections section = indexPath.section;
    BOOL wasDisclaimerShowing = [self sharedEmailAddresses].count > 0;
    if (section == EmailSummarySection && indexPath.row < self.enteredEmails.count) {
        self.enteredEmails[indexPath.row].shared = setting;
    }
    BOOL shouldShowDisclaimer = [self sharedEmailAddresses].count > 0;
    if (shouldShowDisclaimer != wasDisclaimerShowing) {
        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:ShareDisclaimerSection] withRowAnimation:UITableViewRowAnimationFade];
    }
}

#pragma mark - IBActions
- (IBAction)closeTapped:(id)sender {
    [self trimEmailFaxSharedArrays];
    NSArray<NSString *> *sharedEmails = [self sharedEmailAddresses];
    if (self.acceptHIPAASelected || (sharedEmails.count == 0 && self.sharedFaxNumbers.count == 0)) {
        if (self.visitSummary.feedbackQuestion) {
            if ([self endVisitRatingsSatisfied]) {
                // Submit form starting with feedback answer
                [self submitFeedbackAnswer];
            } else {
                // Prompt the user if they are required to enter a rating
                [self presentAlertWithMessageKey:@"visitSummary.rating.none" okHandler:nil];
            }
        } else if ([self.visitSummary endVisitRatingsOptional] && (![self.providerRatingCell.rating integerValue] || ![self.visitRatingCell.rating integerValue])) {
            [self submitRating];
        } else {
            [self.navigationController dismissViewControllerAnimated:YES completion:nil];
        }
    } else {
        if (sharedEmails.count > 0 || self.sharedFaxNumbers.count > 0) {
            [self presentAlertWithMessageKey:@"visitSummary.hipaaReleases.notAccepted" okHandler:nil];
        }
    }
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showHIPAASegue"]) {
        AWSDKLogInfo(@"Tapped HIPAA Releases cell");
        [(HIPAAViewController *)segue.destinationViewController setNotice:(NSString *)sender];
    }
}

#pragma mark - Private Methods
- (void)setupDoneButtonOnKeypadForCell:(KeyboardFieldTableViewCell *)cell {
    UIToolbar *numberToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
    numberToolbar.barStyle = UIBarStyleDefault;
    numberToolbar.items = [NSArray arrayWithObjects:[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                                   [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"misc.done", @"Done barButtonItem")
                                                                    style:UIBarButtonItemStyleDone
                                                                   target:cell
                                                                   action:@selector(toolbarDoneButtonTapped)],
                                   nil];
    [numberToolbar sizeToFit];
    cell.textField.inputAccessoryView = numberToolbar;
}

- (void)reloadEmailFaxSections {
    NSMutableIndexSet *sectionIndexes = [NSMutableIndexSet new];
    [sectionIndexes addIndex:EmailSummarySection];
    [sectionIndexes addIndex:FaxSummarySection];
    [self reloadSections:sectionIndexes];
}

- (void)reloadSections:(NSIndexSet *)sections {
    NSMutableIndexSet *sectionIndexes = [sections mutableCopy];
    [sectionIndexes addIndex:ShareDisclaimerSection];
    [self.tableView reloadSections:sectionIndexes withRowAnimation:UITableViewRowAnimationFade];
}

- (void)trimEmailFaxSharedArrays {
    // Remove duplicate and empty elements
    NSMutableOrderedSet *emailSet = [NSMutableOrderedSet new];
    for (SharedEmail *email in self.enteredEmails) {
        if (email.emailAddress.length) {
            [emailSet addObject:email];
        }
    }
    self.enteredEmails = [emailSet.array mutableCopy];

    NSMutableOrderedSet *faxSet = [NSMutableOrderedSet new];
    for (NSString *faxNumber in self.sharedFaxNumbers) {
        if (faxNumber.length) {
            [faxSet addObject:faxNumber];
        }
    }
    self.sharedFaxNumbers = [faxSet.array mutableCopy];
}

- (NSAttributedString *)formatAttributedHeaderMessageForTitle:(NSString *)title subTitle:(NSString *)subTitle {
    NSRange titleRange = (title.length) ? NSMakeRange(0, title.length) : NSMakeRange(0, 0);
    NSRange subTitleRange = (subTitle.length) ? NSMakeRange(title.length, subTitle.length + 1) : NSMakeRange(0, 0);
    UIFont *titleFont = [UIFont systemFontOfSize:18.0f weight:UIFontWeightRegular];
    UIFont *subTitleFont = [UIFont systemFontOfSize:15.0f weight:UIFontWeightRegular];
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
    paragraphStyle.paragraphSpacing = 0.45 * titleFont.lineHeight;
    NSString *string = (subTitle.length) ? [NSString stringWithFormat:@"%@\n%@", title, subTitle] : [NSString stringWithFormat:@"%@", title];
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:string];
    if (title.length) {
        [attributedText addAttribute:NSFontAttributeName value:titleFont range:titleRange];
    }
    if (subTitle.length) {
        [attributedText addAttribute:NSFontAttributeName value:subTitleFont range:subTitleRange];
    }
    [attributedText addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(0, attributedText.length)];
    [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attributedText.length)];
    return attributedText;
}

@end
