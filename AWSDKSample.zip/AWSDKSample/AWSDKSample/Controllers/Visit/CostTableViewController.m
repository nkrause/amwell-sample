//
//  CostTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 6/10/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "CostTableViewController.h"

#import "AppDelegate.h"
#import "FieldButtonTableViewCell.h"
#import "FindFirstAvailableViewController.h"
#import "LabelButtonTableViewCell.h"
#import "PaymentTableViewController.h"
#import "UITableView+Sample.h"
#import "UITextfield+Compare.h"
#import "WaitingRoomViewController.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKCost.h>
#import <AWSDK/AWSDKErrorCode.h>
#import <AWSDK/AWSDKHealthPlan.h>
#import <AWSDK/AWSDKPaymentMethod.h>
#import <AWSDK/AWSDKSubscription.h>
#import <AWSDK/AWSDKVisit.h>
#import <AWSDK/AWSDKVisitContext.h>
#import <AWSDK/AWSDKVisitService.h>
#import <AWSDK/NSNumberFormatter+Extensions.h>

typedef NS_ENUM(NSUInteger, Sections) {
    MessageSection,
    CostSection,
    PaymentSection,
    CouponSection,
};

typedef NS_ENUM(NSUInteger, MessageSectionCell) {
    PaymentMessage,
};

typedef NS_ENUM(NSUInteger, CostSectionCell) {
    VisitCost,
    VisitZeroCostMessage,
};

typedef NS_ENUM(NSUInteger, PaymentSectionCell) {
    CreditCard,
};

typedef NS_ENUM(NSUInteger, CouponSectionCell) {
    CouponField,
};

typedef void (^UIAlertActionBlock)(UIAlertAction *_Nonnull action);

/**
 *  CostTableViewController creates displays the cost for the current visit and ready's the visit for the
 *  WaitingRoom
 */
@interface CostTableViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, PaymentDelegate, AWSDKVisitDelegate>

@property (weak, nonatomic) IBOutlet UIBarButtonItem *nextButton;
@property (nonatomic) UITextField *couponField;
@property (nonatomic) id<AWSDKPaymentMethod> payment;
@property (assign, nonatomic) BOOL couponApplied;
@property (assign, nonatomic, readonly) BOOL suppressCharge;

@property (nonatomic) UIFont *sectionHeaderLabelDefaultFont;

@end

@implementation CostTableViewController

#pragma mark - AWSDK Method Calls
- (void)readyVisit {
    // This is a Find First Available visit
    if (self.visit.createdForFirstAvailableFlow) {
        [self performSegueWithIdentifier:@"findFirstAvailableSegue" sender:self.visit];
    } else {
        [MBProgressHUD showLoadingOn:self.view];
        /**
         *  Gets user ready for visit and puts them in the Waiting Room. Requires a visit
         *
         *  @param success True if succesful in starting visit, false otherwise
         *  @param error   AWSDKError
         */
        [AWSDKVisitService
            readyToStartVisit:self.visit
                   completion:^(BOOL success, NSError *error) {
                       [MBProgressHUD hideHUDForView:self.view];
                       if (error) {
                           if (error.code == AWSDKErrorCodeInvalidVisitContext) {
                               // Handle Invalid Visit context error
                               NSString *failures = @"";
                               for (NSString *key in [error.userInfo[AWSDKValidationErrorsKey] allKeys]) {
                                   failures = [failures stringByAppendingString:key];

                                   if (![key isEqualToString:[[error.userInfo[AWSDKValidationErrorsKey] allKeys] lastObject]]) {
                                       failures = [failures stringByAppendingString:@", "];
                                   }
                               }
                               // Present Alert for invalidVisitContext errors
                               [self presentAlertWithTitle:NSLocalizedString(@"visitCost.validation.failed.title", @"Cost Table Validation Failed Title")
                                                   message:[NSLocalizedString(@"visitCost.validation.failed.message", @"Cost Table Validation Failed Message") stringByAppendingString:failures]
                                                 okHandler:nil];
                           } else {
                               // Handle other errors
                               [self presentAlertWithError:error okHandler:nil];
                           }
                           self.nextButton.enabled = YES;
                       } else {
                           // Push WaitingRoomViewController
                           [self performSegueWithIdentifier:@"waitingRoomSegue" sender:nil];
                       }
                   }];
    }
}

- (void)cancelVisit {
    [MBProgressHUD showCancelingOn:self.view];
    /**
     *  Cancel Visit, user pressed cancel button
     *
     *  @param success True if visit was canceled
     *  @param error   AWSDKError
     */
    [AWSDKVisitService cancelPendingVisit:self.visit
                           withCompletion:^(BOOL success, NSError *error) {
                               [MBProgressHUD hideHUDForView:self.view];
                               if (error) {
                                   [self presentAlertWithError:error okHandler:nil];
                               }
                               [self.navigationController dismissViewControllerAnimated:YES completion:nil];
                           }];
}

- (void)fetchPayment {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    [MBProgressHUD showLoadingOn:self.view];
    [consumer fetchPaymentMethodWithCompletion:^(id result, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (error) {
            [self presentAlertWithError:error okHandler:nil];
        } else {
            self.payment = result;
            if (self.payment.isExpired) {
                [self presentAlertWithTitle:NSLocalizedString(@"paymentInformation.expired.title", @"Card expired title")
                                    message:NSLocalizedString(@"paymentInformation.expired.message", @"Message explaining card has expired")
                                  okHandler:nil];
            } else {
                [self.tableView reloadDataAnimated:YES];
            }
        }
        if (self.payment || self.visit.cost.isFree) {
            self.nextButton.enabled = YES;
        }
    }];
}

#pragma mark - AWSDKVisitDelegate Placeholder
/**
 *  Note that these delegate methods are not used, and waiting room is set as the delegate during the
 *  actual visit. WaitinRoomVC will handle canceling and entering the visit with a console.
 */
- (void)providerDidEnterVisit {
}
- (void)visitDidComplete:(BOOL)visitSuccessful withEndReason:(AWCoreVisitEndReason)reason {
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    [self.tableView setRowHeight:UITableViewAutomaticDimension];
    [self.tableView setEstimatedRowHeight:44.0];

    self.title = NSLocalizedString(@"visitCost.title", @"Cost Table Validation Failed Title");

    [self.nextButton setTitle:NSLocalizedString(@"visitCost.next", @"Cost Table Next Title")];
    [self fetchPayment];

    [self setCouponApplied:NO];

    [self.visit setDelegate:self];

    if (self.visit.cost.isFree) {
        [self.nextButton setEnabled:YES];
    }
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.visit.cost.isFree) {
        switch (section) {
            case MessageSection:
                return (self.visit.createdForFirstAvailableFlow && self.visit.cost.paymentMessage) || self.suppressCharge ? 1 : 0;
            case CostSection:
                return 2;
            default:
                return 0;
        }
    } else {
        switch (section) {
            case MessageSection:
                return (self.visit.createdForFirstAvailableFlow && self.visit.cost.paymentMessage) || self.suppressCharge ? 1 : 0;
            case CostSection:
                return self.suppressCharge ? 2 : 1;
            case PaymentSection:
                return 1;
            case CouponSection:
                return (self.visit.cost.canApplyCouponCode && !self.suppressCharge) ? 1 : 0;
            default:
                return 0;
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case CostSection: {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"blackCell"];
            switch (indexPath.row) {
                case VisitCost:
                    // Billing may be deferred, if so show custom message
                    cell.textLabel.font = [UIFont systemFontOfSize:19.0 weight:UIFontWeightLight];
                    if (self.visit.cost.isBillingDeferred && [self.visit.cost.deferredBillingText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length > 0) {
                        cell.textLabel.text = self.visit.cost.deferredBillingText;
                    } else {
                        NSNumberFormatter *currencyFormatter = [NSNumberFormatter localizedCurrencyFormatter];
                        NSString *cost = [currencyFormatter stringFromNumber:[NSNumber numberWithFloat:self.visit.cost.expectedCopay]];
                        cell.textLabel.text = cost;
                    }
                    break;
                case VisitZeroCostMessage:
                    cell.textLabel.font = [UIFont systemFontOfSize:14.0 weight:UIFontWeightLight];
                    cell.backgroundColor = [UIColor bkgdGreyColor];
                    cell.textLabel.textColor = [UIColor sampleMediumGrayColor];
                    if (self.suppressCharge) {
                        cell.textLabel.text = NSLocalizedString(@"visitCost.suppressPayment.visitCost.title", @"Cost Table Suppress Payment Cost Title");
                        cell.textLabel.textAlignment = NSTextAlignmentNatural;
                    } else {
                        cell.textLabel.text = NSLocalizedString(@"visitCost.visitZeroCost", @"Cost Table Zero Cost Title");
                        cell.textLabel.textAlignment = NSTextAlignmentCenter;
                    }
                    break;
            }

            return cell;
        }
        case PaymentSection: {
            // Payment Information
            LabelButtonTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"labelButtonCell"];
            if (self.payment.cardType) {
                cell.label.text = [NSString stringWithFormat:@"%@ card ending in %@", self.payment.cardType, self.payment.lastFourDigits];
            } else {
                cell.label.text = NSLocalizedString(@"visitCost.paymentInformation.none", @"Cost Table Payment Information None Title");
            }
            [cell.button setTitle:NSLocalizedString(@"visitCost.updatePaymentInformation", @"Cost Table Update Payment Information Title") forState:UIControlStateNormal];
            [cell.button addTarget:self action:@selector(updatePayment:) forControlEvents:UIControlEventTouchUpInside];
            return cell;
        }
        case CouponSection: {
            FieldButtonTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"fieldButtonCell"];
            [cell.textField setPlaceholder:NSLocalizedString(@"visitCost.couponCode", @"Cost Table Coupon Code Title")];
            self.couponField = cell.textField;

            [cell.button setTitle:NSLocalizedString(@"visitCost.apply", @"Cost Table Coupon Apply Title") forState:UIControlStateNormal];
            [cell.button setTitle:NSLocalizedString(@"visitCost.applied", @"Cost Table Coupon Applied Title") forState:UIControlStateDisabled];
            [cell.button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateDisabled];
            if (self.couponApplied) {
                [cell.textField setEnabled:NO];
                [cell.button setEnabled:NO];
                [cell.textField setTextColor:[UIColor lightGrayColor]];
            } else if (self.visit.cost.proposedCouponCode && [cell.textField.text isEqualToString:@""]) {
                cell.textField.text = self.visit.cost.proposedCouponCode;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self applyCoupon:nil];
                });
            }

            [cell.button addTarget:self action:@selector(applyCoupon:) forControlEvents:UIControlEventTouchUpInside];
            return cell;
        }
        case MessageSection: {
            switch (indexPath.row) {
                case PaymentMessage: {
                    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
                    cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
                    cell.textLabel.numberOfLines = 0;
                    cell.backgroundView.hidden = YES;
                    cell.backgroundColor = UIColor.clearColor;

                    if (self.suppressCharge) {
                        NSString *title = NSLocalizedString(@"visitCost.suppressPayment.title", @"The Title");
                        NSString *subTitle = NSLocalizedString(@"visitCost.suppressPayment.subTitle", @"The SubTitle");
                        cell.textLabel.attributedText = [self formatAttributedHeaderMessageForTitle:title subTitle:subTitle];
                    } else {
                        cell.textLabel.textAlignment = NSTextAlignmentCenter;
                        cell.textLabel.text = self.visit.cost.paymentMessage;
                    }
                    return cell;
                }
            }
        }
    }
    return [UITableViewCell new];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (self.visit.cost.isFree) {
        switch (section) {
            case CostSection:
                return NSLocalizedString(@"visitCost.visitCost", @"Cost Table Visit Cost Title");
            default:
                return nil;
        }
    } else {
        switch (section) {
            case CostSection:
                return NSLocalizedString(@"visitCost.visitCost", @"Cost Table Visit Cost Title");
            case PaymentSection:
                return NSLocalizedString(@"visitCost.paymentInformation", @"Cost Table Payment Information Title");
            case CouponSection:
                return (self.visit.cost.canApplyCouponCode && !self.suppressCharge) ? NSLocalizedString(@"visitCost.couponCode", @"Cost Table Coupon Code Title") : nil;
            default:
                return nil;
        }
    }
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
    if ([view isKindOfClass:[UITableViewHeaderFooterView class]]) {
        UITableViewHeaderFooterView *headerView = (UITableViewHeaderFooterView *)view;
        if (!self.sectionHeaderLabelDefaultFont) {
            self.sectionHeaderLabelDefaultFont = headerView.textLabel.font;
        }
        headerView.textLabel.textAlignment = NSTextAlignmentNatural;
    }
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    CGFloat height = [self heightForHeaderFooterInSection:section];
    if (section == CostSection) {
        NSInteger rows = [self tableView:tableView numberOfRowsInSection:CostSection - 1];
        if (rows > 0) {
            height = self.suppressCharge ? 47.0 : 27.0;
        }
    }
    return height;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return [self heightForHeaderFooterInSection:section];
}

- (CGFloat)heightForHeaderFooterInSection:(NSInteger)section {
    CGFloat height = [self tableView:self.tableView numberOfRowsInSection:section] ? UITableViewAutomaticDimension : CGFLOAT_MIN;
    if (section == MessageSection) {
        height = CGFLOAT_MIN;
    }
    return height;
}

#pragma mark - PaymentDelegate
- (void)didUpdatePayment:(id<AWSDKPaymentMethod>)newPaymentMethod {
    [self setPayment:newPaymentMethod];

    if (self.visit.cost.isFree || self.payment) {
        [self.nextButton setEnabled:YES];
    }

    [self.tableView reloadDataAnimated:YES];
}

#pragma mark - Helpers
- (BOOL)suppressCharge {
    return self.visit.cost.eligibilityRequestError.code == AWSDKErrorCodeTimeout && self.visit.consumer.subscription.healthPlan.suppressCharge;
}

- (BOOL)paymentSufficient {
    return !self.payment.isExpired || self.visit.cost.isFree;
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (self.visit.cost.isFree || self.payment) {
        [self.nextButton setEnabled:YES];
    }

    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    textField.text = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    AWSDKLogInfo(@"Text field: '%@' ended editing with value: %@", textField.placeholder, textField.text);
}

#pragma mark - Selectors
- (void)applyCoupon:(id)sender {
    AWSDKLogInfo(@"Apply coupon button tapped");
    if ([self.couponField isPopulated]) {
        [self.nextButton setEnabled:NO];
        [MBProgressHUD showUpdatingOn:self.view];

        __weak typeof(self) weakSelf = self;
        [self applyCouponWithCompletion:^(BOOL success) {
            [MBProgressHUD hideHUDForView:self.view];

            if (success) {
                weakSelf.couponApplied = YES;
                if (weakSelf.visit.cost.isFree || weakSelf.payment) {
                    [weakSelf.nextButton setEnabled:YES];
                }
                [weakSelf.tableView reloadDataAnimated:YES];
            }
        }];
    } else {
        [self presentAlertWithTitle:NSLocalizedString(@"visitCost.applyFailed", @"Cost Table Coupon Apply Failed Title")
                            message:NSLocalizedString(@"visitCost.applyFailed.tooShort", @"Cost Table Coupon Failed Too Short Title")
                          okHandler:nil];
    }
}

- (void)applyCouponWithCompletion:(SuccessCompletionBlock)completion {
    __weak typeof(self) weakSelf = self;
    [self.visit applyCouponCode:self.couponField.text
                 withCompletion:^(BOOL success, NSError *error) {
                     if (error) {
                         [weakSelf presentAlertWithError:error okHandler:nil];
                         completion(NO);
                     } else {
                         completion(YES);
                     }
                 }];
}

- (void)updatePayment:(id)sender {
    AWSDKLogInfo(@"Update payment button tapped");
    // Display update payment information
    [self performSegueWithIdentifier:@"paymentSegue" sender:self];
}

#pragma mark - IBActions
- (IBAction)nextPressed:(id)sender {
    AWSDKLogInfo(@"Next tapped");
    __weak typeof(self) weakSelf = self;
    self.nextButton.enabled = NO;
    CompletionBlock validatePaymentBlock = ^{
        // Check if CC is expired
        if (![weakSelf paymentSufficient]) {
            [weakSelf presentAlertWithTitle:NSLocalizedString(@"paymentInformation.expired.title", @"Card expired title")
                                    message:NSLocalizedString(@"paymentInformation.expired.message", @"Message explaining card has expired")
                                  okHandler:nil];
            self.nextButton.enabled = YES;
        } else {
            [weakSelf readyVisit];
        }
    };

    // Check is a coupon code exists and hasn't been applied
    if ([self.couponField isPopulated] && !self.couponApplied) {
        // Prompt to apply coupon
        UIAlertController *alert = [UIAlertController alertControllerWithTitleKey:@"visitCost.apply.message"];

        UIAlertActionBlock noBlock = ^(UIAlertAction *_Nonnull action) {
            [weakSelf.couponField setText:@""];
            validatePaymentBlock();
        };
        UIAlertActionBlock yesBlock = ^(UIAlertAction *_Nonnull action) {
            [weakSelf applyCouponWithCompletion:^(BOOL success) {
                if (success) {
                    validatePaymentBlock();
                }
            }];
        };

        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.no", @"Cost Table No Title") style:UIAlertActionStyleDefault handler:[alert defaultAlertHandler:noBlock]]];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.yes", @"Cost Table Yes Title") style:UIAlertActionStyleDestructive handler:[alert defaultAlertHandler:yesBlock]]];
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        validatePaymentBlock();
    }
}

- (IBAction)cancelTapped:(id)sender {
    AWSDKLogInfo(@"Cancel tapped");
    [self cancelVisit];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"waitingRoomSegue"]) {
        ((WaitingRoomViewController *)segue.destinationViewController).visit = self.visit;
        ((WaitingRoomViewController *)segue.destinationViewController).context = self.context;
        self.visit.delegate = (WaitingRoomViewController *)segue.destinationViewController;
    } else if ([segue.identifier isEqualToString:@"findFirstAvailableSegue"]) {
        ((FindFirstAvailableViewController *)segue.destinationViewController).visit = self.visit;
    } else {
        PaymentTableViewController *viewController = [(UINavigationController *)segue.destinationViewController viewControllers][0];
        [viewController setDelegate:self];
    }
}

#pragma mark - Private Methods
- (NSAttributedString *)formatAttributedHeaderMessageForTitle:(NSString *)title subTitle:(NSString *)subTitle {
    NSRange titleRange = (title.length) ? NSMakeRange(0, title.length) : NSMakeRange(0, 0);
    NSRange subTitleRange = (subTitle.length) ? NSMakeRange(title.length, subTitle.length + 1) : NSMakeRange(0, 0);
    UIFont *titleFont = [UIFont systemFontOfSize:18.0f weight:UIFontWeightRegular];
    UIFont *subTitleFont = [UIFont systemFontOfSize:15.0f weight:UIFontWeightRegular];
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
    paragraphStyle.paragraphSpacing = 0.45 * titleFont.lineHeight;
    NSString *string = (subTitle.length) ? [NSString stringWithFormat:@"%@\n%@", title, subTitle] : [NSString stringWithFormat:@"%@", title];
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:string];
    if (title.length) {
        [attributedText addAttribute:NSFontAttributeName value:titleFont range:titleRange];
    }
    if (subTitle.length) {
        [attributedText addAttribute:NSFontAttributeName value:subTitleFont range:subTitleRange];
    }
    [attributedText addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(0, attributedText.length)];
    [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attributedText.length)];
    return attributedText;
}

@end
