//
//  CartVisitTopicsViewController.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 10/10/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "CartVisitTopicsViewController.h"

#import "CostTableViewController.h"
#import "WaitingRoomViewController.h"

typedef void (^UIAlertActionBlock)(UIAlertAction *_Nonnull action);

@interface CartVisitTopicsViewController () <UITextViewDelegate, AWSDKVisitDelegate>

@property (weak, nonatomic) IBOutlet UITextView *topicTextView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *backButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *nextButton;
@property (weak, nonatomic) IBOutlet UILabel *textViewPlaceHolder;

@end

@implementation CartVisitTopicsViewController

#pragma mark AWSDK Method Calls
/**
 *  Creates a visit based on the current visit context
 */
- (void)createVisit {
    __weak typeof(self) weakSelf = self;
    // Disable done button
    [self.nextButton setEnabled:NO];

    // Force accept all contracts
    for (id<AWSDKLegalText> text in self.context.legalText) {
        [text setAccepted];
    }

    for (id<AWSDKModality> modality in AWSDKService.availableModalities) {
        if (modality.code == AWSDKModalityCodeVideo) {
            self.context.selectedModality = modality;
            break;
        }
    }

    [MBProgressHUD showLoadingOn:self.view];
    [AWSDKVisitService createVisitWithContext:self.context
                            consumerOverrides:self.consumerOverrideDetails
                               isQuickConnect:YES
                                visitSourceId:nil
                                   completion:^(id<AWSDKVisit> _Nullable visit, NSError *error) {
                                       [MBProgressHUD hideHUDForView:self.view];

                                       if (error) {
                                           NSArray *recoverableErrorCodes = @[
                                               @(AWSDKErrorCodeValidationBadEligibilityInformation),
                                               @(AWSDKErrorCodeValidationEligibilityException),
                                               @(AWSDKErrorCodeInvalidValue),
                                               @(AWSDKErrorCodeEligibilityInaccuratePrimarySubscriberInfo),
                                               @(AWSDKErrorCodeEligibilityInaccurateDependentSubscriberInfo)
                                           ];
                                           if (visit && [recoverableErrorCodes containsObject:@(error.code)]) {
                                               UIAlertController *ac = [UIAlertController alertControllerWithError:error];

                                               UIAlertActionBlock okBlock = ^(UIAlertAction *_Nonnull action) {
                                                   [weakSelf performSegueWithIdentifier:@"visitCost" sender:visit];
                                               };
                                               UIAlertActionBlock cancelBlock = ^(UIAlertAction *_Nonnull action) {
                                                   [weakSelf dismissViewControllerAnimated:YES completion:nil];
                                               };

                                               [ac addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.ok", @"Visit Context Okay Title")
                                                                                      style:UIAlertActionStyleDefault
                                                                                    handler:[ac defaultAlertHandler:okBlock]]];
                                               [ac addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.cancel", @"Visit Context Cancel Title")
                                                                                      style:UIAlertActionStyleCancel
                                                                                    handler:[ac defaultAlertHandler:cancelBlock]]];
                                               [weakSelf presentAlertController:ac];
                                           } else if (error.code == AWSDKErrorCodeTimeout && visit.consumer.subscription.healthPlan.suppressCharge) {
                                               // Push to visit cost with AWSDKVisit
                                               [weakSelf performSegueWithIdentifier:@"visitCost" sender:visit];
                                           } else {
                                               [weakSelf presentAlertWithError:error
                                                                     okHandler:^(UIAlertAction *action) {
                                                                         [weakSelf dismissViewControllerAnimated:YES completion:nil];
                                                                     }];
                                           }
                                       } else {
                                           // Push to visit cost with AWSDKVisit
                                           [weakSelf performSegueWithIdentifier:@"visitCost" sender:visit];
                                       }
                                   }];
}

#pragma mark - AWSDKVisitDelegate Placeholder
/**
 *  Note that these delegate methods are not used, and waiting room is set as the delegate during the
 *  actual visit. WaitinRoomVC will handle canceling and entering the visit with a console.
 */
- (void)providerDidEnterVisit {
}
- (void)visitDidComplete:(BOOL)visitSuccessful withEndReason:(AWCoreVisitEndReason)reason {
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

- (void)viewDidLoad {
    [super viewDidLoad];

    [self.nextButton setTitle:NSLocalizedString(@"cartPatientInfo.next.title", @"Cart Patient Info Next Title")];

    self.topicTextView.scrollEnabled = YES;
    self.topicTextView.contentSize = [self.topicTextView sizeThatFits:self.topicTextView.frame.size];
    [self setupKeyboardNotifications];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    if (!self.nextButton.isEnabled) {
        [self performSegueWithIdentifier:@"unwindFromCartVisitTopicsCompleteSegue" sender:self];
    }
}

#pragma mark - IBActions

- (IBAction)backButtonTapped:(id)sender {
    AWSDKLogInfo(@"Back button tapped");

    [self performSegueWithIdentifier:@"unwindFromCartVisitTopicsSegue" sender:self];
}

- (IBAction)nextButtonTapped:(id)sender {
    AWSDKLogInfo(@"Next button tapped");

    self.context.otherTopicText = [self.topicTextView.text copy];
    [self.topicTextView resignFirstResponder];
    [self createVisit];
    self.topicTextView.text = nil;
}

#pragma mark - UITextView Delegate

- (void)textViewDidChange:(UITextView *)textView {
    AWSDKLogInfo(@"textViewDidChange called. text =>%@<", textView.text);

    self.textViewPlaceHolder.hidden = (textView.text.length > 0);
}

#pragma mark - Handle keyboard Notifications

- (void)keyboardWillShow:(NSNotification *)notification {
    CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;

    UIEdgeInsets contentInsets;
    if (UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])) {
        contentInsets = UIEdgeInsetsMake(0.0, 0.0, (keyboardSize.height + 50), 0.0);
    } else {
        contentInsets = UIEdgeInsetsMake(0.0, 0.0, (keyboardSize.width + 50), 0.0);
    }

    self.topicTextView.contentInset = contentInsets;
    self.topicTextView.scrollIndicatorInsets = contentInsets;
}

- (void)keyboardWillHide:(NSNotification *)notification {
    self.topicTextView.contentInset = UIEdgeInsetsZero;
    self.topicTextView.scrollIndicatorInsets = UIEdgeInsetsZero;
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"visitCost"]) {
        ((CostTableViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0]).visit = sender;
        ((CostTableViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0]).context = self.context;
    }
}

#pragma mark - Private Methods

- (void)setupKeyboardNotifications {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

@end
