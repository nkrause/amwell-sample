//
//  CartVisitTopicsViewController.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 10/10/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//
#import "ProviderDetailViewController.h"

#import <AWSDK/AWSDKConsumerOverrides.h>
#import <AWSDK/AWSDKVisitContext.h>
#import <UIKit/UIKit.h>

@interface CartVisitTopicsViewController : UIViewController

@property (nonatomic, nonnull) id<AWSDKVisitContext> context;
@property (nonatomic, nullable) AWSDKConsumerOverrides *consumerOverrideDetails;

@end
