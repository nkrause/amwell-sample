//
//  FindFirstAvailableViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/18/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@class SpinnerControl;

// clang-format off
@protocol AWSDKVisitContext, AWSDKAppointment, AWSDKVisit;
// clang-format on

/**
 Handles all Find First Available visit tasks
 */
@interface FindFirstAvailableViewController : UIViewController

@property (nonatomic) id<AWSDKVisit> visit;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *cancelButton;
@property (weak, nonatomic) IBOutlet SpinnerControl *spinner;
@property (weak, nonatomic) IBOutlet UILabel *label;

@end
