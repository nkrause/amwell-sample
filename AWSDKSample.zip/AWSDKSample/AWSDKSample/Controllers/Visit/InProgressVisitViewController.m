//
//  InProgressVisitViewController.m
//  AWSDKSample
//
//  Created by Christopher Majoros on 8/13/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "InProgressVisitViewController.h"
#import "VisitSummaryTableViewController.h"
#import "WaitingRoomViewController.h"

#import <AWSDK/AWSDKVisitDisposition.h>

@interface InProgressVisitViewController ()

@property (nonatomic) AWSDKVisitDisposition currentDisposition;

@end

@implementation InProgressVisitViewController

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.currentDisposition = self.visit.disposition;
}

/**
 *  Rejoin Visit button handler
 */
#pragma mark - Action
- (IBAction)rejoinVisit {
    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Visit" bundle:nil];
    WaitingRoomViewController *waitingRoomController = [storyboard instantiateViewControllerWithIdentifier:@"WaitingRoomViewController"];

    waitingRoomController.visit = self.visit;
    self.visit.delegate = waitingRoomController;
    [self.navigationController pushViewController:waitingRoomController animated:YES];
}

/**
 *  End Visit button handler
 */
- (IBAction)endVisit {
    [MBProgressHUD showCancelingOn:self.view];
    void (^completion)(BOOL success, NSError *error) = ^void(BOOL success, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (error) {
            [self presentAlertWithError:error okHandler:^(UIAlertAction *action) {
                [self dismissViewControllerAnimated:YES completion:nil];
            }];
        } else {
            [self dismissViewControllerAnimated:YES completion:^{
                [self.visit fetchUpdatedStateWithCompletion:^(BOOL success, NSError *_Nullable error) {
                    if (self.currentDisposition != AWSDKVisitDispositionPreVisit) {
                        [self.delegate navigateToVisitSummaryForVisit:self.visit];
                    }
                }];
            }];
        }
    };
    if (self.visit.disposition == AWSDKVisitDispositionInVisit) {
        [AWSDKVisitService endActiveVisit:self.visit withCompletion:completion];
    } else {
        [AWSDKVisitService cancelPendingVisit:self.visit withCompletion:completion];
    }
}

@end

