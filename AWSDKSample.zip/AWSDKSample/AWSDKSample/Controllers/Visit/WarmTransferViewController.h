//
//  WarmTransferViewController.h
//  AWSDKSample
//
//  Created by Stephen Ciauri on 8/15/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "WaitingRoomViewController.h"

#import <AWSDK/AWSDKProvider.h>
#import <UIKit/UIKit.h>

/**
 Used to accept a warm transfer
 */
@protocol WarmTransferDelegate <NSObject>

- (void)acceptWarmTransferWithCompletion:(nullable CompletionBlock)completion;
- (void)cancelPendingVisit;

@end

@interface WarmTransferViewController : UIViewController

@property (nonatomic, nonnull) id<AWSDKProvider> provider;
@property (weak, nonatomic, nullable) id<WarmTransferDelegate> delegate;

@end
