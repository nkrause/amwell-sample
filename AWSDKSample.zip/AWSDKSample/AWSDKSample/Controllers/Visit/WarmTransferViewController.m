//
//  WarmTransferViewController.m
//  AWSDKSample
//
//  Created by Stephen Ciauri on 8/15/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "WarmTransferViewController.h"

#import "NSPersonNameComponents+Localizing.h"
#import "WaitingRoomViewController.h"

#import <AWSDK/AWSDKProviderType.h>

typedef void (^UIAlertActionBlock)(UIAlertAction *_Nonnull action);

@interface WarmTransferViewController ()

@property (weak) IBOutlet UILabel *transferTextLabel;
@property (weak) IBOutlet UIView *spinnerView;

@end

@implementation WarmTransferViewController

#pragma mark - Private methods
- (void)rotateSpinner {
    __weak typeof(self) weakSelf = self;
    [UIView animateWithDuration:2.0f
                     animations:^{
                         CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
                         animation.fromValue = @0.0;
                         animation.toValue = @(2 * M_PI);
                         animation.duration = 2.0f;
                         animation.repeatCount = INFINITY;
                         [weakSelf.spinnerView.layer addAnimation:animation forKey:@"SpinAnimation"];
                     }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self rotateSpinner];
    self.navigationItem.hidesBackButton = YES;
    self.transferTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"transfer.providerTransfer.transferring", "You are being transferred to x text"),
                                            self.provider.nameComponents.localizedFullName,
                                            self.provider.specialty.name];
    [self.delegate acceptWarmTransferWithCompletion:nil];
}

#pragma mark - IBActions
- (IBAction)cancelButtonTapped:(id)sender {
    AWSDKLogInfo(@"Cancel button tapped");
    NSString *title = NSLocalizedString(@"waitingRoom.cancel.title", @"Warm Transfer Cancel Title");
    NSString *message = NSLocalizedString(@"waitingRoom.cancel.message", @"Warm Transfer Cancel Message");
    NSString *confirm = NSLocalizedString(@"waitingRoom.cancel.confirm", @"Warm Transfer Cancel Confirm Title");
    NSString *cancel = NSLocalizedString(@"waitingRoom.cancel.cancel", @"Warm Transfer Cancel Cancel Title");
    UIAlertController *cancelAlert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    __weak typeof(self) weakSelf = self;
    UIAlertActionBlock confirmBlock = ^(UIAlertAction *_Nonnull action) {
        [weakSelf.delegate cancelPendingVisit];
    };
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:confirm style:UIAlertActionStyleDestructive handler:[cancelAlert defaultAlertHandler:confirmBlock]];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancel style:UIAlertActionStyleDefault handler:[cancelAlert defaultAlertHandler:nil]];
    [cancelAlert addAction:confirmAction];
    [cancelAlert addAction:cancelAction];

    [self presentAlertController:cancelAlert];
}

@end
