//
//  VisitContextTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 7/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "VisitContextTableViewController.h"
#import "AppDelegate.h"
#import "CheckTableCell.h"
#import "CostTableViewController.h"
#import "DisclaimerViewController.h"
#import "FieldHtmlTableViewCell.h"
#import "FieldTableViewCell.h"
#import "FindFirstAvailableViewController.h"
#import "HealthKitService.h"
#import "NSString+Sample.h"
#import "NSString+Validation.h"
#import "PickerTableViewCell.h"
#import "ResponseOptionsCell.h"
#import "SwitchTableViewCell.h"
#import "TTTAttributedLabel+Additions.h"
#import "TytoLiveStreamPairedTableViewCell.h"
#import "TytoLiveStreamPairingBaseViewController.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKAppointment.h>
#import <AWSDK/AWSDKBiologicalSex.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKConsumerUpdateForm.h>
#import <AWSDK/AWSDKHealthTrackerRecordForm.h>
#import <AWSDK/AWSDKHealthTrackerType.h>
#import <AWSDK/AWSDKLegalText.h>
#import <AWSDK/AWSDKLogService.h>
#import <AWSDK/AWSDKModality.h>
#import <AWSDK/AWSDKService.h>
#import <AWSDK/AWSDKSubscription.h>
#import <AWSDK/AWSDKPractice.h>
#import <AWSDK/AWSDKHealthPlan.h>
#import <AWSDK/AWSDKSystemConfiguration.h>
#import <AWSDK/AWSDKTriageQuestion.h>
#import <AWSDK/AWSDKVisit.h>
#import <AWSDK/AWSDKVisitContext.h>
#import <AWSDK/AWSDKVisitService.h>
#import <AWSDK/AWSDKVisitTopic.h>

#define UNPAIRED_CELL_ID (@"TytoLiveStreamUnpairedTableViewCell")
#define PAIRED_CELL_ID (@"TytoLiveStreamPairedTableViewCell")
#define CHANGE_WIFI_CELL_ID (@"TytoLiveStreamChangeWifiTableViewCell")

typedef NS_ENUM(NSUInteger, VisitContextSections) { TopicsSection, TriageSection, DisclaimersSection, HealthSummarySection, GuestSection };

typedef void (^UIAlertActionBlock)(UIAlertAction *_Nonnull action);

/**
 *  VisitContextTableViewController handles the initial pre visit screen questionaire. The visit context
 *  must be created and set, and if the questionaire flow is succcesful, a visit object will be created.
 *
 *  Note that two checks happen to determine state
 *  self.isFromFindFirstAvailable is intake during a Find First Available
 *  self.context.provider is nil before initiating Find First Available, nonnil otherwise
 */
@interface VisitContextTableViewController () <UITextFieldDelegate, TTTAttributedLabelDelegate, UIPickerViewDelegate, UIPickerViewDataSource, TytoLiveStreamPairingDelegate>

// IBOutlets
@property (weak, nonatomic) IBOutlet UIBarButtonItem *nextButton;

// HealthKit Related
@property BOOL shareHealthKitData;
@property BOOL showHealthKitOption;
@property (nonatomic) HealthKitService *hkService;

// Other Properties
@property BOOL acceptDisclaimersSelected;
@property (weak, nonatomic) UITextField *inviteGuestField;
@property (weak, nonatomic) UILabel *feedbackQuestion;
@property (nonatomic) UITextField *phoneField;
@property (nonatomic) NSMutableArray<NSString *> *guestList;
@property (nonatomic) NSString *overriddenPhoneNumber;
@property (nonatomic) UIFont *sectionHeaderLabelDefaultFont;
@property (nonatomic) id<AWSDKModality> selectedModality;
@property (weak, nonatomic) IBOutlet UITableViewHeaderFooterView *phoneVisitPhoneFooter;
@property (weak, nonatomic) IBOutlet UITableViewHeaderFooterView *otherTreatmentsHeader;
@property (weak, nonatomic) IBOutlet UILabel *phoneVisitPhoneFooterLabel;
@property (weak, nonatomic) IBOutlet UILabel *responseOptionsHeaderLabel;
@property (nonatomic) ResponseOptionsCell *responseOptionsCell;
@property (nonatomic, readonly) BOOL supportsBothModalities;
@property (nonatomic) BOOL selectedOptionPicked;
@property (nonatomic) NSArray<id<AWSDKModality>> *availableModalities;
@property (assign, nonatomic) BOOL hasTytoLiveStream;
@property (assign, nonatomic) BOOL isTytoLSPaired;
@end

@implementation VisitContextTableViewController
@synthesize consumer = _consumer;
@synthesize networkName = _networkName;
@synthesize networkPassword = _networkPassword;
@synthesize failedRequestAttempts = _failedRequestAttempts;
- (void)segueToCostHelper:(id<AWSDKVisit>)visit {
    //   If this is a phone visit, submit the question response and if that succeeds
    //   push to visit cost. Otherwise its a video visit so we push to  cost directly.
    if (self.context.selectedModality.code == AWSDKModalityCodePhone) {
        [MBProgressHUD showUpdatingOn:self.view];
        [visit submitFeedbackQuestion:self.context.consumerFeedbackQuestion
                           completion:^(BOOL success, NSError *error) {
                               [MBProgressHUD hideHUDForView:self.view];
                               if (error) {
                                   [self presentAlertWithError:error okHandler:nil];
                               } else {
                                   [self performSegueWithIdentifier:@"visitCostSegue" sender:visit];
                               }
                           }];
    } else {
        // Push to visit cost with AWSDKVisit
        [self performSegueWithIdentifier:@"visitCostSegue" sender:visit];
    }
}

#pragma mark AWSDK Method Calls
/**
 *  Creates a visit based on the current visit context
 *  Called by validatePhoneNumber
 */
- (void)createVisit {
    // Disable next ineraction
    [self.nextButton setEnabled:NO];

    if (self.shareHealthKitData) {
        AWSDKLogInfo(@"User opted to share the HealthKit data.");
    } else {
        AWSDKLogInfo(@"User opted to not share the HealthKit data or HealthKit is not available on this device.");
    }

    self.context.selectedModality = self.selectedModality;

    /**
     *  Create a visit object with a pre-visit context customized by the questionaire
     *
     *  @param result AWSDKVisit object to pass to CostViewController
     *  @param error AWSDKError
     */
    if ((self.selectedModality.code == AWSDKModalityCodePhone) && !self.selectedOptionPicked) {
        [self presentAlertWithMessageKey:@"visitSummary.feedback.none" okHandler:nil];
        self.nextButton.enabled = YES;
    } else {
        [MBProgressHUD showCreatingOn:self.view];
        [AWSDKVisitService createVisitWithContext:self.context
                                       completion:^(id<AWSDKVisit> visit, NSError *error) {
                                           [MBProgressHUD hideHUDForView:self.view];

                                           if (error) {
                                               NSArray *recoverableErrorCodes = @[
                                                   @(AWSDKErrorCodeValidationBadEligibilityInformation),
                                                   @(AWSDKErrorCodeValidationEligibilityException),
                                                   @(AWSDKErrorCodeInvalidValue),
                                                   @(AWSDKErrorCodeEligibilityInaccuratePrimarySubscriberInfo),
                                                   @(AWSDKErrorCodeEligibilityInaccurateDependentSubscriberInfo)
                                               ];
                                               if (visit && [recoverableErrorCodes containsObject:@(error.code)]) {
                                                   UIAlertController *ac = [UIAlertController alertControllerWithError:error];

                                                   UIAlertActionBlock okBlock = ^(UIAlertAction *_Nonnull action) {
                                                       [self segueToCostHelper:visit];
                                                   };
                                                   UIAlertActionBlock cancelBlock = ^(UIAlertAction *_Nonnull action) {
                                                       [self dismissViewControllerAnimated:YES completion:nil];
                                                   };

                                                   [ac addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.ok", @"Visit Context Okay Title")
                                                                                          style:UIAlertActionStyleDefault
                                                                                        handler:[ac defaultAlertHandler:okBlock]]];
                                                   [ac addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.cancel", @"Visit Context Cancel Title")
                                                                                          style:UIAlertActionStyleCancel
                                                                                        handler:[ac defaultAlertHandler:cancelBlock]]];
                                                   [self presentAlertController:ac];
                                               } else if (error.code == AWSDKErrorCodeTimeout && visit.consumer.subscription.healthPlan.suppressCharge) {
                                                   [self segueToCostHelper:visit];
                                               } else {
                                                   [self presentAlertWithError:error
                                                                     okHandler:^(UIAlertAction *action) {
                                                                         [self dismissViewControllerAnimated:YES completion:nil];
                                                                     }];
                                               }
                                           } else { // SUCCESS CASE
                                               [self segueToCostHelper:visit];
                                           }
                                       }];
    }
}

/**
 *  Creates a visit context given an appointment
 *  Called by validatePhoneNumber
 *
 *  @param appointment appointment to create a visit context from
 */
- (void)createVisitContextForAppointment:(id<AWSDKAppointment>)appointment {
    [MBProgressHUD showCreatingOn:self.view];
    // Create a visit Context for an appointment
    [AWSDKVisitContext createVisitContextForAppointment:appointment
                                             completion:^(id result, NSError *error) {
                                                 [MBProgressHUD hideHUDForView:self.view];
                                                 if (error) {
                                                     [self presentAlertWithError:error
                                                                       okHandler:^(UIAlertAction *action) {
                                                                           [self dismissViewControllerAnimated:YES completion:nil];
                                                                       }];
                                                 } else {
                                                     self.context = result;
                                                     [self.tableView reloadDataAnimated:YES];
                                                 }
                                             }];
}

/**
 *  Creating a visit requires a phone number to call the consumer back if one gets disconnected
 */
- (void)updateCallbackNumber:(void (^)(BOOL success))completion {
    // If a validation error for the callback number, scroll to the section
    void (^scrollToCallbackNumber)(UIAlertAction *action) = ^void(UIAlertAction *action) {
        [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:[self sectionCallbackNumber]] atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    };
    // Check if callback number has been verified
    if (!self.phoneField) {
        [self presentAlertWithMessageKey:@"intake.phoneVerify" okHandler:scrollToCallbackNumber];
        return;
    }
    // Visit requires a phone number for the consumer check if a phone number is listed
    if (!self.phoneField.text.length) {
        // Required
        [self presentAlertWithMessageKey:@"intake.phoneRequired" okHandler:scrollToCallbackNumber];
        return;
    }
    // Update callback number to text in phoneField
    [self.context updateCallbackNumber:self.phoneField.text
                            completion:^(BOOL success, NSError *error) {
                                if (error) {
                                    [self presentAlertWithError:error okHandler:nil];
                                }
                                if (completion) {
                                    completion(success);
                                }
                            }];
}

/**
 *  Adds guests to the context for multi way video
 */
- (void)updateGuestList:(void (^)(BOOL success))completion {
    __weak typeof(self) weakSelf = self;
    [self.context updateVisitGuestEmails:self.guestList
                              completion:^(BOOL success, NSError *error) {
                                  if (error) {
                                      [weakSelf presentAlertWithError:error okHandler:nil];
                                  }
                                  if (completion) {
                                      completion(success);
                                  }
                              }];
}

/**
 Sync HealthKit data with the server befor creating the visit context.
 */
- (void)syncHealthKitData:(void (^)(BOOL success))completion {
    [self.hkService upload:^(BOOL success, NSError *error) {
        if (!success) {
            AWSDKLogError(@"An error occured: %@", error.localizedDescription);
            completion(NO);
        } else {
            completion(YES);
        }
    }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[UINib nibWithNibName:UNPAIRED_CELL_ID bundle:[NSBundle bundleForClass:self.class]] forCellReuseIdentifier:UNPAIRED_CELL_ID];
    [self.tableView registerNib:[UINib nibWithNibName:PAIRED_CELL_ID bundle:[NSBundle bundleForClass:self.class]] forCellReuseIdentifier:PAIRED_CELL_ID];
    [self.tableView registerNib:[UINib nibWithNibName:CHANGE_WIFI_CELL_ID bundle:[NSBundle bundleForClass:self.class]] forCellReuseIdentifier:CHANGE_WIFI_CELL_ID];

    if (self.appointment) {
        [self createVisitContextForAppointment:self.appointment];
    }

    NSPredicate *supportedModalityPredicate = [NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        id<AWSDKModality> modality = (id<AWSDKModality>)evaluatedObject;
        return modality.code != AWSDKModalityCodeUndefined;
    }];
    self.availableModalities = [self.practice.availableModalities filteredArrayUsingPredicate:supportedModalityPredicate];
    if (self.context.selectedModality) {
        self.selectedModality = self.context.selectedModality;
        // Assign the context's practice to self.practice.
        // because this is a transfer.
        self.practice = self.context.practice;
    } else if (self.appointment) {
        self.selectedModality = self.appointment.modality;
    } else if (self.availableModalities.count > 0) {
        self.selectedModality = self.availableModalities.firstObject;
    }

    self.hkService = [[HealthKitService alloc] init];
    self.showHealthKitOption = NO;

    if (!self.isFromFindFirstAvailable) {
        [self setTitle:NSLocalizedString(@"intake.title", @"Visit Context Title")];
    } else {
        [self setTitle:NSLocalizedString(@"intake.setupVisit", @"Visit Context Setup Visit Title")];
    }
    [self.nextButton setTitle:NSLocalizedString(@"intake.next", @"Visit Context Next Title")];

    self.tableView.estimatedRowHeight = 44.0;
    self.tableView.estimatedSectionFooterHeight = 10.0;
    self.tableView.estimatedSectionHeaderHeight = 25.0;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.sectionFooterHeight = UITableViewAutomaticDimension;
    self.tableView.sectionHeaderHeight = UITableViewAutomaticDimension;

    if ([self.navigationController.viewControllers.firstObject isEqual:self] || self.isFromFindFirstAvailable || self.isTransfer) {
        // If first item in the navigation stack we should add a close button
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelTapped)];
    }

    self.phoneVisitPhoneFooterLabel.text = NSLocalizedString(@"intake.phoneVisitFooter", @"Phone visit telephone footer");
    self.responseOptionsHeaderLabel.text = NSLocalizedString(@"intake.phoneVisitResponseOptions", @"Response Options header");
    self.phoneVisitPhoneFooter.contentView.backgroundColor = [UIColor whiteColor];
    // 0 on up are valid options so we need to see if the user made a selection later before visit is created
    self.selectedOptionPicked = NO;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.navigationController.navigationBar setNeedsLayout];
    if ([self.hkService isHealthDataAvailable]) {
        // Looks like HealthKit data is available. Lets check for permissions.
        [self.hkService requestAuthorization:^(BOOL success, NSError *error) {
            if (!success) {
                AWSDKLogInfo(@"Error prompting the user for authorization for reading and writing the requested health kit types. Error: %@", error);
            } else {
                AWSDKLogInfo(@"Successfully prompted the user for authorization for reading and writing the requested health kit types.");
            }
        }];
    }
}

#pragma mark UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return ([self sectionTopics] >= 0) + ([self sectionTriage] >= 0) + ([self sectionHealthSummary] >= 0) + ([self sectionCallbackNumber] >= 0) + ([self sectionTytoLS] >= 0) + ([self sectionGuests] >= 0)
        + ([self sectionOtherTreatments] >= 0) + ([self sectionLegalText] >= 0) + ([self sectionVisitModality] >= 0);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Topics
    if (section == [self sectionTopics]) {
        return self.context.visitTopics.count + ([AWSDKSystemConfiguration isOtherTopicEnabled] ? 1 : 0);
        // TriageSection
    } else if (section == [self sectionTriage]) {
        return self.context.triageQuestions.count;
        // Legal Text
    } else if (section == [self sectionLegalText]) {
        return 2;
        // Share Health Summary
    } else if (section == [self sectionHealthSummary]) {
        return self.showHealthKitOption ? 2 : 1;
        // Multiway Visit Guests
    } else if (section == [self sectionGuests]) {
        return (self.guestList.count < [AWSDKSystemConfiguration maxVideoGuests]) + self.guestList.count;
        // Callback Number
    } else if (section == [self sectionCallbackNumber]) {
        return 1;
    } else if (section == [self sectionTytoLS]) {
        // TytoLS
        if (self.isTytoLSPaired) {
            return 2;
        }
        return 1;
    } else if (section == [self sectionVisitModality]) {
        // could be 2 if both modes
        if (self.isTransfer) {
            return 1;
        } else if (self.availableModalities) {
            return self.availableModalities.count;
        } else {
            AWSDKLogError(@"Why are there no visit modalities?");
        }
    } else if (section == [self sectionOtherTreatments]) {
        return (self.selectedModality.code == AWSDKModalityCodePhone) ? 1 : 0;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Topics
    if (indexPath.section == [self sectionTopics]) {
        if (indexPath.row < self.context.visitTopics.count) {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];

            id<AWSDKVisitTopic> topic = self.context.visitTopics[indexPath.row];

            [cell.textLabel setText:[topic title]];
            [cell setAccessoryType:([topic selected] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone)];

            return cell;

        } else {
            FieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"fieldCell"];

            [cell.textField setText:self.context.otherTopicText];
            [cell.textField setPlaceholder:NSLocalizedString(@"intake.other", @"Visit Context Other Title")];

            [cell.textField addTarget:self action:@selector(otherFieldChanged:) forControlEvents:UIControlEventEditingChanged];

            return cell;
        }

        // Triage Questions
    } else if (indexPath.section == [self sectionTriage]) {
        FieldHtmlTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"triageCell"];
        id<AWSDKTriageQuestion> question = self.context.triageQuestions[indexPath.row];
        [self processTriageQuestion:question.question forAttributedLabel:cell.headerLabel];

        cell.detailTextField.text = question.response;
        cell.detailTextField.placeholder = NSLocalizedString(@"intake.answer", @"Visit Context Answer Title");
        [cell.detailTextField addTarget:self action:@selector(triageResponseChanged:) forControlEvents:UIControlEventEditingChanged];
        return cell;

        // Disclaimers and legal text
    } else if (indexPath.section == [self sectionLegalText]) {
        if (indexPath.row == 0) {
            NSPredicate *requiredPredicate = [NSPredicate predicateWithFormat:@"required = YES"];
            id<AWSDKLegalText> disclaimer = [self.context.legalText filteredArrayUsingPredicate:requiredPredicate].firstObject;
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            cell.textLabel.text = disclaimer.type == TypeSpecialty ? NSLocalizedString(@"intake.privacyPolicy.plural", @"Plural privacy policies word")
                                                                   : NSLocalizedString(@"intake.privacyPolicy.singular", @"Singular privacy policy word");

            [cell setAccessoryType:UITableViewCellAccessoryDetailButton];

            return cell;

        } else {
            SwitchTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"switchCell"];

            [cell.label setText:NSLocalizedString(@"intake.disclaimers", @"Visit Context Disclaimers Title")];

            [cell.toggle setOn:self.acceptDisclaimersSelected];

            [cell.toggle addTarget:self action:@selector(acceptDisclaimersChanged:) forControlEvents:UIControlEventValueChanged];

            return cell;
        }

        // Health Summary
    } else if (indexPath.section == [self sectionHealthSummary]) {
        SwitchTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"switchCell"];

        if (indexPath.row == 0) {
            [cell.label setText:NSLocalizedString(@"intake.summary", @"Visit Context Summary Title")];

            [cell.toggle setOn:self.context.shareHealthHistory];

            [cell.toggle addTarget:self action:@selector(shouldShareHealthSummaryChanged:) forControlEvents:UIControlEventValueChanged];
        } else if (indexPath.row == 1) {
            [cell.label setText:NSLocalizedString(@"healthkit.visit.alert.title", @"Share HealthKit Data")];

            [cell.toggle setOn:NO];

            [cell.toggle addTarget:self action:@selector(shouldShareHealthKitData:) forControlEvents:UIControlEventValueChanged];
        }

        return cell;

        // Guests
    } else if (indexPath.section == [self sectionGuests]) {
        if (self.guestList.count && indexPath.row < self.guestList.count) {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];

            [cell setAccessoryType:UITableViewCellAccessoryNone];

            [cell.textLabel setText:self.guestList[indexPath.row]];

            return cell;
        } else {
            FieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"fieldCell"];
            cell.textField.autocorrectionType = UITextAutocorrectionTypeNo;

            if (!self.inviteGuestField) {
                [cell.textField setText:@""];
                cell.textField.keyboardType = UIKeyboardTypeEmailAddress;
            }
            self.inviteGuestField = cell.textField;
            [self.inviteGuestField removeTarget:self action:@selector(otherFieldChanged:) forControlEvents:UIControlEventAllEvents];

            [self.inviteGuestField setPlaceholder:NSLocalizedString(@"intake.addGuest", @"Visit Context Add Guest Title")];

            UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
            [toolbar setItems:@[
                [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"intake.cancel", @"Visit Context Cancel Title") style:UIBarButtonItemStylePlain target:self action:@selector(cancelAdd:)],
                [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"intake.add", @"Visit Context Add Title") style:UIBarButtonItemStyleDone target:self action:@selector(addGuest:)]
            ]];
            [toolbar setTintColor:[UIColor aquaColor]];
            [toolbar sizeToFit];
            [self.inviteGuestField setInputAccessoryView:toolbar];

            return cell;
        }
        // Phone number requirement
    } else if (indexPath.section == [self sectionCallbackNumber]) {
        FieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"phoneCell"];

        self.phoneField = cell.textField;

        cell.label.text = (self.selectedModality.code == AWSDKModalityCodeVideo) ? NSLocalizedString(@"intake.phoneHeaderVideo", @"Phone number header for video")
                                                                                 : NSLocalizedString(@"intake.phoneHeaderVoice", @"Phone number header for voice");

        cell.label.font = [UIFont systemFontOfSize:19.0f weight:UIFontWeightLight];
        cell.label.textColor = [UIColor toggletxtTealColor];
        // Grab the phone from the visit context if possible. If it's not available grab from the consumers object.
        NSString *phone;
        if (self.appointment && self.appointment.formattedInitiatorEngagementOverridePhone) {
            phone = self.appointment.formattedInitiatorEngagementOverridePhone;
        } else if (self.overriddenPhoneNumber.isPopulated) {
            phone = self.overriddenPhoneNumber;
        } else if (self.context.phoneNumber.isPopulated) {
            phone = self.context.phoneNumber;
        } else {
            phone = self.context.consumer.phoneNumber;
        }
        [self.phoneField setText:phone];

        [cell.textField addTarget:self action:@selector(phoneNumberOverridden:) forControlEvents:UIControlEventEditingChanged];
        return cell;
        
    } else if (indexPath.section == [self sectionTytoLS]) {
        // Tyto Live Stream
        if (self.isTytoLSPaired) {
            if (indexPath.row == 0) {
                UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:PAIRED_CELL_ID];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                ((TytoLiveStreamPairedTableViewCell *)cell).label.text = NSLocalizedString(@"Tyto.VisitContext.TytoLiveStreamPairedSuccessCell.Message", @"Message label");
                return cell;
            } else {
                return [tableView dequeueReusableCellWithIdentifier:CHANGE_WIFI_CELL_ID];
            }
        } else {
            return [tableView dequeueReusableCellWithIdentifier:UNPAIRED_CELL_ID];
        }
    } else if (indexPath.section == [self sectionVisitModality]) {
        if (self.supportsBothModalities) {
            CheckTableCell *cell = [tableView dequeueReusableCellWithIdentifier:@"checkcell"];

            cell.modalityLabel.text = self.availableModalities[indexPath.row].code == AWSDKModalityCodeVideo ? NSLocalizedString(@"visit.video", @"video label")
                                                                                                                      : NSLocalizedString(@"visit.phoneCall", @"Phone label");

            cell.isChecked = (self.selectedModality.code == self.availableModalities[indexPath.row].code);
            return cell;
        } else {
            // Only one modality
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            cell.textLabel.text = self.selectedModality.code == AWSDKModalityCodeVideo ? NSLocalizedString(@"visit.video", @"Video label") : NSLocalizedString(@"visit.phoneCall", @"Phone label");
            return cell;
        }
    } else if (indexPath.section == [self sectionOtherTreatments]) {
        if (!self.responseOptionsCell) {
            self.responseOptionsCell = [tableView dequeueReusableCellWithIdentifier:@"ResponseOptionCell"];
            self.responseOptionsCell.responseOptionsPicker.delegate = self;
            self.responseOptionsCell.responseOptionsPicker.dataSource = self;
            self.responseOptionsCell.textField.delegate = self;
        }
        [self.responseOptionsCell.responseOptionsPicker selectRow:0 inComponent:0 animated:NO];
        return self.responseOptionsCell;
    }
    return [UITableViewCell new];
}

- (void)dismissPicker {
    [self.responseOptionsCell.textField resignFirstResponder];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == [self sectionOtherTreatments]) {
        if (self.selectedModality.code == AWSDKModalityCodeVideo) {
            return nil;
        } else {
            return self.otherTreatmentsHeader;
        }
    }
    return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    if (section == [self sectionCallbackNumber]) {
        if (self.selectedModality.code == AWSDKModalityCodeVideo) {
            return nil;
        } else {
            return self.phoneVisitPhoneFooter;
        }
    }
    return nil;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    // Topics
    if (section == [self sectionTopics]) {
        return NSLocalizedString(@"intake.topics", @"Visit Context Topics Title");
        // TriageSection
    } else if (section == [self sectionTriage]) {
        return NSLocalizedString(@"intake.triageQuestions", @"Visit Context Triage Questions Title");
        // Legal Text
    } else if (section == [self sectionLegalText]) {
        return NSLocalizedString(@"intake.disclaimers.title", @"Visit Context Disclaimers Title");
        // Share Health Summary
    } else if (section == [self sectionHealthSummary]) {
        return NSLocalizedString(@"intake.healthSummary", @"Visit Context Health Summary Title");
        // Multiway Visit Guests
    } else if (section == [self sectionGuests]) {
        return NSLocalizedString(@"intake.guests", @"Visit Context Guests Title");
        // Callback number
    } else if (section == [self sectionCallbackNumber]) {
        return NSLocalizedString(@"intake.phone", @"Visit Context Phone Title");
    } else if (section == [self sectionVisitModality]) {
        return NSLocalizedString(@"intake.visitType", @"Visit Type, phone or video");
    }
    return @"";
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
    if ([view isKindOfClass:[UITableViewHeaderFooterView class]]) {
        UITableViewHeaderFooterView *headerView = (UITableViewHeaderFooterView *)view;
        if (!self.sectionHeaderLabelDefaultFont) {
            self.sectionHeaderLabelDefaultFont = headerView.textLabel.font;
        }
        headerView.textLabel.textAlignment = NSTextAlignmentNatural;
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return indexPath.section == [self sectionGuests];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (UITableViewCellEditingStyleDelete) {
        [self.guestList removeObjectAtIndex:indexPath.row];
        [self.tableView reloadDataAnimated:YES];
    }
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return indexPath.section == [self sectionGuests] ? UITableViewCellEditingStyleDelete : UITableViewCellEditingStyleNone;
}

#pragma mark - UITableView Helper Methods

- (BOOL)supportsBothModalities {
    if (self.isTransfer) {
        return NO;
    } else {
        return self.availableModalities.count > 1;
    }
}

- (NSInteger)sectionTopics {
    if (!self.isFromFindFirstAvailable && ([AWSDKSystemConfiguration isOtherTopicEnabled] || self.context.visitTopics.count > 0)) {
        return 0;
    }
    return -1;
}

- (NSInteger)sectionTriage {
    if (!self.isFromFindFirstAvailable && self.context.triageQuestions.count && self.context.showTriageQuestions) {
        return ([self sectionTopics] >= 0);
    }
    return -1;
}

- (NSInteger)sectionVisitModality {
    if (!self.isFromFindFirstAvailable) {
        return ([self sectionTopics] >= 0) + ([self sectionTriage] >= 0);
    }
    return -1;
}

- (NSInteger)sectionCallbackNumber {
    if (!self.isFromFindFirstAvailable) {
        return ([self sectionTopics] >= 0) + ([self sectionTriage] >= 0) + ([self sectionVisitModality] >= 0);
    }
    return -1;
}

- (NSInteger)sectionTytoLS {
    if (self.hasTytoLiveStream) {
        return ([self sectionTopics] >= 0) + ([self sectionTriage] >= 0) + ([self sectionVisitModality] >= 0) + ([self sectionCallbackNumber] >= 0);
    } else {
        return -1;
    }
}

- (NSInteger)sectionHealthSummary {
    return ([self sectionTopics] >= 0) + ([self sectionTriage] >= 0) + ([self sectionVisitModality] >= 0) + ([self sectionCallbackNumber] >= 0) + ([self sectionTytoLS] >= 0);

}

- (NSInteger)sectionOtherTreatments {
    if (self.selectedModality.code == AWSDKModalityCodePhone) {
        return ([self sectionTopics] >= 0) + ([self sectionTriage] >= 0) + ([self sectionHealthSummary] >= 0) + ([self sectionVisitModality] >= 0) + ([self sectionCallbackNumber] >= 0) + ([self sectionTytoLS] >= 0);

    }
    return -1;
}

- (NSInteger)sectionGuests {
    if ([AWSDKSystemConfiguration areVideoGuestsSupported] && self.selectedModality.code == AWSDKModalityCodeVideo) {
        return ([self sectionTopics] >= 0) + ([self sectionTriage] >= 0) + ([self sectionHealthSummary] >= 0) + ([self sectionVisitModality] >= 0) + ([self sectionCallbackNumber] >= 0) + ([self sectionTytoLS] >= 0);

    }
    return -1;
}

- (NSInteger)sectionLegalText {
    if (self.context.legalText.count) {
        return ([self sectionTopics] >= 0) + ([self sectionTriage] >= 0) + ([self sectionHealthSummary] >= 0) + ([self sectionVisitModality] >= 0) + ([self sectionCallbackNumber] >= 0) + ([self sectionTytoLS] >= 0)
            + ([self sectionGuests] >= 0) + ([self sectionOtherTreatments] >= 0);
    }
    return -1;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
    NSPredicate *requiredPredicate = [NSPredicate predicateWithFormat:@"required = YES"];
    id<AWSDKLegalText> disclaimer = [self.context.legalText filteredArrayUsingPredicate:requiredPredicate].firstObject;

    [self performSegueWithIdentifier:@"showDisclaimerSegue" sender:disclaimer];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger section = indexPath.section;
    if (section == [self sectionTopics] && indexPath.row < self.context.visitTopics.count) {
        id<AWSDKVisitTopic> topic = self.context.visitTopics[indexPath.row];
        BOOL selected = !topic.selected;
        AWSDKLogInfo(@"%@ topic: %@", selected ? @"Selected" : @"Deselected", topic.title);
        topic.selected = selected;
        [tableView reloadRowsAtIndexPaths:@[ indexPath ] withRowAnimation:UITableViewRowAnimationFade];
    }

    if (section == [self sectionVisitModality]) {
        if (!self.supportsBothModalities || self.selectedModality.code == self.availableModalities[indexPath.row].code) {
            //  action not  needed  when only one modality is supported, or we have 2 but are not changing modalities
            return;
        }
        // switch the videoAWSDKModality
        self.selectedModality = self.availableModalities[indexPath.row];
        [tableView reloadData];
    }
    
    if (section == [self sectionTytoLS]) {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        if (!self.isTytoLSPaired || (self.isTytoLSPaired && indexPath.row != 0)) {
            [self performSegueWithIdentifier:@"TytoLiveStreamPairing" sender:nil];
        }
    }
}

#pragma mark - UITextFieldDelegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    return textField != self.responseOptionsCell.textField;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (textField == self.responseOptionsCell.textField) {
        self.context.consumerFeedbackQuestion.selectedOption = [self.responseOptionsCell.responseOptionsPicker selectedRowInComponent:0];
        textField.text = self.context.consumerFeedbackQuestion.responseOptions[self.context.consumerFeedbackQuestion.selectedOption];
        self.selectedOptionPicked = YES;
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    textField.text = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    AWSDKLogInfo(@"Text field: '%@' ended editing with value: %@", textField.placeholder, textField.text);
}

#pragma mark - TTTAttributedLabelDelegate

- (void)attributedLabel:(TTTAttributedLabel *)label didSelectLinkWithURL:(NSURL *)linkURL {
    NSURL *url = (linkURL.scheme.length) ? linkURL : [[NSURL alloc] initWithString:[@"https://" stringByAppendingString:linkURL.absoluteString]];
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        [[UIApplication sharedApplication] openURL:url
                                           options:@{}
                                 completionHandler:^(BOOL success) {
                                     AWSDKLogInfo(@"Opened URL ->%@<", url.absoluteString);
                                 }];
    }
}

#pragma mark - Observers, Setters, Getters
- (void)acceptDisclaimersChanged:(UISwitch *)sender {
    AWSDKLogInfo(@"Accept disclaimers set to: %@", sender.isOn ? @"Enabled" : @"Disabled");
    self.acceptDisclaimersSelected = [sender isOn];
}

- (void)shouldShareHealthSummaryChanged:(UISwitch *)sender {
    AWSDKLogInfo(@"Share health summary set to: %@", sender.isOn ? @"Enabled" : @"Disabled");
    self.context.shareHealthHistory = [sender isOn];

    if ([(UISwitch *)sender isOn]) {
        if ([self.hkService canSeeHealthKitData] && self.hkService.hkTypes.count > 0) {
            self.showHealthKitOption = YES;
        }
    } else {
        self.showHealthKitOption = NO;
    }

    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:[self sectionHealthSummary]] withRowAnimation:UITableViewRowAnimationFade];
}

- (void)shouldShareHealthKitData:(id)sender {
    self.shareHealthKitData = [(UISwitch *)sender isOn];

    if ([(UISwitch *)sender isOn]) {
        [self presentAlertWithMessageKey:@"healthkit.visit.alert.message"
            yesHandler:^(UIAlertAction *action) {
                self.shareHealthKitData = YES;
            }
            noHandler:^(UIAlertAction *action) {
                self.shareHealthKitData = NO;
                [(UISwitch *)sender setOn:NO];
            }];
    }
}

- (void)triageResponseChanged:(id)sender {
    UITableViewCell *cell = (UITableViewCell *)[[sender superview] superview];

    NSInteger index = [[self.tableView indexPathForCell:cell] row];

    id<AWSDKTriageQuestion> question = [self.context.triageQuestions objectAtIndex:index];

    [question setResponse:[(UITextField *)sender text]];
}

- (void)phoneNumberOverridden:(UITextField *)textField {
    self.overriddenPhoneNumber = textField.text;
}

- (void)otherFieldChanged:(id)sender {
    self.context.otherTopicText = [(UITextField *)sender text];
}

- (void)setContext:(id<AWSDKVisitContext>)context {
    self.guestList = [[NSMutableArray alloc] initWithArray:self.context.guestEmails];
    _context = context;
    self.practice = self.context.practice;
    if (self.context.practice.deviceIntegrationMode == TYTO_LIVESTREAM) {
        [MBProgressHUD showCreatingOn:self.view];
        [self getTytoDevicePairingDetailsFromVisitContext:self.context withCompletion:^{
            [MBProgressHUD hideHUDForView:self.view];
            [self.tableView reloadDataAnimated:YES];
        }];
    }
}

#pragma mark - IBActions
- (void)cancelTapped {
    AWSDKLogInfo(@"Cancel tapped");
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)nextPressed:(id)sender {
    AWSDKLogInfo(@"Next tapped");
    if (![self isValidInput:sender]) {
        return;
    }

    if (self.shareHealthKitData) {
        // Gather and share the HealthKit data, then continue to performNextAction regardless if the sync was successful or not
        [self syncHealthKitData:^(BOOL success) {
            if (!success) {
                [self presentAlertWithMessageKey:@"healthkit.alert.upload.failed.message"
                                       okHandler:^(UIAlertAction *action) {
                                           [self performNextAction];
                                       }];
            } else {
                [self performNextAction];
            }
        }];

    } else {
        // Just perform the next action
        [self performNextAction];
    }
}

- (void)showUnaddedGuestAlert:(id)sender {
    NSString *alertTitle = NSLocalizedString(@"intake.guest.notAdded.title", @"Visit Context Guess Not Added Title");
    NSString *alertMessage = NSLocalizedString(@"intake.guest.notAdded.message", @"Visit Context Guess Not Added Message");
    NSString *continueMessage = NSLocalizedString(@"misc.continue", @"Visit Context Continue Title");
    NSString *cancelMessage = NSLocalizedString(@"misc.cancel", @"Visit Context Cancel Title");
    UIAlertController *unaddedGuestAlert = [UIAlertController alertControllerWithTitle:alertTitle message:alertMessage];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancelMessage style:UIAlertActionStyleCancel handler:[unaddedGuestAlert defaultAlertHandler:nil]];

    UIAlertActionBlock continueBlock = ^(UIAlertAction *_Nonnull action) {
        [self.inviteGuestField setText:@""];
        self.inviteGuestField = nil;
        [self nextPressed:sender];
    };

    UIAlertAction *continueAction = [UIAlertAction actionWithTitle:continueMessage style:UIAlertActionStyleDefault handler:[unaddedGuestAlert defaultAlertHandler:continueBlock]];
    [unaddedGuestAlert addAction:continueAction];
    [unaddedGuestAlert addAction:cancelAction];
    [self presentViewController:unaddedGuestAlert animated:YES completion:nil];
}

- (void)cancelAdd:(id)sender {
    [self dismissKeyboard];
}

- (void)addGuest:(id)sender {
    if ([self.inviteGuestField isPopulated]) {
        if ([[self.guestList valueForKey:@"lowercaseString"] containsObject:[[self.inviteGuestField.text lowercaseString] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]]) {
            [self presentAlertWithTitle:NSLocalizedString(@"intake.guest.duplicate.title", @"Title for email duplicate")
                                message:NSLocalizedString(@"intake.guest.duplicate.message", @"Message indicating that duplicate guest emails are not permitted")
                              okHandler:^(UIAlertAction *action) {
                                  [self.inviteGuestField setText:@""];
                              }];
        } else if (![self.inviteGuestField.text isValidEmailAddress]) {
                    [self presentAlertWithTitle:NSLocalizedString(@"intake.guest.invalid.email.title", @"Title for invalid email")
                                        message:NSLocalizedString(@"intake.guest.invalid.email.message", @"Message indicating that invalid guest emails are not permitted")
                                      okHandler:^(UIAlertAction *action) {
                                          [self.inviteGuestField setText:@""];
                                      }];
        } else {
            [self.guestList addObject:[NSString stringWithString:self.inviteGuestField.text]];
            [self.inviteGuestField setText:@""];
            [self setInviteGuestField:nil];
            [self.tableView reloadDataAnimated:YES];
        }
    }
}

#pragma mark - Private Methods
- (void)performNextAction {
    void (^successBlock)(BOOL success) = ^void(BOOL success) {
        if (success) {
            [self createVisit];
        }
    };

    // If there are guests, updateGuest list first
    if ([self sectionGuests] >= 0) {
        [self updateGuestList:^(BOOL success) {
            // Check if phoneNumber needs to be updated
            if (success && [self sectionCallbackNumber] >= 0) {
                [self updateCallbackNumber:successBlock];
                // Otherwise just create the visit
            } else {
                successBlock(YES);
            }
        }];
        // If no guests, check if updateCallbackNumber
    } else if ([self sectionCallbackNumber] >= 0 && ![self.phoneField.text isEqualToString:self.context.consumer.phoneNumber]) {
        [self updateCallbackNumber:successBlock];
        // Otherwise just create the visit
    } else {
        successBlock(YES);
    }
}

- (BOOL)isValidInput:(id)sender {
    // Check if legal text needs to be accepted
    if ([self sectionLegalText] >= 0) {
        if (!self.acceptDisclaimersSelected) {
            [self presentAlertWithTitle:NSLocalizedString(@"intake.disclaimers.title", @"Visit Context Disclaimers Title")
                                message:NSLocalizedString(@"intake.disclaimers.message", @"Visit Context Disclaimers Message")
                              okHandler:nil];
            return NO;
        } else {
            // Apply the accepted
            for (id<AWSDKLegalText> text in self.context.legalText) {
                [text setAccepted];
            }
        }
    }

    // Check if guest field has a field that hasn't been applied
    if ([self sectionGuests] >= 0 && self.inviteGuestField.text.length) {
        [self showUnaddedGuestAlert:sender];
        return NO;
    }

    return YES;
}

- (void)processTriageQuestion:(NSString *)question forAttributedLabel:(TTTAttributedLabel *)headerLabel {
    UIColor *foregroundColor = [UIColor toggletxtTealColor];
    UIFont *textFont = [UIFont systemFontOfSize:19.0f weight:UIFontWeightLight];
    NSDictionary *attributes = @{
        NSFontAttributeName : textFont,
        NSKernAttributeName : [NSNull null],
        (id)kCTForegroundColorAttributeName : foregroundColor,
        (id)kTTTBackgroundFillColorAttributeName : (id)[UIColor clearColor].CGColor
    };

    headerLabel.enabledTextCheckingTypes = NSTextCheckingTypeLink;
    headerLabel.lineBreakMode = NSLineBreakByWordWrapping;
    headerLabel.numberOfLines = 0;

    // Sample triage questions with html links that is handled by code below
    // Click <a href="https://www.apple.com">here</a> to go to Apple. Click <a href="https://www.google.com">there</a> to go to Google.
    if ([question localizedCaseInsensitiveContainsString:HTTP_LINK]) {
        [headerLabel mapHTMLLinksForString:question withAttributes:attributes];
    } else {
        NSAttributedString *triageQuestion = [[NSAttributedString alloc] initWithString:question attributes:attributes];
        headerLabel.text = triageQuestion;
    }
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // simple < button for all pushed screens
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationItem.backBarButtonItem = backButton;
    if ([segue.identifier isEqualToString:@"visitCostSegue"]) {
        [(CostTableViewController *)segue.destinationViewController setVisit:(id<AWSDKVisit>)sender];
        ((CostTableViewController *)segue.destinationViewController).context = self.context;
    } else if ([segue.identifier isEqualToString:@"showDisclaimerSegue"]) {
        [(DisclaimerViewController *)segue.destinationViewController setDisclaimer:(id<AWSDKLegalText>)sender];
    } else if ([segue.identifier isEqualToString:@"TytoLiveStreamPairing"]) {
        TytoLiveStreamPairingBaseViewController *tytoLiveStreamPairingBaseViewController = segue.destinationViewController;
        _consumer = self.context.consumer;
        _networkName = @"";
        _networkPassword = @"";
        _failedRequestAttempts = 0;
        tytoLiveStreamPairingBaseViewController.delegate = self;
        // simple <Back button for all tyto pairing screens
        UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"misc.back", @"Back button") style:UIBarButtonItemStylePlain target:nil action:nil];
        self.navigationItem.backBarButtonItem = backButton;
    } else {
        AWSDKLogError(@"Unexpected segue");
    }
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return self.context.consumerFeedbackQuestion.responseOptions.count;
}

#pragma mark - UIPickerViewDelegate

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    self.responseOptionsCell.textField.text = self.context.consumerFeedbackQuestion.responseOptions[row];
    self.context.consumerFeedbackQuestion.selectedOption = row;
    self.selectedOptionPicked = YES;
    [self.responseOptionsCell.textField resignFirstResponder];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return self.context.consumerFeedbackQuestion.responseOptions[row];
}

- (void)getTytoDevicePairingDetailsFromVisitContext:(id<AWSDKVisitContext>)context withCompletion:(void (^_Nullable)(void)) completion {
    AWSDKDeviceData *deviceData = [AWSDKDeviceData deviceDataWithNetworkName:@"" networkPassword:@"" andIntegrationType:AWSDKDeviceIntegrationTypeTyto];
    [context.consumer getDevicePairingStatus:deviceData withCompletion:^(id<AWSDKDeviceIntegration>  _Nullable deviceIntegration, NSError * _Nullable error) {
        if (deviceIntegration) {
            self.hasTytoLiveStream = YES;
            self.isTytoLSPaired = deviceIntegration.isDevicePaired; 
        }
        if (completion) {
           completion();
        }
    }];
}

#pragma mark - TytoLiveStreamPairingDelegate

- (void)tytoDeviceHasBeenPaired {
    self.hasTytoLiveStream = YES;
    self.isTytoLSPaired = YES;
    [self.tableView reloadDataAnimated:YES];
}

@end
