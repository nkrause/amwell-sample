//
//  SpeedPassMemberViewController.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 6/22/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "SpeedPassMemberViewController.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKSpeedPass.h>
#import <AWSDK/AWSDKVisit.h>
#import <AWSDK/AWSDKVisitContext.h>
#import <AWSDK/AWSDKVisitService.h>

@interface SpeedPassMemberViewController ()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@end

@implementation SpeedPassMemberViewController

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.nameLabel.text = [NSString stringWithFormat:NSLocalizedString(@"visit.speedPass.confirmMember", @"Is this visit for %@?"), self.speedPass.previousConsumer.nameComponents.givenName];
}

#pragma mark - Actions
- (IBAction)confirmedUserTapped:(id)sender {
    AWSDKLogInfo(@"confirmed user selected");

    [MBProgressHUD showLoadingOn:self.view];
    typeof(self) __weak weakSelf = self;
    [AWSDKVisitService createVisitWithSpeedPass:self.speedPass
                                     completion:^(id<AWSDKVisit> _Nullable visit, NSError *error) {
                                         dispatch_async(dispatch_get_main_queue(), ^{
                                             [MBProgressHUD hideHUDForView:self.view];
                                             if (visit) {
                                                 weakSelf.visit = visit;
                                                 [weakSelf performSegueWithIdentifier:@"confirmedSpeedPass" sender:nil];
                                             } else {
                                                 [weakSelf presentAlertWithError:error okHandler:nil];
                                             }
                                         });
                                     }];
}

@end
