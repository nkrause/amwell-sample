//
//  DisclaimerViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/21/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "DisclaimerViewController.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKEnrollmentService.h>
#import <AWSDK/AWSDKLegalText.h>

/**
 *  DisclaimerViewController shows the disclaimer text in a webView
 */

@interface DisclaimerViewController ()
@property (weak, nonatomic) IBOutlet UIToolbar *requiredActionToolbar;
@end

@implementation DisclaimerViewController

#pragma mark AWSDKMethod Calls

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    if (!self.actionRequired) {
        [self.requiredActionToolbar removeFromSuperview];
    }

    self.navigationItem.hidesBackButton = self.actionRequired;

    self.title = NSLocalizedString(@"intake.termsOfUse.title", "Terms of Use");
    if (self.consumer.outstandingDisclaimer) {
        [self populateWebViewWithLegalText:self.consumer.outstandingDisclaimer];
    } else if ([self.disclaimer conformsToProtocol:@protocol(AWSDKLegalText)]) {
        [self populateWebViewWithLegalText:(id<AWSDKLegalText>)self.disclaimer];
    } else if ([self.disclaimer isKindOfClass:[NSString class]]) {
        [self.webView loadHTMLString:(NSString *)self.disclaimer baseURL:nil];
    } else if (self.fetchEnrollmentAgreement) {
        __weak typeof(self) weakSelf = self;
        [AWSDKEnrollmentService fetchEnrollmentPrivacyPolicy:^(id _Nullable result, NSError *error) {
            [weakSelf.webView loadHTMLString:(NSString *)result baseURL:nil];
        }];
    } else {
        AWSDKLogError(@"No content available");
    }
}

- (void)populateWebViewWithLegalText:(id<AWSDKLegalText>)legalText {
    // The only time the legalText.name will not be populated is during the first available flow

    if (legalText.content) {
        [self.webView loadHTMLString:legalText.content baseURL:nil];
    } else {
        AWSDKLogError(@"No legal text content available");
    }
}

@end
