//
//  ChatTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 9/28/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ChatTableViewController.h"

#import "ButtonTableViewCell.h"
#import "ChatItemCell.h"
#import "FieldButtonTableViewCell.h"
#import "NSPersonNameComponents+Localizing.h"
#import "SubtitleTableViewCell.h"
#import "WaitingRoomViewController.h"

#import <AWSDK/AWSDKChatItem.h>
#import <AWSDK/AWSDKChatReport.h>
#import <AWSDK/AWSDKProvider.h>
#import <AWSDK/AWSDKUser.h>
#import <AWSDK/AWSDKVisit.h>

/**
 *  ChatTableViewController displays a chat report for a visit and sends new chat messages
 */
@interface ChatTableViewController () <UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UITextField *messageField;

@property (atomic, assign) BOOL shouldHideKeyboard;

@end

/**
 *  ChatTableViewControlle displays a tableview of chat items and handles sending and receiving new chat items
 */
@implementation ChatTableViewController

#pragma mark - AWSDK Method Calls
/**
 *  Send the textfield string to the previsit conversation
 */
- (void)sendMessage {
    // UI State changes
    [self.messageField setEnabled:NO];

    // Copy string and clear text
    NSString *message = [self.messageField.text copy];
    [self.messageField setText:@""];

    // Send message, completion returns the report with only the updated chat items
    [self.visit sendPreVisitChatMessage:message
                         withCompletion:^(id<AWSDKChatReport> result, NSError *error) {
                             // UI State changes
                             [self.messageField setEnabled:YES];

                             if (error) {
                                 [self presentAlertWithError:error okHandler:nil];
                             }
                         }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doneTapped)];
    [self.view addGestureRecognizer:tap];

    [self.tableView setBackgroundColor:[UIColor clearColor]];
    [self.view setBackgroundColor:[UIColor clearColor]];

    // Add done button to keyboard
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneTapped)];
    [self setShouldHideKeyboard:NO];

    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    UIBarButtonItem *space = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    [toolbar setItems:@[ space, barButton ]];
    [self.messageField setInputAccessoryView:toolbar];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidChangeFrame:) name:UIKeyboardDidChangeFrameNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidChangeFrameNotification object:nil];
    [super viewWillDisappear:animated];
}

- (CGSize)preferredContentSize {
    return CGSizeMake(self.view.frame.size.width * 0.95, self.view.frame.size.height * 0.95);
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.visit.chatReport.chatItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    id<AWSDKChatItem> item = self.visit.chatReport.chatItems[indexPath.row];

    if (item.messageType.length || !item.user) {
        SubtitleTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"centerItalicCell"];

        [cell.headerLabel setText:item.message];
        [cell setBackgroundView:nil];
        [cell.contentView setBackgroundColor:[UIColor clearColor]];

        return cell;

    } else if (item.userType == AWSDKUserTypeConsumer) {
        ChatItemCell *cell = [tableView dequeueReusableCellWithIdentifier:@"rightChatCell"];

        [cell.nameLabel setText:item.user.nameComponents.localizedFullName];
        [cell.chatLabel setText:item.message];
        [cell setBackgroundView:nil];
        [cell.contentView setBackgroundColor:[UIColor clearColor]];

        return cell;
    } else {
        ChatItemCell *cell = [tableView dequeueReusableCellWithIdentifier:@"leftChatCell"];

        [cell.nameLabel setText:item.user.nameComponents.localizedFullName];
        [cell.chatLabel setText:item.message];
        [cell setBackgroundView:nil];
        [cell.contentView setBackgroundColor:[UIColor clearColor]];

        return cell;
    }
    return nil;
}

// Automated Heights
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}

- (void)tableViewScrollToBottom {
    [self.tableView scrollToRowAtIndexPath:((NSIndexPath *)[[self.tableView indexPathsForVisibleRows] lastObject]) atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    // Finished loading
    if (indexPath == ((NSIndexPath *)[[tableView indexPathsForVisibleRows] lastObject]) && self.isBeingPresented) {
        [self tableViewScrollToBottom];
    }
}
#pragma mark - WaitingRoomDelegate
- (void)chatReportDidChange:(id<AWSDKChatReport>)newChat {
    NSMutableArray *paths = [NSMutableArray new];
    for (id<AWSDKChatItem> item in newChat.chatItems) {
        [paths addObject:[NSIndexPath indexPathForRow:(self.visit.chatReport.chatItems.count - [newChat.chatItems indexOfObject:item] - 1) inSection:0]];
    }

    [self.tableView insertRowsAtIndexPaths:paths withRowAnimation:UITableViewRowAnimationTop];
    [self.tableView scrollToRowAtIndexPath:paths[0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField.text.length) {
        [self sendMessage];
    }
    return NO;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    if ([self isBeingDismissed] || [self shouldHideKeyboard]) {
        [self setShouldHideKeyboard:NO];
        return YES;
    }
    return NO;
}

#pragma mark - Keyboard Observers
// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardDidChangeFrame:(NSNotification *)aNotification {
    [self tableViewScrollToBottom];
}

// Called when keyboard doneTapped
- (void)doneTapped {
    [self setShouldHideKeyboard:YES];
    [self dismissKeyboard];
}

#pragma mark - Actions
- (IBAction)close:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
