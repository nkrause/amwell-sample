//
//  WaitingRoomViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/18/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKVisit.h>

// clang-format off
@protocol AWSDKChatReport, AWSDKVisitContext;
// clang-format on

/**
 Used to signal an update to chat report
 */
@protocol WaitingRoomDelegate <NSObject>

- (void)chatReportDidChange:(nonnull id<AWSDKChatReport>)newChatReport;

@end

@interface WaitingRoomViewController : UIViewController <AWSDKVisitDelegate>

// Set by CostViewController and its delegate
@property (nonatomic, nonnull) id<AWSDKVisit> visit;
@property (nonatomic, nullable) id<AWSDKVisitContext> context;
@property (weak, nonatomic, nullable) IBOutlet UILabel *phoneVisitWaitLabel;
@property (weak, nonatomic, nullable) IBOutlet UILabel *patientsWaitingLabel;
@property (weak, nonatomic, nullable) IBOutlet UILabel *ifYouCloseLabel;
@property (weak, nonatomic, nullable) IBOutlet UIButton *chatButton;
@property (weak, nonatomic, nullable) IBOutlet UILabel *sendTextMessageLabel;
@property (weak, nonatomic, nullable) IBOutlet UISwitch *sendTextMessageSwitch;

@property (atomic, assign, nullable) id<WaitingRoomDelegate> delegate;

- (void)acceptTransferWithCompletion:(nullable CompletionBlock)completion;

@end
