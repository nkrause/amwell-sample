//
//  CartPatientTableViewController.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 10/10/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "CartVisitTopicsViewController.h"
#import "ProviderDetailViewController.h"

#import <AWSDK/AWSDKProvider.h>
#import <UIKit/UIKit.h>

@interface CartPatientInfoViewController : UIViewController

@property (nonatomic, nonnull) id<AWSDKVisitContext> context;
@property (nonatomic) BOOL firstAvailableFlow;

@end
