//
//  CallbackViewController.h
//  AWSDKSample
//
//  Created by Jeremiah.Possion on 1/5/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

@protocol AWSDKVisit;

/**
 CallbackViewController is responsible for monitoring the callback process, responding as necessary to the various states returned.
 */
@interface CallbackViewController : UIViewController

/**
 The AWSDKVisit is set in WaitingRoomViewController's prepareForSegue:sender: method.
 */
@property (nonatomic) id<AWSDKVisit> visit;

@end
