//
//  HIPAAViewController.h
//  AWSDKSample
//
//  Created by Matt Labush on 6/26/17.
//  Copyright © 2017 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

@interface HIPAAViewController : UIViewController

/**
 Set by previous view controller
 */
@property (copy, nonatomic) NSString *notice;

@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end
