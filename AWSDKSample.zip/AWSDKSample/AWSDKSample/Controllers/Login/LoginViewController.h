//
//  LoginViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 2/16/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKConsumer;

/**
 Handles consumer login
 */
@interface LoginViewController : UIViewController

- (IBAction)unwindFromDisclaimerViewController:(UIStoryboardSegue *)segue;

@end
