//
//  EnrollmentTableViewController.m
//  AWSDKSample
//
//  Created by Stephen Ciauri on 10/24/17.
//  Copyright © 2017 American Well. All rights reserved.
//

#import "EnrollmentTableViewController.h"

#import "DisclaimerViewController.h"
#import "HeaderInputControl.h"
#import "NSDateFormatter+CommonFormats.h"
#import "NSString+Sample.h"
#import "PasswordHintsCell.h"
#import "ShareDependentTableViewController.h"

#import <AWSDK/AWSDKAddress.h>
#import <AWSDK/AWSDKBiologicalSex.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKConsumerEnrollmentForm.h>
#import <AWSDK/AWSDKCountry.h>
#import <AWSDK/AWSDKDependentEnrollmentForm.h>
#import <AWSDK/AWSDKEnrollmentService.h>
#import <AWSDK/AWSDKErrorKeys.h>
#import <AWSDK/AWSDKLocale.h>
#import <AWSDK/AWSDKPartialConsumer.h>
#import <AWSDK/AWSDKState.h>
#import <AWSDK/AWSDKSystemConfiguration.h>

static CompletionBlock completionBlock = nil;

const CGFloat DontSendLinkRequestButtonHeight = 43.0;
const CGFloat DefaultEnrollmentCellHeight = 55.0;

@interface EnrollmentTableViewController () <UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate>

typedef NS_ENUM(NSUInteger, EnrollmentSection) { SegmentSection = 0, GeneralSection, AddressSection, AgreementSection, LinkProfileSection };

typedef NS_ENUM(NSUInteger, MatchingFields) { EmailFields, PasswordFields };

typedef NS_ENUM(NSUInteger, RequiredFields) { RequiredFieldPassword, RequiredFieldLastRow };

typedef NS_ENUM(NSUInteger, LinkProfileType) { LinkProfileDuplicate, LinkProfileRequest };

typedef NS_ENUM(NSUInteger, EnrollmentTextFieldTag) {
    FirstName = 0,
    MiddleInitial,
    LastName,
    Gender,
    Sex,
    Birthday,
    Email,
    EmailConfirm,
    Password,
    PasswordConfirm,
    PasswordHints,
    CurrentCountry,
    CurrentState,
    AddressCountry,
    Address1,
    Address2,
    City,
    PostalCode,
    AddressState,
    PhoneNumber,
    PreferredLocale,
};

@property (nonatomic) NSDateFormatter *dateFormatter;
@property (nonatomic) UIToolbar *basicTextViewToolbar;

@property (weak, nonatomic) UIPickerView *currentCountryPickerView;
@property (weak, nonatomic) UIPickerView *addressCountryPickerView;
@property (weak, nonatomic) UIPickerView *currentStatePickerView;
@property (weak, nonatomic) UIPickerView *addressStatePickerView;
@property (weak, nonatomic) UIPickerView *sexPickerView;
@property (weak, nonatomic) UIPickerView *genderIdentityPickerView;
@property (weak, nonatomic) UIDatePicker *datePicker;
@property (weak, nonatomic) UIPickerView *localePicker;

@property (nonatomic) NSArray<NSNumber *> *sexes;           // Ordered list of AWBiologicalSex values
@property (nonatomic) NSDictionary<NSNumber *, NSString *> *sexStrings;     // AWBiologicalSex -> String
@property (nonatomic) NSArray<id<AWSDKGenderIdentity> > *genderIdentities;

@property (nonatomic) BOOL shouldShowSegmentSection;
@property (nonatomic) BOOL shouldShowGeneralSection;
@property (nonatomic) BOOL shouldShowAddressSection;
@property (nonatomic) BOOL shouldShowAgreementSection;
@property (nonatomic) BOOL shouldShowLinkProfileSection;
@property (nonatomic) BOOL shouldShowMiddleInitial;

@property (nonatomic) id<AWSDKLocale> selectedLocale;
@property (nonatomic) id<AWSDKCountry> selectedCurrentCountry;
@property (nonatomic) id<AWSDKCountry> selectedAddressCountry;
@property (nonatomic) id<AWSDKState> selectedCurrentState;
@property (nonatomic) id<AWSDKState> selectedAddressState;

#pragma mark - IBOutlets
@property (weak, nonatomic) IBOutlet UIBarButtonItem *rightButton;
@property (weak, nonatomic) IBOutlet UISegmentedControl *profileTypeSegmentCtrl;

@property (weak, nonatomic) IBOutlet UITableViewCell *middleInitialCell;
@property (weak, nonatomic) IBOutlet UITableViewCell *stateCell;
@property (weak, nonatomic) IBOutlet UITableViewCell *countryCell;
@property (weak, nonatomic) IBOutlet UITableViewCell *countryCellGeneral;
@property (weak, nonatomic) IBOutlet UITableViewCell *disclaimerCell;
@property (weak, nonatomic) IBOutlet UITableViewCell *disclaimerAgreeCell;
@property (weak, nonatomic) IBOutlet UITableViewCell *welcomeEmailCell;
@property (weak, nonatomic) IBOutlet UILabel *middleInitialLabel;
@property (weak, nonatomic) IBOutlet UITableViewCell *localeCell;
@property (weak, nonatomic) IBOutlet UITableViewCell *emailCell;

#pragma mark General Information

@property (weak, nonatomic) IBOutlet HeaderInputControl *firstNameHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *middleInitialHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *lastNameHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *sexHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *genderIdentityHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *birthdayHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *emailHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *emailConfirmHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *passwordHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *passwordConfirmHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *currentCountryHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *currentStateHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *localeHeaderInputControl;
@property (nonatomic) NSLocale *preferredLocale;
@property (nonatomic) NSArray<NSLocale *> *supportedLocales;

#pragma mark Addresss
@property (weak, nonatomic) IBOutlet HeaderInputControl *address1HeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *address2HeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *cityHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *postalCodeHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *countryHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *stateHeaderInputControl;
@property (weak, nonatomic) IBOutlet HeaderInputControl *phoneNumberHeaderInputControl;

@property (nonatomic) PasswordHintsCell *passwordHintCell;
@property (nonatomic) BOOL shouldShowHints;

#pragma mark Agreement
@property (weak, nonatomic) IBOutlet UISwitch *agreementSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *welcomeEmailSwitch;

#pragma mark Link Profile
@property (weak, nonatomic) IBOutlet UILabel *linkRequestMessageLabel;
@property (weak, nonatomic) IBOutlet UITextField *guardianEmailTextField;
@property (weak, nonatomic) IBOutlet UILabel *linkDisclaimerMessageLabel;
@property (weak, nonatomic) IBOutlet UIButton *sendLinkRequestButton;
@property (weak, nonatomic) IBOutlet UIButton *dontSendLinkRequestButton;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *profileTypeSegmentCtrlHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *sendLinkRequestButtonHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *dontSendLinkRequestButtonHeightConstraint;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *profileTypeSegmentCtrlBottomSpaceConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *linkRequestMessageLabelBottomSpaceConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *guardianEmailTextFieldBottomSpaceConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *linkDisclaimerMessageLabelBottomSpaceConstraint;

#pragma mark IBOutletCollections
@property (nonatomic) IBOutletCollection(HeaderInputControl) NSArray<HeaderInputControl *> *allTextFields;
@property (nonatomic) IBOutletCollection(HeaderInputControl) NSArray<HeaderInputControl *> *pickerTextFields;

@property (nonatomic, assign) LinkProfileType linkProfile;

@property (nonatomic, assign) BOOL editDependentMode;
@property (nonatomic, assign) EnrollmentMode previousMode;
@property (nonatomic, strong) UIColor *rightButtonTintColor;
@property (nonatomic, strong) AWSDKDemographicForm *demoForm;

@end

@implementation EnrollmentTableViewController

#pragma mark - View Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];

    [self updateViews];

    self.sexStrings = AWSDKSystemConfiguration.sexes;
    self.sexes = [[self.sexStrings allKeys] sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        if ([obj1 integerValue] < [obj2 integerValue]) {
            return NSOrderedAscending;
        }
        if ([obj1 integerValue] > [obj2 integerValue]) {
            return NSOrderedDescending;
        }
        return NSOrderedSame;
    }];
    self.genderIdentities = AWSDKSystemConfiguration.genderIdentities;
    self.supportedLocales = [AWSDKSystemConfiguration supportedLocales];

    [self setUpPickerViews];
    // setupConsumerView will assign tags which must preceed allTextFields
    [self setupConsumerView];

    self.allTextFields = [self.allTextFields sortedArrayUsingDescriptors:@[ [NSSortDescriptor sortDescriptorWithKey:@"textField.tag" ascending:YES] ]];

    self.tableView.estimatedRowHeight = DefaultEnrollmentCellHeight;
    self.tableView.estimatedSectionHeaderHeight = 22.0;
    self.tableView.estimatedSectionFooterHeight = UITableViewAutomaticDimension;
    
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.sectionHeaderHeight = UITableViewAutomaticDimension;
    self.tableView.sectionFooterHeight = UITableViewAutomaticDimension;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"disclaimerSegue"]) {
        DisclaimerViewController *destination = (DisclaimerViewController *)segue.destinationViewController;
        destination.fetchEnrollmentAgreement = YES;
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.navigationController.navigationBar setNeedsLayout];
}

#pragma mark - View Setup

- (void)setUpPickerViews {
    UIPickerView *currentCountryPickerView = [UIPickerView new];
    UIPickerView *addressCountryPickerView = [UIPickerView new];
    UIPickerView *currentStatePickerView = [UIPickerView new];
    UIPickerView *addressStatePickerView = [UIPickerView new];
    UIPickerView *sexPickerView = [UIPickerView new];
    UIPickerView *genderIdentityPickerView = [UIPickerView new];
    UIDatePicker *datePicker = [UIDatePicker new];
    UIPickerView *localePicker = [UIPickerView new];
    datePicker.datePickerMode = UIDatePickerModeDate;
    [datePicker addTarget:self action:@selector(datePickerDidChange:) forControlEvents:UIControlEventValueChanged];

    for (UIPickerView *picker in @[ currentCountryPickerView, addressCountryPickerView, currentStatePickerView, addressStatePickerView, sexPickerView, genderIdentityPickerView, localePicker ]) {
        picker.delegate = self;
        picker.dataSource = self;
        picker.showsSelectionIndicator = YES;
    }

    self.currentCountryPickerView = currentCountryPickerView;
    self.addressCountryPickerView = addressCountryPickerView;
    self.currentStatePickerView = currentStatePickerView;
    self.addressStatePickerView = addressStatePickerView;
    self.sexPickerView = sexPickerView;
    self.genderIdentityPickerView = genderIdentityPickerView;
    self.datePicker = datePicker;
    self.localePicker = localePicker;

    [self setUpTextFields];
}

- (void)setUpTextFields {
    UIToolbar *keyboardToolbar = [[UIToolbar alloc] init];
    [keyboardToolbar sizeToFit];
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"misc.done", @"Done barButtonItem")
                                                                   style:UIBarButtonItemStyleDone
                                                                  target:self.view
                                                                  action:@selector(endEditing:)];
    UIBarButtonItem *flexibleItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardToolbar setItems:@[ flexibleItem, doneButton ]];
    [doneButton setTintColor:[UIColor aquaColor]];
    self.basicTextViewToolbar = keyboardToolbar;

    for (HeaderInputControl *textFieldContainer in self.allTextFields) {
        textFieldContainer.textField.delegate = self;
        textFieldContainer.textField.inputAccessoryView = self.basicTextViewToolbar;
    }

    self.currentCountryHeaderInputControl.textField.inputView = self.currentCountryPickerView;
    self.countryHeaderInputControl.textField.inputView = self.addressCountryPickerView;
    self.currentStateHeaderInputControl.textField.inputView = self.currentStatePickerView;
    self.stateHeaderInputControl.textField.inputView = self.addressStatePickerView;
    self.sexHeaderInputControl.textField.inputView = self.sexPickerView;
    self.genderIdentityHeaderInputControl.textField.inputView = self.genderIdentityPickerView;
    self.birthdayHeaderInputControl.textField.inputView = self.datePicker;
    self.localeHeaderInputControl.textField.inputView = self.localePicker;

    self.dateFormatter = [NSDateFormatter new];
    self.dateFormatter.dateStyle = NSDateFormatterLongStyle;

    //  we need to set the country when we are not multicountry because the country picker will be invisible, so we need to 'pick' the only country in code.
    if (!AWSDKSystemConfiguration.isMultiCountry) {
        self.selectedCurrentCountry = AWSDKEnrollmentService.countries[0];
        self.selectedAddressCountry = AWSDKEnrollmentService.countries[0];
    }

    /*  Need to assign the tags for these text fields because the tags must correspond to the rows.
     */
    self.firstNameHeaderInputControl.textField.tag = FirstName;
    self.firstNameHeaderInputControl.textField.textContentType = UITextContentTypeGivenName;
    self.firstNameHeaderInputControl.textField.autocapitalizationType = UITextAutocapitalizationTypeWords;
    self.firstNameHeaderInputControl.textField.autocorrectionType = UITextAutocorrectionTypeNo;

    self.middleInitialHeaderInputControl.textField.tag = MiddleInitial;
    self.middleInitialHeaderInputControl.textField.textContentType = UITextContentTypeMiddleName;
    self.middleInitialHeaderInputControl.textField.autocapitalizationType = UITextAutocapitalizationTypeWords;
    self.middleInitialHeaderInputControl.textField.autocorrectionType = UITextAutocorrectionTypeNo;


    self.lastNameHeaderInputControl.textField.tag = LastName;
    self.lastNameHeaderInputControl.textField.textContentType = UITextContentTypeFamilyName;
    self.lastNameHeaderInputControl.textField.autocapitalizationType = UITextAutocapitalizationTypeWords;
    self.lastNameHeaderInputControl.textField.autocorrectionType = UITextAutocorrectionTypeNo;

    self.sexHeaderInputControl.textField.tag = Sex;
    self.genderIdentityHeaderInputControl.textField.tag = Gender;
    self.birthdayHeaderInputControl.textField.tag = Birthday;

    self.emailHeaderInputControl.textField.tag = Email;
    self.emailHeaderInputControl.textField.keyboardType = UIKeyboardTypeEmailAddress;
    self.emailHeaderInputControl.textField.textContentType = UITextContentTypeEmailAddress;

    self.emailConfirmHeaderInputControl.textField.tag = EmailConfirm;
    self.emailConfirmHeaderInputControl.textField.keyboardType = UIKeyboardTypeEmailAddress;
    self.emailHeaderInputControl.textField.textContentType = UITextContentTypeEmailAddress;

    self.passwordHeaderInputControl.textField.tag = Password;
    self.passwordHeaderInputControl.textField.secureTextEntry = YES;
    self.passwordConfirmHeaderInputControl.textField.secureTextEntry = YES;
    self.passwordHeaderInputControl.textField.textContentType = UITextContentTypePassword;

    self.passwordConfirmHeaderInputControl.textField.tag = PasswordConfirm;
    self.passwordConfirmHeaderInputControl.textField.textContentType = UITextContentTypePassword;

    self.currentCountryHeaderInputControl.textField.tag = CurrentCountry;
    self.currentStateHeaderInputControl.textField.tag = CurrentState;
    self.address1HeaderInputControl.textField.tag = Address1;
    self.address2HeaderInputControl.textField.tag = Address2;
    self.cityHeaderInputControl.textField.tag = City;
    self.postalCodeHeaderInputControl.textField.tag = PostalCode;
    self.countryHeaderInputControl.textField.tag = AddressCountry;
    self.stateHeaderInputControl.textField.tag = AddressState;
    self.phoneNumberHeaderInputControl.textField.tag = PhoneNumber;
    self.localeHeaderInputControl.textField.tag = PreferredLocale;
}

- (void)setupConsumerView {
    if (self.editDependentMode) {
        self.firstNameHeaderInputControl.textField.text = self.consumer.nameComponents.givenName;
        self.middleInitialHeaderInputControl.textField.text = self.consumer.nameComponents.middleName;
        self.lastNameHeaderInputControl.textField.text = self.consumer.nameComponents.familyName;
        self.sexHeaderInputControl.textField.text = self.consumer.localizedGenderName;
        [self.sexPickerView selectRow:[self.sexes indexOfObject:@(self.consumer.gender)] inComponent:0 animated:NO];
        if (self.consumer.genderIdentity != nil) {
            [self.genderIdentityPickerView selectRow:[self.genderIdentities indexOfObjectPassingTest:^BOOL(id<AWSDKGenderIdentity> _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                return [obj.key isEqualToString:self.consumer.genderIdentity.key];
            }] inComponent:0 animated:NO];
        }
        self.birthdayHeaderInputControl.textField.text = [NSDateFormatter.longerDateFormatter stringFromDate:self.consumer.dateOfBirth];
        self.datePicker.date = self.consumer.dateOfBirth;
    }
}

- (void)updateViews {
    self.editDependentMode = (self.mode == DependentMode && self.consumer);
    self.shouldShowSegmentSection = (self.mode != ConsumerMode) && !(self.mode == DependentMode && self.consumer) && AWSDKSystemConfiguration.isDependentLinkingEnabled;
    self.shouldShowGeneralSection = (self.mode != LinkMode);
    self.shouldShowAddressSection = self.mode == ConsumerMode && AWSDKEnrollmentService.isConsumerAddressRequired;
    self.shouldShowAgreementSection = (self.mode != LinkMode && !self.editDependentMode);
    self.shouldShowLinkProfileSection = (self.mode == LinkMode);
    self.shouldShowMiddleInitial = AWSDKEnrollmentService.isConsumerMiddleInitialCollected;

    self.rightButtonTintColor = self.rightButtonTintColor ?: self.rightButton.tintColor;
    self.rightButton.title = (self.editDependentMode) ? NSLocalizedString(@"dependents.doneButton", @"Done title") : NSLocalizedString(@"dependents.createButton", @"Create title");
    self.rightButton.enabled = (self.mode != LinkMode) ? YES : NO;
    self.rightButton.tintColor = (self.mode != LinkMode) ? self.rightButtonTintColor : [UIColor clearColor];

    self.profileTypeSegmentCtrl.selectedSegmentIndex = (self.mode == LinkMode) ? 1 : 0;

    NSString *dependentTitle = self.editDependentMode ? NSLocalizedString(@"dependents.edit", @"Edit Child title") : NSLocalizedString(@"dependents.add", @"Add Child title");
    self.navigationItem.title = self.mode == DependentMode ? dependentTitle : self.navigationItem.title;

    self.linkRequestMessageLabel.text = (self.linkProfile == LinkProfileDuplicate) ? NSLocalizedString(@"dependents.existingChildMessage.title", @"Existing Child")
                                                                                   : NSLocalizedString(@"dependents.requestAccessMessage.title", @"Request Dependent Access");
    self.linkDisclaimerMessageLabel.text = NSLocalizedString(@"dependents.requestAccessDisclaimer.title", @"Disclaimer Message");

    [self.sendLinkRequestButton setTitle:NSLocalizedString(@"dependents.sendLinkRequestButton.title", @"Send Request Title") forState:UIControlStateNormal];
    [self.dontSendLinkRequestButton setTitle:NSLocalizedString(@"dependents.dontSendLinkRequestButton.title", @"Don't Send Request Title") forState:UIControlStateNormal];

    self.dontSendLinkRequestButtonHeightConstraint.constant = (self.linkProfile == LinkProfileDuplicate) ? DontSendLinkRequestButtonHeight : 0.0;
    self.dontSendLinkRequestButton.hidden = (self.linkProfile == LinkProfileRequest);

    // Dynamically set contraints to prevent autolayout exception when height is zero
    self.profileTypeSegmentCtrlHeightConstraint.priority = (self.shouldShowSegmentSection) ? 900 : 750;
    self.sendLinkRequestButtonHeightConstraint.priority = (self.shouldShowSegmentSection) ? 900 : 750;
    self.dontSendLinkRequestButtonHeightConstraint.priority = (self.shouldShowSegmentSection) ? 900 : 750;

    self.profileTypeSegmentCtrlBottomSpaceConstraint.priority = (self.shouldShowSegmentSection) ? 900 : 750;
    self.linkRequestMessageLabelBottomSpaceConstraint.priority = (self.mode == LinkMode) ? 900 : 749;
    self.guardianEmailTextFieldBottomSpaceConstraint.priority = (self.mode == LinkMode) ? 900 : 749;
    self.linkDisclaimerMessageLabelBottomSpaceConstraint.priority = (self.mode == LinkMode) ? 900 : 749;
}

#pragma mark - IBActions

- (IBAction)cancelTapped:(UIBarButtonItem *)button {
    AWSDKLogInfo(@"Cancel button tapped");
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)createButtonTapped:(UIBarButtonItem *)button {
    AWSDKLogInfo(@"Create button tapped");
    [self.view endEditing:YES];
    button.enabled = NO;

    if (self.mode == PartialMode) {
        [self completePartiallyEnrolledConsumerWithCompletion:^{
            button.enabled = YES;
        }];
    } else {
        [self enrollUserWithCompletion:^{
            button.enabled = YES;
        }];
    }
}

- (IBAction)profileSegmentValueChanged:(id)sender {
    if (self.profileTypeSegmentCtrl.selectedSegmentIndex == 0) {
        self.mode = self.previousMode;
    } else {
        self.previousMode = self.mode;
        self.mode = LinkMode;
        self.linkProfile = LinkProfileRequest;
    }

    [self updateViews];
    [self.tableView reloadData];
}

- (IBAction)sendLinkRequestButtonTapped:(UIButton *)button {
    [self requestDependentAccessForConsumer:[[ConsumerService sharedInstance] consumer] guardianEmail:self.guardianEmailTextField.text withCompletion:nil];
}

- (IBAction)dontSendLinkRequestButtonTapped:(UIButton *)button {
    AWSDKDemographicForm *form = self.demoForm ?: [AWSDKDependentEnrollmentForm form];
    [self enrollUserWithForm:form dependentCheck:NO withCompletion:nil];
}

#pragma mark - Submission

- (void)completePartiallyEnrolledConsumerWithCompletion:(CompletionBlock)completion {
    if (![self validateMatchingFields:EmailFields] || ![self validateMatchingFields:PasswordFields] || ![self validateRequiredFields]) {
        if (completion) {
            completion();
        }
        return;
    } else if (!self.selectedCurrentState || !self.selectedCurrentCountry) {
        if (completion) {
            completion();
        }
        // Form incomplete
        return;
    } else if (!self.agreementSwitch.isOn) {
        [self highlightErrorFieldsWithAWSDKValidationErrorsDictionary:@{ @"hasAcceptedPrivacyPolicy" : @1 }];
        if (completion) {
            completion();
        }
        return;
    } else {
        __weak typeof(self) weakSelf = self;
        [MBProgressHUD showEnrollingOn:self.view];
        [self.partialConsumer completeEnrollmentWithLocation:self.selectedCurrentState
                                                    username:self.partialConsumerUsername
                                                 newUsername:self.emailHeaderInputControl.textField.text
                                                    password:self.partialConsumerPassword
                                                 newPassword:self.passwordHeaderInputControl.textField.text
                                                  completion:^(id _Nullable result, NSError *error) {
                                                      dispatch_async(dispatch_get_main_queue(), ^{
                                                          [MBProgressHUD hideHUDForView:self.view];
                                                          if (error) {
                                                              [weakSelf presentAlertWithError:error];
                                                              [weakSelf highlightErrorFieldsWithAWSDKValidationErrorsDictionary:error.userInfo[AWSDKValidationErrorsKey]];
                                                          } else if ([result conformsToProtocol:@protocol(AWSDKConsumer)]) {
                                                              [[ConsumerService sharedInstance] setConsumer:result];
                                                              [weakSelf.presentingViewController.presentingViewController dismissViewControllerAnimated:YES completion:nil];
                                                          }
                                                      });
                                                      if (completion) {
                                                          completion();
                                                      }
                                                  }];
    }
}

- (void)enrollUserWithCompletion:(CompletionBlock)completion {
    AWSDKDemographicForm *form = self.mode == ConsumerMode ? [AWSDKConsumerEnrollmentForm form] : [AWSDKDependentEnrollmentForm form];
    form.firstName = self.firstNameHeaderInputControl.textField.text;
    if (AWSDKSystemConfiguration.middleNameHandling == AWSDKConsumerMiddleNameHandlingInitial) {
        form.middleInitial = self.middleInitialHeaderInputControl.textField.text;
    } else if (AWSDKSystemConfiguration.middleNameHandling == AWSDKConsumerMiddleNameHandlingFullName) {
        form.middleName = self.middleInitialHeaderInputControl.textField.text;
    }
    form.lastName = self.lastNameHeaderInputControl.textField.text;
    if (self.sexHeaderInputControl.textField.text.length) {
        form.gender = (AWSDKBiologicalSex)self.sexes[[self.sexPickerView selectedRowInComponent:0]].integerValue;
    }
    if (AWSDKSystemConfiguration.isExtensibleGenderSupportEnabled && self.genderIdentityHeaderInputControl.textField.text.length) {
        form.genderIdentity = self.genderIdentities[[self.genderIdentityPickerView selectedRowInComponent:0]];
    }
    if (self.birthdayHeaderInputControl.textField.text != nil) {
        form.dateOfBirth = [self.datePicker date];
    }

    switch (self.mode) {
        case ConsumerMode: {
            AWSDKConsumerEnrollmentForm *consumerEnrollmentForm = (AWSDKConsumerEnrollmentForm *)form;
            consumerEnrollmentForm.sendWelcomeEmail = self.welcomeEmailSwitch.isOn;
            if ([self validateMatchingFields:EmailFields] && [self validateMatchingFields:PasswordFields] && [self validateRequiredFields]) {
                [self populateConsumerForm:consumerEnrollmentForm];
            } else {
                if (completion) {
                    completion();
                }
                return;
            }
            break;
        }
        case DependentMode: {
            AWSDKDependentEnrollmentForm *dependentForm = (AWSDKDependentEnrollmentForm *)form;
            [self populateDependentForm:dependentForm];
            break;
        }
        default:
            // Incompatible mode
            if (completion) {
                completion();
            }
            return;
    }

    [self enrollUserWithForm:form dependentCheck:YES withCompletion:completion];
}

- (void)enrollUserWithForm:(AWSDKDemographicForm *)form dependentCheck:(BOOL)dependentCheck withCompletion:(CompletionBlock)completion {
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD showLoadingOn:self.view];
    [AWSDKEnrollmentService
        enrollConsumerWithForm:form
                dependentCheck:dependentCheck
                    completion:^(id _Nullable result, NSError *error) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [MBProgressHUD hideHUDForView:self.view];
                            if (!error) {
                                // UI Logic for Sample App to dismiss proper view controller
                                if ([form conformsToProtocol:@protocol(AWSDKDependentEnrollmentForm)]) {
                                    // Refresh consumer context
                                    [[ConsumerService sharedInstance] refreshConsumerWithCompletion:^(BOOL success, NSError *error) {
                                        if (success) {
                                            [weakSelf dismissViewControllerAnimated:YES completion:nil];
                                        } else {
                                            [weakSelf presentAlertWithError:error okHandler:nil];
                                        }
                                        if (completion) {
                                            completion();
                                        }
                                    }];
                                } else {
                                    id<AWSDKConsumerEnrollmentForm> consumerForm = (id<AWSDKConsumerEnrollmentForm>)form;
                                    // Password was provided
                                    if (consumerForm.password.length) {
                                        // Update ConsumerService to set the new consumer
                                        [[ConsumerService sharedInstance] setConsumer:result];
                                        [weakSelf.presentingViewController.presentingViewController dismissViewControllerAnimated:YES completion:nil];
                                        if (completion) {
                                            completion();
                                        }
                                    } else {
                                        // Present alert stating that the consumer must check their email to generate a password
                                        UIViewController *destination = weakSelf.presentingViewController;
                                        [weakSelf dismissViewControllerAnimated:YES
                                                                     completion:^{
                                                                         [destination presentAlertWithTitle:NSLocalizedString(@"enrollment.successful.title", @"Enrollment Success Title")
                                                                                                    message:NSLocalizedString(
                                                                                                                @"enrollment.successful.checkEmail", @"Alert message - Check email for instructions")];
                                                                     }];
                                    }
                                }
                            } else {
                                if (error.code == AWSDKErrorCodeValidationDependentMatchFound) {
                                    completionBlock = completion;
                                    self.demoForm = form;
                                    self.linkProfile = LinkProfileDuplicate;
                                    [weakSelf presentDuplicateDependentViewWithForm:form dependentCheck:dependentCheck withCompletion:completion];
                                } else {
                                    [weakSelf presentAlertWithError:error];
                                    [weakSelf highlightErrorFieldsWithAWSDKValidationErrorsDictionary:error.userInfo[AWSDKValidationErrorsKey]];
                                    if (completion) {
                                        completion();
                                    }
                                }
                            }
                        });
                    }];
}

- (void)requestDependentAccessForConsumer:(id<AWSDKConsumer>)consumer guardianEmail:(NSString *)guardianEmail withCompletion:(CompletionBlock)completion {
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD showLoadingOn:self.view];
    [consumer requestDependentAccessFromGuardianEmail:guardianEmail
                                           completion:^(BOOL success, NSError *error) {
                                               [MBProgressHUD hideHUDForView:self.view];
                                               if (!error) {
                                                   NSString *message = [NSString
                                                       stringWithFormat:NSLocalizedString(@"dependent.requestAccessSent.message", @"Dependent access request sent message detail"), guardianEmail];
                                                   [weakSelf presentAlertWithTitle:NSLocalizedString(@"dependent.requestAccessSent.title", @"Dependent access request sent alert title")
                                                                           message:message
                                                                         okHandler:^(UIAlertAction *action) {
                                                                             // UI Logic for Sample App to dismiss proper view controller
                                                                             [[ConsumerService sharedInstance] refreshConsumerWithCompletion:^(BOOL success, NSError *error) {
                                                                                 dispatch_async(dispatch_get_main_queue(), ^{
                                                                                     if (success) {
                                                                                         [weakSelf dismissViewControllerAnimated:YES completion:nil];
                                                                                     } else {
                                                                                         [weakSelf presentAlertWithError:error okHandler:nil];
                                                                                     }
                                                                                 });
                                                                                 if (completion) {
                                                                                     completion();
                                                                                 }
                                                                             }];
                                                                         }];
                                               } else {
                                                   [weakSelf presentAlertWithError:error];
                                                   [weakSelf highlightErrorFieldsWithAWSDKValidationErrorsDictionary:error.userInfo[AWSDKValidationErrorsKey]];
                                                   if (completion) {
                                                       completion();
                                                   }
                                               }
                                           }];
}

- (void)populateConsumerForm:(AWSDKConsumerEnrollmentForm *)form {
    if (self.agreementSwitch.isOn) {
        [form setAcceptedPrivacyPolicy];
    }

    form.email = self.emailHeaderInputControl.textField.text;
    form.password = self.passwordHeaderInputControl.textField.text;

    if (self.shouldShowAddressSection) {
        form.address = [AWSDKAddress address];
        form.address.addressOne = self.address1HeaderInputControl.textField.text;
        form.address.addressTwo = self.address2HeaderInputControl.textField.text;
        form.address.city = self.cityHeaderInputControl.textField.text;
        form.address.state = self.selectedAddressState;
        form.address.country = self.selectedAddressCountry;
        form.address.zip = self.postalCodeHeaderInputControl.textField.text;
    }
    form.phoneNumber = self.phoneNumberHeaderInputControl.textField.text;
    form.stateOfLegalResidence = self.selectedCurrentState;
    form.countryOfLegalResidence = self.selectedCurrentCountry;

    form.preferredLocale = self.preferredLocale;
}

- (void)populateDependentForm:(AWSDKDependentEnrollmentForm *)form {
    form.authenticatedParent = ConsumerService.sharedInstance.parentConsumer;
    if (self.agreementSwitch.isOn) {
        [form setAcceptedPrivacyPolicy];
    }
}

- (BOOL)validateMatchingFields:(MatchingFields)fields {
    BOOL matches;
    NSString *localizedKey;
    UITextField *firstResponder;
    switch (fields) {
        case EmailFields:
            matches = [self.emailHeaderInputControl.textField.text caseInsensitiveCompare:self.emailConfirmHeaderInputControl.textField.text] == NSOrderedSame;
            localizedKey = @"enrollment.email.mismatch";
            firstResponder = self.emailConfirmHeaderInputControl.textField;
            break;
        case PasswordFields:
            matches = [self.passwordHeaderInputControl.textField.text caseInsensitiveCompare:self.passwordConfirmHeaderInputControl.textField.text] == NSOrderedSame;
            localizedKey = @"enrollment.password.mismatch";
            firstResponder = self.passwordConfirmHeaderInputControl.textField;
            break;
    }
    if (!matches) {
        [self presentAlertWithMessageKey:localizedKey
                               okHandler:^(UIAlertAction *action) {
                                   [firstResponder becomeFirstResponder];
                               }];
    }
    return matches;
}

- (BOOL)validateRequiredFields {
    BOOL valid = YES;
    NSString *localizedKey;
    UITextField *firstResponder;

    for (NSUInteger fieldNumber = RequiredFieldPassword; fieldNumber < RequiredFieldLastRow && valid; fieldNumber++) {
        switch (fieldNumber) {
            case RequiredFieldPassword:
                valid = (self.welcomeEmailSwitch.isOn || self.passwordHeaderInputControl.textField.text.length);
                localizedKey = @"enrollment.password.required";
                firstResponder = self.passwordHeaderInputControl.textField;
                break;
            case RequiredFieldLastRow:
                break;
        }
    }

    if (!valid) {
        [self presentAlertWithMessageKey:localizedKey
                               okHandler:^(UIAlertAction *action) {
                                   [firstResponder becomeFirstResponder];
                               }];
    }
    return valid;
}

- (void)highlightErrorFieldsWithAWSDKValidationErrorsDictionary:(NSDictionary<NSString *, id> *)errorDict {
    // The AWSDKValidationErrorsDictionary will either contain a dictionary or an AWSDKErrorCode

    NSMutableArray<UITextField *> *fieldsToHighlight = @[].mutableCopy;

    [errorDict enumerateKeysAndObjectsUsingBlock:^(NSString *_Nonnull key, id _Nonnull obj, BOOL *_Nonnull stop) {
        if ([key isEqualToString:@"address"]) {
            NSDictionary<NSString *, NSNumber *> *addressErrorDict = errorDict[@"address"];
            [self highlightErrorFieldsWithAWSDKValidationErrorsDictionary:addressErrorDict];
        } else if ([key isEqualToString:@"dateOfBirth"]) {
            [fieldsToHighlight addObject:self.birthdayHeaderInputControl.textField];
        } else if ([key isEqualToString:@"email"]) {
            [fieldsToHighlight addObject:self.emailHeaderInputControl.textField];
        } else if ([key isEqualToString:@"firstName"]) {
            [fieldsToHighlight addObject:self.firstNameHeaderInputControl.textField];
        } else if ([key isEqualToString:@"middleInitial"]) {
            [fieldsToHighlight addObject:self.middleInitialHeaderInputControl.textField];
        } else if ([key isEqualToString:@"lastName"]) {
            [fieldsToHighlight addObject:self.lastNameHeaderInputControl.textField];
        } else if ([key isEqualToString:@"password"]) {
            [fieldsToHighlight addObject:self.passwordHeaderInputControl.textField];
        } else if ([key isEqualToString:@"stateOfLegalResidence"]) {
            [fieldsToHighlight addObject:self.currentStateHeaderInputControl.textField];
        } else if ([key isEqualToString:@"hasAcceptedPrivacyPolicy"]) {
            self.agreementSwitch.tintColor = UIColor.redColor;
        } else if ([key isEqualToString:@"phoneNumber"]) {
            [fieldsToHighlight addObject:self.phoneNumberHeaderInputControl.textField];
        } else if ([key isEqualToString:@"addressOne"]) {
            [fieldsToHighlight addObject:self.address1HeaderInputControl.textField];
        } else if ([key isEqualToString:@"addressTwo"]) {
            [fieldsToHighlight addObject:self.address2HeaderInputControl.textField];
        } else if ([key isEqualToString:@"city"]) {
            [fieldsToHighlight addObject:self.cityHeaderInputControl.textField];
        } else if ([key isEqualToString:@"zip"]) {
            [fieldsToHighlight addObject:self.postalCodeHeaderInputControl.textField];
        } else if ([key isEqualToString:@"state"]) {
            [fieldsToHighlight addObject:self.stateHeaderInputControl.textField];
        }
    }];

    dispatch_async(dispatch_get_main_queue(), ^{
        for (UITextField *field in fieldsToHighlight) {
            field.tintColor = UIColor.redColor;
            field.rightViewMode = UITextFieldViewModeAlways;
            field.rightView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
            // In your application, you may map the button's action to an AlertController that would display some detailed text describing the error
        }
    });
}

#pragma mark - DatePicker Listener

- (void)datePickerDidChange:(UIDatePicker *)datePicker {
    self.birthdayHeaderInputControl.textField.text = [self.dateFormatter stringFromDate:datePicker.date];
}

#pragma mark - UITableViewDataSource

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
    if (indexPath == [NSIndexPath indexPathForRow:PasswordHints inSection:GeneralSection]) {
        // Special treatment for password hints.  Need a dynamic cell
        if (!self.passwordHintCell) {
            self.passwordHintCell = (PasswordHintsCell *)cell;
        }
        return self.passwordHintCell;
    } else if (cell == self.middleInitialCell) {
        switch (AWSDKSystemConfiguration.middleNameHandling) {
            case AWSDKConsumerMiddleNameHandlingFullName:
                self.middleInitialHeaderInputControl.textField.placeholder = NSLocalizedString(@"enrollment.fullMiddleName.placeholder", @"Enrollment Full Middle Name Placeholder");
                self.middleInitialLabel.text = NSLocalizedString(@"enrollment.fullMiddleName", @"Middle Name");
                break;
            default:
                break;
        }
    } else if (cell == self.emailCell && self.mode == PartialMode) {
        self.emailHeaderInputControl.textField.text = self.partialConsumer.emailOnFile;
    }
    return cell;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
    if (indexPath == [NSIndexPath indexPathForRow:PasswordHints inSection:GeneralSection]) {
        if (self.passwordHintCell && [self.passwordHintCell passwordHintsSupported]) {
            if (self.shouldShowHints) {
                self.passwordHintCell.hidden = NO;
                return UITableViewAutomaticDimension;
            } else {
                self.passwordHintCell.hidden = YES;
                return 0.0;
            }
        } else {
            self.passwordHintCell.hidden = YES;
            return 0.0;
        }
    }
    if (indexPath == [NSIndexPath indexPathForRow:Gender inSection:GeneralSection] && self.genderIdentities.count == 0) {
        // Do not show Gender Identity picker if not supported by the platform.
        return 0.0;
    }

    if (cell == self.localeCell && self.supportedLocales.count == 1) {
        // No need to show locale picker because only one locale supported
        return 0.0;
    }
    if (cell == self.middleInitialCell && !self.shouldShowMiddleInitial) {
        return 0.0;
    } else {
        if (!AWSDKSystemConfiguration.isMultiCountry && (cell == self.countryCell || cell == self.countryCellGeneral)) {
            return 0.0;
        }

        if (indexPath.section == SegmentSection && !self.shouldShowSegmentSection) {
            return 0.0;
        } else if (indexPath.section == GeneralSection && !self.shouldShowGeneralSection) {
            return 0.0;
        } else if (indexPath.section == AddressSection && !self.shouldShowAddressSection) {
            return 0.0;
        } else if (indexPath.section == AgreementSection && !self.shouldShowAgreementSection) {
            return 0.0;
        } else if (indexPath.section == LinkProfileSection) {
            return (self.shouldShowLinkProfileSection) ? [super tableView:tableView heightForRowAtIndexPath:indexPath] : 0.0;
        } else if (self.mode == PartialMode && indexPath.section != AgreementSection) {
            return [@[ @(Email), @(EmailConfirm), @(Password), @(PasswordConfirm), @(CurrentState), @(CurrentCountry) ] containsObject:@(indexPath.row)]
                ? [super tableView:tableView heightForRowAtIndexPath:indexPath]
                : 0.0;
        } else if (self.mode == DependentMode && indexPath.section != AgreementSection) {
            return [@[ @(FirstName), @(LastName), @(MiddleInitial), @(Birthday), @(Sex), @(Gender) ] containsObject:@(indexPath.row)] ? [super tableView:tableView heightForRowAtIndexPath:indexPath] : 0.0;
        } else if (self.mode == DependentMode && (cell == self.disclaimerAgreeCell || cell == self.welcomeEmailCell)) {
            return 0.0;
        }
        return DefaultEnrollmentCellHeight;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == SegmentSection) {
        return nil;
    } else if (section == GeneralSection && !self.shouldShowGeneralSection) {
        return nil;
    } else if (section == AddressSection && !self.shouldShowAddressSection) {
        return nil;
    } else if (section == AgreementSection && !self.shouldShowAgreementSection) {
        return nil;
    } else if (section == LinkProfileSection) {
        return nil;
    } else {
        return [super tableView:tableView titleForHeaderInSection:section];
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == SegmentSection) {
        return (self.shouldShowSegmentSection) ? UITableViewAutomaticDimension : CGFLOAT_MIN;
    } else if (section == GeneralSection && !self.shouldShowGeneralSection) {
        return CGFLOAT_MIN;
    } else if (section == AddressSection && !self.shouldShowAddressSection) {
        return CGFLOAT_MIN;
    } else if (section == AgreementSection && !self.shouldShowAgreementSection) {
        return CGFLOAT_MIN;
    } else if (section == LinkProfileSection) {
        return CGFLOAT_MIN;
    } else {
        return [super tableView:tableView heightForHeaderInSection:section];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

#pragma mark - UIPickerViewDataSource

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (pickerView == self.addressCountryPickerView || pickerView == self.currentCountryPickerView) {
        return AWSDKEnrollmentService.countries[row].name;
    } else if (pickerView == self.addressStatePickerView) {
        return self.selectedAddressCountry.states[row].name;
    } else if (pickerView == self.currentStatePickerView) {
        return self.selectedCurrentCountry.enrollmentStates[row].name;
    } else if (pickerView == self.sexPickerView) {
        return self.sexStrings[self.sexes[row]];
    } else if (pickerView == self.genderIdentityPickerView) {
        return self.genderIdentities[row].name;
    } else if (pickerView == self.localePicker) {
        NSLocale *locale = self.supportedLocales[row];
        NSString *localeIdentifier = locale.localeIdentifier;
        return [locale displayNameForKey:NSLocaleIdentifier value:localeIdentifier];
    } else {
        return nil;
    }
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (pickerView == self.addressCountryPickerView || pickerView == self.currentCountryPickerView) {
        return AWSDKEnrollmentService.countries.count;
    } else if (pickerView == self.addressStatePickerView && self.selectedAddressCountry) {
        return self.selectedAddressCountry.states.count;
    } else if (pickerView == self.currentStatePickerView && self.selectedCurrentCountry) {
        return self.selectedCurrentCountry.enrollmentStates.count;
    } else if (pickerView == self.sexPickerView) {
        return self.sexes.count;
    } else if (pickerView == self.genderIdentityPickerView) {
        return self.genderIdentities.count;
    } else if (pickerView == self.localePicker) {
        return self.supportedLocales.count;
    } else {
        return 0;
    }
}

#pragma mark - UIPickerViewDelegate

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (pickerView == self.addressCountryPickerView) {
        id<AWSDKCountry> selectedCountry = AWSDKEnrollmentService.countries[row];
        // If a new country is selected, clear out the selected state value since it is no longer valid
        if (self.selectedAddressCountry != selectedCountry) {
            self.selectedAddressCountry = selectedCountry;
            [self.addressStatePickerView selectRow:0 inComponent:0 animated:NO];
            self.stateHeaderInputControl.textField.text = nil;
            self.selectedAddressState = nil;
        }
        self.countryHeaderInputControl.textField.text = self.selectedAddressCountry.name;
    } else if (pickerView == self.currentCountryPickerView) {
        id<AWSDKCountry> selectedCountry = AWSDKEnrollmentService.countries[row];
        // If a new country is selected, clear out the selected state value since it is no longer valid
        if (self.selectedCurrentCountry != selectedCountry) {
            self.selectedCurrentCountry = selectedCountry;
            [self.currentStatePickerView selectRow:0 inComponent:0 animated:NO];
            self.currentStateHeaderInputControl.textField.text = nil;
            self.selectedCurrentState = nil;
        }
        self.currentCountryHeaderInputControl.textField.text = self.selectedCurrentCountry.name;
    } else if (pickerView == self.addressStatePickerView && self.selectedAddressCountry) {
        self.selectedAddressState = self.selectedAddressCountry.states[row];
        self.stateHeaderInputControl.textField.text = self.selectedAddressState.name;
    } else if (pickerView == self.currentStatePickerView && self.selectedCurrentCountry) {
        self.selectedCurrentState = self.selectedCurrentCountry.enrollmentStates[row];
        self.currentStateHeaderInputControl.textField.text = self.selectedCurrentState.name;
    } else if (pickerView == self.sexPickerView) {
        self.sexHeaderInputControl.textField.text = self.sexStrings[self.sexes[row]];
    } else if (pickerView == self.genderIdentityPickerView) {
        self.genderIdentityHeaderInputControl.textField.text = self.genderIdentities[row].name;
    } else if (pickerView == self.localePicker) {
        self.preferredLocale = self.supportedLocales[row];
        NSString *localeIdentifer = self.preferredLocale.localeIdentifier;
        self.localeHeaderInputControl.textField.text = [self.preferredLocale displayNameForKey:NSLocaleIdentifier value:localeIdentifer];
    }
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    switch (textField.tag) {
        case CurrentState:
            return self.selectedCurrentCountry != nil;
        case AddressState:
            return self.selectedAddressCountry != nil;
        default:
            return YES;
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    textField.rightView = nil;
    textField.tintColor = nil;

    switch (textField.tag) {
        case CurrentCountry:
            [self pickerView:self.currentCountryPickerView didSelectRow:[self.currentCountryPickerView selectedRowInComponent:0] inComponent:0];
            textField.text = AWSDKEnrollmentService.countries[[self.currentCountryPickerView selectedRowInComponent:0]].name;
            break;
        case CurrentState:
            [self pickerView:self.currentStatePickerView didSelectRow:[self.currentStatePickerView selectedRowInComponent:0] inComponent:0];
            textField.text = self.selectedCurrentState.name;
            break;
        case AddressCountry:
            [self pickerView:self.addressCountryPickerView didSelectRow:[self.addressCountryPickerView selectedRowInComponent:0] inComponent:0];
            textField.text = AWSDKEnrollmentService.countries[[self.addressCountryPickerView selectedRowInComponent:0]].name;
            break;
        case AddressState:
            [self pickerView:self.addressStatePickerView didSelectRow:[self.addressStatePickerView selectedRowInComponent:0] inComponent:0];
            textField.text = self.selectedAddressState.name;
            break;
        case Sex: {
            NSInteger row = [self.sexPickerView selectedRowInComponent:0];
            textField.text = self.sexStrings[self.sexes[row]];
            break;
        }
        case Gender:
            textField.text = self.genderIdentities[[self.genderIdentityPickerView selectedRowInComponent:0]].name;
            break;
        case PreferredLocale: {
            self.preferredLocale = self.supportedLocales[0];
            [self pickerView:self.localePicker didSelectRow:[self.localePicker selectedRowInComponent:0] inComponent:0];
            NSString *localeIdentifier = self.preferredLocale.localeIdentifier;
            textField.text = [self.preferredLocale displayNameForKey:NSLocaleIdentifier value:localeIdentifier];
            break;
        }
        case Password: {
            if (!self.shouldShowHints) {
                [self showHints:YES];
            }
            break;
        }
        default:
            break;
    }
}

- (void)showHints:(BOOL)show {
    self.shouldShowHints = show;
    [self.tableView beginUpdates];
    NSIndexPath *passwordHintsIndexPath = [NSIndexPath indexPathForRow:PasswordHints inSection:GeneralSection];
    [self.tableView reloadRowsAtIndexPaths:@[ passwordHintsIndexPath ] withRowAnimation:UITableViewRowAnimationNone];
    if (self.passwordHeaderInputControl.textField.text.length == 0) {
        [self.passwordHintCell setHintIconsToInitialState];
    }
    [self.tableView endUpdates];
    if (show) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.tableView scrollToRowAtIndexPath:passwordHintsIndexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
        });
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField reason:(UITextFieldDidEndEditingReason)reason {
    textField.text = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textFieldName = @"unknown";
    switch (textField.tag) {
        case FirstName:
            textFieldName = @"FirstName";
            break;
        case MiddleInitial:
            textFieldName = @"MiddleInitial";
            break;
        case LastName:
            textFieldName = @"LastName";
            break;
        case Sex:
            textFieldName = @"Sex";
            break;
        case Gender:
            textFieldName = @"Gender";
        case Birthday:
            textFieldName = @"MBirthday";
            break;
        case Email:
            textFieldName = @"Email";
            break;
        case EmailConfirm:
            textFieldName = @"EmailConfirm";
            break;
        case Password: {
            textFieldName = @"Password";
            [self showHints:NO];
            break;
        }
        case PasswordConfirm:
            textFieldName = @"PasswordConfirm";
            break;
        case CurrentCountry:
            textFieldName = @"CurrentCountry";
            break;
        case CurrentState:
            textFieldName = @"CurrentState";
            break;
        case AddressCountry:
            textFieldName = @"AddressCountry";
            break;
        case Address1:
            textFieldName = @"Address1";
            break;
        case Address2:
            textFieldName = @"Address2";
            break;
        case City:
            textFieldName = @"City";
            break;
        case PostalCode:
            textFieldName = @"PostalCode";
            break;
        case AddressState:
            textFieldName = @"AddressState";
            break;
        case PhoneNumber:
            textFieldName = @"PhoneNumber";
            break;
        case PreferredLocale:
            textFieldName = @"PreferredLocale";
            break;
        default:
            break;
    }
    AWSDKLogInfo(@"%@ textField did end editing with value: %@", textFieldName, textField.text);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField != self.guardianEmailTextField) {
        NSIndexSet *indexes = [self.allTextFields indexesOfObjectsPassingTest:^BOOL(HeaderInputControl *obj, NSUInteger idx, BOOL *stop) {
            return (obj.textField == textField);
        }];
        NSUInteger index = [indexes firstIndex];

        //  NSUInteger index = [self.allTextFields indexOfObject:textField];
        NSRange range;
        range.location = index + 1;
        range.length = self.allTextFields.count - index - 1;

        // make the next textfield that has a height (i.e is not hidden) the first responder
        for (HeaderInputControl *control in [self.allTextFields subarrayWithRange:range]) {
            if (control.textField.frame.size.height > 0) {
                [control.textField becomeFirstResponder];
                return YES;
            }
        }
    }
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *newPassword = [textField.text stringByReplacingCharactersInRange:range withString:string];

    if (textField == self.passwordHeaderInputControl.textField) {
        [self.passwordHintCell checkPasswordAgainstCriteria:newPassword];
    }

    NSIndexSet *indexes = [self.pickerTextFields indexesOfObjectsPassingTest:^BOOL(HeaderInputControl *obj, NSUInteger idx, BOOL *stop) {
        return (obj.textField == textField);
    }];
    return (indexes.count > 0) ? NO : YES;
    //  return ![self.pickerTextFields containsObject:textField];
}

#pragma mark - Alert Handling

- (void)presentDuplicateDependentViewWithForm:(AWSDKDemographicForm *)form dependentCheck:(BOOL)dependentCheck withCompletion:(CompletionBlock)completion {
    self.mode = LinkMode;
    [self updateViews];
    [self.tableView reloadData];
}
@end
