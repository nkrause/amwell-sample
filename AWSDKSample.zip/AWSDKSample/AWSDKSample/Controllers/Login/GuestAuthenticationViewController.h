//
//  GuestAuthenticationViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 4/29/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

/**
 Class allows authentication of a guest invited to a visit from a URL
 */
@interface GuestAuthenticationViewController : UIViewController

@end
