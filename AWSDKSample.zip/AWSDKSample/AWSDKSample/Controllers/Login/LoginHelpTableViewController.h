//
//  LoginHelpViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 3/30/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

/*
 This class handles cases where the consumer doesn't have their login credentials
 After validating their identity the consumer can have their username or password
 emailed to the email address on file
 In some cases the consumer's username hint can also be returned to the SDK in
 the callback to be shown to the user.
 */
@interface LoginHelpTableViewController : UITableViewController

@end
