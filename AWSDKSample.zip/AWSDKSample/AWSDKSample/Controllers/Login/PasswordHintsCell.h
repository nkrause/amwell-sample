//
//  PasswordHintsCell.h
//  AWSDKSample
//
//  Created by Ed Chianese on 5/17/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PasswordHintsCell : UITableViewCell

@property (nonatomic) IBOutlet UILabel *passwordRequiresSpecialCharactersTip;
@property (nonatomic) IBOutlet UIImageView *passwordRequiresSpecialCharactersIcon;
@property (nonatomic) IBOutlet UIView *passwordRequiresSpecialCharactersView;

@property (nonatomic) IBOutlet UILabel *passwordTooLongTip;
@property (nonatomic) IBOutlet UIImageView *passwordTooLongIcon;
@property (nonatomic) IBOutlet UIView *passwordTooLongView;

@property (nonatomic) IBOutlet UILabel *passwordTooShortTip;
@property (nonatomic) IBOutlet UIImageView *passwordTooShortIcon;
@property (nonatomic) IBOutlet UIView *passwordTooShortView;

@property (nonatomic) IBOutlet UILabel *passwordRequiresLettersTip;
@property (nonatomic) IBOutlet UIImageView *passwordRequiresLettersIcon;
@property (nonatomic) IBOutlet UIView *passwordRequiresLettersView;

@property (nonatomic) IBOutlet UILabel *passwordRequiresNumbersTip;
@property (nonatomic) IBOutlet UIImageView *passwordRequiresNumbersIcon;
@property (nonatomic) IBOutlet UIView *passwordRequiresNumbersView;

@property (nonatomic) IBOutlet UILabel *passwordContainsInvalidCharactersTip;
@property (nonatomic) IBOutlet UIImageView *passwordContainsInvalidCharactersIcon;
@property (nonatomic) IBOutlet UIView *passwordContainsInvalidCharactersView;
@property (nonatomic) IBOutlet UIStackView *hintStack;

typedef NS_OPTIONS(NSUInteger, PasswordToolTipOptions) {
    PasswordUnspecifiedTip = 0 << 0,
    PasswordRequiresSpecialCharactersTip = 1 << 0,
    PasswordTooLongTip = 1 << 1,
    PasswordTooShortTip = 1 << 2,
    PasswordRequiresLettersTip = 1 << 3,
    PasswordRequiresNumbersTip = 1 << 4,
    PasswordContainsInvalidCharactersTip = 1 << 5,
};

@property (assign, nonatomic) PasswordToolTipOptions passwordHintsBitmask;

- (void)setHintIconsToInitialState;
- (void)checkPasswordAgainstCriteria:(NSString *)pswd;
- (void)setup;
- (BOOL)passwordHintsAvailable;
- (BOOL)passwordHintsSupported;

@end
