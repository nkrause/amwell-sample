//
//  EnrollmentTableViewController.h
//  AWSDKSample
//
//  Created by Stephen Ciauri on 10/24/17.
//  Copyright © 2017 American Well. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EnrollmentTableViewController : UITableViewController

typedef NS_ENUM(NSUInteger, EnrollmentMode) {
    ConsumerMode,
    DependentMode,
    PartialMode,
    LinkMode,
};

@property (nonatomic) EnrollmentMode mode;
@property (nonatomic) id<AWSDKPartialConsumer> partialConsumer;
@property (nonatomic) id<AWSDKConsumer> consumer;
@property (nonatomic) NSString *partialConsumerUsername;
@property (nonatomic) NSString *partialConsumerPassword;

@end
