//
//  GuestAuthenticationViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 4/29/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "GuestAuthenticationViewController.h"

#import <AWSDK/AWCoreGuestConsoleDelegate.h>
#import <AWSDK/AWSDKAuthenticationService.h>
#import <AWSDK/AWSDKErrorCode.h>
#import <AWSDK/AWSDKService.h>

/**
 *  Class allows authentication of a guest invited to a visit from a URL
 */
@interface GuestAuthenticationViewController () <UITextFieldDelegate, UIScrollViewDelegate, AWCoreGuestConsoleDelegate>

@property (weak, nonatomic) IBOutlet UIBarButtonItem *joinButton;
@property (weak, nonatomic) IBOutlet UITextField *emailField;
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *logoLeadingConstraint;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@end

@implementation GuestAuthenticationViewController

#pragma mark - AWSDKMethod Calls
/**
 *  Authenticates the email given and presents the view controller result to display the visit
 *
 *  @param sender self.joinButton
 */
- (IBAction)joinTapped:(id)sender {
    [MBProgressHUD showHUDAddedTo:self.view];
    [AWSDKAuthenticationService authenticateGuestWithURL:[AWSDKService launchUrl]
                                                   email:self.emailField.text
                                                    name:self.nameField.text
                                                delegate:self
                                              completion:^(id _Nullable result, NSError *error) {
                                                  [MBProgressHUD hideHUDForView:self.view];
                                                  if (error) {
                                                      [self presentAlertWithError:error];
                                                  } else if (result) {
                                                      // If no error, take the console given from the call and display it
                                                      [self presentViewController:result animated:YES completion:nil];
                                                  }
                                              }];
}

#pragma mark - AWCoreGuestConsoleDelegate
/**
 *  Called when guest leaves the visit
 *
 *  @param reason Please refer to AWSDKVisitEndReason.h for details
 */
- (void)leftVisitWithReason:(AWCoreVisitEndReason)reason {
    [AWSDKService updateLaunchUrl:nil];

    AWSDKLogInfo(@"Left visit with reason %ld", (long)reason);

    [self presentVisitEndedAlert];
    [self dismissViewControllerAnimated:YES
                             completion:^{
                                 [self.parentViewController dismissViewControllerAnimated:YES completion:nil];
                             }];
}

- (void)presentVisitEndedAlert {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"visitEnd.title", @"The visit has ended title for guest") message:NSLocalizedString(@"visitEnd.visitEnded", @"The visit has ended for a guest") okHandler:nil];
    UIWindow *window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    window.rootViewController = [UIViewController new];
    window.windowLevel = UIWindowLevelAlert + 1;
    [window makeKeyAndVisible];
    [window.rootViewController presentViewController:alertController animated:YES completion:nil];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//
#pragma mark - UIViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidChangeFrame:) name:UIKeyboardDidChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillBeHidden:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];

    [super viewWillDisappear:animated];
}

#pragma mark - IBActions
- (IBAction)closeTapped:(id)sender {
    [AWSDKService updateLaunchUrl:nil];
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Keyboard Observers
// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardDidChangeFrame:(NSNotification *)aNotification {
    NSDictionary *info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;

    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    self.scrollView.contentInset = contentInsets;
    self.scrollView.scrollIndicatorInsets = contentInsets;
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification *)aNotification {
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    self.scrollView.contentInset = contentInsets;
    self.scrollView.scrollIndicatorInsets = contentInsets;
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == self.emailField) {
        [self.nameField becomeFirstResponder];
    } else if (textField == self.nameField) {
        [self joinTapped:textField];
    }
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    UITextField *otherField = textField == self.emailField ? self.nameField : self.emailField;

    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    [self.joinButton setEnabled:([otherField isPopulated] && newString.length)];
    return YES;
}
@end
