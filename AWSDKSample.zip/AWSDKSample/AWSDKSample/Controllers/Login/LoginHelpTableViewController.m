//
//  LoginHelpTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 3/30/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "LoginHelpTableViewController.h"

#import "DatePickerCell.h"
#import "FieldTableViewCell.h"
#import "NSDateFormatter+CommonFormats.h"
#import "SwitchTableViewCell.h"
#import "UITableViewController+CollapsiblePicker.h"

#import <AWSDK/AWSDKAuthenticationService.h>

const long LegalAgeInSeconds = 568036800;
/*
 * This class handles cases where the consumer doesn't have their login credentials
 * After validating their identity the consumer can have their username or password
 * emailed to the email address on file
 * In some cases the consumer's username hint can also be returned to the SDK in
 * the callback to be shown to the user.
 */
@interface LoginHelpTableViewController () <UITextFieldDelegate>

@property (nonatomic) UIDatePicker *datePicker;
@property (nonatomic) UITextField *lastNameField;
@property (nonatomic) UITextField *emailField;
@property (nonatomic) UILabel *dateLabel;

@property (weak, nonatomic) IBOutlet UIButton *findUsernameButton;
@property (weak, nonatomic) IBOutlet UIButton *resetPasswordButton;

@property (nonatomic, assign) BOOL emailCellShown;
@property (nonatomic, assign) BOOL datePickerShown;

/**
 *  Handles UI changes for errors
 */
@property (nonatomic) ErrorService *errorService;

@end

@implementation LoginHelpTableViewController

#pragma mark AWSDK Method Calls
/**
 *  Handles forgot username flow
 */
- (void)fetchUsername {
    [MBProgressHUD showLoadingOn:self.view];

    /*
     * Uses the consumer's last name and date of birth to find their username in the
     * telehealth platform.
     * Note that the username hint may not be returned as the result. In this case,
     * when there is no result and no error, the username has been emailed to the
     * address on file and can be retrieved by the user.
     * The username hint is a partially hidden username like k***@a***.net
     *
     */

    [AWSDKAuthenticationService
        getUsernameForUserWithLastName:self.lastNameField.text
                           dateOfBirth:[self.datePicker date]
                            completion:^(id _Nullable result, NSError *error) {
                                [MBProgressHUD hideHUDForView:self.view];
                                if (error) {
                                    [self presentAlertWithError:error okHandler:nil];
                                } else {
                                    NSString *title = NSLocalizedString(@"login.help.findUsername.title", @"Find Username Title");
                                    NSString *message = NSLocalizedString(@"login.help.findUsername.sent", @"Find username request sent message in alert");
                                    if (result) {
                                        message = [NSString stringWithFormat:NSLocalizedString(@"login.help.findUsername.yourUsername", @"Your username is %@ format string"), result];
                                    }
                                    [self presentAlertWithTitle:title
                                                        message:message
                                                      okHandler:^(UIAlertAction *action) {
                                                          [self dismissViewControllerAnimated:YES completion:nil];
                                                      }];
                                }
                            }];
}

/**
 *  Handles forgot password flow
 */
- (void)resetPassword {
    [MBProgressHUD showLoadingOn:self.view];
    /*
     * Uses the consumers email address, last name and date of birth to validate them with the telehealth platform
     * And send a temporary password to the email address on file.
     */
    [AWSDKAuthenticationService resetPasswordWithLastName:self.lastNameField.text
                                              dateOfBirth:[self.datePicker date]
                                                    email:self.emailField.text
                                               completion:^(BOOL success, NSError *error) {
                                                   [MBProgressHUD hideHUDForView:self.view];
                                                   [self.errorService handleError:error];
                                                   if (!error) {
                                                       // Always display message to avoid security risk
                                                       [self presentAlertWithMessageKey:@"login.help.resetPassword.sent"
                                                                              okHandler:^(UIAlertAction *action) {
                                                                                  [self dismissViewControllerAnimated:YES completion:nil];
                                                                              }];
                                                   }
                                               }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    self.emailCellShown = NO;
    self.datePickerShown = NO;

    self.errorService = [[ErrorService alloc] initWithSender:self];
}

#pragma mark - IBActions
- (IBAction)findUsernameTapped:(id)sender {
    [self fetchUsername];
}

- (IBAction)resetPasswordTapped:(id)sender {
    if (!self.emailCellShown) {
        // Insert Cell
        self.emailCellShown = YES;
        [self.tableView beginUpdates];
        NSArray *paths = @[ [NSIndexPath indexPathForRow:2 + self.datePickerShown inSection:0], [NSIndexPath indexPathForRow:3 + self.datePickerShown inSection:0] ];
        [[self tableView] insertRowsAtIndexPaths:paths withRowAnimation:UITableViewRowAnimationTop];
        [self.resetPasswordButton setEnabled:NO];
        [self.tableView endUpdates];
    } else {
        [self resetPassword];
    }
}

- (IBAction)cancelTapped:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)datePickerChanged:(id)sender {
    if ([self.lastNameField isPopulated] && [self.datePicker date]) {
        [self.findUsernameButton setEnabled:YES];
        if ([self.emailField isPopulated] || !self.emailCellShown) {
            [self.resetPasswordButton setEnabled:YES];
        } else {
            [self.resetPasswordButton setEnabled:NO];
        }
    }
    NSDateFormatter *formatter = [NSDateFormatter mediumDateFormatter];
    NSString *dateString = [formatter stringFromDate:self.datePicker.date];
    [UIView transitionWithView:self.dateLabel
                      duration:0.2f
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        [self.dateLabel setText:dateString];
                    }
                    completion:nil];
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row != 0 || indexPath.row != 4) {
        [self dismissKeyboard];
    }
    if (indexPath.row == 0) {
        [self.lastNameField becomeFirstResponder];
    }
    if (indexPath.row == 4) {
        [self.emailField becomeFirstResponder];
    }
    if (indexPath.row == 1) {
        self.datePickerShown = !self.datePickerShown;
        [self toggleCell:self.datePickerShown atIndexPath:[NSIndexPath indexPathForRow:2 inSection:0] withLabel:self.dateLabel];
    }
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - UITableViewDataSource
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [UITableViewCell new];
    if (indexPath.row == 0) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"lastNameCell"];
        self.lastNameField = ((FieldTableViewCell *)cell).textField;

        [self.errorService addObserver:cell forKeyPath:@"lastName"];
    } else if (indexPath.row == 1) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"dateCell"];
        if ([cell.detailTextLabel.text isEqualToString:@""]) {
            NSDate *date = self.datePicker ? self.datePicker.date : [NSDate dateWithTimeIntervalSinceNow:-LegalAgeInSeconds];
            NSDateFormatter *formatter = [NSDateFormatter mediumDateFormatter];
            NSString *dateString = [formatter stringFromDate:date];
            [cell.detailTextLabel setText:dateString];
        }
        self.dateLabel = cell.detailTextLabel;
    } else if (indexPath.row == 2 && self.datePickerShown) {
        // Collapsible Picker
        cell = [tableView dequeueReusableCellWithIdentifier:@"datePickerCell"];
        if (!self.datePicker) {
            self.datePicker = ((DatePickerCell *)cell).datePicker;
            self.datePicker.date = [NSDate dateWithTimeIntervalSinceNow:-LegalAgeInSeconds];
            [self.datePicker setMaximumDate:[NSDate date]];
        }
        [self.errorService addObserver:cell forKeyPath:@"dob"];
    } else if (indexPath.row == 2 + self.datePickerShown) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"emailPromptCell"];
        cell.textLabel.text = NSLocalizedString(@"login.help.enterEmail", @"Enter email text field title");
    } else if (indexPath.row == 3 + self.datePickerShown) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"emailCell"];
        self.emailField = ((FieldTableViewCell *)cell).textField;

        [self.errorService addObserver:cell forKeyPath:@"email"];
    } else {
        AWSDKLogWarn(@"Unexpected index path");
    }
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2 + (2 * self.emailCellShown) + self.datePickerShown;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 30.0;
}

#pragma mark UITextField Delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    [self.tableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionNone];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSRange textFieldRange = NSMakeRange(0, [textField.text length]);
    if (NSEqualRanges(range, textFieldRange) && [string length] == 0) {
        // Empty
        if (textField == self.lastNameField) {
            [self.findUsernameButton setEnabled:NO];
            [self.resetPasswordButton setEnabled:NO];
        }
        if (textField == self.emailField) {
            [self.resetPasswordButton setEnabled:NO];
        }
    } else {
        // Enable buttons
        if (textField == self.lastNameField && [self.datePicker date]) {
            [self.findUsernameButton setEnabled:YES];
            [self.resetPasswordButton setEnabled:YES];
        }
        if (textField == self.emailField && [self.lastNameField isPopulated] && [self.datePicker date]) {
            [self.resetPasswordButton setEnabled:YES];
        }
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == self.lastNameField && self.emailField) {
        [self.emailField becomeFirstResponder];
    } else {
        [textField resignFirstResponder];
    }
    return YES;
}

@end
