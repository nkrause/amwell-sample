//
//  PasswordHintsCell.m
//  AWSDKSample
//
//  Created by Ed Chianese on 5/17/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import "PasswordHintsCell.h"

#import <AWSDK/AWSDKSystemConfiguration.h>
@implementation PasswordHintsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self setup];
}

- (BOOL)passwordHintsAvailable {
    return self.passwordHintsBitmask != PasswordUnspecifiedTip;
}

- (BOOL)passwordHintsSupported {
    // For older servers that do not support hints, these properties will be empty,  Tables that use this cell will want to set the height of the hints cell to 0 so nothing is shown.
    BOOL hasPasswords = self.passwordTooShortTip.text.length || self.passwordTooLongTip.text.length || self.passwordContainsInvalidCharactersTip.text.length
        || self.passwordRequiresNumbersTip.text.length || self.passwordRequiresLettersTip.text.length || self.passwordRequiresSpecialCharactersTip.text.length;
    return hasPasswords;
}

- (void)setup {
    self.passwordHintsBitmask = PasswordUnspecifiedTip;
    self.passwordTooShortTip.text = [AWSDKSystemConfiguration passwordTooShortMessage];
    self.passwordTooLongTip.text = [AWSDKSystemConfiguration passwordTooLongMessage];
    self.passwordContainsInvalidCharactersTip.text = [AWSDKSystemConfiguration passwordContainsInvalidCharactersMessage];
    self.passwordRequiresNumbersTip.text = [AWSDKSystemConfiguration passwordRequiresNumbersMessage];
    self.passwordRequiresLettersTip.text = [AWSDKSystemConfiguration passwordRequiresLettersMessage];
    self.passwordRequiresSpecialCharactersTip.text = [AWSDKSystemConfiguration passwordRequiresSpecialCharactersMessage];

    if (![AWSDKSystemConfiguration passwordMustContainNumbers]) {
        [self.hintStack removeArrangedSubview:self.passwordRequiresNumbersView];
        [self.passwordRequiresNumbersView removeFromSuperview];
    }
    if (![AWSDKSystemConfiguration passwordMustContainLetters]) {
        [self.hintStack removeArrangedSubview:self.passwordRequiresLettersView];
        [self.passwordRequiresLettersView removeFromSuperview];
    }

    if ([AWSDKSystemConfiguration minimumNumberOfSpecialCharactersInPassword] == 0) {
        [self.hintStack removeArrangedSubview:self.passwordRequiresSpecialCharactersView];
        [self.passwordRequiresSpecialCharactersView removeFromSuperview];
    }
    if (![self passwordHintsSupported]) {
        self.hintStack.hidden = YES;
    }
    [self setNeedsLayout];
    [self layoutIfNeeded];
    [self setUserInteractionEnabled:NO];
}

#pragma hint helper
- (void)checkPasswordAgainstCriteria:(NSString *)pswd {
    if ([self passwordHintsSupported]) {
        if (pswd.length == 0) {
            [self setHintIconsToInitialState];
            return;
        }

        if (pswd.length > [AWSDKSystemConfiguration maxPasswordLength]) {
            // password too long
            self.passwordHintsBitmask |= PasswordTooLongTip;
            self.passwordTooLongIcon.image = [self passwordIconCheckFail];
            self.passwordTooLongTip.textColor = [UIColor redColor];
        } else {
            // password ok
            self.passwordHintsBitmask &= ~PasswordTooLongTip;
            self.passwordTooLongIcon.image = [self passwordIconChosenCheck];
            self.passwordTooLongTip.textColor = [UIColor blackColor];
        }

        if (pswd.length < [AWSDKSystemConfiguration minPasswordLength]) {
            // password too short
            self.passwordHintsBitmask |= PasswordTooShortTip;
            self.passwordTooShortIcon.image = [self passwordIconCheckFail];
            self.passwordTooShortTip.textColor = [UIColor redColor];

        } else {
            // password ok
            self.passwordHintsBitmask &= ~PasswordTooShortTip;
            self.passwordTooShortIcon.image = [self passwordIconChosenCheck];
            self.passwordTooShortTip.textColor = [UIColor blackColor];
        }

        if ([AWSDKSystemConfiguration passwordMustContainLetters]) {
            NSCharacterSet *notDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
            if ([pswd rangeOfCharacterFromSet:notDigits].location == NSNotFound) {
                // no letters
                self.passwordHintsBitmask |= PasswordRequiresLettersTip;
                self.passwordRequiresLettersIcon.image = [self passwordIconCheckFail];
                self.passwordRequiresLettersTip.textColor = [UIColor redColor];
            } else {
                self.passwordHintsBitmask &= ~PasswordRequiresLettersTip;
                self.passwordRequiresLettersIcon.image = [self passwordIconChosenCheck];
                self.passwordRequiresLettersTip.textColor = [UIColor blackColor];
            }
        }

        if ([AWSDKSystemConfiguration passwordMustContainNumbers]) {
            if ([pswd rangeOfCharacterFromSet:[NSCharacterSet decimalDigitCharacterSet]].location == NSNotFound) {
                // no numbers
                self.passwordHintsBitmask |= PasswordRequiresNumbersTip;
                self.passwordRequiresNumbersIcon.image = [self passwordIconCheckFail];
                self.passwordRequiresNumbersTip.textColor = [UIColor redColor];

            } else {
                self.passwordHintsBitmask &= ~PasswordRequiresNumbersTip;
                self.passwordRequiresNumbersIcon.image = [self passwordIconChosenCheck];
                self.passwordRequiresNumbersTip.textColor = [UIColor blackColor];
            }
        }
        NSArray<NSString *> *listSpecialCharacters = [[AWSDKSystemConfiguration specialCharacterSetAllowedInPassword] componentsSeparatedByString:@","];
        if ([AWSDKSystemConfiguration minimumNumberOfSpecialCharactersInPassword] > 0) {
            NSUInteger totalOccurrances = 0;
            for (NSString *sp in listSpecialCharacters) {
                totalOccurrances += [[pswd componentsSeparatedByString:sp] count] - 1;
            }

            AWSDKLogInfo(@"The TOTAL COUNT OF SPECIAL CHARACTERS IS  %lu", (unsigned long)totalOccurrances);
            if (totalOccurrances < [AWSDKSystemConfiguration minimumNumberOfSpecialCharactersInPassword]) {
                // not enough special characters
                self.passwordHintsBitmask |= PasswordRequiresSpecialCharactersTip;
                self.passwordRequiresSpecialCharactersIcon.image = [self passwordIconCheckFail];
                self.passwordRequiresSpecialCharactersTip.textColor = [UIColor redColor];

            } else {
                self.passwordHintsBitmask &= ~PasswordRequiresSpecialCharactersTip;
                self.passwordRequiresSpecialCharactersIcon.image = [self passwordIconChosenCheck];
                self.passwordRequiresSpecialCharactersTip.textColor = [UIColor blackColor];
            }
        }

        // check if there is an illegal character.  i.e. not a letter, not a number and not one of the special characters
        for (int i = 0; i < [pswd length]; i++) {
            NSString *ch = [pswd substringWithRange:NSMakeRange(i, 1)];
            if ([ch rangeOfCharacterFromSet:[NSCharacterSet alphanumericCharacterSet]].location == NSNotFound) {
                // not letters or numbers
                // check if its a special
                NSUInteger countSpecialChar = 0;
                for (NSString *sp in listSpecialCharacters) {
                    countSpecialChar += [[ch componentsSeparatedByString:sp] count] - 1;
                }
                if (countSpecialChar == 0 && ch.length > 0) {
                    // not a number, letter or special.  Must be illegal
                    self.passwordHintsBitmask |= PasswordContainsInvalidCharactersTip;
                    self.passwordContainsInvalidCharactersIcon.image = [self passwordIconCheckFail];
                    self.passwordContainsInvalidCharactersTip.textColor = [UIColor redColor];
                    return;

                } else {
                    self.passwordHintsBitmask &= ~PasswordContainsInvalidCharactersTip;
                    self.passwordContainsInvalidCharactersIcon.image = [self passwordIconChosenCheck];
                    self.passwordContainsInvalidCharactersTip.textColor = [UIColor blackColor];
                }
            } else {
                self.passwordHintsBitmask &= ~PasswordContainsInvalidCharactersTip;
                self.passwordContainsInvalidCharactersIcon.image = [self passwordIconChosenCheck];
                self.passwordContainsInvalidCharactersTip.textColor = [UIColor blackColor];
            }
        }
    }
}

- (void)setHintIconsToInitialState {
    self.passwordHintsBitmask = PasswordUnspecifiedTip;
    self.passwordContainsInvalidCharactersIcon.image = [self passwordIconCheckOff];
    self.passwordRequiresSpecialCharactersIcon.image = [self passwordIconCheckOff];
    self.passwordRequiresLettersIcon.image = [self passwordIconCheckOff];
    self.passwordRequiresNumbersIcon.image = [self passwordIconCheckOff];
    self.passwordTooShortIcon.image = [self passwordIconCheckOff];
    self.passwordTooLongIcon.image = [self passwordIconCheckOff];

    self.passwordContainsInvalidCharactersTip.textColor = [UIColor lightGrayColor];
    self.passwordRequiresSpecialCharactersTip.textColor = [UIColor lightGrayColor];
    self.passwordRequiresLettersTip.textColor = [UIColor lightGrayColor];
    self.passwordRequiresNumbersTip.textColor = [UIColor lightGrayColor];
    self.passwordTooShortTip.textColor = [UIColor lightGrayColor];
    self.passwordTooLongTip.textColor = [UIColor lightGrayColor];
}

- (UIImage *)passwordIconCheckOff {
    return [UIImage imageNamed:@"iconCheckOff"];
}

- (UIImage *)passwordIconChosenCheck {
    return [UIImage imageNamed:@"iconChosenCheck"];
}

- (UIImage *)passwordIconCheckFail {
    return [UIImage imageNamed:@"iconCheckFail"];
}
@end
