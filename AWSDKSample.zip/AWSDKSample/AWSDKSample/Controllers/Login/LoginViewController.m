//
//  LoginViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 2/16/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "LoginViewController.h"

#import "DisclaimerViewController.h"
#import "EnrollmentTableViewController.h"

// Importing specific headers from the AWSDK framework like so
#import <AWSDK/AWSDKAuthenticationService.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKConsumerEnrollmentForm.h>
#import <AWSDK/AWSDKPartialConsumer.h>
#import <AWSDK/AWSDKService.h>
#import <AWSDK/AWSDKURLFeature.h>

@interface LoginViewController () <UITextFieldDelegate, UIScrollViewDelegate>

@property (weak, nonatomic) IBOutlet UITextField *usernameTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
@property (weak, nonatomic) IBOutlet UISwitch *autoLoginSwitch;
@property (weak, nonatomic) IBOutlet UILabel *autoLoginLabel;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *loginButton;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@property (nonatomic, readonly) NSString *authKey;

@end

/**
 *  This class handles UI for authentication with username and password
 *  Actual authentication happens in ConsumerService
 */
@implementation LoginViewController

#pragma mark - AWSDKMethod Calls

- (void)loginCompletionActions:(BOOL)success withResult:(id)result {
    /*
     * Note that after successful authentication in some cases
     * the telehealth platform may not have all necessary user
     * info for our services.
     * In this case the comsumer may need to complete enrollment
     * before progressing.
     * You will get an AWSDKPartialConsumer back from authentication
     * in this case.
     */
    [self.loginButton setEnabled:YES];

    if (success) {
        if ([result conformsToProtocol:@protocol(AWSDKConsumer)]) {
            id<AWSDKConsumer> consumer = (id<AWSDKConsumer>)result;
            if (consumer.outstandingDisclaimer) {
                [MBProgressHUD hide];
                [self performSegueWithIdentifier:@"outstandingDisclaimerSegue" sender:consumer];
            } else {
                /**
                 *  The consumer object may have been cached if logged in previously.
                 *  To refresh dependents the consumer object must be refreshed.
                 */
                [[ConsumerService sharedInstance] refreshConsumerWithCompletion:^(BOOL success, id result) {
                    [MBProgressHUD hide];
                    /*
                     * If we get an AWSDKConsumer object back from authentication
                     * the consumer is fully enrolled and we can continue from here
                     */
                    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
                }];
            }
        } else if ([result conformsToProtocol:@protocol(AWSDKPartialConsumer)]) {
            [MBProgressHUD hide];
            /*
             * If we get an AWSDKPartialConsumer we must complete consumer enrollment
             * before any other consumer actions can take place
             * See EnrollmentTableViewController.m
             */
            [self performSegueWithIdentifier:@"signUpSegue" sender:result];
        } else {
            AWSDKLogWarn(@"Authentication successful, but with an unexpected result");
        }
    } else {
        [MBProgressHUD hide];
        if ([result isKindOfClass:[NSError class]]) {
            [self presentAlertWithError:result
                              okHandler:^(UIAlertAction *action) {
                                  [self.loginButton setEnabled:NO];
                                  self.passwordTextField.text = @"";
                              }];
        } else {
            [self presentAlertWithMessageKey:@"misc.fail.unknown"];
        }
    }
}

- (void)loginWithCredentials {
    /*
     *  Send the username and password along to the ConsumerService class.
     *  This will make the actual SDK call to authenticate and store the consumer
     */
    ConsumerService *consumerService = [ConsumerService sharedInstance];

    [self.loginButton setEnabled:NO];

    /*
     * This method handles errors itself, so a different completion block is passed
     * which is only called if no error is found and authentication worked
     * See ConsumerService for error handling
     */
    [MBProgressHUD show];
    [consumerService authenticateConsumerWithUsername:self.usernameTextField.text
                                         withPassword:self.passwordTextField.text
                                      enableAutoLogin:[self.autoLoginSwitch isOn]
                                       withCompletion:^void(BOOL success, id result) {
                                           [self loginCompletionActions:success withResult:result];
                                       }];
}

- (void)loginWithMutualAuth {
    /*
     *  Send the username and password along to the ConsumerService class.
     *  This will make the actual SDK call to authenticate and store the consumer
     */
    ConsumerService *consumerService = [ConsumerService sharedInstance];

    [self.loginButton setEnabled:NO];

    /*
     * This method handles errors itself, so a different completion block is passed
     * which is only called if no error is found and authentication worked
     * See ConsumerService for error handling
     *
     */
    [MBProgressHUD show];
    [consumerService authenticateConsumerMutualAuthToken:self.passwordTextField.text
                                          withCompletion:^(BOOL success, id _Nullable result) {
                                              [self loginCompletionActions:success withResult:result];
                                          }];
}

//-----------------------------------------------------------------------------------------------------//
//------------Everything past here is UI for the sample app, no more API calls here -------------------//
//-----------------------------------------------------------------------------------------------------//

- (void)viewDidLoad {
    [super viewDidLoad];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];

    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"useMutualAuth"] boolValue]) {
        self.passwordTextField.placeholder = @"Mutual Auth Token";
        self.passwordTextField.secureTextEntry = NO;
        [self.usernameTextField setHidden:YES];
        [self.autoLoginLabel setHidden:YES];
        [self.autoLoginSwitch setHidden:YES];
    } else {
        self.usernameTextField.text = @"";
        self.passwordTextField.text = @"";
        self.passwordTextField.secureTextEntry = YES;

        NSString *userName = [ConsumerService sharedInstance].fetchUserName;
        if (userName) {
            [self.autoLoginSwitch setOn:YES];
            self.usernameTextField.text = userName;
            self.passwordTextField.text = @"";
            if (self.authKey) {
                // Populate password field to let user know that it's not required
                self.passwordTextField.text = @"password";
            }
        }
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidChangeFrame:) name:UIKeyboardDidChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillBeHidden:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];

    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

- (NSString *)authKey {
    return [ConsumerService sharedInstance].fetchAuthenticationKey;
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == self.usernameTextField) {
        [self passwordTapped:textField];
    } else {
        [textField resignFirstResponder];
        if ([self.loginButton isEnabled] || self.authKey) {
            [self loginTapped:self.loginButton];
        }
    }
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    // Max character limit
    UITextField *otherField = textField == self.usernameTextField ? self.passwordTextField : self.usernameTextField;
    NSUInteger oldLength = [textField.text length];
    NSUInteger replacementLength = [string length];
    NSUInteger rangeLength = range.length;

    NSUInteger newLength = oldLength - rangeLength + replacementLength;

    if (newLength == 0) {
        [self.loginButton setEnabled:NO];
    } else if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"useMutualAuth"] boolValue] || [otherField isPopulated]) {
        [self.loginButton setEnabled:YES];
    }
    return YES;
}

#pragma mark - Keyboard Observers
// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardDidChangeFrame:(NSNotification *)aNotification {
    NSDictionary *info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;

    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    self.scrollView.contentInset = contentInsets;
    self.scrollView.scrollIndicatorInsets = contentInsets;
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification *)aNotification {
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    self.scrollView.contentInset = contentInsets;
    self.scrollView.scrollIndicatorInsets = contentInsets;
}

#pragma mark - IBActions
- (IBAction)usernameTapped:(id)sender {
    AWSDKLogInfo(@"Username field tapped");
    [self.usernameTextField becomeFirstResponder];
}

- (IBAction)passwordTapped:(id)sender {
    AWSDKLogInfo(@"Password field tapped");
    [self.passwordTextField becomeFirstResponder];
}

- (IBAction)loginTapped:(id)sender {
    AWSDKLogInfo(@"Login tapped");
    if (!AWSDKService.isInitialized) {
        // Show error indicating that the SDK isn't initialized and to quit and reopen the app when the server is up.
        [self presentUninitializedAlert];
    } else if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"useMutualAuth"] boolValue]) {
        [self loginWithMutualAuth];
    } else {
        [self loginWithCredentials];
    }
}

- (void)presentUninitializedAlert {
    [self presentAlertWithTitle:NSLocalizedString(@"error.initialization.notInitialized.title", @"SDK is not initialized")
                        message:NSLocalizedString(@"error.initialization.notInitialized.message", "Send to background and return to foreground")
                      okHandler:nil];
}

- (IBAction)unwindFromDisclaimerViewController:(UIStoryboardSegue *)segue {
    if ([segue.sourceViewController isKindOfClass:[UINavigationController class]]
        && ((DisclaimerViewController *)((UINavigationController *)segue.sourceViewController).viewControllers.firstObject).consumer) {
        if ([segue.identifier isEqualToString:@"declinedDisclaimerSegue"]) {
            AWSDKLogInfo(@"Member declined disclaimer");
            // Handle this however you like
        } else {
            AWSDKLogWarn(@"Unexpected segue identifier")
        }
    } else {
        AWSDKLogWarn(@"Unexpected sourceViewController or invalid consumer object");
    }
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"signUpSegue"]) {
        AWSDKLogInfo(@"Sign up button tapped");

        EnrollmentTableViewController *controller = ((UINavigationController *)segue.destinationViewController).viewControllers[0];

        if ([sender conformsToProtocol:@protocol(AWSDKPartialConsumer)]) {
            controller.mode = PartialMode;
            controller.partialConsumer = (id<AWSDKPartialConsumer>)sender;
            controller.partialConsumerPassword = self.passwordTextField.text;
            controller.partialConsumerUsername = self.usernameTextField.text;
        } else {
            controller.mode = ConsumerMode;
        }
    } else if ([segue.identifier isEqualToString:@"outstandingDisclaimerSegue"] && [segue.destinationViewController isKindOfClass:[UINavigationController class]] &&
        [sender conformsToProtocol:@protocol(AWSDKConsumer)]) {
        AWSDKLogInfo(@"Presenting outstanding disclaimer");
        UINavigationController *navController = segue.destinationViewController;
        DisclaimerViewController *disclaimerVC = (DisclaimerViewController *)navController.viewControllers.firstObject;
        disclaimerVC.actionRequired = YES;
        disclaimerVC.consumer = ((id<AWSDKConsumer>)sender);
    } else if ([segue.identifier isEqualToString:@"reminder"]) {
        AWSDKLogInfo(@"Reminder button tapped");
    }
}

- (BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender {
    if (!AWSDKService.isInitialized) {
        [self presentUninitializedAlert];
        return NO;
    } else {
        return YES;
    }
}

- (BOOL)disablesAutomaticKeyboardDismissal {
    return NO;
}

@end
