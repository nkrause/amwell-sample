//
//  TechCheckTableViewController.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 12/28/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TechCheckTableViewController : UITableViewController

@end
