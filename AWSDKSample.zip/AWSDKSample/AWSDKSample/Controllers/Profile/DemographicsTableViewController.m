//
//  DemographicsTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 6/9/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "DemographicsTableViewController.h"

#import "BottomBorderTextField.h"
#import "DatePickerCell.h"
#import "FieldTableViewCell.h"
#import "PasswordHintsCell.h"
#import "PickerTableViewCell.h"
#import "UITableView+Sample.h"
#import "UITextField+Compare.h"
#import "UIViewController+Handlers.h"

#import <AWSDK/AWSDKAddress.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKConsumerUpdateForm.h>
#import <AWSDK/AWSDKCountry.h>
#import <AWSDK/AWSDKDependentUpdateForm.h>
#import <AWSDK/AWSDKEnrollmentService.h>
#import <AWSDK/AWSDKProtectedPropertyKey.h>
#import <AWSDK/AWSDKService.h>
#import <AWSDK/AWSDKState.h>
#import <AWSDK/AWSDKSubscription.h>
#import <AWSDK/AWSDKSystemConfiguration.h>

typedef NS_ENUM(NSInteger, DemographicSection) {
    UserSection,
    AccountSection,
    AddressSection,
};

typedef NS_ENUM(NSInteger, ProtectedView) {
    UndefinedView,
    Protected,
    UnProtected,
};

typedef NS_ENUM(NSUInteger, UserRow) {
    UserFirstNameIndexRow = 0,
    UserMiddleInitialIndexRow,
    UserLastNameIndexRow,
    UserGenderIdentityIndexRow,
    UserGenderIndexRow,
    UserDateOfBirthRow,
    UserRowCount            // must be last
};

const NSUInteger AccountConfirmEmailFieldIndexRow = 1;
const NSUInteger AccountPasswordHints = 2;
const NSUInteger AccountPreferredLocaleIndexRow = 5;
const NSUInteger AccountCountryOfLegalResidenceIndexRow = 6;
const NSUInteger AddressCountryIndexRow = 0;
const NSUInteger AddressCityIndexRow = 3;

const CGFloat EstimatedTableRowHeight = 61.0;
const CGFloat StandardTableRowHeight = 100.0;
const CGFloat DoubleTableRowHeight = 189.0;

/**
 *  DemographicsTableViewController displays current account information, and allows updating
 *  fields in the edit state.
 *
 *  Note that the following fields may not be able to be edited while a healthPlan is in place or the user is a
 *  feed consumer:
 *  - First, middle initial, and last name
 *  - Date of Birth
 *  - Gender
 *  - Primary Address
 *  Refer to AWSDKService to check which of these fields can be edited
 */
@interface DemographicsTableViewController () <UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource>

@property (nonatomic) UITextField *firstNameField;
@property (nonatomic) UITextField *middleInitialField;
@property (nonatomic) UITextField *lastNameField;
@property (nonatomic) UIPickerView *genderIdentityPicker;
@property (nonatomic) UIPickerView *sexPicker;

@property (nonatomic) UIDatePicker *datePicker;
@property (nonatomic) UITextField *emailField;
@property (nonatomic) UITextField *confirmEmailField;
@property (nonatomic) UITextField *passwordField;
@property (nonatomic) UIPickerView *currentCountryPicker;
@property (nonatomic) UIPickerView *currentStatePicker;
@property (nonatomic) IBOutlet UIPickerView *localePicker;
@property (nonatomic) UITextField *phoneField;
@property (nonatomic) PasswordHintsCell *passwordHintCell;
@property (nonatomic) BOOL shouldShowHints;
@property (nonatomic) BOOL isEditingPassword;
@property (readonly) AWSDKBiologicalSex selectedSex;

// Address
@property (nonatomic) UITextField *addressOneField;
@property (nonatomic) UITextField *addressTwoField;
@property (nonatomic) UITextField *cityField;
@property (nonatomic) UITextField *zipField;
@property (nonatomic) UIPickerView *countryPicker;
@property (nonatomic) UIPickerView *statePicker;

@property (assign, nonatomic) BOOL requiresUpdate;
@property (nonatomic) NSArray<NSNumber *> *sexes;           // Ordered list of AWBiologicalSex values
@property (nonatomic) NSDictionary<NSNumber *, NSString *> *sexStrings;     // AWBiologicalSex -> String
@property (nonatomic) NSArray<id<AWSDKGenderIdentity> > *genderIdentities;
@property (nonatomic) BOOL showUnselectedGender;            // TRUE if consumer has not yet selected a gender identity
@property (nonatomic) NSArray<id<AWSDKCountry>> *countries;
@property (nonatomic) NSArray<NSLocale *> *supportedLocales;
@property (nonatomic) NSMutableArray<NSString *> *editableProperties;
@property (nonatomic) ErrorService *errorService;
@end

@implementation DemographicsTableViewController

NSString *const hiddenPassword = @"********";

#pragma mark - AWSDK Method Calls
/**
 *  Creates and populates an AWSDKConsumerUpdateForm object to use to updateDemographics:
 */
- (void)updateDemographics:(ConsumerResultCompletionBlock)completion {
    if (self.emailField && ![self.emailField.text isEqualToString:self.consumer.email] && ![self.emailField.text isEqualToString:self.confirmEmailField.text]) {
        [self presentViewController:[UIAlertController alertControllerWithMessageKey:@"enrollment.email.mismatch" okHandler:nil]
                           animated:YES
                         completion:^{
                             NSDictionary *userInfo = @{
                                 NSLocalizedDescriptionKey : NSLocalizedString(@"enrollment.email.mismatch", @"Email and confirmation email mismatch"),
                                 NSLocalizedFailureReasonErrorKey : NSLocalizedString(@"enrollment.email.mismatch.reason", @"Enrollment Email Mismatch Reason")
                             };
                             NSError *error = [NSError errorWithDomain:@"com.americanwell.sampleapp.errordomain.demographics" code:AWSDKErrorCodeValidationEmailMismatch userInfo:userInfo];
                             completion(nil, error);
                         }];
    } else {
        AWSDKDemographicForm *form = ((self.consumer.authenticatedParent) ? self.updateDependentForm : self.updateConsumerForm);
        [self.consumer updateDemographicsWithForm:form
                                   withCompletion:^(id<AWSDKConsumer> _Nullable consumer, NSError *error) {
                                       if (consumer && !error && [form isKindOfClass:AWSDKConsumerUpdateForm.class]) {
                                           AWSDKConsumerUpdateForm *consumerForm = (AWSDKConsumerUpdateForm *)form;
                                           if (consumerForm.password.length || consumerForm.email.length) {
                                               // User updated their credentials, so you should clear them from the auto-login/remember me feature.
                                               [ConsumerService.sharedInstance clearAuthenticationKey];
                                               [ConsumerService.sharedInstance clearUserName];
                                           }
                                       }
                                       completion(consumer, error);
                                   }];
    }
}

/**
 *  Creates AWSDKConsumerUpdateForm if changes are made
 *
 *  @return AWSDKConsumerUpdateForm
 */
- (AWSDKConsumerUpdateForm *)updateConsumerForm {
    AWSDKConsumerUpdateForm *data = [AWSDKConsumerUpdateForm form];

    if (self.firstNameField && ![self.firstNameField.text isEqualToString:self.consumer.nameComponents.givenName]) {
        data.firstName = self.firstNameField.text;
    }

    if (self.middleInitialField) {
        switch (AWSDKSystemConfiguration.middleNameHandling) {
            case AWSDKConsumerMiddleNameHandlingInitial:
                if (![self.middleInitialField.text isEqualToString:[self.consumer.nameComponents.middleName substringToIndex:1]]) {
                    data.middleInitial = self.middleInitialField.text;
                }
                break;
            case AWSDKConsumerMiddleNameHandlingFullName:
                if (![self.middleInitialField.text isEqualToString:self.consumer.nameComponents.middleName]) {
                    data.middleName = self.middleInitialField.text;
                }
                break;
            default:
                break;
        }
    }

    if (self.lastNameField && ![self.lastNameField.text isEqualToString:self.consumer.nameComponents.familyName]) {
        data.lastName = self.lastNameField.text;
    }
    if ([self selectedSex] != self.consumer.gender) {
        data.gender = self.selectedSex;
    }
    if (AWSDKSystemConfiguration.isExtensibleGenderSupportEnabled) {
        id<AWSDKGenderIdentity> selectedGender = [self selectedGenderIdentity];
        if (self.consumer.genderIdentity == nil || (selectedGender != nil && selectedGender.key != self.consumer.genderIdentity.key)) {
            data.genderIdentity = selectedGender;
        }
    }
    if (self.datePicker && ([NSCalendar.currentCalendar compareDate:self.consumer.dateOfBirth toDate:self.datePicker.date toUnitGranularity:NSCalendarUnitDay] != NSOrderedSame)) {
        data.dateOfBirth = [self.datePicker date];
    }
    if (self.emailField && ![self.emailField.text isEqualToString:self.consumer.email]) {
        data.email = self.emailField.text;
    }
    if (self.passwordField && ![self.passwordField.text isEqualToString:hiddenPassword]) {
        data.password = self.passwordField.text;
    }
    if (self.phoneField && ![self.phoneField.text isEqualToString:self.consumer.phoneNumber]) {
        data.phoneNumber = self.phoneField.text;
    }
    if (self.currentStatePicker && ![[self selectedCurrentState] isEqual:self.consumer.stateOfLegalResidence]) {
        data.stateOfLegalResidence = [self selectedCurrentState];
    }

    if (self.currentCountryPicker && ![[self selectedCurrentCountry] isEqual:self.consumer.countryOfLegalResidence]) {
        data.countryOfLegalResidence = [self selectedCurrentCountry];
    }

    if (self.localePicker && ![self.consumer.preferredLocale.localeIdentifier isEqualToString:[self selectedLocale].localeIdentifier]) {
        data.preferredLocale = [self selectedLocale];
    }
    // Address
    if (!self.consumer.wasFeedGenerated || ![AWSDKSystemConfiguration isPropertyProtected:kProtectedAddress]) {
        AWSDKAddress *address = [AWSDKAddress address];
        address.addressOne = self.addressOneField.text;
        address.addressTwo = self.addressTwoField.text;
        address.city = self.cityField.text;
        address.state = [self selectedAddressState];
        address.country = [self selectedAddressCountry];
        address.zip = self.zipField.text;
        if (![self.consumer.address isEqual:address] && self.addressOneField && self.addressTwoField && self.cityField && self.statePicker && self.zipField) {
            data.address = address;
        }
    }
    return data;
}

/**
 *  Creates AWSDKDependentUpdateForm if changes are made
 *
 *  @return AWSDKDependentUpdateForm
 */
- (AWSDKDependentUpdateForm *)updateDependentForm {
    AWSDKDependentUpdateForm *data = [AWSDKDependentUpdateForm form];

    if (self.firstNameField && ![self.firstNameField.text isEqualToString:self.consumer.nameComponents.givenName]) {
        data.firstName = self.firstNameField.text;
    }
    if (self.middleInitialField) {
        switch (AWSDKSystemConfiguration.middleNameHandling) {
            case AWSDKConsumerMiddleNameHandlingInitial:
                if (![self.middleInitialField.text isEqualToString:[self.consumer.nameComponents.middleName substringToIndex:1]]) {
                    data.middleInitial = self.middleInitialField.text;
                }
                break;
            case AWSDKConsumerMiddleNameHandlingFullName:
                if (![self.middleInitialField.text isEqualToString:self.consumer.nameComponents.middleName]) {
                    data.middleName = self.middleInitialField.text;
                }
                break;
            default:
                break;
        }
    }
    if (self.lastNameField && ![self.lastNameField.text isEqualToString:self.consumer.nameComponents.familyName]) {
        data.lastName = self.lastNameField.text;
    }
    if ([self selectedSex] != self.consumer.gender) {
        data.gender = self.selectedSex;
    }
    if ([self selectedGenderIdentity] != self.consumer.genderIdentity) {
        data.genderIdentity = [self selectedGenderIdentity];
    }

    if (self.datePicker && ([NSCalendar.currentCalendar compareDate:self.consumer.dateOfBirth toDate:self.datePicker.date toUnitGranularity:NSCalendarUnitDay] != NSOrderedSame)) {
        data.dateOfBirth = [self.datePicker date];
    }
    return data;
}

//-----------------------------------------------------------------------------------------------------//
//---------------Everything beyond here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - Helpers

- (NSLocale *)selectedLocale {
    return self.supportedLocales[[self.localePicker selectedRowInComponent:0]];
}
- (id<AWSDKCountry>)selectedCurrentCountry {
    return self.countries[[self.currentCountryPicker selectedRowInComponent:0]];
}

- (id<AWSDKCountry>)selectedAddressCountry {
    return self.countries[[self.countryPicker selectedRowInComponent:0]];
}

- (id<AWSDKState>)selectedCurrentState {
    return [self selectedCurrentCountry].enrollmentStates[[self.currentStatePicker selectedRowInComponent:0]];
}

- (id<AWSDKState>)selectedAddressState {
    return [self selectedAddressCountry].states[[self.statePicker selectedRowInComponent:0]];
}

- (AWSDKBiologicalSex)selectedSex {
    return (AWSDKBiologicalSex)self.sexes[[self.sexPicker selectedRowInComponent:0]].integerValue;
}

- (id<AWSDKGenderIdentity>)selectedGenderIdentity {
    NSInteger selectedRow = [self.genderIdentityPicker selectedRowInComponent:0];

    if (self.showUnselectedGender) {
        if (selectedRow == 0) {
            return nil;
        }
        selectedRow -= 1;
    }
    return self.genderIdentities[selectedRow];
}

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    if (!self.consumer) {
        AWSDKLogWarn(@"Error: the consumer property should already be assigned.");
    }

    self.navigationItem.rightBarButtonItem = self.editButtonItem;

    self.countries = AWSDKEnrollmentService.countries;
    self.supportedLocales = [AWSDKSystemConfiguration supportedLocales];
    self.sexStrings = AWSDKSystemConfiguration.sexes;
    self.sexes = [[self.sexStrings allKeys] sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        if ([obj1 integerValue] < [obj2 integerValue]) {
            return NSOrderedAscending;
        }
        if ([obj1 integerValue] > [obj2 integerValue]) {
            return NSOrderedDescending;
        }
        return NSOrderedSame;
    }];
    self.showUnselectedGender = self.consumer.genderIdentity == nil;
    self.genderIdentities = AWSDKSystemConfiguration.genderIdentities;

    self.requiresUpdate = NO;

    self.errorService = [[ErrorService alloc] initWithSender:self];
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
    AWSDKLogInfo(@"Editing mode %@", editing ? @"enabled" : @"disabled");
    // Block to adjust editing state. Not called when updateDemographics has an error.
    void (^successBlock)(void) = ^void() {
        [super setEditing:editing animated:animated];

        [self.firstNameField setUserInteractionEnabled:editing];
        [self.middleInitialField setUserInteractionEnabled:editing];
        [self.lastNameField setUserInteractionEnabled:editing];
        [self.sexPicker setUserInteractionEnabled:editing && (!self.consumer.wasFeedGenerated || ![AWSDKSystemConfiguration isPropertyProtected:kProtectedGender])];
        [self.genderIdentityPicker setUserInteractionEnabled:editing && (!self.consumer.wasFeedGenerated || ![AWSDKSystemConfiguration isPropertyProtected:kProtectedGenderIdentity])];
        [self.datePicker setUserInteractionEnabled:editing && (!self.consumer.wasFeedGenerated || ![AWSDKSystemConfiguration isPropertyProtected:kProtectedAddress])];

        [self.emailField setUserInteractionEnabled:editing];
        [self.confirmEmailField setUserInteractionEnabled:editing];
        [self.passwordField setUserInteractionEnabled:editing];
        [self.phoneField setUserInteractionEnabled:editing];
        [self.currentStatePicker setUserInteractionEnabled:editing];

        [self.addressOneField setUserInteractionEnabled:editing];
        [self.addressTwoField setUserInteractionEnabled:editing];
        [self.cityField setUserInteractionEnabled:editing];
        [self.zipField setUserInteractionEnabled:editing];
        [self.statePicker setUserInteractionEnabled:editing && (!self.consumer.wasFeedGenerated || ![AWSDKSystemConfiguration isPropertyProtected:kProtectedAddress])];

        [self.tableView reloadDataAnimated:YES];
    };

    if (!editing && self.requiresUpdate) {
        [self.view endEditing:YES];

        [MBProgressHUD showUpdatingOn:self.view];
        [self.errorService clearErrors];
        [self updateDemographics:^(id<AWSDKConsumer> result, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view];
            [self.errorService handleError:error];
            if (result) {
                self.consumer = result;
                successBlock();
                if (!self.editingCurrentUser) {
                    //  We need to update the Consumer so we get a new list of dependents. This lets the home page drop down show the newly edited version of the dependent instead of her old value.
                    [[ConsumerService sharedInstance] refreshConsumerWithCompletion:^(BOOL success, id<AWSDKConsumer> _Nullable result) {
                        self.consumer = [result.dependents
                            filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(id<AWSDKConsumer> _Nullable evaluatedObject, NSDictionary<NSString *, id> *bindings) {
                                return [evaluatedObject isEqual:self.consumer];
                            }]].firstObject;
                    }];
                } else {
                    ConsumerService.sharedInstance.consumer = result;
                }
            }
        }];

    } else {
        successBlock();
    }
}

#pragma mark - UITableViewDataSource
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleNone;
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == UserSection) {
        return NSLocalizedString(@"demographics.user", @"table section - User");
    } else if (section == AccountSection) {
        return (!self.consumer.isDependent) ? NSLocalizedString(@"demographics.account", @"table section - Account") : nil;
    } else if (section == AddressSection) {
        return (!self.consumer.isDependent && [AWSDKEnrollmentService isConsumerAddressRequired]) ? NSLocalizedString(@"demographics.primaryAddress", @"table section - Address") : nil;
    }
    return nil;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.consumer.isDependent ? 1 : 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == UserSection) {
        return UserRowCount;
    } else if (section == AccountSection) {
        return 8;
    } else if (section == AddressSection) {
        return [AWSDKEnrollmentService isConsumerAddressRequired] ? 6 : 0;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return [self heightForHeaderFooterInSection:section];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return [self heightForHeaderFooterInSection:section];
}

- (CGFloat)heightForHeaderFooterInSection:(NSInteger)section {
    // UserSection
    if (section == UserSection) {
        return UITableViewAutomaticDimension;
        // AccountSection
    } else if (section == AccountSection) {
        return (!self.consumer.isDependent) ? UITableViewAutomaticDimension : CGFLOAT_MIN;
        // AddressSection
    } else if (section == AddressSection) {
        return (!self.consumer.isDependent && [AWSDKEnrollmentService isConsumerAddressRequired]) ? UITableViewAutomaticDimension : CGFLOAT_MIN;
    }
    return CGFLOAT_MIN;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = nil;

    switch (indexPath.section) {
        case UserSection: {
            if (indexPath.row == UserFirstNameIndexRow) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"firstName" forIndexPath:indexPath];
                if (!self.firstNameField) {
                    [self setFirstNameField:((FieldTableViewCell *)cell).textField];
                    [self.firstNameField setText:self.consumer.nameComponents.givenName];
                    // Protected Field check
                    if (self.consumer.wasFeedGenerated && [AWSDKSystemConfiguration isPropertyProtected:kProtectedFirstName]) {
                        [self.firstNameField setTextColor:[UIColor lightGrayColor]];
                        [self.firstNameField setTag:Protected];
                    } else {
                        [self.firstNameField setTextColor:[UIColor darkTextColor]];
                        [self.firstNameField setTag:UnProtected];
                    }
                }
            } else if (indexPath.row == UserMiddleInitialIndexRow) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"middleInitial" forIndexPath:indexPath];
                ((FieldTableViewCell *)cell).textField.placeholder = AWSDKSystemConfiguration.middleNameHandling == AWSDKConsumerMiddleNameHandlingInitial
                    ? NSLocalizedString(@"enrollment.middleName", @"Enrollment Middle Initial")
                    : NSLocalizedString(@"enrollment.fullMiddleName", @"Middle Name");
                if (!self.middleInitialField) {
                    [self setMiddleInitialField:((FieldTableViewCell *)cell).textField];
                    self.middleInitialField.text = AWSDKSystemConfiguration.middleNameHandling == AWSDKConsumerMiddleNameHandlingInitial ? [self.consumer.nameComponents.middleName substringToIndex:1]
                                                                                                                                         : self.consumer.nameComponents.middleName;
                    // Protected Field check
                    if (self.consumer.wasFeedGenerated && [AWSDKSystemConfiguration isPropertyProtected:kProtectedMiddleInitial]) {
                        [self.middleInitialField setTextColor:[UIColor lightGrayColor]];
                        [self.middleInitialField setTag:Protected];
                    } else {
                        [self.middleInitialField setTextColor:[UIColor darkTextColor]];
                        [self.middleInitialField setTag:UnProtected];
                    }
                }
            } else if (indexPath.row == UserLastNameIndexRow) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"lastName" forIndexPath:indexPath];
                if (!self.lastNameField) {
                    [self setLastNameField:((FieldTableViewCell *)cell).textField];
                    [self.lastNameField setText:self.consumer.nameComponents.familyName];
                    // Protected Field check
                    if (self.consumer.wasFeedGenerated && [AWSDKSystemConfiguration isPropertyProtected:kProtectedLastName]) {
                        [self.lastNameField setTextColor:[UIColor lightGrayColor]];
                        [self.lastNameField setTag:Protected];
                    } else {
                        [self.lastNameField setTextColor:[UIColor darkTextColor]];
                        [self.lastNameField setTag:UnProtected];
                    }
                }
            } else if (indexPath.row == UserGenderIdentityIndexRow) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"genderIdentity" forIndexPath:indexPath];
                if (!self.genderIdentityPicker) {
                    self.genderIdentityPicker = ((PickerTableViewCell *)cell).picker;
                    [self.genderIdentityPicker reloadAllComponents];
                    if (self.consumer.genderIdentity != nil) {
                        [self.genderIdentityPicker selectRow:[self.genderIdentities indexOfObjectPassingTest:^BOOL(id<AWSDKGenderIdentity> _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            return [obj.key isEqualToString:self.consumer.genderIdentity.key];
                        }] inComponent:0 animated:NO];
                    }
                    [self.genderIdentityPicker setTag:self.consumer.wasFeedGenerated && [AWSDKSystemConfiguration isPropertyProtected:kProtectedGenderIdentity] ? Protected : UnProtected];
                }
            } else if (indexPath.row == UserGenderIndexRow) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"gender" forIndexPath:indexPath];
                if (!self.sexPicker) {
                    [self setSexPicker:((PickerTableViewCell *)cell).picker];
                    [self.sexPicker reloadAllComponents];
                    if (self.consumer.gender != AWSDKBiologicalSexNotSet) {
                        [self.sexPicker selectRow:[self.sexes indexOfObject:@(self.consumer.gender)] inComponent:0 animated:NO];
                    }
                    [self.sexPicker setTag:self.consumer.wasFeedGenerated && [AWSDKSystemConfiguration isPropertyProtected:kProtectedGender] ? Protected : UnProtected];
                }
            } else if (indexPath.row == UserDateOfBirthRow) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"dateOfBirth" forIndexPath:indexPath];
                if (!self.datePicker) {
                    [self setDatePicker:((DatePickerCell *)cell).datePicker];
                    [self.datePicker setMaximumDate:[NSDate date]];
                    self.datePicker.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
                    self.datePicker.date = self.consumer.dateOfBirth;
                    if (self.consumer.wasFeedGenerated && [AWSDKSystemConfiguration isPropertyProtected:kProtectedDateOfBirth]) {
                        [self.datePicker setTag:Protected];
                        [self.datePicker setValue:[UIColor lightGrayColor] forKey:@"textColor"];
                    } else {
                        [self.datePicker setTag:UnProtected];
                        [self.datePicker setValue:[UIColor darkTextColor] forKey:@"textColor"];
                    }
                }
            }
            break;
        }
        case AccountSection: {
            if (indexPath.row == 0) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"email"];
                if (!self.emailField) {
                    [self setEmailField:((FieldTableViewCell *)cell).textField];
                    [self.emailField setText:self.consumer.email];
                }
            } else if (indexPath.row == 1) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"confirmEmailCell"];
                if (!self.confirmEmailField) {
                    [self setConfirmEmailField:((FieldTableViewCell *)cell).textField];
                    [self.confirmEmailField setText:self.consumer.email];
                }

            } else if (indexPath.row == AccountPasswordHints) {
                // Special treatment for password hints.  Need a dynamic cell
                if (!self.passwordHintCell && self.isEditingPassword) {
                    self.passwordHintCell = (PasswordHintsCell *)[tableView dequeueReusableCellWithIdentifier:@"RealPasswordHintCell" forIndexPath:indexPath];
                }
                if (self.isEditingPassword && [self.passwordHintCell passwordHintsSupported] && self.shouldShowHints) {
                    return self.passwordHintCell;
                }
            } else if (indexPath.row == 3) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"password"];
                if (!self.passwordField) {
                    [self setPasswordField:((FieldTableViewCell *)cell).textField];
                    [self.passwordField setText:hiddenPassword];
                }
            } else if (indexPath.row == 4) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"phoneNumber"];
                if (!self.phoneField) {
                    [self setPhoneField:((FieldTableViewCell *)cell).textField];
                    [self.phoneField setText:self.consumer.phoneNumber];
                }
            } else if (indexPath.row == 5) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"preferredLocale"];
                if (!self.localePicker) {
                    self.localePicker = ((PickerTableViewCell *)cell).picker;
                    [self.localePicker reloadAllComponents];
                    if (self.consumer.preferredLocale) {
                        NSInteger index = [self.supportedLocales indexOfObject:self.consumer.preferredLocale];

                        if (index == NSNotFound) {
                            index = 0; // we always have 1 locale
                        }
                        [self.localePicker selectRow:index inComponent:0 animated:NO];
                    } else {
                        [self.localePicker selectRow:0 inComponent:0 animated:NO];
                    }
                }
            }

            else if (indexPath.row == 6) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"countryOfLegalResidence"];
                if (!self.currentCountryPicker) {
                    self.currentCountryPicker = ((PickerTableViewCell *)cell).picker;
                    [self.currentCountryPicker reloadAllComponents];
                    if (self.consumer.countryOfLegalResidence) {
                        NSInteger index = [self.countries indexOfObject:self.consumer.countryOfLegalResidence];
                        [self.currentCountryPicker selectRow:index inComponent:0 animated:NO];
                    }
                }
            } else if (indexPath.row == 7) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"stateOfLegalResidence"];
                if (!self.currentStatePicker) {
                    [self setCurrentStatePicker:((PickerTableViewCell *)cell).picker];
                    [self.currentStatePicker reloadAllComponents];
                    if (self.consumer.stateOfLegalResidence) {
                        NSInteger index = [[self selectedCurrentCountry].enrollmentStates indexOfObject:self.consumer.stateOfLegalResidence];
                        if (index == NSNotFound) {
                            [self initializeCurrentCountryPicker];
                            index = [[self selectedCurrentCountry].enrollmentStates indexOfObject:self.consumer.stateOfLegalResidence];
                        }
                        [self.currentStatePicker selectRow:index inComponent:0 animated:NO];
                    }
                }
            }
            break;
        }
        case AddressSection: {
            if (indexPath.row == AddressCountryIndexRow) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"country"];
                if (!self.countryPicker) {
                    self.countryPicker = ((PickerTableViewCell *)cell).picker;
                    [self.countryPicker reloadAllComponents];
                    if (self.consumer.address.country) {
                        NSInteger index = [self.countries indexOfObject:self.consumer.address.country];
                        [self.countryPicker selectRow:index inComponent:0 animated:NO];
                    }
                    [self.countryPicker setTag:self.consumer.wasFeedGenerated && [AWSDKSystemConfiguration isPropertyProtected:kProtectedAddress] ? Protected : UnProtected];
                }
            } else if (indexPath.row == 1) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"addressOne"];
                if (!self.addressOneField) {
                    [self setAddressOneField:((FieldTableViewCell *)cell).textField];
                    [self.addressOneField setText:self.consumer.address.addressOne];
                }
            } else if (indexPath.row == 2) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"addressTwo"];
                if (!self.addressTwoField) {
                    [self setAddressTwoField:((FieldTableViewCell *)cell).textField];
                    [self.addressTwoField setText:self.consumer.address.addressTwo];
                }
            } else if (indexPath.row == AddressCityIndexRow) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"city"];
                if (!self.cityField) {
                    [self setCityField:((FieldTableViewCell *)cell).textField];
                    [self.cityField setText:self.consumer.address.city];
                }
            } else if (indexPath.row == 4) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"state"];
                if (!self.statePicker) {
                    [self setStatePicker:((PickerTableViewCell *)cell).picker];
                    [self.statePicker reloadAllComponents];
                    if (self.consumer.address.state) {
                        NSInteger index = [[self selectedAddressCountry].states indexOfObject:self.consumer.address.state];
                        if (index == NSNotFound) {
                            [self initializeAddressCountryPicker];
                            index = [[self selectedAddressCountry].states indexOfObject:self.consumer.address.state];
                        }
                        [self.statePicker selectRow:index inComponent:0 animated:NO];
                    }
                    [self.statePicker setTag:self.consumer.wasFeedGenerated && [AWSDKSystemConfiguration isPropertyProtected:kProtectedAddress] ? Protected : UnProtected];
                }
            } else if (indexPath.row == 5) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"zip"];
                if (!self.zipField) {
                    [self setZipField:((FieldTableViewCell *)cell).textField];
                    [self.zipField setText:self.consumer.address.zip];
                }
            }
            if ([cell isKindOfClass:[FieldTableViewCell class]]) {
                UITextField *field = ((FieldTableViewCell *)cell).textField;
                if (self.consumer.wasFeedGenerated && [AWSDKSystemConfiguration isPropertyProtected:kProtectedAddress]) {
                    [field setTag:Protected];
                    [field setTextColor:[UIColor lightGrayColor]];
                } else {
                    [field setTag:UnProtected];
                    [field setTextColor:[UIColor darkGrayColor]];
                }
            }
            break;
        }
    }

    cell = cell ?: [[UITableViewCell alloc] initWithFrame:CGRectZero];

    if ([cell isKindOfClass:[FieldTableViewCell class]]) {
        [((FieldTableViewCell *)cell).textField setUserInteractionEnabled:tableView.editing];
    } else if ([cell isKindOfClass:[PickerTableViewCell class]]) {
        [((PickerTableViewCell *)cell).picker setUserInteractionEnabled:tableView.editing];
    }
    if (cell.reuseIdentifier) {
        [self.errorService addObserver:cell forKeyPath:cell.reuseIdentifier];
    }

    return cell;
}

// There are rare cases where cells may render out of order.
// Since some of our cells have dependencies on lazily loaded properties initialized by other cells, we will have to force their initialization

- (void)initializeCurrentCountryPicker {
    NSIndexPath *currentCountryIndexPath = [NSIndexPath indexPathForRow:6 inSection:AccountSection];
    AWSDKLogDebug(@"Lazily initializing currentCountry cell");
    [self tableView:self.tableView cellForRowAtIndexPath:currentCountryIndexPath];
}

- (void)initializeAddressCountryPicker {
    NSIndexPath *addressCountryIndexPath = [NSIndexPath indexPathForRow:AddressCountryIndexRow inSection:AddressSection];
    AWSDKLogDebug(@"Lazily initializing addressCountry cell");
    [self tableView:self.tableView cellForRowAtIndexPath:addressCountryIndexPath];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSUInteger section = indexPath.section;
    NSUInteger row = indexPath.row;
    CGFloat height = UITableViewAutomaticDimension;

    if (section == UserSection) {
        if (row == UserMiddleInitialIndexRow) {
            height = ([AWSDKEnrollmentService isConsumerMiddleInitialCollected]) ? UITableViewAutomaticDimension : CGFLOAT_MIN;
        } else if (row == UserGenderIdentityIndexRow) {
            height = AWSDKSystemConfiguration.isExtensibleGenderSupportEnabled ? StandardTableRowHeight : CGFLOAT_MIN;
        } else if (row == UserGenderIndexRow) {
            height = StandardTableRowHeight;
        } else if (row == UserDateOfBirthRow) {
            height = DoubleTableRowHeight;
        }
    } else if (section == AccountSection) {
        if (row == AccountConfirmEmailFieldIndexRow) {
            height = (self.tableView.isEditing) ? UITableViewAutomaticDimension : CGFLOAT_MIN;
        } else if (row == AccountPasswordHints) {
            if (self.isEditingPassword && [self.passwordHintCell passwordHintsSupported] && self.shouldShowHints) {
                return UITableViewAutomaticDimension;
            }
            return CGFLOAT_MIN;
        } else if (row == AccountCountryOfLegalResidenceIndexRow) {
            height = (AWSDKSystemConfiguration.isMultiCountry) ? DoubleTableRowHeight : CGFLOAT_MIN;
        } else if (row == AccountPreferredLocaleIndexRow) {
            height = self.supportedLocales.count == 1 ? CGFLOAT_MIN : DoubleTableRowHeight;
        }
    } else if (section == AddressSection) {
        if (row == AddressCountryIndexRow) {
            height = (AWSDKSystemConfiguration.isMultiCountry) ? UITableViewAutomaticDimension : CGFLOAT_MIN;
        } else if (row == AddressCityIndexRow) {
            height = DoubleTableRowHeight;
        }
    }

    return height;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return EstimatedTableRowHeight;
}

#pragma mark - ScrollViewDelegate
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    CGPoint translation = [scrollView.panGestureRecognizer translationInView:scrollView.superview];

    if (translation.y > 0)
        [self dismissKeyboard];
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (pickerView == self.sexPicker) {
        return self.sexes.count;
    } else if (pickerView == self.genderIdentityPicker) {
        return self.genderIdentities.count + (self.showUnselectedGender ? 1 : 0);
    } else if (pickerView == self.currentStatePicker) {
        return [self selectedCurrentCountry].enrollmentStates.count;
    } else if (pickerView == self.statePicker) {
        return [self selectedAddressCountry].states.count;
    } else if (pickerView == self.localePicker) {
        return self.supportedLocales.count;
    } else {
        return self.countries.count;
    }
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *label = (UILabel *)view;
    if (!label) {
        label = [[UILabel alloc] init];
        [label setFont:[UIFont systemFontOfSize:19.0 weight:UIFontWeightLight]];
        [label setTextAlignment:NSTextAlignmentNatural];
        [label setAdjustsFontSizeToFitWidth:YES];
        [label setNumberOfLines:0];
        [label setTextColor:pickerView.tag == Protected ? [UIColor lightGrayColor] : [UIColor darkTextColor]];
    }
    // Set Text
    NSString *text = @"";
    if (pickerView == self.sexPicker) {
        text = self.sexStrings[self.sexes[row]];
    } else if (pickerView == self.genderIdentityPicker) {
        if (self.showUnselectedGender) {
            if (row == 0) {
                text = @"";
            } else {
                text = self.genderIdentities[row - 1].name;
            }
        } else {
            text = self.genderIdentities[row].name;
        }
    } else if (pickerView == self.currentStatePicker) {
        text = [self selectedCurrentCountry].enrollmentStates[row].name;
    } else if (pickerView == self.statePicker) {
        text = [self selectedAddressCountry].states[row].name;
    } else if (pickerView == self.localePicker) {
        NSLocale *tempLocale = self.supportedLocales[row];
        NSString *localeIdentifier = tempLocale.localeIdentifier;
        text = [tempLocale displayNameForKey:NSLocaleIdentifier value:localeIdentifier];
    } else {
        text = self.countries[row].name;
    }

    [label setText:text];
    return label;
}
#pragma mark - UIPickerViewDelegate
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    NSString *text = @"UNKNOWN";
    NSString *pickerName = @"UNKNOWN";
    if (pickerView == self.sexPicker) {
        text = self.sexStrings[self.sexes[row]];
        pickerName = @"sex";
    } else if (pickerView == self.genderIdentityPicker) {
        if (self.showUnselectedGender) {
            if (row == 0) {
                text = @"";
            } else {
                text = self.genderIdentities[row - 1].name;
            }
        } else {
            text = self.genderIdentities[row].name;
        }
        pickerName = @"gender identity";
    } else if (pickerView == self.currentStatePicker) {
        text = [self selectedCurrentCountry].enrollmentStates[row].name;
        pickerName = @"current state";
    } else if (pickerView == self.statePicker) {
        text = [self selectedAddressCountry].states[row].name;
        pickerName = @"address state";
    } else if (pickerView == self.currentCountryPicker) {
        text = self.countries[row].name;
        pickerName = @"country";
        [self.currentStatePicker selectRow:0 inComponent:0 animated:NO];
        [self.currentStatePicker reloadAllComponents];
    } else if (pickerView == self.localePicker) {
        NSLocale *tempLocale = self.supportedLocales[row];
        NSString *localeIdentifier = tempLocale.localeIdentifier;
        text = [tempLocale displayNameForKey:NSLocaleIdentifier value:localeIdentifier];
        pickerName = @"locale";

    } else if (pickerView == self.countryPicker) {
        text = self.countries[row].name;
        pickerName = @"addressCountry";
        [self.statePicker selectRow:0 inComponent:0 animated:NO];
        [self.statePicker reloadAllComponents];
    }
    AWSDKLogInfo(@"Selected %@ in %@ picker", text, pickerName);
    [self setRequiresUpdate:YES];
    [self dismissKeyboard];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if (textField.tag == Protected) {
        [self displayProtectedMessage];
        return NO;
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == self.firstNameField && [AWSDKEnrollmentService isConsumerMiddleInitialCollected]) {
        [self.middleInitialField becomeFirstResponder];
    } else if (textField == self.middleInitialField || textField == self.middleInitialField) {
        [self.lastNameField becomeFirstResponder];
    } else if (textField == self.emailField) {
        [self.confirmEmailField becomeFirstResponder];
    } else if (textField == self.confirmEmailField) {
        [self.passwordField becomeFirstResponder];
    } else {
        [textField resignFirstResponder];
    }
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (textField == self.passwordField) {
        self.isEditingPassword = YES;
        if (!self.shouldShowHints) {
            [self showHints:YES];
        }
    }
    [self setRequiresUpdate:YES];
}

- (void)showHints:(BOOL)show {
    self.shouldShowHints = show;
    [self.tableView beginUpdates];
    if (self.passwordField.text.length == 0) {
        [self.passwordHintCell setHintIconsToInitialState];
    }
    [self.tableView reloadRowsAtIndexPaths:@[ [NSIndexPath indexPathForRow:AccountPasswordHints inSection:AccountSection] ] withRowAnimation:UITableViewRowAnimationNone];
    [self.tableView endUpdates];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    // Max character limit
    NSUInteger oldLength = [textField.text length];
    NSUInteger replacementLength = [string length];
    NSUInteger rangeLength = range.length;

    NSUInteger newLength = oldLength - rangeLength + replacementLength;

    if (textField == self.passwordField) {
        NSString *newPassword = [textField.text stringByReplacingCharactersInRange:range withString:string];
        if (![textField.text isEqualToString:hiddenPassword]) {
            [self.passwordHintCell checkPasswordAgainstCriteria:newPassword];
        }

    } else if (textField == self.middleInitialField) {
        return AWSDKSystemConfiguration.middleNameHandling == AWSDKConsumerMiddleNameHandlingFullName ? YES : newLength <= 1;
    }
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    textField.text = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    AWSDKLogInfo(@"'%@' textField editing ended with value: %@", textField.placeholder, textField.text);
    if (textField == self.passwordField) {
        self.isEditingPassword = NO;
        [self showHints:NO];
    }
}

#pragma mark - IBActions
- (IBAction)datePickerChanged:(id)sender {
    UIDatePicker *picker = sender;
    AWSDKLogInfo(@"Selected %@ in date picker", picker.date);
    [self setRequiresUpdate:YES];
    [self dismissKeyboard];
}

- (void)displayProtectedMessage {
    [self presentAlertWithMessageKey:@"demographics.protected.message" okHandler:nil];
}

@end
