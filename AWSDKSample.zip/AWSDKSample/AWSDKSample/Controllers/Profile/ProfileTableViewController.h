//
//  ProfileTableViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 5/13/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface ProfileTableViewController : UITableViewController

@end
