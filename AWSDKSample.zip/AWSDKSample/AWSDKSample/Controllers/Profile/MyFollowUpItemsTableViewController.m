//
//  MyFollowUpItemsTableViewController.m
//  AWSDKSample
//
//  Created by Caleb Lindsey on 6/1/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "DropDownTableViewCell.h"
#import "FollowUpItemTableViewCell.h"
#import "MyFollowUpItemsTableViewController.h"
#import "NSDateFormatter+CommonFormats.h"
#import "UITableView+Sample.h"
#import "VisitReportPDFViewController.h"

#import <AWSDKSample-Swift.h>
#import <AWSDK/AWSDKFollowUpItemSearchRequest.h>
#import <Foundation/Foundation.h>

/**
 *  Displays a menu for filtering a consumer's follow-up items
 */
@interface MyFollowUpItemsTableViewController ()

@property (nonatomic) AWSDKFollowUpItemTypeFilter currentFilter;
@property (nonatomic) EmptyContentView *emptyView;
@property (nonatomic) NSArray<NSString *> *filterArray;
@property (nonatomic, nullable) NSArray<id<AWSDKFollowUpItem>> *followUpItems;
@property (nonatomic) BOOL isExpanded;
@property (nonatomic, nullable) id<AWSDKPaginatedFollowUpItems> paginatedFollowUpItems;
@property (nonatomic, weak) IBOutlet UIButton *loadMoreButton;

@end

@implementation MyFollowUpItemsTableViewController

#pragma mark - AWSDKMethodCalls
- (void)fetchDocumentsAndClearPrevious:(BOOL)clearResults {
    __weak typeof(self) weakSelf = self;
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    [MBProgressHUD showLoadingOn:self.view];
    
    id<AWSDKFollowUpItemSearchRequest> thisRequest;
    if (clearResults) {
        thisRequest = [[FollowUpItemSearchRequest alloc] initWithTypeFilter:self.currentFilter];
    } else {
        thisRequest = self.paginatedFollowUpItems.nextPage;
    }

    BOOL shouldAppendItems = self.paginatedFollowUpItems.nextPage;

    [consumer fetchPaginatedFollowUpItems:thisRequest completion:^(id<AWSDKPaginatedFollowUpItems> _Nullable paginatedFollowUpItems, NSError * _Nullable error) {
        [MBProgressHUD hideHUDForView:self.view];

        if (paginatedFollowUpItems) {
            if (clearResults) {
                weakSelf.followUpItems = paginatedFollowUpItems.list;
            } else if (shouldAppendItems) {
                weakSelf.followUpItems = [weakSelf.followUpItems arrayByAddingObjectsFromArray:paginatedFollowUpItems.list];
            }

            weakSelf.paginatedFollowUpItems = paginatedFollowUpItems;

            weakSelf.isExpanded = NO;
            weakSelf.emptyView.alpha = weakSelf.isEmpty ? 1.0 : 0.0;
            [weakSelf.loadMoreButton setHidden:paginatedFollowUpItems.nextPage == nil];

            [weakSelf.tableView reloadDataAnimated:YES];
        } else if (error) {
            [weakSelf presentAlertWithError:error okHandler:nil];
        }
    }];
}

- (void)showFollowUpItemPDF:(id<AWSDKFollowUpItem>)followUpItem
{
    [MBProgressHUD showLoadingOn:self.view];

    __weak typeof(self) weakSelf = self;
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    [followUpItem getPDF:consumer completion:^(NSData * _Nullable data, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:weakSelf.view];

            if (data) {
                [weakSelf performSegueWithIdentifier:@"pDFSegue" sender:data];
            } else if (error) {
                [weakSelf presentAlertWithError:error okHandler:nil];
            }
        });
    }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything below here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad
{
    [super viewDidLoad];

    self.tableView.estimatedRowHeight = 70;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.backgroundColor = UIColor.bkgdGreyColor;
    self.tableView.tintColor = UIColor.aquaColor;

    UIImage *emptyImage = [UIImage imageNamed:@"noHealthDocuments"];
    self.emptyView = [[EmptyContentView alloc] initWithImage: emptyImage message:NSLocalizedString(@"healthDocuments.empty", @"Health Documents empty") buttonTitle:nil];
    self.emptyView.alpha = 0;
    self.tableView.backgroundView = self.emptyView;
    
    self.filterArray = @[@"all", @"referral", @"visitReferral", @"labReferral", @"imagingReferral", @"sickSlip"];
    self.currentFilter = AWSDKFollowUpItemTypeFilterAll;

    [self fetchDocumentsAndClearPrevious:YES];
}

#pragma mark - Private Methods
- (NSString *)titleForFilterString:(NSString *)filter
{
    if ([filter isEqualToString:@"imagingReferral"]) {
        return [self titleForFilter:AWSDKFollowUpItemTypeFilterImagingReferral];
    } else if ([filter isEqualToString:@"labReferral"]) {
        return [self titleForFilter:AWSDKFollowUpItemTypeFilterLabReferral];
    } else if ([filter isEqualToString:@"visitReferral"]) {
           return [self titleForFilter:AWSDKFollowUpItemTypeFilterVisitReferral];
    } else if ([filter isEqualToString:@"referral"]) {
        return [self titleForFilter:AWSDKFollowUpItemTypeFilterReferral];
    } else if ([filter isEqualToString:@"sickSlip"]) {
        return [self titleForFilter:AWSDKFollowUpItemTypeFilterSickSlip];
    } else {
        return [self titleForFilter:AWSDKFollowUpItemTypeFilterAll];
    }
}

- (NSString *)titleForFilter:(AWSDKFollowUpItemTypeFilter)filter
{
    if (filter == AWSDKFollowUpItemTypeFilterImagingReferral) {
        return NSLocalizedString(@"followUp.type.imagingReferral", @"Filter by Follow-Up item type Imaging Referral");
    } else if (filter == AWSDKFollowUpItemTypeFilterLabReferral) {
        return NSLocalizedString(@"followUp.type.labReferral", @"Filter by Follow-Up item type Lab Referral");
    } else if (filter == AWSDKFollowUpItemTypeFilterReferral) {
        return NSLocalizedString(@"followUp.type.referral", @"Filter by Follow-Up item type Referral");
    } else if (filter == AWSDKFollowUpItemTypeFilterVisitReferral) {
           return NSLocalizedString(@"followUp.type.visitReferral", @"Filter by Follow-Up item type Visit Referral");
    } else if (filter == AWSDKFollowUpItemTypeFilterSickSlip) {
        return NSLocalizedString(@"followUp.type.sickSlip", @"Filter by Follow-Up item type Sick Slip");
    } else {
        return NSLocalizedString(@"followUp.type.all", @"Filter by Follow-Up item type all");
    }
}

- (BOOL)isEmpty
{
    return self.followUpItems.count == 0;
}

#pragma mark - UITableViewDataSource
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        DocumentsHeaderView *headerView = [[DocumentsHeaderView alloc] initWithTitle:NSLocalizedString(@"followUp.filterSection", @"Title for follow-up filter type section")];
        headerView.backgroundColor = UIColor.bkgdGreyColor;
        return headerView;
    }

    return [[UIView alloc] init];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 50.0;
    }

    return 32.0;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return (self.isEmpty && self.currentFilter == AWSDKFollowUpItemTypeFilterAll) ? 0 : 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            DropDownTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"myDocumentsSelectCell" forIndexPath:indexPath];
            cell.filterLabel.text = [self titleForFilter:self.currentFilter];
            cell.dividerView.alpha = self.isExpanded ? 0.0 : 1.0;
            return cell;
        } else {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"filterCell" forIndexPath:indexPath];
            BOOL isSelected = self.currentFilter == [FollowUpItemSearchRequest filterFromString:self.filterArray[indexPath.row - 1]];
            cell.textLabel.text = [self titleForFilterString:self.filterArray[indexPath.row - 1]];
            cell.accessoryType = isSelected ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
            return cell;
        }
    } else {
        FollowUpItemTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"myDocumentsCell" forIndexPath:indexPath];
        cell.title.text = self.followUpItems[indexPath.row].itemDescription;
        cell.dateLabel.text = [[NSDateFormatter longDateMonthDayTimeFormatter] stringFromDate:self.followUpItems[indexPath.row].createdDate];
        return cell;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        if (self.isExpanded) {
            return self.filterArray.count + 1;
        } else {
            return 1;
        }
    } else {
        return self.followUpItems.count;
    }
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            self.isExpanded = !self.isExpanded;

            NSRange range = NSMakeRange(0, 1);
            NSIndexSet *section = [NSIndexSet indexSetWithIndexesInRange:range];
            [self.tableView reloadSections:section withRowAnimation:UITableViewRowAnimationAutomatic];
        } else {
            self.currentFilter = [FollowUpItemSearchRequest filterFromString:self.filterArray[indexPath.row - 1]];
            [self fetchDocumentsAndClearPrevious:YES];
        }
    } else {
        id<AWSDKFollowUpItem> followUpItem = self.followUpItems[indexPath.row];
        [self showFollowUpItemPDF:followUpItem];
    }

    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - IBActions
- (IBAction)loadMoreDocumentsPressed:(UIButton *)sender {
    [self fetchDocumentsAndClearPrevious:NO];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"pDFSegue"]) {
        VisitReportPDFViewController *controller = segue.destinationViewController;
        [controller setPDFData:sender];
    }
}

@end
