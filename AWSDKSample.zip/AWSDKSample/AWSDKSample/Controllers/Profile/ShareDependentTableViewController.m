//
//  ShareDependentTableViewController.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 4/5/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ShareDependentTableViewController.h"

#import "DependentTableViewCell.h"
#import "NSDateFormatter+CommonFormats.h"
#import "NSPersonNameComponents+Localizing.h"
#import "SectionHeaderTableViewCell.h"
#import "ShareChildGrantTableViewCell.h"
#import "ShareChildMessageTableViewCell.h"
#import "ShareChildSelectTableViewCell.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKDependentEnrollmentForm.h>
#import <AWSDK/AWSDKEnrollmentService.h>

@interface ShareDependentTableViewController ()

typedef NS_ENUM(NSUInteger, ShareDependentSection) { HeaderSection = 0, DependentSection, GrantSection };

#pragma mark - IBOutlets
@property (weak, nonatomic) IBOutlet UIBarButtonItem *rightButton;

#pragma mark Grant Access
@property (weak, nonatomic) IBOutlet UILabel *linkRequestMessageLabel;
@property (weak, nonatomic) IBOutlet UILabel *linkDisclaimerMessageLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *dontGrantAccessButtonHeightConstraint;

@property (nonatomic) NSMutableIndexSet *rowSelectionIndexSet;

@end

@implementation ShareDependentTableViewController

#pragma mark - View Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];

    [self checkRequestForDependentAccess];

    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    if (![consumer canAddDependent]) {
        self.navigationItem.rightBarButtonItem = nil;
    }

    self.navigationItem.title = NSLocalizedString(@"dependent.shareAccess.title", @"Share Title");

    // Disable and hide right button
    self.rightButton.enabled = NO;
    self.rightButton.tintColor = [UIColor clearColor];

    self.rowSelectionIndexSet = [NSMutableIndexSet new];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkRequestForDependentAccess) name:ConsumerUpdatedNotification object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - TableView Data Source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == DependentSection) {
        return (self.dependentAccessRequest.dependents.count) ?: 1;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *memberName = self.dependentAccessRequest.requestor.nameComponents.localizedFullName;
    if (indexPath.section == HeaderSection) {
        ShareChildMessageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"headerMessageCell" forIndexPath:indexPath];
        NSString *message = [NSString stringWithFormat:NSLocalizedString(@"dependents.shareAccessMessage.title", @"Share Dependent Message"), memberName, memberName];
        cell.messageLabel.text = message;
        return cell;
    } else if (indexPath.section == DependentSection) {
        if (self.dependentAccessRequest.dependents.count) {
            ShareChildSelectTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"selectDependentCell" forIndexPath:indexPath];
            cell.nameLabel.text = self.dependentAccessRequest.dependents[indexPath.row].nameComponents.localizedFullName;
            cell.dobLabel.text = [NSString stringWithFormat:NSLocalizedString(@"enrollment.dateOfBirth.title", @"Enrollment Date of Birth Title"),
                                           [NSDateFormatter.longerDateFormatter stringFromDate:self.dependentAccessRequest.dependents[indexPath.row].dateOfBirth]];
            cell.checkButton.selected = [self.rowSelectionIndexSet containsIndex:indexPath.row];
            cell.checkButton.tag = indexPath.row;
            [cell.checkButton addTarget:self action:@selector(checkButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
            cell.separator.backgroundColor = (indexPath.row > 0) ? [UIColor lightGrayColor] : [UIColor clearColor];
            return cell;
        } else {
            UITableViewCell *cell = [UITableViewCell new];
            return cell;
        }
    } else if (indexPath.section == GrantSection) {
        ShareChildGrantTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"grantDenyAccessCell" forIndexPath:indexPath];
        NSString *message = [NSString stringWithFormat:NSLocalizedString(@"dependents.shareAccessDisclaimer.title", @"Share Dependent Disclaimer"), memberName, memberName, memberName];
        cell.messageLabel.text = message;
        [cell.grantAccessButton addTarget:self action:@selector(grantAccessButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
        [cell.dontGrantAccessButton addTarget:self action:@selector(dontGrantAccessButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
        return cell;
    }
    return nil;
}

#pragma mark - TableView Delegate

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == DependentSection) {
        SectionHeaderTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"selectDependentHeaderCell"];
        NSString *memberName = self.dependentAccessRequest.requestor.nameComponents.localizedFullName;
        cell.headerLabel.text = [NSString stringWithFormat:NSLocalizedString(@"dependents.shareAccessHeader.title", @"Share Dependent Header"), memberName];
        return cell;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == HeaderSection) {
        return 20.0;
    } else if (section == DependentSection) {
        return 40.0;
    } else if (section == GrantSection) {
        return CGFLOAT_MIN;
    }
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == DependentSection) {
        [self toggleIndex:indexPath.row];
        [tableView reloadDataAnimated:NO];
    }
}

#pragma mark - IBActions

- (IBAction)cancelTapped:(UIBarButtonItem *)button {
    AWSDKLogInfo(@"Cancel button tapped");
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)createButtonTapped:(UIBarButtonItem *)button {
    AWSDKLogInfo(@"Create button tapped");
    [self.view endEditing:YES];
    button.enabled = NO;
}

- (IBAction)checkButtonTapped:(UIButton *)button {
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:button.tag inSection:DependentSection];
    [self tableView:self.tableView didSelectRowAtIndexPath:indexPath];
}

- (IBAction)grantAccessButtonTapped:(UIButton *)button {
    __block NSMutableArray<id<AWSDKConsumer>> *dependents = [NSMutableArray new];
    [self.rowSelectionIndexSet enumerateIndexesUsingBlock:^(NSUInteger idx, BOOL *stop) {
        [dependents addObject:self.dependentAccessRequest.dependents[idx]];
    }];

    __weak typeof(self) weakSelf = self;
    [MBProgressHUD showUpdatingOn:self.view];
    [self.dependentAccessRequest acceptWithGuardian:[[ConsumerService sharedInstance] consumer]
                                         dependents:dependents
                                         completion:^(BOOL success, NSError *error) {
                                             dispatch_async(dispatch_get_main_queue(), ^{
                                                 [MBProgressHUD hideHUDForView:self.view];
                                                 if (error) {
                                                     [weakSelf presentAlertWithError:error
                                                                           okHandler:^(UIAlertAction *action){
                                                                           }];
                                                 } else {
                                                     [[NSNotificationCenter defaultCenter] postNotificationName:ConsumerUpdatedNotification object:[[ConsumerService sharedInstance] consumer]];
                                                     [weakSelf dismissViewControllerAnimated:YES completion:nil];
                                                 }
                                             });
                                         }];
}

- (IBAction)dontGrantAccessButtonTapped:(UIButton *)button {
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD showUpdatingOn:self.view];
    [self.dependentAccessRequest declineWithGuardian:[[ConsumerService sharedInstance] consumer]
                                          completion:^(BOOL success, NSError *error) {
                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                  [MBProgressHUD hideHUDForView:self.view];
                                                  if (error) {
                                                      [weakSelf presentAlertWithError:error
                                                                            okHandler:^(UIAlertAction *action){
                                                                            }];
                                                  } else {
                                                      [weakSelf dismissViewControllerAnimated:YES completion:nil];
                                                  }
                                              });
                                          }];
}

#pragma mark - Private Methods

- (void)checkRequestForDependentAccess {
    // Dependents count already provided by caller
    if (self.dependentAccessRequest) {
        return;
    }
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD showLoadingOn:self.view];
    [[[ConsumerService sharedInstance] consumer] fetchDependentAccessRequestWithCompletion:^(id<AWSDKDependentAccessRequest>  _Nullable dependentAccessRequest, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view];
            [weakSelf.tableView reloadDataAnimated:YES];
        });
    }];
}

- (void)toggleIndex:(NSUInteger)index {
    BOOL contains = [self.rowSelectionIndexSet containsIndex:index];
    if (contains) {
        [self.rowSelectionIndexSet removeIndex:index];
    } else {
        [self.rowSelectionIndexSet addIndex:index];
    }
}

@end
