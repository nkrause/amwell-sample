//
//  DemographicsTableViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 6/9/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface DemographicsTableViewController : UITableViewController

@property (nonatomic) id<AWSDKConsumer> consumer;
@property (nonatomic, assign) BOOL editingCurrentUser;
@end
