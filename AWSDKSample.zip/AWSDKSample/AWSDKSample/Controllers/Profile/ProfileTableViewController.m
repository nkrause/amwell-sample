//
//  ProfileTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/13/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ProfileTableViewController.h"

#import "DemographicsTableViewController.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKConsumerUpdateForm.h>
#import <AWSDK/AWSDKLogService.h>
#import <AWSDK/AWSDKService.h>
#import <AWSDK/AWSDKSystemConfiguration.h>

@interface ProfileTableViewController ()
@property (weak, nonatomic) IBOutlet UISwitch *textReminderSwitch;
@end

/**
 *  Displays the navigation options for Subscription, Pharmacy, Dependents, and Payment Information
 */
@implementation ProfileTableViewController

#pragma mark - AWSDK Method Calls

- (void)viewDidLoad {
    [super viewDidLoad];

    self.textReminderSwitch.on = ConsumerService.sharedInstance.consumer.appointmentReminderTextsEnabled;
}

- (IBAction)switchTapped:(UISwitch *)sender {
    AWSDKLogInfo(@"Text reminders set to %@", sender.isOn ? @"enabled" : @"disabled");
    BOOL previousSwitchState = !sender.isOn;
    sender.enabled = NO;
    // Return if consumer is a dependent
    if (![[ConsumerService sharedInstance] isParent]) {
        return;
    }

    AWSDKConsumerUpdateForm *updateForm = [AWSDKConsumerUpdateForm form];
    updateForm.appointmentReminderTextPreference = sender.isOn ? PreferenceEnabled : PreferenceDisabled;
    [ConsumerService.sharedInstance.consumer updateDemographicsWithForm:updateForm
                                                         withCompletion:^(id _Nullable result, NSError *error) {
                                                             sender.enabled = YES;
                                                             if (error) {
                                                                 AWSDKLogError(@"Error updating text message preference: %@", error);
                                                                 dispatch_async(dispatch_get_main_queue(), ^{
                                                                     [sender setOn:previousSwitchState animated:YES];
                                                                 });
                                                             } else if ([result conformsToProtocol:@protocol(AWSDKConsumer)]) {
                                                                 id<AWSDKConsumer> consumer = (id<AWSDKConsumer>)result;
                                                                 AWSDKLogInfo(@"Consumer text message preference updated to: %@", consumer.appointmentReminderTextsEnabled ? @"enabled" : @"disabled");
                                                             }
                                                         }];
}

/**
 *  Apply a service key to determine which practices are available to them
 *
 *  @param key NSString of consumer key from Alert
 */
- (void)applyServiceKey:(NSString *)key {
    if (key.length) {
        [MBProgressHUD showUpdatingOn:self.view];
        [[[ConsumerService sharedInstance] consumer] applyServiceKey:key
                                                      withCompletion:^(BOOL success, NSError *error) {
                                                          [MBProgressHUD hideHUDForView:self.view];
                                                          if (success) {
                                                              // Refresh HomeCollectionViewController practices
                                                              [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshPractices" object:nil];
                                                          } else if (error) {
                                                              // Handle error
                                                              [self presentAlertWithError:error okHandler:nil];
                                                          }
                                                      }];
    } else {
        [self presentAlertWithTitle:NSLocalizedString(@"services.invalidAlert.title", "Invalid Service Key") message:NSLocalizedString(@"services.nonBlankMessage.title", @"Enter Non Empty Service Key")];
    }
}

//-----------------------------------------------------------------------------------------------------//
//---------------Everything bellow is UI for the sample app, no more API calls here -------------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UITableViewDataSource

/*
   Apply special case rules for displaying or not displaying table rows

   @remark all cases where reuse ID is 'hideForDependent' are not going to appear in the table view.  The one exception is the row at indexPath 0.
*/
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Hide specific cells depending on configuration or a dependent
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];

    // Dependent case
    if (![[ConsumerService sharedInstance] isParent] && ([cell.reuseIdentifier isEqualToString:@"hideForDependent"] && !(indexPath.row == 0))) {
        return 0;
    }
    // Service Key case
    if ([cell.reuseIdentifier isEqualToString:@"serviceKeyCollected"] && !AWSDKSystemConfiguration.isServiceKeyCollected) {
        return 0;
    }
    // Collecting insurance case
    if ([cell.reuseIdentifier isEqualToString:@"insuranceCollected"] && !AWSDKSystemConfiguration.isMemberHealthInsuranceCollected) {
        return 0;
    }

    if ([cell.reuseIdentifier isEqualToString:@"appointmentReadiness"] && !AWSDKSystemConfiguration.isAppointmentReadinessCheckEnabled) {
        return 0;
    }
    return [super tableView:tableView heightForRowAtIndexPath:indexPath];
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];

    AWSDKLogInfo(@"%@ cell tapped", cell.textLabel.text ?: @"Text Reminders");

    // Add Service Key
    if ([cell.reuseIdentifier isEqualToString:@"serviceKeyCollected"]) {
        NSString *alertTitle = NSLocalizedString(@"services.addAlert.title", @"ServiceKey Alert Title");
        NSString *alertMessage = NSLocalizedString(@"services.addAlert.message", @"Blank Space");
        NSString *doneTitle = NSLocalizedString(@"services.addAlert.done", @"ServiceKey Alert Done");
        NSString *cancelTitle = NSLocalizedString(@"services.addAlert.cancel", @"ServiceKey Alert Cancel");

        UIAlertController *addService = [UIAlertController alertControllerWithTitle:alertTitle message:alertMessage preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *done = [UIAlertAction actionWithTitle:doneTitle
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction *_Nonnull action) {
                                                         AWSDKLogInfo(@"Service key done button tapped");
                                                         NSString *key = [[[addService textFields] firstObject] text];
                                                         [self applyServiceKey:key];
                                                     }];

        [addService addTextFieldWithConfigurationHandler:^(UITextField *_Nonnull textField) {
            textField.placeholder = NSLocalizedString(@"services.addAlert.placeholder", @"ServiceKey Alert Placeholder");
        }];

        [addService addAction:done];

        [addService addAction:[UIAlertAction actionWithTitle:cancelTitle
                                                       style:UIAlertActionStyleCancel
                                                     handler:^(UIAlertAction *_Nonnull action) {
                                                         AWSDKLogInfo(@"Service key cancel button tapped");
                                                     }]];

        addService.view.accessibilityIdentifier = @"addServiceKeyAlert";
        addService.textFields.firstObject.accessibilityIdentifier = @"addServiceKeyInputField";

        [self presentViewController:addService animated:YES completion:nil];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"profileSegue"]) {
        AWSDKLogInfo(@"'My Information' row tapped");
        DemographicsTableViewController *demographicsViewController = segue.destinationViewController;
        demographicsViewController.editingCurrentUser = YES;
        demographicsViewController.consumer = ConsumerService.sharedInstance.consumer;
    }
}
@end
