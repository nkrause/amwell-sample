//
//  PharmacySearchViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/17/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKPharmacy;

@protocol PharmacySearchDelegate <NSObject>

/**
 Called when a pharmacy has been selected
 */
- (void)didSelectPharmacy:(id<AWSDKPharmacy>)pharmacy;

@end

@interface PharmacySearchViewController : UIViewController <UISearchBarDelegate, UITableViewDataSource, UITableViewDelegate>

/**
 Notifies when a pharmacy has been selected and updated
 */
@property (nonatomic) id<PharmacySearchDelegate> delegate;

@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;

@property (weak, nonatomic) IBOutlet UITableView *resultsTable;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *cancelButton;
@property (nonatomic) IBOutlet UIBarButtonItem *locationButton;

@end
