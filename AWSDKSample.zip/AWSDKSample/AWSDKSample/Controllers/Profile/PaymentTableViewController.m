//
//  PaymentViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/16/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "PaymentTableViewController.h"

#import "CostTableViewController.h"
#import "FieldTableViewCell.h"
#import "NSDateFormatter+CommonFormats.h"
#import "PickerTableViewCell.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKAddress.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKCountry.h>
#import <AWSDK/AWSDKCreditCardType.h>
#import <AWSDK/AWSDKEnrollmentService.h>
#import <AWSDK/AWSDKPaymentMethod.h>
#import <AWSDK/AWSDKPaymentMethodForm.h>
#import <AWSDK/AWSDKState.h>
#import <AWSDK/AWSDKSystemConfiguration.h>

typedef NS_ENUM(NSUInteger, PaymentSections) { CreditCardSection, BillingAddressSection };

/**
 *  Displays fields prefilled with the consumers current payment method if available.
 *  Entering the edit states allows the fields to update the payment method
 */
@interface PaymentTableViewController () <UITextFieldDelegate>

@property (nonatomic) id<AWSDKPaymentMethod> payment;
@property (nonatomic) NSArray<id<AWSDKCountry>> *countries;

@property (nonatomic) ErrorService *errorService;
@property (nonatomic) id<AWSDKConsumer> consumer;

@property (nonatomic) NSNumberFormatter *numberFormatter;

@property (nonatomic) UITextField *currentTextField;
@end

@implementation PaymentTableViewController

#pragma mark AWSDK Method Calls
- (void)fetchPayment {
    [MBProgressHUD showLoadingOn:self.view];
    [self.consumer fetchPaymentMethodWithCompletion:^(id result, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (error) {
            [self presentAlertWithError:error okHandler:nil];
        } else {
            self.payment = result;
            if (result == nil) {
                [self setEditing:YES];
            } else if (self.payment.isExpired) {
                [self
                    presentAlertWithTitle:NSLocalizedString(@"paymentInformation.expired.title", @"Card expired title")
                                  message:[NSString stringWithFormat:NSLocalizedString(@"paymentInformation.expired.paramMessage", @"Message explaining card has expired"), self.payment.lastFourDigits]
                                okHandler:nil];
            } else {
                [self.tableView reloadDataAnimated:YES];
            }
        }
    }];
}

/**
 *  Update the consumer's payment information with the current information
 */
- (void)updatePayment:(PaymentMethodCompletionBlock)completion {
    // Retrive AWSDKCreditCardType
    AWSDKCreditCardType *type = [AWSDKCreditCardType creditCardTypeForNumber:self.numberField.text];
    if (!type) {
        [self presentAlertWithMessageKey:@"paymentInformation.invalidCard"
                               okHandler:^(UIAlertAction *action) {
                                   [self setEditing:YES animated:YES];
                               }];
        return;
    }

    // Create payment method form instance
    AWSDKPaymentMethodForm *form = [AWSDKPaymentMethodForm form];

    // Add billing address
    AWSDKAddress *address = [AWSDKAddress address];
    address.addressOne = self.addressField.text;
    address.addressTwo = self.addressTwoField.text;
    address.city = self.cityField.text;
    address.zip = self.zipField.text;
    address.state = [self selectedState];
    address.country = [self selectedCountry];

    [form setBillingAddress:address];

    // Set card information
    [form setBillingName:self.nameField.text];
    [form setCardNumber:self.numberField.text];
    [form setCvvCode:self.cvvCodeField.text];
    [form setExpMonth:self.expirationMonthField.text];
    [form setExpYear:self.expirationYearField.text];
    [form setCardType:type];

    BOOL ccExpired = [[NSDate date] compare:[self userProvidedCreditCardExpirationDate]] == NSOrderedDescending;
    if (ccExpired) {
        [self presentAlertWithTitle:NSLocalizedString(@"paymentInformation.expired.title", @"Card expired title")
                            message:[NSString stringWithFormat:NSLocalizedString(@"paymentInformation.expired.enteredMessage", @"Message explaining card has expired")]
                          okHandler:nil];
        return;
    }

    // Update PaymentMethod
    [self.consumer updatePaymentMethod:form withCompletion:completion];
}

- (NSDate *)userProvidedCreditCardExpirationDate {
    NSString *ccExpString = [NSString stringWithFormat:@"%@/%@", self.expirationMonthField.text, self.expirationYearField.text];
    return [[NSDateFormatter ccDateFormatter] dateFromString:ccExpString];
}

//-----------------------------------------------------------------------------------------------------//
//---------------Everything beyond here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    self.numberFormatter = [NSNumberFormatter new];
    self.numberFormatter.numberStyle = NSNumberFormatterNoStyle;

    self.navigationItem.rightBarButtonItem = self.editButtonItem;
    if (self.delegate) {
        // Modal from VisitCost, add cancel button
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"misc.back", @"Back button")
                                                                                 style:UIBarButtonItemStylePlain
                                                                                target:self
                                                                                action:@selector(cancel:)];
    }
    self.consumer = [[ConsumerService sharedInstance] consumer];
    self.countries = AWSDKEnrollmentService.countries;
    self.tableView.estimatedRowHeight = 61;
    // Error Handling per cell
    self.errorService = [[ErrorService alloc] initWithSender:self];
    // AWSDK Calls
    [self fetchPayment];
}

#pragma mark - Helpers
- (id<AWSDKCountry>)selectedCountry {
    return self.countries[[self.countryPicker selectedRowInComponent:0]];
}
- (id<AWSDKState>)selectedState {
    return [self selectedCountry].states[[self.statePicker selectedRowInComponent:0]];
}

- (void)cancel:(id)sender {
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
    AWSDKLogInfo(@"TableView editing %@", editing ? @"began" : @"ended");
    __weak typeof(self) weakSelf = self;
    void (^successBlock)(void) = ^void() {
        [super setEditing:editing animated:animated];

        [self.nameField setUserInteractionEnabled:editing];
        [self.numberField setUserInteractionEnabled:editing];
        [self.cvvCodeField setUserInteractionEnabled:editing];
        [self.expirationMonthField setUserInteractionEnabled:editing];
        [self.expirationYearField setUserInteractionEnabled:editing];
        [self.addressField setUserInteractionEnabled:editing];
        [self.addressTwoField setUserInteractionEnabled:editing];
        [self.cityField setUserInteractionEnabled:editing];
        [self.zipField setUserInteractionEnabled:editing];
        [self.statePicker setUserInteractionEnabled:editing];

        [self.tableView reloadDataAnimated:animated];
    };

    // Toggle interaction
    if (self.currentTextField.isFirstResponder) {
        // After pressing 'Done' this makes sure the keyboard is not left up. That causes flicker.
        [self.currentTextField resignFirstResponder];
    }
    if (!editing) {
        [self.errorService clearErrors];
        [self updatePayment:^(id result, NSError *error) {
            [weakSelf.errorService handleError:error];
            if (result) {
                [weakSelf.delegate didUpdatePayment:result];
                /**
                 If we are presented from the CostTableViewController go back to last page of intake workflow where user can initiate editing of credit card again, use a coupon, or begin the
                 visit.
                 */
                if ([weakSelf.delegate isKindOfClass:[CostTableViewController class]]) {
                    [weakSelf cancel:nil];
                } else {
                    successBlock();
                }
            }
        }];
    } else {
        //  This clears both the Credit Card and CVV the first time we start to edit the payment and after credit card invalid errors.
        self.numberField.text = @"";
        self.cvvCodeField.text = @"";
        successBlock();
    }
}

#pragma mark UIPickerViewDataSource
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return pickerView == self.statePicker ? [self selectedCountry].states.count : self.countries.count;
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *label = (UILabel *)view;
    if (!label) {
        label = [[UILabel alloc] init];
        [label setFont:[UIFont systemFontOfSize:19.0 weight:UIFontWeightLight]];
        [label setTextAlignment:NSTextAlignmentNatural];
        [label setAdjustsFontSizeToFitWidth:YES];
        [label setNumberOfLines:0];
    }

    // Set Text
    if (pickerView == self.statePicker) {
        label.text = [self selectedCountry].states[row].name;
    } else if (pickerView == self.countryPicker) {
        label.text = self.countries[row].name;
    }
    return label;
}

#pragma mark - UIPicketViewDelegate
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (pickerView == self.statePicker) {
        AWSDKLogInfo(@"State picker value changed to: %@", [self selectedCountry].states[row].name);
    } else if (pickerView == self.countryPicker) {
        AWSDKLogInfo(@"Country picker value changed to: %@", self.countries[row].name);
        [self.statePicker selectRow:0 inComponent:0 animated:NO];
        [self.statePicker reloadAllComponents];
    }
}

#pragma mark - UITableViewDataSource
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleNone;
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return section == CreditCardSection ? NSLocalizedString(@"paymentInformation.creditCard", @"table section - Credit card")
                                        : NSLocalizedString(@"paymentInformation.billingAddress", @"table section - Billing address");
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return section == CreditCardSection ? 2 + 3 * self.editing : 6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [UITableViewCell new];
    if (indexPath.section == CreditCardSection) {
        if (indexPath.row == 0) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"billingName"];
            if (!self.nameField) {
                [self setNameField:((FieldTableViewCell *)cell).textField];
                [self.nameField setText:self.payment.billingName];
                [self.nameField setUserInteractionEnabled:self.editing];
            }
        } else if (indexPath.row == 1) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"cardNumber"];
            if (!self.numberField) {
                [self setNumberField:((FieldTableViewCell *)cell).textField];
                [self.numberField setUserInteractionEnabled:self.editing];
            }
        } else if (indexPath.row == 2) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"cvvCode"];
            if (!self.cvvCodeField) {
                [self setCvvCodeField:((FieldTableViewCell *)cell).textField];
                [self.cvvCodeField setUserInteractionEnabled:self.editing];
            }
        } else if (indexPath.row == 3) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"expMonth"];
            if (!self.expirationMonthField) {
                [self setExpirationMonthField:((FieldTableViewCell *)cell).textField];
                [self.expirationMonthField setUserInteractionEnabled:self.editing];
            }
        } else if (indexPath.row == 4) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"expYear"];
            if (!self.expirationYearField) {
                [self setExpirationYearField:((FieldTableViewCell *)cell).textField];
                [self.expirationYearField setUserInteractionEnabled:self.editing];
            }
        }
    } else {
        if (indexPath.row == 0) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"country"];
            if (!self.countryPicker) {
                self.countryPicker = ((PickerTableViewCell *)cell).picker;
            }
            self.countryPicker.userInteractionEnabled = self.editing;
            NSUInteger countryIndex = [self.countries indexOfObject:self.payment.billingAddress.country];
            if (countryIndex != NSNotFound) {
                [self.countryPicker selectRow:countryIndex inComponent:0 animated:NO];
                [self.countryPicker reloadAllComponents];
            }
        } else if (indexPath.row == 1) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"addressOne"];
            if (!self.addressField) {
                [self setAddressField:((FieldTableViewCell *)cell).textField];
                [self.addressField setText:self.payment.billingAddress.addressOne];
                [self.addressField setUserInteractionEnabled:self.editing];
            }
        } else if (indexPath.row == 2) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"addressTwo"];
            if (!self.addressTwoField) {
                [self setAddressTwoField:((FieldTableViewCell *)cell).textField];
                [self.addressTwoField setText:self.payment.billingAddress.addressTwo];
                [self.addressTwoField setUserInteractionEnabled:self.editing];
            }
        } else if (indexPath.row == 3) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"city"];
            if (!self.cityField) {
                [self setCityField:((FieldTableViewCell *)cell).textField];
                [self.cityField setText:self.payment.billingAddress.city];
                [self.cityField setUserInteractionEnabled:self.editing];
            }
        } else if (indexPath.row == 4) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"state"];
            if (!self.statePicker) {
                [self setStatePicker:((PickerTableViewCell *)cell).picker];
                [self.statePicker setUserInteractionEnabled:self.editing];
            }
            NSUInteger stateIndex = [[self selectedCountry].states indexOfObject:self.payment.billingAddress.state];
            if (stateIndex != NSNotFound) {
                [self.statePicker selectRow:stateIndex inComponent:0 animated:NO];
                [self.statePicker reloadAllComponents];
            }
        } else if (indexPath.row == 5) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"zip"];
            if (!self.zipField) {
                [self setZipField:((FieldTableViewCell *)cell).textField];
                [self.zipField setText:self.payment.billingAddress.zip];
                [self.zipField setUserInteractionEnabled:self.editing];
            }
        }
    }
    if (cell.reuseIdentifier) {
        [self.errorService addObserver:cell forKeyPath:cell.reuseIdentifier];
    }

    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (!AWSDKSystemConfiguration.isMultiCountry && indexPath.section == BillingAddressSection && (indexPath.row == 0)) {
        // if we are not multcountry hide the country picker by making its cell 0 height
        return 0.0;
    }
    return UITableViewAutomaticDimension;
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self.editButtonItem setEnabled:[self validateFields:nil]];
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    [self.editButtonItem setEnabled:[self validateFields:textField] && newString.length];

    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.currentTextField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    textField.text = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    AWSDKLogInfo(@"Text field %@ did end editing with value: %@", textField.placeholder, textField.text);
    if (textField == self.expirationYearField || textField == self.expirationMonthField) {
        NSNumber *number = [self.numberFormatter numberFromString:textField.text];
        textField.text = [self.numberFormatter stringFromNumber:number];
    }
}

- (BOOL)validateFields:(UITextField *)changingTextField {
    return YES;
}

#pragma mark - Setters
/**
 *  Prefills all the textfields with the payment
 *
 *  @param payment Set by fetchPayment
 */
- (void)setPayment:(id<AWSDKPaymentMethod>)payment {
    _payment = payment;

    if (payment) {
        // Card Info
        [self.nameField setText:payment.billingName];
        NSString *description = [NSString
            stringWithFormat:NSLocalizedString(@"paymentInformation.cardEndingIn", @"Format string - Card ending in %@ (last four digits of card)"), payment.cardType, payment.lastFourDigits];
        // If card is expired, do not populate the numberField
        self.numberField.text = (self.payment.isExpired) ? @"" : description;
        // Billing Address
        [self.addressField setText:payment.billingAddress.addressOne];
        [self.addressTwoField setText:payment.billingAddress.addressTwo];
        [self.cityField setText:payment.billingAddress.city];
        [self.zipField setText:payment.billingAddress.zip];
    }
}

@end
