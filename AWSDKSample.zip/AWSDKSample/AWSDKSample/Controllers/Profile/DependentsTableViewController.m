//
//  DependentsTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/13/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "DependentsTableViewController.h"

#import "DemographicsTableViewController.h"
#import "DependentTableViewCell.h"
#import "EnrollmentTableViewController.h"
#import "NSDateFormatter+CommonFormats.h"
#import "NSPersonNameComponents+Localizing.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKDependentEnrollmentForm.h>
#import <AWSDK/AWSDKEnrollmentService.h>

/**
 *  Displays a list of dependents
 */
@interface DependentsTableViewController ()

@property (nonatomic) NSArray<id<AWSDKConsumer>> *dependents;
@property (nonatomic) NSMutableDictionary *sharedParentsDictionary;

@end

@implementation DependentsTableViewController

#pragma mark - Notification for Consumer Updated
- (void)didUpdateConsumer:(NSNotification *)notification {
    [self fetchDependents];
}

//-----------------------------------------------------------------------------------------------------//
//---------------Everything beyond here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    [self fetchDependents];

    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    if (![consumer canAddDependent]) {
        self.navigationItem.rightBarButtonItem = nil;
    }

    self.sharedParentsDictionary = [NSMutableDictionary new];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didUpdateConsumer:) name:ConsumerUpdatedNotification object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dependents.count ? self.dependents.count : 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.dependents.count) {
        DependentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"dependentCell" forIndexPath:indexPath];
        cell.nameLabel.text = self.dependents[indexPath.row].nameComponents.localizedFullName;
        cell.dobLabel.text = [NSString stringWithFormat:NSLocalizedString(@"enrollment.dateOfBirth.title", @"Cell format string - DOB: %@ (formatted date of birth)"),
                                       [NSDateFormatter.longerUTCDateFormatter stringFromDate:self.dependents[indexPath.row].dateOfBirth]];
        cell.sharedLabel.text = [self formatSharedParentDisplay:indexPath.row];
        cell.tag = indexPath.row;
        return cell;
    } else {
        UITableViewCell *cell = [UITableViewCell new];
        cell.textLabel.text = NSLocalizedString(@"misc.none", @"Placeholder cell - None");
        return cell;
    }
}

#pragma mark - UITableViewDelegate

- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    return (self.dependents.count) ? indexPath : nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"enrollmentSegue"]) {
        EnrollmentTableViewController *enrollViewController = [(UINavigationController *)segue.destinationViewController viewControllers][0];
        enrollViewController.mode = DependentMode;
        AWSDKLogInfo(@"Add dependent button tapped");
    } else if ([segue.identifier isEqualToString:@"profileSegue"] && [sender isKindOfClass:[DependentTableViewCell class]]) {
        AWSDKLogInfo(@"Dependent row tapped");
        DependentTableViewCell *cell = (DependentTableViewCell *)sender;
        DemographicsTableViewController *demographicsViewController = segue.destinationViewController;
        demographicsViewController.editingCurrentUser = NO;
        demographicsViewController.consumer = self.dependents[cell.tag];
    }
}

// This empty action is required
- (IBAction)unwindFromEnrollDependentSegue:(UIStoryboardSegue *)segue sender:(id)sender {
}

#pragma mark - Private Methods

- (void)fetchDependents {
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD showLoadingOn:self.view];
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    [consumer fetchDependentsWithCompletion:^(NSArray<id<AWSDKConsumer>> *consumers, NSError *error) {
        weakSelf.dependents = consumers;
        [weakSelf invalidateSharedParentsDictionary];
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view];
            [weakSelf.tableView reloadDataAnimated:YES];
        });
    }];
}

- (NSString *)formatSharedParentDisplay:(NSUInteger)index {
    NSString *key = [NSString stringWithFormat:@"%ld", (long)index];
    NSString *sharingMessage = self.sharedParentsDictionary[key];
    if (!sharingMessage) {
        id<AWSDKConsumer> parent = (id<AWSDKConsumer>)[[ConsumerService sharedInstance] consumer];
        NSMutableArray<NSString *> *parentsFullName = [NSMutableArray new];
        [((id<AWSDKConsumer>)self.dependents[index]).parents enumerateObjectsUsingBlock:^(id<AWSDKConsumer> obj, NSUInteger idx, BOOL *stop) {
            if (![obj isEqual:parent]) {
                [parentsFullName addObject:obj.nameComponents.localizedFullName];
            }
        }];
        NSString *separatedNames = [parentsFullName componentsJoinedByString:@", "];
        sharingMessage = (separatedNames.length) ? [NSString stringWithFormat:NSLocalizedString(@"dependents.shared.title", @"Format string - Shared with %@ (parent's name)"), separatedNames] : nil;
        self.sharedParentsDictionary[key] = sharingMessage;
    }
    return sharingMessage;
}

- (void)invalidateSharedParentsDictionary {
    self.sharedParentsDictionary = [NSMutableDictionary new];
}

@end
