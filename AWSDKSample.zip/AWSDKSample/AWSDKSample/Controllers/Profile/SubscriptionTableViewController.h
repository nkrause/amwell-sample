//
//  SubscriptionTableViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/17/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface SubscriptionTableViewController : UITableViewController

// Subscription fields
@property (nonatomic) UISwitch *noInsuranceSwitch;
@property (nonatomic) UIPickerView *healthPlanPicker;
@property (nonatomic) UIPickerView *relationshipPicker;
@property (nonatomic) UIDatePicker *primaryDoBPicker;

@property (nonatomic) UITextField *subscriberIdField;
@property (nonatomic) UITextField *subscriberSuffixField;
@property (nonatomic) UITextField *primaryFirstNameField;
@property (nonatomic) UITextField *primaryLastNameField;

@end
