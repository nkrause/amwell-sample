//
//  TechCheckTableViewController.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 12/28/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import "TechCheckTableViewController.h"

#import "ConsumerService.h"
#import "GradientButton.h"
#import "NSDateFormatter+CommonFormats.h"
#import "UIApplication+AVAuthorization.h"
#import "UIView+Animation.h"

#import <AWSDK/AWSDKAppointmentReadiness.h>
#import <AWSDK/AWSDKAppointmentReadinessOverrides.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKLogService.h>
#import <AVFoundation/AVFoundation.h>

@interface TechCheckTableViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *apptReadyStatusImageView;
@property (weak, nonatomic) IBOutlet UILabel *statusMessageLabel;
@property (weak, nonatomic) IBOutlet UILabel *statusDetailMessageLabel;
@property (weak, nonatomic) IBOutlet GradientButton *startTestButton;
@property (weak, nonatomic) IBOutlet UILabel *lastTestDateLabel;
@property (weak, nonatomic) IBOutlet UIImageView *cameraStatusImageView;
@property (weak, nonatomic) IBOutlet UILabel *cameraLabel;
@property (weak, nonatomic) IBOutlet UIImageView *microphoneStatusImageView;
@property (weak, nonatomic) IBOutlet UILabel *microphoneLabel;
@property (weak, nonatomic) IBOutlet UIImageView *speakerStatusImageView;
@property (weak, nonatomic) IBOutlet UILabel *speakerLabel;
@property (weak, nonatomic) IBOutlet UIImageView *speedtestStatusImageView;
@property (weak, nonatomic) IBOutlet UILabel *speedtestLabel;

@property (weak, nonatomic) IBOutlet UILabel *cameraDeviceNameTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *cameraDeviceNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *speakerDeviceNameTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *speakerDeviceNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *microphoneDeviceNameTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *microphoneDeviceNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *downloadSpeedTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *downloadSpeedLabel;
@property (weak, nonatomic) IBOutlet UILabel *uploadSpeedTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *uploadSpeedLabel;
@property (weak, nonatomic) IBOutlet UILabel *latencyTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *latencyLabel;
@property (weak, nonatomic) IBOutlet UILabel *jitterTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *jitterLabel;
@property (weak, nonatomic) IBOutlet UILabel *platformVersionTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *platformVersionLabel;

@property (nonatomic) id<AWSDKAppointmentReadiness>_Nullable appointmentReadiness;
@property (nonatomic) AWSDKAppointmentReadinessOverrides *appointmentReadinessOverrides;
@property (nonatomic) BOOL authorizationChanged;

@end

@implementation TechCheckTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self setupView];
    [self setupNotifications];

    __weak typeof(self) weakSelf = self;
    [self fetchConsumerReadiness:^(BOOL success, NSError *error) {
        [weakSelf updateView];
        [weakSelf requestPermissions];
    }];
}

/**
 Updates the consumer's readiness status on the American Well telehealth platform

 @discussion This routine fetches the current readiness values from the server and updates the values.

 @param overrides The state of the consumer's readiness for an upcoming appointment on the current device.
 @param completion Executed when the network calls have completed.
 */
- (void)updateConsumerReadiness:(AWSDKAppointmentReadinessOverrides *)overrides withCompletion:(GenericCompletionBlock)completion {
    __weak typeof(self) weakSelf = self;
    if (self.appointmentReadiness) {
        AWSDKLogDebug(@"Updating appointment readiness state");
        [self.appointmentReadiness updateAppointmentReadinessWithStatus:overrides.techCheckPassed
                                                            appointment:nil
                                                             completion:^(BOOL success, NSError *error) {
                                                                 if (error) {
                                                                     AWSDKLogError(@"Error updating appointment readiness status: %@", error);
                                                                     completion(success, error);
                                                                 } else if (success) {
                                                                     AWSDKLogInfo(@"Updated consumer's readiness status to %d", overrides.techCheckPassed);
                                                                     [weakSelf.appointmentReadiness updateAppointmentReadinessWithOverrides:overrides
                                                                                                                                 completion:^(BOOL success, NSError *error) {
                                                                                                                                     completion(success, error);
                                                                                                                                 }];
                                                                 }
                                                             }];
    }
}

- (void)fetchConsumerReadiness:(GenericCompletionBlock)completion {
    self.appointmentReadiness = nil;
    [MBProgressHUD showLoadingOn:self.view];
    [ConsumerService.sharedInstance.consumer fetchAppointmentReadinessStatusWithCompletion:^(id<AWSDKAppointmentReadiness> _Nullable appointmentReadiness, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (error) {
            AWSDKLogError(@"Error fetching appointment readiness status: %@", error);
            completion(NO, error);
        } else if (appointmentReadiness) {
            self.appointmentReadiness = appointmentReadiness;
            self.appointmentReadinessOverrides = self.appointmentReadiness.getAppointmentReadinessOverride;
            completion(YES, nil);
        }
    }];
}

/**
 @discussion Be aware that you can only request application permissions once in the lifetime of the application. If the user declines any of the permissions, they must enter the iOS settings screen
 for the application to enable them again. The [AppointmentReadinessViewController openDeviceSettings] method takes care of that. Also note that if AV permissions are changed through the settings
 screen while the application is running in the background, the application will terminate and restart. This is normal iOS behavior, so be sure to account for this.

 */
- (void)requestPermissions {
    AWSDKLogInfo(@"Microphone permission: %d, Camera permission: %d", UIApplication.sharedApplication.microphoneAuthorized, UIApplication.sharedApplication.cameraAuthorized);
    __weak typeof(self) weakSelf = self;
    [self resetView];
    [self fetchConsumerReadiness:^(BOOL success, NSError *error) {
        if (weakSelf.appointmentReadiness) {
            self.appointmentReadinessOverrides = self.appointmentReadiness.getAppointmentReadinessOverride;
            [UIApplication.sharedApplication requestMicrophoneAuthorizationWithCompletion:^(BOOL microphoneSuccess) {
                self.appointmentReadinessOverrides.microphonePassed = microphoneSuccess;
                [UIApplication.sharedApplication requestCameraAuthorizationWithCompletion:^(BOOL cameraSuccess) {
                    self.appointmentReadinessOverrides.cameraPassed = cameraSuccess;
                    self.appointmentReadinessOverrides.techCheckPassed = (microphoneSuccess && cameraSuccess);
                    AWSDKLogInfo(@"User %@ permissions - Microphone: %d Camera: %d", self.appointmentReadinessOverrides.techCheckPassed ? @"approved" : @"declined", microphoneSuccess, cameraSuccess);
                    [weakSelf updateConsumerReadiness:self.appointmentReadinessOverrides
                                       withCompletion:^(BOOL success, NSError *error) {
                                           [self fetchConsumerReadiness:^(BOOL success, NSError *error) {
                                               [weakSelf updateView];
                                           }];
                                       }];
                }];
            }];
        }
    }];
}

#pragma mark - Table view data source

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];

    if ([cell.reuseIdentifier isEqualToString:@"startTestCell"]) {
        if ((!AWSDKSystemConfiguration.isAppointmentReadinessCheckEnabled || self.appointmentReadiness.techCheckPassed) && !self.authorizationChanged) {
            return 0;
        }
    } else if ([cell.reuseIdentifier isEqualToString:@"lastTestDateCell"]) {
        if (!self.appointmentReadiness.techCheckPassed) {
            return 0;
        }
    } else if ([cell.reuseIdentifier isEqualToString:@"downloadSpeedCell"] || [cell.reuseIdentifier isEqualToString:@"uploadSpeedCell"] ||
        [cell.reuseIdentifier isEqualToString:@"latencyCell"] || [cell.reuseIdentifier isEqualToString:@"jitterCell"]) {
        if (!self.appointmentReadiness.platformType || self.appointmentReadiness.platformType.type == AWSDKPlatformTypeIDiOS) {
            return 0;
        }
    }
    return [super tableView:tableView heightForRowAtIndexPath:indexPath];
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([cell.reuseIdentifier isEqualToString:@"speakerSpeedTestCell"]) {
        self.speedtestStatusImageView.hidden = (!self.appointmentReadiness.platformType || self.appointmentReadiness.platformType.type == AWSDKPlatformTypeIDiOS);
        self.speedtestLabel.hidden = self.speedtestStatusImageView.hidden;
    }
}

#pragma mark - Actions

- (IBAction)deviceSettingsButtonTapped {
    [self checkPermissionsWithCompletion:^(BOOL success) {
        AWSDKLogInfo(@"Open Device Settings button tapped");
        [UIApplication.sharedApplication openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]
            options:@{}
            completionHandler:^(BOOL success) {
                [self updateView];
            }];
    }];
}

- (IBAction)startTestButtonTapped:(id)sender {
    AWSDKLogInfo(@"Start Test button tapped");
    [self requestPermissions];
}

- (void)setupView {
    self.statusMessageLabel.text = NSLocalizedString(@"techCheck.loading", @"Loading Tech Check Info");
    self.statusDetailMessageLabel.text = NSLocalizedString(@"techCheck.loading.detail", @"Loading Tech Check Detail Info");
    [self.startTestButton setTitle:NSLocalizedString(@"techCheck.startTest.button", @"Open Settings App") forState:UIControlStateNormal];
    self.cameraLabel.text = NSLocalizedString(@"techCheck.cameraStatus.title", @"Camera State");
    self.speakerLabel.text = NSLocalizedString(@"techCheck.SpeakerStatus.title", @"Speaker Status");
    self.microphoneLabel.text = NSLocalizedString(@"techCheck.microphoneStatus.title", @"Microphone Status");
    self.speedtestLabel.text = NSLocalizedString(@"techCheck.SpeedtestStatus.title", @"Speedtest Status");
    self.cameraDeviceNameTitleLabel.text = NSLocalizedString(@"techCheck.cameraDeviceName.title", @"Camera Device Name");
    self.speakerDeviceNameTitleLabel.text = NSLocalizedString(@"techCheck.speakerDeviceName.title", @"Speaker Device Name");
    self.microphoneDeviceNameTitleLabel.text = NSLocalizedString(@"techCheck.microphoneDeviceName.title", @"Microphone Device Name");
    self.downloadSpeedTitleLabel.text = NSLocalizedString(@"techCheck.downloadSpeed.title", @"Download Speed");
    self.uploadSpeedTitleLabel.text = NSLocalizedString(@"techCheck.uploadSpeed.title", @"Upload Speed");
    self.latencyTitleLabel.text = NSLocalizedString(@"techCheck.latency.title", @"Latency");
    self.jitterTitleLabel.text = NSLocalizedString(@"techCheck.jitter.title", @"Jitter");
    self.platformVersionTitleLabel.text = NSLocalizedString(@"techCheck.platformVersion.title", @"Platform Version");
}

- (void)updateView {
    BOOL microphonePassed = [[UIApplication sharedApplication] microphoneAuthorized];
    BOOL cameraPassed = [[UIApplication sharedApplication] cameraAuthorized];

    self.authorizationChanged = NO;
    if (self.appointmentReadinessOverrides) {
        self.authorizationChanged = (self.appointmentReadinessOverrides.microphonePassed != microphonePassed);
        self.authorizationChanged |= (self.appointmentReadinessOverrides.cameraPassed != cameraPassed);

        if (self.authorizationChanged || !microphonePassed || !cameraPassed) {
            self.appointmentReadinessOverrides.microphonePassed = microphonePassed;
            self.appointmentReadinessOverrides.cameraPassed = cameraPassed;
            self.appointmentReadinessOverrides.techCheckPassed = (microphonePassed && cameraPassed);
        }
        
        if (self.appointmentReadinessOverrides.techCheckPassed) {
            self.apptReadyStatusImageView.image = [UIImage imageNamed:@"iconApptReadyPass"];
            self.statusMessageLabel.text = NSLocalizedString(@"techCheck.pass", @"Tech Check Passed");
            self.statusDetailMessageLabel.text = NSLocalizedString(@"techCheck.pass.detail", @"Tech Check Passed Detail");
        } else {
            self.apptReadyStatusImageView.image = [UIImage imageNamed:@"iconApptReadyFail"];
            self.statusMessageLabel.text = NSLocalizedString(@"techCheck.fail", @"Tech Check Failed");
            self.statusDetailMessageLabel.text = NSLocalizedString(@"techCheck.fail.detail", @"Tech Check Failed Detail");
        }

        [self.startTestButton setTitle:NSLocalizedString(@"techCheck.startTest.button", @"Start Test") forState:UIControlStateNormal];

        if (self.appointmentReadiness.datePassedTechCheck) {
            NSString *dateString = [[NSDateFormatter shortDateFormatter] stringFromDate:self.appointmentReadiness.datePassedTechCheck];
            NSString *platformName = (self.appointmentReadiness.platformType.type != AWSDKPlatformTypeIDUnknown) ? self.appointmentReadiness.platformType.localizedDisplayName
                                                                                                                 : NSLocalizedString(@"misc.notAvailable", @"Not Available");
            self.lastTestDateLabel.text = [NSString stringWithFormat:NSLocalizedString(@"techCheck.lastTest", @""), platformName, dateString];
            self.lastTestDateLabel.hidden = NO;
        } else {
            self.lastTestDateLabel.hidden = YES;
        }

        BOOL speedtestPassed = (self.appointmentReadiness.downloadSpeedMbps >= 0 && self.appointmentReadiness.uploadSpeedMbps >= 0);
        
        self.appointmentReadinessOverrides.cameraDeviceName = [self cameraDeviceName];
        self.appointmentReadinessOverrides.microphoneDeviceName = [self microphoneDeviceName];
        self.appointmentReadinessOverrides.speakerDeviceName = [self speakerDeviceName];
        
        self.cameraStatusImageView.image = (self.appointmentReadinessOverrides.cameraPassed) ? [UIImage imageNamed:@"iconApptReadyPass"] : [UIImage imageNamed:@"iconApptReadyFail"];
        self.speakerStatusImageView.image = (self.appointmentReadinessOverrides.speakerPassed) ? [UIImage imageNamed:@"iconApptReadyPass"] : [UIImage imageNamed:@"iconApptReadyFail"];
        self.microphoneStatusImageView.image = (self.appointmentReadinessOverrides.microphonePassed) ? [UIImage imageNamed:@"iconApptReadyPass"] : [UIImage imageNamed:@"iconApptReadyFail"];
        self.speedtestStatusImageView.image = (speedtestPassed) ? [UIImage imageNamed:@"iconApptReadyPass"] : [UIImage imageNamed:@"iconApptReadyFail"];

        self.cameraDeviceNameLabel.text = (self.appointmentReadinessOverrides.cameraDeviceName) ?: NSLocalizedString(@"misc.notAvailable", @"Not Available");
        self.speakerDeviceNameLabel.text = (self.appointmentReadinessOverrides.speakerDeviceName) ?: NSLocalizedString(@"misc.notAvailable", @"Not Available");
        self.microphoneDeviceNameLabel.text = (self.appointmentReadinessOverrides.microphoneDeviceName) ?: NSLocalizedString(@"misc.notAvailable", @"Not Available");
        self.downloadSpeedLabel.text = [NSString stringWithFormat:@"%0.1lf Mbps", self.appointmentReadiness.downloadSpeedMbps];
        self.uploadSpeedLabel.text = [NSString stringWithFormat:@"%0.1lf Mbps", self.appointmentReadiness.uploadSpeedMbps];
        self.latencyLabel.text = [NSString stringWithFormat:@"%ld ms", (long)self.appointmentReadiness.latencyMs];
        self.jitterLabel.text = [NSString stringWithFormat:@"%ld ms", (long)self.appointmentReadiness.jitter];
        self.platformVersionLabel.text = (self.appointmentReadiness.platformVersion) ?: NSLocalizedString(@"misc.notAvailable", @"Not Available");
        [self.tableView reloadData];
    }
}

- (void)resetView {
    self.apptReadyStatusImageView.image = [UIImage imageNamed:@"iconApptReadyFail"];
    self.statusMessageLabel.text = NSLocalizedString(@"techCheck.checking", @"Tech Check Checking");
    self.statusDetailMessageLabel.text = NSLocalizedString(@"techCheck.checking.detail", @"Tech Check Checking Detail");
}

#pragma mark - Notifications

- (void)setupNotifications {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleWillResignActive) name:UIApplicationWillResignActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleDidBecomeActive) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleDidEnterBackground) name:UIApplicationDidEnterBackgroundNotification object:nil];
}

- (void)handleWillResignActive {
    AWSDKLogInfo(@"Resigned active");
}

- (void)handleDidBecomeActive {
    AWSDKLogInfo(@"Did become active");
    self.appointmentReadinessOverrides.microphonePassed = [[UIApplication sharedApplication] microphoneAuthorized];
    self.appointmentReadinessOverrides.cameraPassed = [[UIApplication sharedApplication] cameraAuthorized];
    [self updateView];
}

- (void)handleDidEnterBackground {
    AWSDKLogInfo(@"Did enter background");
}

#pragma mark - AVCaptureDevice Methods

- (void)checkPermissionType:(NSString *)type completion:(SuccessCompletionBlock)completion {
    NSString *typeString = @"";
    if (type == AVMediaTypeAudio) {
        typeString = @"Audio";
    } else if (type == AVMediaTypeVideo) {
        typeString = @"Video";
    } else {
        [[NSException exceptionWithName:@"AWSDKInvalidArgumentException" reason:@"Unexpected media type. Can only check AVMediaTypeAudio and AVMediaTypeVideo" userInfo:nil] raise];
    }
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:type];
    if (authStatus == AVAuthorizationStatusAuthorized) {
        AWSDKLogDebug(@"%@ Authorized", typeString);
        completion(YES);
    } else if (authStatus == AVAuthorizationStatusDenied) {
        AWSDKLogWarn(@"%@ Permission Denied", typeString);
        completion(NO);
    } else if (authStatus == AVAuthorizationStatusNotDetermined) {
        // If not determined, determine
        AWSDKLogDebug(@"Request %@ access", typeString);
        [AVCaptureDevice requestAccessForMediaType:type
                                 completionHandler:^(BOOL granted) {
                                     if (granted) {
                                         AWSDKLogDebug(@"%@ Authorized", typeString);
                                     } else {
                                         AWSDKLogWarn(@"%@ Permission Denied", typeString);
                                     }
                                     completion(granted);
                                 }];
    } else {
        AWSDKLogError(@"Unable to authorize %@ permissions. Access restricted due to device limitations or parental controls", typeString);
        completion(NO);
    }
}

- (void)checkCameraPermissionsWithCompletion:(SuccessCompletionBlock)completion {
    [self checkPermissionType:AVMediaTypeVideo completion:completion];
}

- (void)checkMicrophonePermissionsWithCompletion:(SuccessCompletionBlock)completion {
    [self checkPermissionType:AVMediaTypeAudio completion:completion];
}

- (void)checkPermissionsWithCompletion:(SuccessCompletionBlock)completion {
    __weak typeof(self) weakSelf = self;
    [self checkCameraPermissionsWithCompletion:^(BOOL success) {
        if (success) {
            [weakSelf checkMicrophonePermissionsWithCompletion:completion];
        } else {
            completion(NO);
        }
    }];
}

#pragma mark - Private Methods

- (NSString *)cameraDeviceName {
    AVCaptureDevice *device;
    device = [AVCaptureDevice defaultDeviceWithDeviceType:AVCaptureDeviceTypeBuiltInWideAngleCamera mediaType:AVMediaTypeVideo position:AVCaptureDevicePositionFront];
    return [device localizedName];
}

- (NSString *)microphoneDeviceName {
    AVCaptureDevice *device;
    device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeAudio];
    return [device localizedName];
}

- (NSString *)speakerDeviceName {
    AVAudioSessionRouteDescription *currentRoute = AVAudioSession.sharedInstance.currentRoute;
    NSMutableArray<NSString *> *portNames = [NSMutableArray new];
    [currentRoute.outputs enumerateObjectsUsingBlock:^(AVAudioSessionPortDescription * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [portNames addObject: obj.portName];
    }];
    NSString *speakers = [portNames componentsJoinedByString:@","];
    return speakers;
}

@end
