//
//  PaymentTableViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/16/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKPaymentMethod;

@protocol PaymentDelegate <NSObject>

/**
 Called when payment has been updated
 */
- (void)didUpdatePayment:(id<AWSDKPaymentMethod>)newPaymentMethod;

@end

@interface PaymentTableViewController : UITableViewController <UIPickerViewDataSource, UIPickerViewDelegate>

@property (nonatomic) id<PaymentDelegate> delegate;

@property (weak, nonatomic) UITextField *nameField;
@property (weak, nonatomic) UITextField *numberField;
@property (weak, nonatomic) UITextField *cvvCodeField;
@property (weak, nonatomic) UITextField *expirationMonthField;
@property (weak, nonatomic) UITextField *expirationYearField;

@property (weak, nonatomic) UITextField *addressField;
@property (weak, nonatomic) UITextField *addressTwoField;
@property (weak, nonatomic) UITextField *cityField;
@property (weak, nonatomic) UITextField *zipField;
@property (weak, nonatomic) UIPickerView *statePicker;
@property (weak, nonatomic) UIPickerView *countryPicker;

@end
