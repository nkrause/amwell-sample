//
//  MyVisitReportsTableViewController.m
//  AWSDKSample
//
//  Created by Caleb Lindsey on 6/1/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "DropDownTableViewCell.h"
#import "VisitReportTableViewCell.h"
#import "MyVisitReportsTableViewController.h"
#import "NSDateFormatter+CommonFormats.h"
#import "UITableView+Sample.h"
#import "VisitReportSummaryViewController.h"

#import <AWSDKSample-Swift.h>
#import <AWSDK/AWSDKVisitReportSearchRequest.h>
#import <Foundation/Foundation.h>

/**
 *  Displays a list of a consumer's visit reports sectioned by year
 */
@interface MyVisitReportsTableViewController ()

@property (nonatomic, nonnull) EmptyContentView *emptyView;
@property (nonatomic, nonnull) NSArray<NSString *> *filters;
@property (nonatomic, nonnull) NSString *yearFilter;
@property (nonatomic) NSInteger currentYear;
@property (nonatomic) BOOL isExpanded;
@property (nonatomic, nullable) NSArray<id<AWSDKVisitReport>> *visitReports;
@property (nonatomic, nullable) id<AWSDKPaginatedVisitReports> paginatedVisitReports;
@property (nonatomic, nullable) NSMutableDictionary<NSString *, NSMutableArray<id<AWSDKVisitReport>> *> *groupedReports;
@property (nonatomic, weak) IBOutlet UIButton *loadMoreButton;

@end

@implementation MyVisitReportsTableViewController

#pragma mark - AWSDKMethodCalls
- (void)fetchReportsAndClearResults:(BOOL)clearResults {
    __weak typeof(self) weakSelf = self;
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    [MBProgressHUD showLoadingOn:self.view];

    id<AWSDKVisitReportSearchRequest> thisRequest;
    if (clearResults) {
        NSDate *startDate = nil;
        NSDate *endDate = nil;
        [self alterStartEndDate:&startDate endDate:&endDate];

        AWSDKItemSearchOptions *searchOptions = [AWSDKItemSearchOptions alloc];
        searchOptions.startDate = startDate;
        searchOptions.endDate = endDate;
        thisRequest = [[VisitReportSearchRequest alloc] initWithDispositionMask:self.dispositionMask pageSize:10 startIndex:0 scheduledOnly:NO options:searchOptions];
    } else {
        thisRequest = self.paginatedVisitReports.nextPage;
    }

    BOOL shouldAppendItems = self.paginatedVisitReports.nextPage;

    [consumer fetchPaginatedVisitReports:thisRequest completion:^(id<AWSDKPaginatedVisitReports>  _Nullable paginatedVisitReports, NSError * _Nullable error) {
        [MBProgressHUD hideHUDForView:self.view];

        if (paginatedVisitReports) {
            if (clearResults) {
                weakSelf.visitReports = paginatedVisitReports.list;
            } else if (shouldAppendItems) {
                weakSelf.visitReports = [weakSelf.visitReports arrayByAddingObjectsFromArray:paginatedVisitReports.list];
            }

            weakSelf.paginatedVisitReports = paginatedVisitReports;

            [weakSelf groupReportsByYear];

            weakSelf.isExpanded = NO;
            weakSelf.emptyView.alpha = weakSelf.isEmpty ? 1.0 : 0.0;
            [weakSelf.loadMoreButton setHidden:paginatedVisitReports.nextPage == nil];

            [weakSelf.tableView reloadDataAnimated:YES];
        } else if (error) {
            [weakSelf presentAlertWithError:error okHandler:nil];
        }
    }];
}

- (void)fetchReportSummaryForReport:(id<AWSDKVisitReport>)report forReconnect:(BOOL)isReconnect {
    [MBProgressHUD showLoadingOn:self.navigationController.view];

    [report fetchReportSummary:^(id<AWSDKVisitReportSummary> summary, NSError *error) {
        [MBProgressHUD hideHUDForView:self.navigationController.view];

        if (error) {
            [self presentAlertWithError:error okHandler:nil];
        } else if (summary) {
            NSString *segueIdentifier = isReconnect ? @"providerDetailSegue" : @"reportSegue";
            [self performSegueWithIdentifier:segueIdentifier sender:@{@"summary" : summary}];
        }
    }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything below here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad
{
    [super viewDidLoad];

    self.tableView.estimatedRowHeight = 70;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.sectionHeaderHeight = 50;
    self.tableView.backgroundColor = UIColor.bkgdGreyColor;

    UIImage *emptyImage = [UIImage imageNamed:@"noPreviousVisits"];
    self.emptyView = [[EmptyContentView alloc] initWithImage: emptyImage message:NSLocalizedString(@"previousVisits.empty", @"Previous Visits empty") buttonTitle:nil];
    self.emptyView.alpha = 0;
    self.tableView.backgroundView = self.emptyView;

    self.yearFilter = NSLocalizedString(@"visitReport.filterAllYears", @"Title for visit report filter section all years");

    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitYear fromDate:[NSDate date]];
    self.currentYear = components.year;
    
    [self fetchReportsAndClearResults:YES];
}

#pragma mark - Private Methods
- (void)groupReportsByYear
{
    self.groupedReports = [[NSMutableDictionary alloc] init];

    for (id<AWSDKVisitReport> report in self.visitReports) {
        NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitYear fromDate:[self displayDateForVisitReport:report]];
        NSString *yearString = [NSString stringWithFormat:@"%ld", (long)components.year];

        if (self.groupedReports[yearString] == nil) {
            self.groupedReports[yearString] = [[NSMutableArray alloc] init];
        }

        [self.groupedReports[yearString] addObject:report];
    }

    if ([self.yearFilter isEqualToString:NSLocalizedString(@"visitReport.filterAllYears", @"Title for visit report filter section all years")]) {
        [self updateFilters];
    }
}

- (BOOL)isEmpty
{
    return self.visitReports.count == 0;
}

- (void)updateFilters
{
    NSMutableArray *filterArray = [[NSMutableArray alloc] initWithArray:self.groupedReports.allKeys];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"intValue" ascending:NO];
    filterArray = [[filterArray sortedArrayUsingDescriptors:@[sortDescriptor]] mutableCopy];
    [filterArray insertObject:NSLocalizedString(@"visitReport.filterAllYears", @"Title for visit report filter section all years") atIndex:0];

    self.filters = [[NSArray alloc] initWithArray:filterArray];
}

- (NSString *)getYearBySection:(NSInteger)section
{
    if ([self.yearFilter isEqualToString:NSLocalizedString(@"visitReport.filterAllYears", @"Title for visit report filter section all years")]) {
        section -= 1;
        NSInteger reportSection = self.currentYear - section;

        return [NSString stringWithFormat:@"%ld", (long)reportSection];
    } else {
        return self.yearFilter;
    }
}

- (void)alterStartEndDate:(NSDate **)startDate endDate:(NSDate **)endDate
{
    if ([self.yearFilter isEqualToString: self.filters.firstObject]) {
        return;
    }

    NSInteger year = [self.yearFilter integerValue];

    if (year) {
        NSDate *currentDate = [NSDate date];

        NSDateComponents *firstDayOfYearComponents = [NSCalendar.currentCalendar components:NSCalendarUnitYear fromDate:currentDate];
        firstDayOfYearComponents.month = 1;
        firstDayOfYearComponents.day = 1;
        firstDayOfYearComponents.year = year;
        firstDayOfYearComponents.timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
        NSDate *firstDayOfYear = [NSCalendar.currentCalendar dateFromComponents:firstDayOfYearComponents];

        NSDateComponents *lastDayOfYearComponents = [NSCalendar.currentCalendar components:NSCalendarUnitYear fromDate:currentDate];
        lastDayOfYearComponents.year = 1;
        lastDayOfYearComponents.second = -1;
        lastDayOfYearComponents.timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
        NSDate *lastDayOfYear = [NSCalendar.currentCalendar dateByAddingComponents:lastDayOfYearComponents toDate:firstDayOfYear options:NSCalendarMatchFirst];

        *startDate = firstDayOfYear;
        *endDate = ([lastDayOfYear laterDate:currentDate] == lastDayOfYear) ? currentDate : lastDayOfYear;
    }
}

- (NSDate *)displayDateForVisitReport:(id<AWSDKVisitReport>)report {
    return report.visitDate ?: (report.schedule.waitStartTime ?: report.schedule.scheduledStartTime);
}

- (AWSDKVisitDisposition)dispositionMask {
    return AWSDKVisitDispositionCompleted | AWSDKVisitDispositionExpired | AWSDKVisitDispositionDeleted | AWSDKVisitDispositionConsumerDisconnected |
        AWSDKVisitDispositionConsumerCanceled | AWSDKVisitDispositionDeleted | AWSDKVisitDispositionProviderResponseTimeout | AWSDKVisitIntegrationStatusBailed |
        AWSDKVisitDispositionProviderDisconnected | AWSDKVisitDispositionProviderCanceled | AWSDKVisitDispositionExpired;
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.groupedReports.count + 1;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSString *sectionTitle;

    if (section == 0) {
        sectionTitle = NSLocalizedString(@"visitReport.filterYearSection", @"Title for visit report filter year section");
    } else {
        NSString *yearBySection = [self getYearBySection:section];
        NSString *currentYear = [NSString stringWithFormat:@"%ld", (long)self.currentYear];

        if ([yearBySection isEqualToString:currentYear]) {
            sectionTitle = NSLocalizedString(@"visitReport.currentYearSection", @"Title for visit report section current year");
        } else {
            sectionTitle = yearBySection;
        }
    }

    DocumentsHeaderView *headerView = [[DocumentsHeaderView alloc] initWithTitle:sectionTitle.uppercaseString];
    headerView.backgroundColor = UIColor.bkgdGreyColor;
    return headerView;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            DropDownTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"visitReportsSelectCell" forIndexPath:indexPath];
            cell.filterLabel.text = self.yearFilter;
            cell.dividerView.alpha = self.isExpanded ? 0.0 : 1.0;
            return cell;
        } else {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"filterCell" forIndexPath:indexPath];
            BOOL isSelected = self.yearFilter == self.filters[indexPath.row - 1];
            cell.textLabel.text = self.filters[indexPath.row - 1];
            cell.accessoryType = isSelected ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
            return cell;
        }
    } else {
        VisitReportTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyVisitReportCell" forIndexPath:indexPath];

        NSArray<id<AWSDKVisitReport>> *sectionReports = self.groupedReports[[self getYearBySection:indexPath.section]];

        NSString *cellTitle = [NSString stringWithFormat:NSLocalizedString(@"visitSummary.visitWith.noVisitType", @"Visit Summary Visit with Title no Visit Type"), sectionReports[indexPath.row].providerName];
        cell.titleLabel.text = cellTitle;
        NSDate *visitDate = [self displayDateForVisitReport:sectionReports[indexPath.row]];
        cell.dateLabel.text = [[NSDateFormatter longDateMonthDayTimeFormatter] stringFromDate:visitDate];
        cell.practiceLabel.text = self.visitReports[indexPath.row].providerType.name;
        return cell;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return self.isExpanded ? (self.filters.count + 1) : 1;
    } else {
        return self.groupedReports[[self getYearBySection:section]].count;
    }
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            self.isExpanded = !self.isExpanded;

            NSRange range = NSMakeRange(0, 1);
            NSIndexSet *section = [NSIndexSet indexSetWithIndexesInRange:range];
            [self.tableView reloadSections:section withRowAnimation:UITableViewRowAnimationAutomatic];
        } else {
            self.yearFilter = self.filters[indexPath.row - 1];
            [self fetchReportsAndClearResults:YES];
        }
    } else {
        id<AWSDKVisitReport> report = self.visitReports[indexPath.row];
        [self fetchReportSummaryForReport:report forReconnect:NO];
    }

    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - IBActions
- (IBAction)loadMoreDocumentsPressed:(UIButton *)sender {
    [self fetchReportsAndClearResults:NO];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"reportSegue"]) {
        // Sets report for which report summary
        [(VisitReportSummaryViewController *)segue.destinationViewController setSummary:sender[@"summary"]];
    }
}

@end
