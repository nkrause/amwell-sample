//
//  MyFollowUpItemsTableViewController.h
//  AWSDKSample
//
//  Created by Caleb Lindsey on 6/1/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface MyFollowUpItemsTableViewController : UITableViewController

@end
