//
//  PharmacyTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/13/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "PharmacyTableViewController.h"

#import "FieldTableViewCell.h"
#import "PharmacySearchViewController.h"
#import "PickerTableViewCell.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKAddress.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKCountry.h>
#import <AWSDK/AWSDKEnrollmentService.h>
#import <AWSDK/AWSDKPharmacy.h>
#import <AWSDK/AWSDKState.h>
#import <AWSDK/NSError+AWSDKError.h>

typedef NS_ENUM(NSUInteger, Sections) {
    PreferredSection,
    NonPreferredSection,
};

/**
 *  Displays information regarding pharmacies related to the consumer
 *  PreferredPharmacy appears first and in bold type
 */
@interface PharmacyTableViewController () <PharmacySearchDelegate, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource>

@property (nonatomic) UITextField *address1Field;
@property (nonatomic) UITextField *address2Field;
@property (nonatomic) UITextField *cityField;
@property (nonatomic) UITextField *zipField;
@property (nonatomic) UIPickerView *statePicker;
@property (nonatomic) UIPickerView *countryPicker;

@property (nonatomic) NSMutableArray<NSArray<NSString *> *> *pharmacyDisplayFields;
@property (nonatomic) NSMutableArray<id<AWSDKPharmacy>> *pharmacyObjects;
@property (nonatomic) AWSDKAddress *shippingAddress;
@property (nonatomic) NSMutableArray<NSString *> *displayFields;
@property (nonatomic) NSArray<id<AWSDKCountry>> *countries;

@property (assign, atomic) BOOL updatePharmacyRequired;
@property (assign, atomic) BOOL updateShippingAddressRequired;
@property (assign, atomic) BOOL fetchedShippingAddress;

@property (nonatomic) UIActivityIndicatorView *activityIndicator;

@property (nonatomic) ErrorService *errorService;

@end

static int const kEstimatedRowHeight = 10.0;
static int const kHeaderHeight = 15.0;
static int const kFooterHeight = 15.0;
static int const kSeparatorHeight = 2.0;
static int const kPickerCellHeight = 167.0;
static int const kFieldCellHeight = 61.0;
static int const kNumberOfAddressRows = 6;

@implementation PharmacyTableViewController

#pragma mark - AWSDK Pharmacy Method Calls
/**
 *  Fetches all pharmacies for the current consumer and reloads the table to display.
 */
- (void)fetchPharmacies {
    __weak typeof(self) weakSelf = self;
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    [MBProgressHUD showLoadingOn:self.view];
    [consumer fetchPharmaciesWithCompletion:^void(id results, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (error) {
            // As implemented, the server will return an error if there is no preferred pharmacy, rather than HTTP 204
            if (error.domain != AWSDKErrorDomainSDK) {
                [weakSelf presentAlertWithError:error okHandler:nil];
            }
        } else {
            [weakSelf.pharmacyObjects removeAllObjects];
            weakSelf.pharmacyObjects = results;
            [weakSelf refreshTableViewWithUpdatedPharmacyObjects];
        }
    }];
}

- (void)refreshTableViewWithUpdatedPharmacyObjects {
    [self.pharmacyDisplayFields removeAllObjects];
    // Enumerate over pharmacy objects
    for (id<AWSDKPharmacy> pharmacy in self.pharmacyObjects) {
        [self updatePharmacyDisplayFieldsWithPharmacy:pharmacy];
    }
    [self.tableView reloadData];
    self.editButtonItem.enabled = self.pharmacyObjects.firstObject.isMailOrder;
}

/**
 *  Update the pharmacy with the selected cell
 */
- (void)updatePharmacy:(id<AWSDKPharmacy>)pharmacy withCompletion:(GenericCompletionBlock)completion {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    [MBProgressHUD showUpdatingOn:self.view];
    [consumer updatePreferredPharmacy:pharmacy
                       withCompletion:^(BOOL success, NSError *error) {
                           [MBProgressHUD hideHUDForView:self.view];
                           completion(success, error);
                       }];
}

#pragma mark - AWSDK Shipping Address Method Calls

- (void)fetchShippingAddress {
    __weak typeof(self) weakSelf = self;
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    [MBProgressHUD showLoadingOn:self.view];
    [consumer getShippingAddress:^(id result, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (error) {
            weakSelf.shippingAddress = nil;
            // As implemented, the server will return an error if there is no shipping address, rather than HTTP 204
            if (error.domain != AWSDKErrorDomainSDK) {
                [weakSelf presentAlertWithError:error okHandler:nil];
            }
        } else {
            weakSelf.fetchedShippingAddress = YES;
            weakSelf.shippingAddress = result;
            [weakSelf.tableView reloadDataAnimated:YES];
        }
    }];
}

- (void)updateShippingAddress:(GenericCompletionBlock)completion {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    if (!self.shippingAddress) {
        self.shippingAddress = [AWSDKAddress address];
    }
    // Update current shipping address object with fields
    self.shippingAddress.addressOne = self.address1Field.text;
    self.shippingAddress.addressTwo = self.address2Field.text;
    self.shippingAddress.city = self.cityField.text;
    self.shippingAddress.zip = self.zipField.text;
    self.shippingAddress.state = [self selectedState];
    self.shippingAddress.country = [self selectedCountry];

    // Update using the same shipping address object
    [MBProgressHUD showUpdatingOn:self.view];
    [consumer updateShippingAddress:self.shippingAddress
                         completion:^(BOOL success, NSError *error) {
                             [MBProgressHUD hideHUDForView:self.view];
                             completion(success, error);
                         }];
}

#pragma mark - PharmacySearchDelegate
/**
 *  Receives signal to refresh the DataSource to reflect new PreferredPharmacy added
 */
- (void)didSelectPharmacy:(id<AWSDKPharmacy>)pharmacy;
{
    __weak typeof(self) weakSelf = self;
    [self.pharmacyObjects removeAllObjects];
    [self.pharmacyDisplayFields removeAllObjects];

    if (pharmacy.isMailOrder) {
        // If a mail order pharmacy is selected, enter edit mode
        [self setUpdatePharmacyRequired:YES];
        [self setEditing:YES];
        [self.pharmacyObjects addObject:pharmacy];
        [self refreshTableViewWithUpdatedPharmacyObjects];
    } else {
        // Otherwise, update server with new preferred pharmacy and fetch the phamacies again
        void (^pharmacyBlock)(BOOL success, NSError *error) = ^void(BOOL success, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view];
            [weakSelf.errorService handleError:error];
            if (success) {
                [weakSelf setUpdatePharmacyRequired:NO];
                [weakSelf fetchPharmacies];
            }
        };

        [MBProgressHUD showUpdatingOn:self.view];
        [self updatePharmacy:pharmacy withCompletion:pharmacyBlock];
    }
}

//-----------------------------------------------------------------------------------------------------//
//---------------Everything beyond here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.countries = AWSDKEnrollmentService.countries;
    self.navigationItem.rightBarButtonItem = self.editButtonItem;

    self.pharmacyDisplayFields = [NSMutableArray new];

    self.fetchedShippingAddress = NO;

    self.errorService = [[ErrorService alloc] initWithSender:self];
    [self fetchPharmacies];
    [self fetchShippingAddress];
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
    AWSDKLogInfo(@"Tableview editing %@", editing ? @"began" : @"ended");
    __weak typeof(self) weakSelf = self;
    void (^successBlock)(void) = ^void() {
        [super setEditing:editing animated:animated];

        [weakSelf.address1Field setUserInteractionEnabled:editing];
        [weakSelf.address2Field setUserInteractionEnabled:editing];
        [weakSelf.cityField setUserInteractionEnabled:editing];
        [weakSelf.zipField setUserInteractionEnabled:editing];
        [weakSelf.statePicker setUserInteractionEnabled:editing];

        [weakSelf.tableView reloadDataAnimated:animated];
    };

    void (^pharmacyBlock)(BOOL success, NSError *error) = ^void(BOOL success, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        [weakSelf.errorService handleError:error];
        if (success) {
            [weakSelf setUpdatePharmacyRequired:NO];
            [weakSelf fetchPharmacies];
            successBlock();
        }
    };

    // Toggle interaction
    if (!editing) {
        if (self.updateShippingAddressRequired) {
            [self.errorService clearErrors];
            [self updateShippingAddress:^(BOOL success, NSError *error) {
                [MBProgressHUD hideHUDForView:self.view];
                [weakSelf.errorService handleError:error];

                if (success) {
                    [weakSelf setUpdateShippingAddressRequired:NO];

                    if ([weakSelf updatePharmacyRequired]) {
                        [weakSelf updatePharmacy:weakSelf.pharmacyObjects.firstObject withCompletion:pharmacyBlock];
                    } else {
                        successBlock();
                    }
                }
            }];
        } else if (self.updatePharmacyRequired) {
            [self updatePharmacy:self.pharmacyObjects.firstObject withCompletion:pharmacyBlock];
        } else {
            successBlock();
        }
    } else {
        successBlock();
    }
}

#pragma mark - Helpers
- (id<AWSDKCountry>)selectedCountry {
    return self.countries[[self.countryPicker selectedRowInComponent:0]];
}
- (id<AWSDKState>)selectedState {
    return [self selectedCountry].enrollmentStates[[self.statePicker selectedRowInComponent:0]];
}

#pragma mark - UITableViewDataSource
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == self.pharmacyObjects.count + 1) {
        return indexPath.row == 3 ? kPickerCellHeight : kFieldCellHeight;
    }
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return kEstimatedRowHeight;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSInteger sections;
    if (self.pharmacyObjects.count) {
        sections = (self.pharmacyObjects.firstObject.isMailOrder) ? self.pharmacyObjects.count + 1 : self.pharmacyObjects.count;
    } else {
        sections = 1;
    }
    return sections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger rows;
    if (section < self.pharmacyObjects.count) {
        // Get row count for pharmacy
        NSArray<NSString *> *thisPharm = self.pharmacyDisplayFields[section];
        rows = thisPharm.count;
    } else {
        // Get row count for shipping fields
        rows = (self.shippingAddress || self.editing ? kNumberOfAddressRows : 1);
    }
    return rows;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section < self.pharmacyObjects.count) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:(indexPath.section == 0) ? @"preferredCell" : @"cell" forIndexPath:indexPath];

        NSMutableArray<NSString *> *displayFieldArray;
        displayFieldArray = (self.pharmacyDisplayFields.count) ? self.pharmacyDisplayFields[indexPath.section] : @[ NSLocalizedString(@"alert.loading", @"Placeholder cell - Loading") ].copy;
        cell.textLabel.text = displayFieldArray[indexPath.row];
        cell.textLabel.numberOfLines = 0;
        cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;

        return cell;
    } else {
        switch (indexPath.row) {
            case 0: {
                PickerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"countryCell"];
                if (!self.countryPicker) {
                    self.countryPicker = cell.picker;
                }
                NSInteger index = [self.countries indexOfObject:self.shippingAddress.country];
                if (self.countryPicker && index && index < [self.countryPicker numberOfRowsInComponent:0]) {
                    [self.countryPicker selectRow:index inComponent:0 animated:NO];
                }
                [self.countryPicker setUserInteractionEnabled:self.editing];
                return cell;
            }
            case 1: {
                if (self.shippingAddress || self.editing) {
                    FieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"address1Cell"];
                    if (!self.address1Field) {
                        [cell.textField setText:self.shippingAddress.addressOne];
                        [cell.textField setUserInteractionEnabled:self.editing];
                    }
                    [self setAddress1Field:cell.textField];

                    [self.errorService addObserver:cell forKeyPath:@"addressOne"];
                    [self.errorService addObserver:cell forKeyPath:@"shippingAddress"];
                    return cell;
                }
                UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
                if (self.fetchedShippingAddress) {
                    [cell.textLabel setText:NSLocalizedString(@"shippingAddress.none", @"Placeholder cell - No shipping address on file")];
                } else {
                    [cell.textLabel setText:NSLocalizedString(@"alert.loading", @"Placeholder cell - Loading")];
                }
                return cell;
            }
            case 2: {
                FieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"address2Cell"];
                if (!self.address2Field) {
                    [cell.textField setText:self.shippingAddress.addressTwo];
                    [cell.textField setUserInteractionEnabled:self.editing];
                }
                [self setAddress2Field:cell.textField];

                [self.errorService addObserver:cell forKeyPath:@"addressTwo"];
                [self.errorService addObserver:cell forKeyPath:@"shippingAddress"];
                return cell;
            }
            case 3: {
                FieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cityCell"];
                if (!self.cityField) {
                    [cell.textField setText:self.shippingAddress.city];
                    [cell.textField setUserInteractionEnabled:self.editing];
                }
                [self setCityField:cell.textField];
                [self.errorService addObserver:cell forKeyPath:@"city"];
                [self.errorService addObserver:cell forKeyPath:@"shippingAddress"];
                return cell;
            }
            case 4: {
                PickerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"stateCell"];
                if (!self.statePicker) {
                    [self setStatePicker:cell.picker];

                    [self.errorService addObserver:cell forKeyPath:@"state"];
                    [self.errorService addObserver:cell forKeyPath:@"shippingAddress"];

                    [self.statePicker setUserInteractionEnabled:self.editing];

                    NSInteger index = [[self selectedCountry].enrollmentStates indexOfObject:self.shippingAddress.state];
                    if (self.statePicker && index && index < [self.statePicker numberOfRowsInComponent:0]) {
                        [self.statePicker selectRow:index inComponent:0 animated:NO];
                    }
                }
                return cell;
            }
            case 5: {
                FieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"zipCell"];
                if (!self.zipField) {
                    [cell.textField setText:self.shippingAddress.zip];
                    [cell.textField setUserInteractionEnabled:self.editing];
                }
                [self setZipField:cell.textField];
                [self.errorService addObserver:cell forKeyPath:@"zip"];
                [self.errorService addObserver:cell forKeyPath:@"shippingAddress"];
                return cell;
            }
        }
    }
    return [UITableViewCell new];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return (section == NonPreferredSection) ? kHeaderHeight : 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    // Only use footer for separator
    return (section == PreferredSection) ? kFooterHeight : 0;
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
    if (section == NonPreferredSection && [view isMemberOfClass:[UITableViewHeaderFooterView class]]) {
        ((UITableViewHeaderFooterView *)view).backgroundView.backgroundColor = [UIColor whiteColor];
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, kFooterHeight)];
    if (section == PreferredSection) {
        // Separator line added to footer so that is scrolls up with the first section
        // White is added to surround the separator with a white padding between sections
        UIView *separatorView = [[UIView alloc] initWithFrame:CGRectMake(kFooterHeight, kFooterHeight - kSeparatorHeight, tableView.bounds.size.width - kFooterHeight * 2, kSeparatorHeight)];
        footerView.backgroundColor = [UIColor whiteColor];
        separatorView.backgroundColor = [UIColor lightGrayColor];
        separatorView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [footerView addSubview:separatorView];
    }
    return footerView;
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleNone;
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    [self setUpdateShippingAddressRequired:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == self.address1Field) {
        [self.address2Field becomeFirstResponder];
    } else if (textField == self.address2Field) {
        [self.cityField becomeFirstResponder];
    } else {
        [textField resignFirstResponder];
    }
    return YES;
}

#pragma mark - UIPickerViewDataSource
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *label = (UILabel *)view;
    if (!label) {
        label = [[UILabel alloc] init];
        [label setFont:[UIFont systemFontOfSize:19.0 weight:UIFontWeightLight]];
        [label setTextAlignment:NSTextAlignmentNatural];
        [label setAdjustsFontSizeToFitWidth:YES];
        [label setNumberOfLines:0];
    }
    if (pickerView == self.statePicker) {
        label.text = [self selectedCountry].enrollmentStates[row].name;
    } else if (pickerView == self.countryPicker) {
        label.text = self.countries[row].name;
    }
    // Set Text
    return label;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return pickerView == self.statePicker ? [self selectedCountry].enrollmentStates.count : self.countries.count;
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

#pragma mark - UIPickerViewDelegate
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (pickerView == self.countryPicker) {
        AWSDKLogInfo(@"Selected country: %@", [self selectedCountry].name);
        [self.statePicker reloadAllComponents];
    } else if (pickerView == self.statePicker) {
        AWSDKLogInfo(@"Selected state: %@", [self selectedState].name);
    }
    [self setUpdateShippingAddressRequired:YES];
}
#pragma mark - Setters
// Builds an array of cell field display strings from an AWSDKPharmacy object and adds it to the pharmacyDisplayFields array.
- (void)updatePharmacyDisplayFieldsWithPharmacy:(id<AWSDKPharmacy>)pharmacy {
    NSMutableString *fieldsString = [NSMutableString new];
    NSMutableArray *fields = [NSMutableArray new];
    if (pharmacy == nil) {
        [fields addObject:NSLocalizedString(@"pharmacy.none", @"Placeholder cell - No pharmacy on file")];
    } else {
        NSString *nameField = [NSString stringWithFormat:@"%@ %@",
                                        pharmacy.name,
                                        (pharmacy.isMailOrder) ? NSLocalizedString(@"pharmacySearch.mailOrder", @"Table section title - Mail-order pharmacies")
                                                               : NSLocalizedString(@"pharmacy.retail", @"(Retail) with parenthesis")];
        [fieldsString appendString:nameField];

        if (pharmacy.address.displayString) {
            [fieldsString appendString:[NSString stringWithFormat:@"\n%@", pharmacy.address.displayString]];
        }

        if (pharmacy.contactPhone) {
            [fieldsString appendFormat:@"\n%@", [NSString stringWithFormat:NSLocalizedString(@"pharmacy.phone", @"Format string: p(phone abbreviation): %@ (phone number)"), pharmacy.contactPhone]];
        }
        if (pharmacy.contactFax) {
            [fieldsString appendFormat:@"\n%@", [NSString stringWithFormat:NSLocalizedString(@"pharmacy.fax", @"Format string: f(fax abbreviation): %@ (fax number)"), pharmacy.contactFax]];
        }
        if (pharmacy.contactEmail) {
            [fieldsString appendString:[NSString stringWithFormat:@"\n%@", pharmacy.contactEmail]];
        }
    }
    [fields addObject:fieldsString.copy];
    [self.pharmacyDisplayFields addObject:fields];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    AWSDKLogInfo(@"Search button tapped");
    PharmacySearchViewController *searchViewController = [(UINavigationController *)segue.destinationViewController viewControllers][0];
    [searchViewController setDelegate:self];
}

@end
