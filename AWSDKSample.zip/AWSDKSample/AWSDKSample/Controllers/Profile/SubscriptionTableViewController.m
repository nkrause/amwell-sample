//
//  SubscriptionTableViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/17/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "SubscriptionTableViewController.h"

#import "DatePickerCell.h"
#import "ErrorService.h"
#import "FieldTableViewCell.h"
#import "ImageViewController.h"
#import "NSDateFormatter+CommonFormats.h"
#import "PickerTableViewCell.h"
#import "SwitchTableViewCell.h"
#import "UITableView+Sample.h"
#import "UITableViewController+CollapsiblePicker.h"
#import "UItextField+Compare.h"

#import <AWSDK/AWSDK.h>

typedef NS_ENUM(NSUInteger, formSections) {
    HasInsuranceSection,
    InsuranceSection,
    SubscriberSection,
};

typedef void (^UIAlertActionBlock)(UIAlertAction *action);

/**
 *  Displays cells containing information about the current Subscription if availabe. By entering the
 *  edit state, the user can update the subscription fields.
 */
@interface SubscriptionTableViewController () <UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate, UIPopoverPresentationControllerDelegate>

// Retains value for primaryDoBPicker
@property BOOL noInsuranceSelected;

// Retains the AWSDK DataObjects
@property (nonatomic, strong) id<AWSDKSubscription> subscription;
@property (nonatomic) id<AWSDKRelationshipToSubscriber> selectedRelationship;
@property (nonatomic) id<AWSDKHealthPlan> selectedHealthPlan;

// Set if subscription was marked as invalid, but should save anyway;
@property (assign, nonatomic) BOOL ignoreEligibility;

// List of available plans and relationships
@property (nonatomic) NSArray<id<AWSDKHealthPlan>> *healthPlans;
@property (nonatomic) NSArray<id<AWSDKRelationshipToSubscriber>> *relationships;

// Dictionary connecting AWSDKHealthPlan to UIImage
@property (nonatomic) NSMutableDictionary<NSString *, UIImage *> *cards;

/**
 *  Handles UI changes for errors
 */
@property (nonatomic) ErrorService *errorService;

@end

@implementation SubscriptionTableViewController

#pragma mark - AWSDK Method Calls
/**
 *  Fetches available Health Plans
 */
- (void)fetchAvailableHealthPlans {
    self.healthPlans = AWSDKHealthPlan.healthPlans;
    self.relationships = [AWSDKSubscriptionForm getRelationships];
    // Filter out relationships if the current user is a dependent
    if (![[ConsumerService sharedInstance] isParent]) {
        self.relationships = [self.relationships filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(id object, NSDictionary *bindings) {
            return [object isValidForMinor];
        }]];
    }
    // Reload Picker View
    [self.relationshipPicker reloadAllComponents];
    [self.healthPlanPicker reloadAllComponents];
    // Update Selection
    [self updatePickers];
}

/**
 *  Fetches the consumers healthPlan if one is available
 */
- (void)fetchConsumerHealthPlan {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    [consumer fetchHealthPlanSubscription:^(id<AWSDKSubscription> subscription, NSError *error) {
        if (error) {
            [self presentAlertWithError:error okHandler:nil];
        } else {
            if (!subscription) {
                self.noInsuranceSelected = YES;
            } else {
                self.subscription = subscription;
                self.selectedRelationship = [subscription relationshipToSubscriber];
                self.selectedHealthPlan = [subscription healthPlan];

                // Update selections
                [self updatePickers];
            }
            [self.tableView reloadDataAnimated:YES];
        }
    }];
}

/**
 *  Creates a new subscription and updates the consumer with it
 */
- (void)createAndUpdateConsumerHealthPlan:(SubscriptionCompletionBlock)completion {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    AWSDKSubscriptionForm *form = [AWSDKSubscriptionForm form];
    if (self.selectedHealthPlan == nil && self.healthPlans.count > 0) {
        self.selectedHealthPlan = self.healthPlans[([self.healthPlanPicker selectedRowInComponent:0])];
    }
    if (self.selectedRelationship == nil && self.relationships.count > 0) {
        self.selectedRelationship = self.relationships[([self.relationshipPicker selectedRowInComponent:0])];
    }
    [form setHealthPlan:self.selectedHealthPlan];

    [form setSubscriberID:self.subscriberIdField.text];
    [form setSubscriberSuffix:self.subscriberSuffixField.text];

    [form setRelationshipToSubscriber:self.selectedRelationship];

    if (!self.selectedRelationship.isPrimary) {
        [form setPrimarySubscriberFirstName:self.primaryFirstNameField.text];
        [form setPrimarySubscriberLastName:self.primaryLastNameField.text];
        [form setPrimarySubscriberDateOfBirth:[self.primaryDoBPicker date]];
    }

    // Set when subscription was marked as invalid by the health plan provider but consumer clicks to save anyway.
    [form setIgnoreEligibility:self.ignoreEligibility];

    // Validate subscriberID with healthPlan
    if (![self validSubscriberID]) {
        // Display custom error message if the system has one set
        if (form.healthPlan.validationErrorMessage) {
            [self presentAlertWithTitle:@"Validation Error" message:form.healthPlan.validationErrorMessage okHandler:nil];
        } else {
            [self presentAlertWithMessageKey:@"updateInsurance.subscriberID.invalid.plan" okHandler:nil];
        }
        return;
    }

    [MBProgressHUD showUpdatingOn:self.view];
    [consumer updateHealthPlanSubscription:form
                          withVisitContext:nil
                            withCompletion:^(_Nullable id<AWSDKSubscription> subscription, NSError *error) {
                                [MBProgressHUD hideHUDForView:self.view];
                                completion(subscription, error);
                            }];
}

/**
 *  The consumer removed their plan, and is updated with no plan
 */
- (void)updateConsumerWithNoHealthPlan:(SubscriptionCompletionBlock)completion {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    [MBProgressHUD showUpdatingOn:self.view];
    [consumer updateHealthPlanSubscription:nil
                          withVisitContext:nil
                            withCompletion:^(_Nullable id<AWSDKSubscription> subscription, NSError *error) {
                                [MBProgressHUD hideHUDForView:self.view];
                                completion(subscription, error);
                            }];
}

/**
 *  Regex from server to validate a subscriberID
 *
 *  @return True if self.subscriberIdField conforms to the regex
 */
- (BOOL)validSubscriberID {
    id<AWSDKHealthPlan> plan = self.healthPlans[([self.healthPlanPicker selectedRowInComponent:0])];

    NSString *iD = self.subscriberIdField.text;
    if (plan.validationRegex && ![iD isEqualToString:@""]) {
        if ([iD rangeOfString:plan.validationRegex options:NSRegularExpressionSearch].location != NSNotFound) {
            return YES;
        } else {
            [self setEditing:YES animated:YES];
            return NO;
        }
    }
    return YES;
}

//-----------------------------------------------------------------------------------------------------//
//---------------Everything beyond here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    [self.tableView setRowHeight:UITableViewAutomaticDimension];
    [self.tableView setEstimatedRowHeight:44.0];

    // Only allow non feed members to edit insurance information
    if ([[[ConsumerService sharedInstance] consumer] wasFeedGenerated]) {
        self.navigationItem.rightBarButtonItem = nil;
    } else {
        self.navigationItem.rightBarButtonItem = self.editButtonItem;
    }

    self.cards = [NSMutableDictionary new];

    [self fetchConsumerHealthPlan];
    [self fetchAvailableHealthPlans];

    self.errorService = [[ErrorService alloc] initWithSender:self];
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
    AWSDKLogInfo(@"Tableview edit mode %@", editing ? @"enabled" : @"disabled");
    // Block to adjust editing state. Not called when updating a consumer health plan has an error.
    void (^successBlock)(void) = ^void() {
        [super setEditing:editing animated:animated];

        [self.noInsuranceSwitch setHidden:!editing];
        [self.noInsuranceSwitch setUserInteractionEnabled:editing];
        [self.healthPlanPicker setUserInteractionEnabled:editing];
        [self.relationshipPicker setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && editing];
        [self.primaryDoBPicker setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && editing];
        [self.subscriberSuffixField setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && editing];
        [self.subscriberIdField setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && editing];
        [self.primaryFirstNameField setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && editing];
        [self.primaryLastNameField setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && editing];

        [self fetchConsumerHealthPlan];
    };

    if (!editing) {
        // Attempt to apply health plan
        // Apply no health plan
        if (self.noInsuranceSelected) {
            [self.errorService clearErrors];
            [self updateConsumerWithNoHealthPlan:^(id result, NSError *error) {
                [MBProgressHUD hideHUDForView:self.view];
                [self.errorService handleError:error];

                if (!error) {
                    successBlock();
                }
            }];
            // Apply new health plan
        } else {
            [self.errorService clearErrors];
            [self createAndUpdateConsumerHealthPlan:^(id result, NSError *error) {
                [MBProgressHUD hideHUDForView:self.view];

                if (error) {
                    // Check if subscription is invalid.
                    NSArray *acceptableErrorCodes =
                        @[ @(AWSDKErrorCodeValidationEligibilityException),
                           @(AWSDKErrorCodeEligibilityInaccuratePrimarySubscriberInfo),
                           @(AWSDKErrorCodeValidationBadEligibilityInformation) ];
                    if ([acceptableErrorCodes containsObject:@(error.code)]) {
                        // Subscription info is not saved, but can be still saved if bypassed.
                        UIAlertController *ac = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"updateInsurance.eligibilityCheckFail.title", @"Eligibility Check Failed title")
                                                                                    message:NSLocalizedString(@"updateInsurance.eligibilityCheckFail.message", @"Eligibility Check Failed message")];

                        UIAlertActionBlock saveBlock = ^(UIAlertAction *action) {
                            // Overrides ignore eligbilty and calls setEditing to trigger createAndUpdateConsumerHealthPlan call again
                            [self setIgnoreEligibility:YES];
                            [self setEditing:NO animated:NO];
                            return;
                        };
                        UIAlertActionBlock cancelBlock = ^(UIAlertAction *action) {
                            return;
                        };

                        [ac addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.save.anyway", @"Subscription Alert Save")
                                                                       style:UIAlertActionStyleDefault
                                                                     handler:[ac defaultAlertHandler:saveBlock]]];
                        [ac addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.cancel", @"Subscription Alert Cancel")
                                                                         style:UIAlertActionStyleCancel
                                                                       handler:[ac defaultAlertHandler:cancelBlock]]];
                        [self presentAlertController:ac];

                    } else {
                        [self.errorService handleError:error];
                    }
                }

                if (result) {
                    // Set back to default
                    [self setIgnoreEligibility:NO];
                    successBlock();
                }
            }];
        }
    } else {
        successBlock();
    }
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if ([cell isKindOfClass:[FieldTableViewCell class]]) {
        // Check for other open cells
        UITextField *cellField = ((FieldTableViewCell *)cell).textField;
        [cellField becomeFirstResponder];
    } else {
        [self dismissKeyboard];
    }
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if ([cell isKindOfClass:[PickerTableViewCell class]]) {
        // Present card popover
        [self performSegueWithIdentifier:@"imageSegue" sender:cell];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    // Reduce height just enough to display the header label on InsuranceSection when the HasInsuranceSection is hidden
    // Tableview background color is the same as header background.
    if (section == InsuranceSection && !self.noInsuranceSelected) {
        return 0.0f;
    }
    return -1;
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.noInsuranceSelected) {
        return 1;
    } else if (!self.selectedHealthPlan.showPrimarySubscriberQuestion) {
        return 2;
    } else {
        return 3;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case HasInsuranceSection:
            return self.editing || self.noInsuranceSelected ? 1 : 0;
            break;
        case InsuranceSection:
            return 2 + [self.selectedHealthPlan usesSuffix];
            break;

        case SubscriberSection:
            if (!self.selectedRelationship.isPrimary && self.selectedRelationship) {
                return 4;
            } else {
                return 1;
            }
        default:
            break;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case HasInsuranceSection: {
            SwitchTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"switchCell"];

            self.noInsuranceSwitch = [cell toggle];
            [self.noInsuranceSwitch setHidden:!self.editing];
            [self.noInsuranceSwitch setUserInteractionEnabled:self.editing];
            [self.noInsuranceSwitch setOn:self.noInsuranceSelected];
            [self.noInsuranceSwitch addTarget:self action:@selector(didUpdateInsuranceSwitch:) forControlEvents:UIControlEventValueChanged];

            [[cell label] setText:NSLocalizedString(@"updateInsurance.noInsurance", @"Subscription Update Insurance Without Insurance")];

            return cell;
        }
        case InsuranceSection: {
            if (indexPath.row == 0) {
                PickerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"healthPlan"];

                self.healthPlanPicker = [cell picker];
                [self.healthPlanPicker setUserInteractionEnabled:self.editing];

                if (!self.selectedHealthPlan) {
                    self.selectedHealthPlan = [self.healthPlans firstObject];
                }
                if (!self.editing) {
                    [self.healthPlanPicker selectRow:[self.healthPlans indexOfObject:self.selectedHealthPlan] inComponent:0 animated:NO];
                }

                [cell.label setText:NSLocalizedString(@"updateInsurance.insuranceProvider", @"Subscription Update Insurance Provider")];

                // Check if a cardImage is available, if one is show accessory
                UIImage *card = [self.cards objectForKey:self.selectedHealthPlan.name];
                [cell setEditingAccessoryType:card ? UITableViewCellAccessoryDetailButton : UITableViewCellAccessoryNone];

                [self.errorService addObserver:cell forKeyPath:cell.reuseIdentifier];

                return cell;

            } else if (indexPath.row == 1) {
                FieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"subscriberID"];

                self.subscriberIdField = [cell textField];
                [self.subscriberIdField setUserInteractionEnabled:self.editing];

                if (!self.editing) {
                    [self.subscriberIdField setText:self.subscription.subscriberID];
                }

                [cell.textField setPlaceholder:NSLocalizedString(@"updateInsurance.subscriberID", @"Subscription Update Insurance")];

                [self.errorService addObserver:cell forKeyPath:cell.reuseIdentifier];

                return cell;

            } else if (indexPath.row == 2) {
                FieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"subscriberSuffix"];

                self.subscriberSuffixField = [cell textField];
                [self.subscriberSuffixField setUserInteractionEnabled:self.editing];

                if (!self.editing) {
                    [self.subscriberSuffixField setText:self.subscription.subscriberSuffix];
                }

                [cell.textField setPlaceholder:NSLocalizedString(@"updateInsurance.subscriberSuffix", @"Subscription Update Insurance Subscriber Suffix")];

                [self.errorService addObserver:cell forKeyPath:cell.reuseIdentifier];

                return cell;
            }
        }
        case SubscriberSection: {
            if (indexPath.row == 0) {
                PickerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"relationshipToSubscriber"];

                self.relationshipPicker = cell.picker;
                [self.relationshipPicker setUserInteractionEnabled:self.editing];

                if (!self.selectedRelationship) {
                    self.selectedRelationship = [self.relationships firstObject];
                } else {
                    [self.relationshipPicker selectRow:[self.relationships indexOfObject:self.selectedRelationship] inComponent:0 animated:NO];
                }

                [self.errorService addObserver:cell forKeyPath:cell.reuseIdentifier];

                return cell;

            } else if (indexPath.row == 1) {
                FieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"primarySubscriberFirstName"];

                self.primaryFirstNameField = [cell textField];
                if (!self.editing) {
                    [self.primaryFirstNameField setText:self.subscription.primarySubscriberFirstName];
                }
                [self.primaryFirstNameField setUserInteractionEnabled:self.editing];

                [cell.textField setPlaceholder:NSLocalizedString(@"updateInsurance.firstName", @"Subscription Update Insurance FirstName")];

                [self.errorService addObserver:cell forKeyPath:cell.reuseIdentifier];

                return cell;

            } else if (indexPath.row == 2) {
                FieldTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"primarySubscriberLastName"];

                self.primaryLastNameField = [cell textField];
                if (!self.editing) {
                    [self.primaryLastNameField setText:self.subscription.primarySubscriberLastName];
                }
                [self.primaryLastNameField setUserInteractionEnabled:self.editing];

                [cell.textField setPlaceholder:NSLocalizedString(@"updateInsurance.lastName", @"Subscription Update Insurance LastName")];

                [self.errorService addObserver:cell forKeyPath:cell.reuseIdentifier];

                return cell;

            } else if (indexPath.row == 3) {
                DatePickerCell *cell = [tableView dequeueReusableCellWithIdentifier:@"primarySubscriberDateOfBirth"];

                if (!self.primaryDoBPicker) {
                    self.primaryDoBPicker = [cell datePicker];
                    self.primaryDoBPicker.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
                    if (self.subscription.primarySubscriberDateOfBirth)
                        self.primaryDoBPicker.date = self.subscription.primarySubscriberDateOfBirth;
                    [self.primaryDoBPicker setMaximumDate:[NSDate date]];
                }
                [self.primaryDoBPicker setUserInteractionEnabled:self.editing];

                [self.errorService addObserver:cell forKeyPath:cell.reuseIdentifier];

                return cell;
            }
        }
    }
    AWSDKLogWarn(@"Unexpected index path");
    return [UITableViewCell new];
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleNone;
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == HasInsuranceSection) {
        return nil;
    } else if (section == InsuranceSection) {
        return NSLocalizedString(@"updateInsurance.subscriptionInformation", @"Subscription Update Insurance Information Title");
    } else if (section == SubscriberSection) {
        return NSLocalizedString(@"updateInsurance.subscriberInformation", @"Subscription Update Insurance Subscriber Title");
    }
    return nil;
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return pickerView == self.healthPlanPicker ? self.healthPlans.count : self.relationships.count;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *label = (UILabel *)view;
    if (!label) {
        label = [[UILabel alloc] init];
        [label setFont:[UIFont systemFontOfSize:19.0 weight:UIFontWeightLight]];
        [label setTextAlignment:NSTextAlignmentNatural];
        [label setAdjustsFontSizeToFitWidth:YES];
        [label setNumberOfLines:0];
        if (pickerView == self.healthPlanPicker) {
            [label setTextColor:([self.healthPlans[row] enrollmentEnabled] ? [UIColor darkTextColor] : [UIColor lightGrayColor])];
        }
    }

    // Set Text
    [label setText:(pickerView == self.healthPlanPicker ? [self.healthPlans[row] name] : [self.relationships[row] title])];
    return label;
}

#pragma mark - UIPickerViewDelegate
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (pickerView == self.relationshipPicker) {
        self.selectedRelationship = self.relationships[row];
        AWSDKLogInfo(@"Selected %@ in %@ picker", self.selectedRelationship.title, @"Relationship");
    } else if (pickerView == self.healthPlanPicker) {
        self.selectedHealthPlan = self.healthPlans[row];
        if (!self.selectedHealthPlan.enrollmentEnabled) {
            [self presentAlertWithMessageKey:@"updateInsurance.enrollmentEnabled.disabled" okHandler:nil];
        }
        [self.relationshipPicker setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && self.editing];
        [self.primaryDoBPicker setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && self.editing];
        [self.subscriberSuffixField setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && self.editing];
        [self.subscriberIdField setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && self.editing];
        [self.primaryFirstNameField setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && self.editing];
        [self.primaryLastNameField setUserInteractionEnabled:self.selectedHealthPlan.enrollmentEnabled && self.editing];
        AWSDKLogInfo(@"Selected %@ in %@ picker", self.selectedHealthPlan.name, @"Health Plan");
    }
    [self.editButtonItem setEnabled:[self validateFields:nil]];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self.editButtonItem setEnabled:[self validateFields:nil]];
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    [self.editButtonItem setEnabled:[self validateFields:textField] && string.length];

    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    textField.text = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    AWSDKLogInfo(@"%@ did end editing with value: %@", textField.placeholder, textField.text);
}

#pragma mark - Observers and Setters
- (void)didUpdateInsuranceSwitch:(id)sender {
    [self setNoInsuranceSelected:self.noInsuranceSwitch.on];
    if (!self.noInsuranceSelected && !self.subscription) {
        self.navigationItem.rightBarButtonItem = self.editButtonItem;
    }
    [self.tableView reloadDataAnimated:YES];
    [self.editButtonItem setEnabled:[self validateFields:nil]];
}

- (void)setSelectedHealthPlan:(id<AWSDKHealthPlan>)selectedHealthPlan {
    _selectedHealthPlan = selectedHealthPlan;

    // Check if health plan has a card, if not get one
    if (![self.cards valueForKey:selectedHealthPlan.name]) {
        if (selectedHealthPlan.hasCardImage) {
            [selectedHealthPlan getCardImage:^(id image, NSError *error) {
                if (!error) {
                    [self.cards setValue:image forKey:selectedHealthPlan.name];
                }
                [self.tableView reloadDataAnimated:YES];
            }];
        } else {
            [self.tableView reloadDataAnimated:YES];
        }
    } else {
        [self.tableView reloadDataAnimated:YES];
    }
}

- (void)setSelectedRelationship:(id<AWSDKRelationshipToSubscriber>)selectedRelationship {
    _selectedRelationship = selectedRelationship;

    [self.tableView reloadDataAnimated:NO];
}

#pragma mark - Helper Methods
- (BOOL)validateFields:(UITextField *)changingTextField {
    if (!self.noInsuranceSelected) {
        if (self.subscriberIdField != changingTextField && ![self.subscriberIdField isPopulated]) {
            return NO;
        }
        if ([self.selectedHealthPlan usesSuffix]) {
            if (self.subscriberSuffixField != changingTextField && ![self.subscriberSuffixField isPopulated]) {
                return NO;
            }
        }
        if (!self.selectedRelationship.isPrimary) {
            if (self.primaryFirstNameField != changingTextField && ![self.primaryFirstNameField isPopulated]) {
                return NO;
            }
            if (self.primaryLastNameField != changingTextField && ![self.primaryLastNameField isPopulated]) {
                return NO;
            }
        }
    }
    return YES;
}

- (void)updatePickers {
    // Select current relationship if available
    if (self.subscription.relationshipToSubscriber && self.relationships.count && self.relationshipPicker) {
        NSInteger index = [self.relationships indexOfObject:self.subscription.relationshipToSubscriber];
        if (index != NSNotFound && self.relationshipPicker) {
            [self.relationshipPicker selectRow:index inComponent:0 animated:NO];
        }
    }
    // Select current health plan if available
    if (self.subscription.healthPlan && self.healthPlans.count && self.healthPlanPicker) {
        NSInteger index = [self.healthPlans indexOfObject:self.subscription.healthPlan];
        if (index != NSNotFound && self.healthPlanPicker) {
            [self.healthPlanPicker selectRow:index inComponent:0 animated:NO];
        }
    }
    // Select subscribers date of birth if available
    if (self.subscription.primarySubscriberDateOfBirth && self.primaryDoBPicker) {
        self.primaryDoBPicker.date = self.subscription.primarySubscriberDateOfBirth;
    }
}

#pragma mark - UIPopoverPresentationControllerDelegate
- (UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    return YES;
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Health Plan Popover segue
    if ([segue.identifier isEqualToString:@"imageSegue"]) {
        // Popover settings
        [segue.destinationViewController.popoverPresentationController setDelegate:self];
        [segue.destinationViewController.popoverPresentationController setSourceView:sender];

        // Set Card Image
        UIImage *card = [self.cards valueForKey:self.selectedHealthPlan.name];
        [((ImageViewController *)segue.destinationViewController) setImage:card];
    }
}

@end
