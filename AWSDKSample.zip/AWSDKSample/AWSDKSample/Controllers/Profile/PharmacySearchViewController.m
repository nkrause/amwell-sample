//
//  PharmacySearchViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/17/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "PharmacySearchViewController.h"

#import "PharmacyResultTableViewCell.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKPharmacy.h>
#import <AWSDK/AWSDKPharmacyService.h>
#import <MobileCoreServices/MobileCoreServices.h>

/**
 *  PharmacySearchViewController fetches pharmacies based on zipCode and displays the results in
 *  the resultsTable.
 */
@interface PharmacySearchViewController () <CLLocationManagerDelegate>

@property (nonatomic) NSMutableArray *mailOrderPharmacies;
@property (nonatomic) NSMutableArray *generalPharmacies;

@property (nonatomic) CLLocationManager *locationManager;

@end

@implementation PharmacySearchViewController

#pragma mark - AWSDK Method Calls
/**
 *  Update the search results with a zipCode search
 *
 *  @param zipCode NSString for a partial or full zipCode
 */
- (void)fetchPharmaciesWithZipCode:(NSString *)zipCode {
    __weak typeof(self) weakSelf = self;

    // Clear results array
    [self.mailOrderPharmacies removeAllObjects];
    [self.generalPharmacies removeAllObjects];
    [self.resultsTable reloadDataAnimated:YES];

    [MBProgressHUD showLoadingOn:self.view];
    [AWSDKPharmacyService fetchPharmaciesWithZipCode:zipCode
                                          completion:^(NSArray *results, NSError *error) {
                                              [MBProgressHUD hideHUDForView:self.view];
                                              // Split up results for general and mail order
                                              for (id<AWSDKPharmacy> pharmacy in results) {
                                                  if (pharmacy.isMailOrder) {
                                                      [weakSelf.mailOrderPharmacies addObject:pharmacy];
                                                  } else {
                                                      [weakSelf.generalPharmacies addObject:pharmacy];
                                                  }
                                              }
                                              // Reload results
                                              [weakSelf.resultsTable reloadDataAnimated:YES];
                                          }];
}

- (void)fetchPharmaciesWithLocation:(CLLocation *)location {
    __weak typeof(self) weakSelf = self;

    // Clear results array
    [self.mailOrderPharmacies removeAllObjects];
    [self.generalPharmacies removeAllObjects];
    [self.resultsTable reloadDataAnimated:YES];

    // Create region with 50 miles
    // Note that CLCirulcarRegion uses meters as its radius, not miles
    CLCircularRegion *region = [[CLCircularRegion alloc] initWithCenter:location.coordinate radius:50 * 1609.344 identifier:@"region"];

    [MBProgressHUD showLoadingOn:self.view];
    // Fetch with region
    [AWSDKPharmacyService fetchPharmaciesWithRegion:region
                                         completion:^(NSArray *results, NSError *error) {
                                             [MBProgressHUD hideHUDForView:self.view];
                                             [weakSelf.locationButton setEnabled:YES];

                                             // Split up results for general and mail order
                                             for (id<AWSDKPharmacy> pharmacy in results) {
                                                 if (pharmacy.isMailOrder) {
                                                     [weakSelf.mailOrderPharmacies addObject:pharmacy];
                                                 } else {
                                                     [weakSelf.generalPharmacies addObject:pharmacy];
                                                 }
                                             }
                                             // Reload results
                                             [weakSelf.resultsTable reloadDataAnimated:YES];
                                         }];
}

//-----------------------------------------------------------------------------------------------------//
//---------------Everything beyond here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    [self setTitle:NSLocalizedString(@"pharmacySearch.title", @"Navigation title - Find pharmacy")];

    [self.searchBar setPlaceholder:NSLocalizedString(@"pharmacySearch.prompt", @"Navigation title - Enter a postal code")];

    UIToolbar *keyboardDoneButtonView = [[UIToolbar alloc] init];
    [keyboardDoneButtonView sizeToFit];
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"misc.done", @"Done barButtonItem")
                                                                   style:UIBarButtonItemStyleDone
                                                                  target:self
                                                                  action:@selector(doneClicked)];
    UIBarButtonItem *flexibleItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardDoneButtonView setItems:@[ flexibleItem, doneButton ]];
    [doneButton setTintColor:[UIColor aquaColor]];

    [self setupLocationManager];

    self.searchBar.inputAccessoryView = keyboardDoneButtonView;

    [self.resultsTable setRowHeight:UITableViewAutomaticDimension];
    [self.resultsTable setEstimatedRowHeight:138.0];

    self.generalPharmacies = [NSMutableArray new];
    self.mailOrderPharmacies = [NSMutableArray new];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidChangeFrame:) name:UIKeyboardDidChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillBeHidden:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];

    [super viewWillDisappear:animated];
}

#pragma mark - Keyboard Observers
// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardDidChangeFrame:(NSNotification *)aNotification {
    NSDictionary *info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;

    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    self.resultsTable.contentInset = contentInsets;
    self.resultsTable.scrollIndicatorInsets = contentInsets;
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification *)aNotification {
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    self.resultsTable.contentInset = contentInsets;
    self.resultsTable.scrollIndicatorInsets = contentInsets;
}

#pragma mark - UISearchBarDelegate
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
    if ([searchBar.text isEqualToString:NSLocalizedString(@"pharmacySearch.currentLocation", @"Search bar placeholder - Current location")]) {
        return NO;
    }
    return YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    if (![searchText isEqualToString:NSLocalizedString(@"pharmacySearch.currentLocation", @"Search bar placeholder - Current location")] && searchText.length == 5) {
        [self fetchPharmaciesWithZipCode:searchText];
        [searchBar resignFirstResponder];
    }
}

- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    NSString *newText = [searchBar.text stringByReplacingCharactersInRange:range withString:text];
    AWSDKLogInfo(@"Search bar text changed to: %@", newText);
    if (!text.length) {
        // User is deleting text
        return YES;
    } else if (newText.length > 5) {
        // New text is greater than 5 characters
        return NO;
    } else if ([newText rangeOfCharacterFromSet:[NSCharacterSet decimalDigitCharacterSet].invertedSet].location != NSNotFound) {
        // New text contains non-decimal characters
        return NO;
    } else {
        return YES;
    }
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return self.generalPharmacies.count > 0 ? self.generalPharmacies.count : 1;
    } else if (section == 1) {
        return self.mailOrderPharmacies.count > 0 ? self.mailOrderPharmacies.count : 1;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.generalPharmacies.count > 0 && indexPath.section == 0) {
        PharmacyResultTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"resultCell"];

        id<AWSDKPharmacy> pharmacy = self.generalPharmacies[indexPath.row];
        [cell handlePharmacy:pharmacy];

        return cell;
    } else if (self.mailOrderPharmacies.count > 0 && indexPath.section == 1) {
        PharmacyResultTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"resultCell"];

        id<AWSDKPharmacy> pharmacy = self.mailOrderPharmacies[indexPath.row];
        [cell handlePharmacy:pharmacy];

        return cell;
    } else {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"noResultsCell"];
        cell.textLabel.text = NSLocalizedString(@"pharmacySearch.noResults", @"No search results");
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    id<AWSDKPharmacy> pharmacy;
    if (self.generalPharmacies.count > 0 && indexPath.section == 0) {
        pharmacy = self.generalPharmacies[indexPath.row];
    } else if (self.mailOrderPharmacies.count > 0 && indexPath.section == 1) {
        pharmacy = self.mailOrderPharmacies[indexPath.row];
    }
    if (pharmacy) {
        AWSDKLogInfo(@"Selected pharmacy: %@", pharmacy.name);
        [self.delegate didSelectPharmacy:pharmacy];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return section == 0 ? NSLocalizedString(@"pharmacySearch.general", @"Table section title - Retail pharmacies")
                        : NSLocalizedString(@"pharmacySearch.mailOrder", @"Table section title - Mail-order pharmacies");
}

#pragma mark - Location Manager
- (void)setupLocationManager {
    self.locationManager = [CLLocationManager new];
    [self.locationManager setDelegate:self];
    [self.locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    [self.locationManager setDistanceFilter:kCLDistanceFilterNone];
    [self.locationManager requestWhenInUseAuthorization];
}

#pragma mark CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations {
    [manager stopUpdatingLocation];

    // Search by Cllocation
    [self fetchPharmaciesWithLocation:[locations lastObject]];
}

- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
    switch (status) {
        case kCLAuthorizationStatusDenied:
        case kCLAuthorizationStatusRestricted:
        case kCLAuthorizationStatusNotDetermined:
            [self showLocationButton:NO];
            break;
        default:
            [self showLocationButton:YES];
            break;
    }
}

- (void)showLocationButton:(BOOL)shouldShow {
    NSArray<UIBarButtonItem *> *barButtonItems = self.navigationItem.rightBarButtonItems;
    if (shouldShow) {
        if (![barButtonItems containsObject:self.locationButton]) {
            [self.navigationItem setRightBarButtonItems:[barButtonItems arrayByAddingObject:self.locationButton]];
        }
    } else {
        if ([barButtonItems containsObject:self.locationButton]) {
            NSMutableArray *items = barButtonItems.mutableCopy;
            [items removeObject:self.locationButton];
            [self.navigationItem setRightBarButtonItems:items];
        }
    }
}

#pragma mark - IBActions
- (void)doneClicked {
    [self.view endEditing:YES];
}

- (IBAction)cancelTapped:(id)sender {
    AWSDKLogInfo(@"Cancel button tapped");
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)locationButtonTapped:(id)sender {
    AWSDKLogInfo(@"Near Me button tapped");
    [self.locationButton setEnabled:NO];

    // Update to get a location
    [self.locationManager startUpdatingLocation];

    // Set textfield to show current location
    [self.searchBar setText:NSLocalizedString(@"pharmacySearch.currentLocation", @"Search bar placeholder - Current location")];
}

@end
