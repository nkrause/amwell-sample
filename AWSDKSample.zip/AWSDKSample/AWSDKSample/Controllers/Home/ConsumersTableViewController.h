//
//  ConsumersTableViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 4/7/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKConsumer;

/**
 Notifys when a consumer was selected, returning the consumer object
 */
@protocol ConsumersDelegate <NSObject>

- (void)didSelectConsumer:(id<AWSDKConsumer>)consumer;

@end

@interface ConsumersTableViewController : UITableViewController

@property (nonatomic, assign) id<ConsumersDelegate> delegate;

// Contains both primary consumer and dependents
@property (nonatomic, nonnull) NSMutableArray<id<AWSDKConsumer>> *consumers;

/**
 Used to set popover size the same as this contentSize
 */
@property (nonatomic, assign) CGSize contentSize;

@end
