//
//  HomeViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 8/5/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "HomeViewController.h"

#import "AppDelegate.h"
#import "CategoryViewController.h"
#import "ConsumersTableViewController.h"
#import "DisclaimerViewController.h"
#import "ImageCollectionViewCell.h"
#import "InProgressVisitViewController.h"
#import "LoginViewController.h"
#import "NSPersonNameComponents+Localizing.h"
#import "NotificationsTableViewController.h"
#import "ProvidersTableViewController.h"
#import "RefreshControl.h"
#import "ShareDependentTableViewController.h"
#import "TelehealthNotificationService.h"
#import "VisitContextTableViewController.h"
#import "VisitSummaryTableViewController.h"

#import <AWSDK/AWSDKAppointment.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKConsumerService.h>
#import <AWSDK/AWSDKDependentAccessRequest.h>
#import <AWSDK/AWSDKEnrollmentService.h>
#import <AWSDK/AWSDKPractice.h>
#import <AWSDK/AWSDKPracticeCategory.h>
#import <AWSDK/AWSDKPracticeSearchResult.h>
#import <AWSDK/AWSDKPracticeService.h>
#import <AWSDK/AWSDKPracticeSubCategory.h>
#import <AWSDK/AWSDKService.h>
#import <AWSDK/AWSDKVisitContext.h>

#ifdef USE_CRASHLYTICS
#    import <Crashlytics/Crashlytics.h>
#endif

/**
 *  HomeViewController handles the following:
 *  - Displaying practices for the current consumer
 *  - Changing the current consumer
 *  - Starting appointments from URLs
 */
@interface HomeViewController () <UIPopoverPresentationControllerDelegate, ConsumersDelegate, UICollectionViewDelegate, UICollectionViewDataSource, InProgressVisitDelegate>

@property (assign, nonatomic) CGSize headerSize;
@property (assign, nonatomic) CGSize practiceSize;
@property (assign, nonatomic) BOOL isFetchingPractices;
@property (assign, nonatomic) BOOL isFetchingActiveVisit;

@property (nonatomic) IBOutlet UIBarButtonItem *bellButton;
@property (nonatomic) IBOutlet UIBarButtonItem *bellWithDotButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *userProfileButton;

/**
 *  Indicators
 */
@property (nonatomic) UIRefreshControl *refreshControl;

/**
 *  Array of Search Results
 */
@property (nonatomic) NSArray<id<AWSDKPractice>> *practices;
@property (nonatomic) NSMutableArray<id<AWSDKPractice>> *filteredPractices;

@property (nonatomic) NotificationsBitmask notifications;

/**
 Button that displays category list
 */
@property (weak, nonatomic) IBOutlet UIButton *categoryButton;
@property (weak, nonatomic) IBOutlet UIImageView *downArrow;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *downArrowTrailingEdgeContainerConstraint;

@property (nonatomic) IBOutletCollection(UIButton) NSArray<UIButton *> *circleButtons;
@property (nonatomic) AWSDKDependentAccessRequest *dependentAccessRequest;

@end

@implementation HomeViewController

#pragma mark - AWSDK Method Calls

/**
 *  Fetch all the available practices for the current consumer and save them in self.practices
 *  Note: Practices are Services, and the terminology is interchangable
 */
- (void)fetchPractices {
    if (self.isFetchingPractices) {
        return;
    }
    if (![[ConsumerService sharedInstance] consumer]) {
        return;
    }

    self.isFetchingPractices = YES;
    /**
     *  This method fetches all AWSDKPracticeSearchResult (s) for the current consumer
     *
     *  @param results An array of AWSDKPracticeSearchResult for each available practice
     *  @param error   AWSDKErrors
     */
    [MBProgressHUD show];
    [AWSDKPracticeService fetchPracticesAndCategoriesForConsumer:[[ConsumerService sharedInstance] consumer]
                                                  withCompletion:^void(NSArray *results, NSArray *categories, NSError *error) {
                                                      AWSDKLogDebug(@"Fetching complete");
                                                      self.isFetchingPractices = NO;
                                                      [MBProgressHUD hide];
                                                      if (error) {
                                                          if ([self.refreshControl isRefreshing]) {
                                                              [self.refreshControl endRefreshing];
                                                          }
                                                          // Error handling
                                                          [self presentAlertWithError:error okHandler:nil];
                                                      } else {
                                                          // Allocate a copy of the array
                                                          self.practices = results;
                                                          self.categories = categories;
                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              [self filterByCategory];
                                                          });

                                                          if ([self.refreshControl isRefreshing]) {
                                                              [self.refreshControl endRefreshing];
                                                          }
                                                      }
                                                  }];
}

/**
 *  Fetch active visit (if one exists) for the current consumer.
 */
- (void)fetchActiveVisit {
    if (self.isFetchingActiveVisit) {
        return;
    }
    if (![[ConsumerService sharedInstance] parentConsumer]) {
        return;
    }
    self.isFetchingActiveVisit = YES;
    [[ConsumerService sharedInstance] checkForActiveVisitWithCompletion:^(id<AWSDKVisit>  _Nullable result) {
        self.isFetchingActiveVisit = NO;
        if (result != nil) {
            [self handleActiveVisit:result];
        }
    }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.currentCategoryIndex = -1;
    self.refreshControl = [[RefreshControl alloc] init];

    [self.refreshControl addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventValueChanged];
    [self.collectionView addSubview:self.refreshControl];
    [self.collectionView setAlwaysBounceVertical:YES];

    [self.welcomeButton setTitleEdgeInsets:UIEdgeInsetsMake(0.0, 10.0, 0.0, 10.0)];
    if ([UIView userInterfaceLayoutDirectionForSemanticContentAttribute:self.view.semanticContentAttribute] == UIUserInterfaceLayoutDirectionLeftToRight) {
        self.welcomeButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    } else {
        self.welcomeButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    }

    for (UIButton *button in self.circleButtons) {
        button.titleLabel.textAlignment = NSTextAlignmentCenter;
    }

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleAppointment:) name:@"thnAppointment" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleActiveVisit:) name:@"activeVisit" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refresh:) name:@"refreshPractices" object:nil];

    self.headerSize = CGSizeMake(CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame) * 0.70);

    self.practiceSize = CGSizeMake((self.headerSize.width - 1) / 2, (CGRectGetHeight(self.view.frame) - self.headerSize.height - 1) / 2);

    dispatch_async(dispatch_get_main_queue(), ^{
        [self performSegueWithIdentifier:@"loginStartUp" sender:self];
    });

    // Add notification to handle consumer changes
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didUpdateConsumer:) name:ConsumerUpdatedNotification object:nil];
    [self fetchPractices];
    self.categoryButton.titleLabel.textColor = [UIColor whiteColor];
    self.categoryButton.backgroundColor = [UIColor aquaColor];

    self.notifications = NoNotifications;
    [self setUserHasNotifications:NO];
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    // Detect slide over or size changes and resize
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];

    self.headerSize = CGSizeMake(size.width, size.height * 0.70);

    self.practiceSize = CGSizeMake((self.headerSize.width - 1) / 2, (size.height - self.headerSize.height - 1) / 2);

    [self.collectionView reloadSections:[NSIndexSet indexSetWithIndex:0]];
}

- (void)filterByCategory {
    if (self.currentCategoryIndex == -1) {
        [self.categoryButton setTitle:NSLocalizedString(@"category.allServices", @"Button - Show all categories") forState:UIControlStateNormal];
        self.filteredPractices = [NSMutableArray arrayWithArray:self.practices];
    } else {
        self.filteredPractices = [NSMutableArray new];
        for (id<AWSDKPractice> p in self.practices) {
            // for each practice get its subcategory id.
            // if subcategory id is found in one of the subcategories, put the practice in the filtered list.
            id<AWSDKPracticeCategory> category = self.categories[self.currentCategoryIndex];
            [self.categoryButton setTitle:category.name forState:UIControlStateNormal];
            for (id<AWSDKPracticeSubCategory> psc in category.subCategories) {
                if ([p.subCategories containsObject:psc]) {
                    [self.filteredPractices addObject:p];
                    break;
                }
            }
        }
    }
    [self.categoryButton sizeToFit];
    float width = self.categoryButton.frame.size.width;
    self.downArrowTrailingEdgeContainerConstraint.constant = ((self.view.bounds.size.width - width) / 2) - (self.downArrow.bounds.size.width + 3);
    [self.view setNeedsLayout];
    [self.view layoutIfNeeded];
    [self.collectionView reloadSections:[NSIndexSet indexSetWithIndex:0]];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self filterByCategory];
    [self checkForNotifications];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [(RefreshControl *)self.refreshControl scrollViewDidScroll:scrollView];
}

#pragma mark UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.filteredPractices.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ImageCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    id<AWSDKPractice> practice = self.filteredPractices[indexPath.row];

    if (practice.logo || practice.smallLogo) {
        [cell.label setHidden:YES];
        [cell.imageView setHidden:NO];
        [cell.imageView setImage:practice.logo ?: practice.smallLogo];
    } else if (practice.hasLogo && !practice.logo) {
        [cell.spinner startAnimating];
        [practice fetchPracticeLogo:^(BOOL success, NSError *error) {
            if (success) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [collectionView reloadItemsAtIndexPaths:@[ indexPath ]];
                });
            }
        }];
    } else if (practice.hasSmallLogo && !practice.smallLogo) {
        [cell.spinner startAnimating];
        [practice fetchPracticeSmallLogo:^(BOOL success, NSError *error) {
            if (success) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [collectionView reloadItemsAtIndexPaths:@[ indexPath ]];
                });
            }
        }];
    } else {
        [cell.label setHidden:NO];
        [cell.label setText:practice.name];
        [cell.imageView setHidden:YES];
    }

    return cell;
}

#pragma mark UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    [self performSegueWithIdentifier:@"providersSegue" sender:self.filteredPractices[indexPath.row]];
}

#pragma mark - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return self.practiceSize;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 1;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 1;
}

#pragma mark - IBActions
/*
 * There is no sense of sessions with the AWSDK. Therefore there is no formal logout or deauthenticate.
 * The sample app handles logout by removing references to the consumer objects.
 */
- (IBAction)logout:(id)sender {
    [self logout:sender withCompletion:nil];
}

- (void)logout:(id)sender withCompletion:(CompletionBlock)completion {
    // Pop to HomeViewController if not currently top most view controller
    [self.navigationController popToRootViewControllerAnimated:YES];
    if (sender) {
        AWSDKLogInfo(@"Logout button tapped");
        // Remove any context of the AWSDKConsumer in consumerService
        [[ConsumerService sharedInstance] deauthenticateConsumer];
        [self performSegueWithIdentifier:@"loginSegue" sender:self];
    }
    // Remove any available practices
    self.practices = nil;
    self.filteredPractices = nil;
    [self.collectionView reloadData];
    // Present Login popover
    if (completion) {
        completion();
    }
}

- (IBAction)welcomeButtonTapped:(id)sender {
    AWSDKLogInfo(@"Consumer dropdown tapped");
    
    __weak typeof(self) weakSelf = self;
    ConsumerService *service = [ConsumerService sharedInstance];
    // Add sorted consumers (consumer and dependents) to array
    [MBProgressHUD show];
    [service.parentConsumer fetchDependentsWithCompletion:^(NSArray<id<AWSDKConsumer>> *consumers, NSError *error) {
        [MBProgressHUD hide];
        if (error) {
            [self presentAlertWithError:error okHandler:nil];
        } else {
            NSMutableArray<id<AWSDKConsumer>> *allConsumers = consumers.mutableCopy;
            [allConsumers insertObject:service.parentConsumer atIndex:0];
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf performSegueWithIdentifier:@"consumersSegue" sender:allConsumers];
            });
        }
    }];
}

- (IBAction)placeholderButtonTapped:(id)sender {
    AWSDKLogInfo(@"Fake button tapped");
    [[UIViewController topMostAlertVC] presentAlertWithMessageKey:@"placeholder.message" okHandler:nil];
}

- (IBAction)refresh:(id)sender {
    AWSDKLogInfo(@"Pulled to refresh practices");
    [self fetchPractices];
}

- (IBAction)unwindFromDisclaimerViewControllerToHome:(UIStoryboardSegue *)segue {
    if ([segue.sourceViewController isKindOfClass:[DisclaimerViewController class]] && ((DisclaimerViewController *)segue.sourceViewController).consumer) {
        id<AWSDKConsumer> consumer = ((DisclaimerViewController *)segue.sourceViewController).consumer;
        if ([segue.identifier isEqualToString:@"acceptedDisclaimerSegue"]) {
            [consumer acceptDisclaimer:^(BOOL success, NSError *error) {
                if (error) {
                    [self presentAlertWithError:error];
                } else if (!success) {
                    [self presentAlertWithMessageKey:@"login.disclaimer.fail"];
                } else {
                    // Success case
                }
            }];
        } else {
            AWSDKLogWarn(@"Unexpected segue identifier");
        }
    } else {
        AWSDKLogWarn(@"Unexpected sourceViewController or invalid consumer object");
    }
}

- (IBAction)categoryButtonTapped:(id)sender {
    AWSDKLogInfo(@"Category button tapped");
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Category" bundle:nil];
    CategoryViewController *categoryViewController = [storyboard instantiateViewControllerWithIdentifier:@"CategoryViewController"];
    categoryViewController.delegate = self;
    categoryViewController.categories = self.categories;
    [self.navigationController presentViewController:categoryViewController animated:YES completion:nil];
}

#pragma mark - Notification Handling

/**
 Checks the appointment if it can be started

 @param notification notification containing the AWSDKAppointment
 */
- (void)handleAppointment:(NSNotification *)notification {
    if ([[notification object] conformsToProtocol:@protocol(AWSDKAppointment)]) {
        AWSDKLogDebug(@"Handling appointment");

        id<AWSDKAppointment> appointment = [notification object];
        UIAlertController *appointmentAlert;

        if (appointment.status == Early) {
            // If early, present an alert stating so
            appointmentAlert = [UIAlertController alertControllerWithMessageKey:@"thn.early.message" okHandler:nil];
        } else if (appointment.status == Late) {
            // If Late, present an alert stating so
            appointmentAlert = [UIAlertController alertControllerWithMessageKey:@"thn.late.message" okHandler:nil];
        } else if (appointment.status == NoProvider) {
            // If No Providers, present an alert stating so
            appointmentAlert = [UIAlertController alertControllerWithMessageKey:@"thn.noProvider.message" okHandler:nil];
        } else if (appointment.status == OnTime && appointment.provider && [appointment readyToStart]) {
            // If On time, show a message to prompt starting the appointment
            appointmentAlert = [UIAlertController alertControllerWithMessageKey:@"thn.onTime.message"
                                                                     yesHandler:^(UIAlertAction *action) {
                                                                         [self performSegueWithIdentifier:@"thnSegue" sender:appointment];
                                                                     }];
        } else {
            // The appointment cannot be started for a different reason
            appointmentAlert = [UIAlertController alertControllerWithMessageKey:@"thn.cantStart.message" okHandler:nil];
        }
        // Check if consumer is logged in
        if ([[ConsumerService sharedInstance] isloggedIn] && appointmentAlert) {
            AWSDKLogDebug(@"Displaying alert when as view did appear already called");
            __weak typeof(self) weakSelf = self;
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf presentAlertController:appointmentAlert];
            });
        }
    }
}

/**
 Checks to see if the consumer wants to rejoin the active visit

 @param visit the active AWSDKVisit
 */
- (void)handleActiveVisit:(id<AWSDKVisit>)visit {
    if ([[ConsumerService sharedInstance] isloggedIn]) {
        AWSDKLogDebug(@"Handling active visit");
        [self performSegueWithIdentifier:@"inProgressVisitSegue" sender:visit];
    }
}

#pragma mark - Consumer Notifications
/**
 *  Notification from ConsumerService that the current consumer did change. Update UI
 *
 *  @param NSNotification notification object containing the consumer
 */
- (void)didUpdateConsumer:(NSNotification *)notification {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    id<AWSDKConsumer> parent = [[ConsumerService sharedInstance] parentConsumer];

#ifdef USE_CRASHLYTICS
    [Crashlytics.sharedInstance setUserName:consumer.nameComponents.localizedFullName ?: parent.nameComponents.localizedFullName];
    [Crashlytics.sharedInstance setUserEmail:consumer.email ?: parent.email];
#endif

    if (consumer) {
        // Update welcome button with name
        NSString *name = [NSString stringWithFormat:NSLocalizedString(@"profile.welcome", @"Format string - Welcome, %@ (first name)"), consumer.nameComponents.givenName];
        if (![[ConsumerService sharedInstance] isParent]) {
            name = [NSString stringWithFormat:@"%@ (%@)", name, parent.nameComponents.givenName];
        }
        [self.welcomeButton setTitle:name forState:UIControlStateNormal];

        // Look for active visit
        [self fetchActiveVisit];

        // Update Practices
        [self fetchPractices];

        // Check for notifications
        [self checkForNotifications];
    }
}

#pragma mark - ConsumersDelegate
/**
 *  Consumers popover selected a different consumer or dependent, update accordingly
 *
 *  @param consumer AWSDKConsumer object to of consumer to show and be logged in as
 */
- (void)didSelectConsumer:(id<AWSDKConsumer>)consumer {
    ConsumerService *service = [ConsumerService sharedInstance];
    // Set the new consumer context
    [service setConsumer:consumer];
}

#pragma mark - UIPopoverPresentationControllerDelegate
- (UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    return YES;
}

#pragma mark - InProgressVisitDelegate
- (void)navigateToVisitSummaryForVisit:(id<AWSDKVisit>)visit {
    [self performSegueWithIdentifier:@"visitSummarySegue" sender:visit];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSString *segueName = segue.identifier;
    // VisitContextViewController
    if ([segueName isEqualToString:@"thnSegue"]) {
        AWSDKLogInfo(@"Launched with an appointment link. Presenting VisitContextTableViewController");
        // Send visitContext to VisitContextViewController
        [(VisitContextTableViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0] setAppointment:sender];
    } else if ([segueName isEqualToString:@"consumersSegue"]) {
        // ConsumersTableViewController
        AWSDKLogInfo(@"Presenting consumer selection popover");
        
        ((ConsumersTableViewController *)segue.destinationViewController).consumers = sender;
        // Set ConsumersDelegate as self to know when a consumer was selected
        [((ConsumersTableViewController *)segue.destinationViewController) setDelegate:self];
        // Set popover presentationController's delegate as self to manage presentation

        [segue.destinationViewController.popoverPresentationController setDelegate:self];

        CGFloat contentHeight = ((ConsumersTableViewController *)segue.destinationViewController).contentSize.height;
        UIView *sourceView = segue.destinationViewController.popoverPresentationController.sourceView;

        [sourceView setFrame:CGRectMake(sourceView.frame.origin.x, sourceView.frame.origin.y, self.welcomeButtonWrapperView.bounds.size.width, contentHeight)];

        segue.destinationViewController.popoverPresentationController.sourceView = sourceView;
        segue.destinationViewController.popoverPresentationController.sourceRect = sourceView.bounds;
        segue.destinationViewController.popoverPresentationController.canOverlapSourceViewRect = YES;

        // Resize the contentSize as the amount of consumer rows
        segue.destinationViewController.preferredContentSize = CGSizeMake(self.welcomeButtonWrapperView.bounds.size.width, contentHeight);
    } else if ([segueName isEqualToString:@"providersSegue"]) {
        // ProvidersTableViewController
        AWSDKLogInfo(@"Tapped %@ practice", ((id<AWSDKPractice>)sender).name);
        [((ProvidersTableViewController *)segue.destinationViewController) setPractice:sender];
    } else if ([segueName isEqualToString:@"telehealth"]) {
        // TelehealthTableViewController
        AWSDKLogInfo(@"Tapped telehealth button");
    } else if ([segue.identifier isEqualToString:@"shareDependentsSegue"]) {
        ShareDependentTableViewController *destination = [(UINavigationController *)segue.destinationViewController viewControllers][0];
        destination.dependentAccessRequest = self.dependentAccessRequest;
    } else if ([segue.identifier isEqualToString:@"notifications"]) {
        NotificationsTableViewController *destination = segue.destinationViewController;
        destination.notificationStatus = self.notifications;
    } else if ([segue.identifier isEqualToString:@"inProgressVisitSegue"]) {
        InProgressVisitViewController *destination = [(UINavigationController *)segue.destinationViewController viewControllers][0];
        destination.visit = sender;
        destination.delegate = self;
    } else if ([segue.identifier isEqualToString:@"visitSummarySegue"]) {
        VisitSummaryTableViewController *destination = [(UINavigationController *)segue.destinationViewController viewControllers][0];
        destination.visit = sender;
        destination.showOptionToSendVisitSummary = [AWSDKSystemConfiguration showOptionToSendVisitSummary];
        destination.isEfaxEnabled = [AWSDKSystemConfiguration isEfaxEnabled];
    }
}

#pragma mark CategoryChangedDelegate delegate

- (void)setCategoryIndex:(NSInteger)index {
    self.currentCategoryIndex = index;
}

- (NSArray<id<AWSDKPracticeCategory>> *)getCategories {
    return self.categories;
}

#pragma mark - Private Methods

- (void)setUserHasNotifications:(BOOL)hasNotifications {
    if (hasNotifications) {
        [self.navigationItem setRightBarButtonItems:@[ self.userProfileButton, self.bellWithDotButton ] animated:YES];
    } else {
        [self.navigationItem setRightBarButtonItems:@[ self.userProfileButton, self.bellButton ] animated:YES];
    }
}

- (void)checkForNotifications {
    void (^updateBellState)(BOOL hasNotifications) = ^void(BOOL hasNotifications) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self setUserHasNotifications:hasNotifications];
        });
    };

    id<AWSDKConsumer> consumer = ConsumerService.sharedInstance.consumer;
    [TelehealthNotificationService checkNotificationsForConsumer:consumer
                                                      completion:^(NotificationsBitmask notificationMask) {
                                                          self.notifications = notificationMask;
                                                          updateBellState(notificationMask != NoNotifications);
                                                      }];
}

@end
