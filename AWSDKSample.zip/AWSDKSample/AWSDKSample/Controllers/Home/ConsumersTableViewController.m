//
//  ConsumersTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 4/7/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ConsumersTableViewController.h"

#import "NSPersonNameComponents+Localizing.h"

#import <AWSDK/AWSDKConsumer.h>

/**
 *  ConsumersTableView that shows all the consumers (dependents and primary parent consumer).
 *  Upon selection the VC will dismiss and call the delegate didSelectConsumer
 */
@interface ConsumersTableViewController ()

@end

/**
 *  This class handles presenting the list of consumers for the parent consumer
 *  And allows switching between consumer contexts.
 */
@implementation ConsumersTableViewController

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything here is UI for the sample app, no more API calls here -------------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    AWSDKLogInfo(@"Selected %@", self.consumers[indexPath.row].nameComponents.localizedFullName);
    if (self.consumers[indexPath.row] != [[ConsumerService sharedInstance] consumer]) {
        // Consumer selected that is not current consumer, call delegate
        [self.delegate didSelectConsumer:self.consumers[indexPath.row]];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UITableViewDataSource
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"basicCell"];
    [cell.textLabel setText:self.consumers[indexPath.row].nameComponents.localizedFullName];
    [cell.textLabel setTextColor:[UIColor whiteColor]];
    [cell.textLabel setBackgroundColor:[UIColor clearColor]];
    [cell setLayoutMargins:UIEdgeInsetsZero];
    [cell setSeparatorInset:UIEdgeInsetsZero];

    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.consumers count];
}

#pragma mark - Getters
/**
 *  Getter used by configurinng the popoverPresentationController to set its size as this content size
 *
 *  @return CGSize representing the used size  of the TableView altered by number of rows
 */
- (CGSize)contentSize {
    [self.tableView setRowHeight:44.0];
    CGFloat height = self.consumers.count * self.tableView.rowHeight;
    _contentSize = CGSizeMake(200, height);
    return _contentSize;
}

@end
