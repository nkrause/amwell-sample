//
//  TelehealthTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 11/22/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "TelehealthTableViewController.h"

@interface TelehealthTableViewController ()

@end

@implementation TelehealthTableViewController

#pragma mark - Prepare for Segue
- (IBAction)unwindFromScheduledVisitSegue:(UIStoryboardSegue *)segue {
    AWSDKLogInfo(@"Unwinding from ScheduleViewController to AppointmentTableViewController screen.");
    dispatch_async(dispatch_get_main_queue(), ^{
        [self performSegueWithIdentifier:@"appointments" sender:self];
    });
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"messages"]) {
        AWSDKLogInfo(@"Messages cell tapped");
    } else if ([segue.identifier isEqualToString:@"language"]) {
        AWSDKLogInfo(@"Language selection cell tapped");
    } else if ([segue.identifier isEqualToString:@"visitReports"]) {
        AWSDKLogInfo(@"Visit summaries cell tapped");
    } else if ([segue.identifier isEqualToString:@"profile"]) {
        AWSDKLogInfo(@"My Profile cell tapped");
    } else if ([segue.identifier isEqualToString:@"appointments"]) {
        AWSDKLogInfo(@"Appointments cell tapped");
    } else if ([segue.identifier isEqualToString:@"health"]) {
        AWSDKLogInfo(@"Health cell tapped");
    }
}

@end
