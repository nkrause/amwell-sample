//
//  HomeViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 8/5/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//
#import "CategoryChangedDelegate.h"

#import <AWSDK/AWSDKPracticeCategory.h>
@interface HomeViewController : UIViewController <CategoryChangedDelegate>

- (IBAction)unwindFromDisclaimerViewControllerToHome:(nonnull UIStoryboardSegue *)segue;

- (void)logout:(nonnull id)sender withCompletion:(nullable CompletionBlock)completion;

@property (weak, nonatomic, nullable) IBOutlet UIButton *welcomeButton;
@property (weak, nonatomic, nullable) IBOutlet UIView *welcomeButtonWrapperView;
@property (weak, nonatomic, nullable) IBOutlet UICollectionView *collectionView;
/**
 -1 means all practices in all categories.  Otherwise the index into the category array;
 */
@property (assign, nonatomic) NSInteger currentCategoryIndex;
@property (nonatomic, nullable) NSArray<id<AWSDKPracticeCategory>> *categories;

@end
