//
//  NotificationsTableViewController.h
//  AWSDKSample
//
//  Created by Stephen Ciauri on 7/24/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import "TelehealthNotificationService.h"

#import <UIKit/UIKit.h>

@interface NotificationsTableViewController : UITableViewController

@property (nonatomic) NotificationsBitmask notificationStatus;

@end
