//
//  NotificationsTableViewController.m
//  AWSDKSample
//
//  Created by Stephen Ciauri on 7/24/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import "NotificationsTableViewController.h"

#import "MessageFolderViewController.h"
#import "NotificationsTableViewCell.h"
#import "ShareDependentTableViewController.h"
#import "TelehealthNotificationService.h"

#import <AWSDK/AWSDKConsumer.h>

@interface NotificationsTableViewController ()
@property (nonatomic) NSArray<NSArray<NSString *> *> *dataSource;
@end

@implementation NotificationsTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configureDataSource];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self reloadNotificationStatus];
}

- (void)reloadNotificationStatus {
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD showLoadingOn:self.view];
    [TelehealthNotificationService checkNotificationsForConsumer:ConsumerService.sharedInstance.consumer
                                                      completion:^(NotificationsBitmask notificationMask) {
                                                          [MBProgressHUD hideHUDForView:self.view];
                                                          weakSelf.notificationStatus = notificationMask;
                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              [weakSelf configureDataSource];
                                                          });
                                                      }];
}

- (void)configureDataSource {
    NSMutableArray<NSArray<NSString *> *> *mutableDataSource = @[].mutableCopy;

    if (self.notificationStatus == NoNotifications) {
        NSString *nothingTitle = NSLocalizedString(@"No Notifications", @"Title for no notifications");
        NSString *nothingSubtitle = NSLocalizedString(@"You are caught up!", @"Subtitle, nothing to see here");
        [mutableDataSource addObject:@[ nothingTitle, nothingSubtitle ]];
        self.dataSource = mutableDataSource;
        [self.tableView reloadData];
        return;
    }
    if (self.notificationStatus & ChildAccessNotification) {
        NSString *childRequestTitle = NSLocalizedString(@"Child Access Request", @"Title for child access request");
        NSString *childRequestBody = NSLocalizedString(@"Someone has requested access to one or more of your children’s profiles.", @"Subtitle for child access request");
        [mutableDataSource addObject:@[ childRequestTitle, childRequestBody ]];
    }
    if (self.notificationStatus & UpcomingAppointmentNotification) {
        NSString *upcomingAppointmentTitle = NSLocalizedString(@"Join Your Appointment", @"Title for upcoming appointment notification");
        NSString *upcomingAppointmentBody = NSLocalizedString(@"You have a scheduled visit starting soon.", @"Notify user that their scheduled visit will start soon");
        [mutableDataSource addObject:@[ upcomingAppointmentTitle, upcomingAppointmentBody ]];
    }
    if (self.notificationStatus & SecureMessageNotification) {
        NSString *secureMessageTitle = NSLocalizedString(@"New Secure Message", @"Title for unread secure message");
        NSString *secureMessageBody = NSLocalizedString(@"You have received a message.", @"Subtitle for unread secure message");
        [mutableDataSource addObject:@[ secureMessageTitle, secureMessageBody ]];
    }

    self.dataSource = mutableDataSource;
    [self.tableView reloadData];
}

- (NotificationsBitmask)statusForRow:(NSInteger)row {
    NSInteger rowCounter = -1;
    if (self.notificationStatus == NoNotifications) {
        rowCounter++;
        if (rowCounter == row) {
            return NoNotifications;
        }
    }
    if (self.notificationStatus & ChildAccessNotification) {
        rowCounter++;
        if (rowCounter == row) {
            return ChildAccessNotification;
        }
    }
    if (self.notificationStatus & UpcomingAppointmentNotification) {
        rowCounter++;
        if (rowCounter == row) {
            return UpcomingAppointmentNotification;
        }
    }
    if (self.notificationStatus & SecureMessageNotification) {
        rowCounter++;
        if (rowCounter == row) {
            return SecureMessageNotification;
        }
    }
    return NoNotifications;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NotificationsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"notificationCell" forIndexPath:indexPath];

    NSString *title = self.dataSource[indexPath.row].firstObject;
    NSString *subtitle = self.dataSource[indexPath.row].lastObject;

    [cell configureWithTitle:title subtitle:subtitle];

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NotificationsBitmask status = [self statusForRow:indexPath.row];
    if (status == NoNotifications) {
        return;
    } else if (status == ChildAccessNotification) {
        [MBProgressHUD showLoadingOn:self.view];
        __weak typeof(self) weakSelf = self;
        [[[ConsumerService sharedInstance] consumer] fetchDependentAccessRequestWithCompletion:^(id<AWSDKDependentAccessRequest>  _Nullable dependentAccessRequest, NSError * _Nullable error) {
            [MBProgressHUD hideHUDForView:self.view];
            if (dependentAccessRequest) {
                [weakSelf performSegueWithIdentifier:@"shareChildNotification" sender:dependentAccessRequest];
            }
        }];
    } else if (status == UpcomingAppointmentNotification) {
        [self performSegueWithIdentifier:@"appointmentNotification" sender:nil];
    } else if (status == SecureMessageNotification) {
        [self performSegueWithIdentifier:@"unreadMessageNotification" sender:nil];
    }
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"shareChildNotification"]) {
        ShareDependentTableViewController *destination = [(UINavigationController *)segue.destinationViewController viewControllers][0];
        destination.dependentAccessRequest = (AWSDKDependentAccessRequest *)sender;
    }
    else if ([segue.identifier isEqualToString:@"unreadMessageNotification"]) {
        UISplitViewController *splitViewController = (UISplitViewController *)segue.destinationViewController;
        for (UINavigationController *navController in splitViewController.childViewControllers) {
            if ([navController isKindOfClass:[UINavigationController class]]){
                if ([navController.topViewController isKindOfClass:[MessageFolderViewController class]]){
                    MessageFolderViewController *controller = (MessageFolderViewController *)navController.topViewController;
                    controller.showInbox = YES;
                }
            }
        }

    }
}

@end
