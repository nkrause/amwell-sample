//
//  MeasurementDetailViewController.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/14/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

@protocol AWSDKTrackerTemplate;

@interface MeasurementDetailViewController : UIViewController

@property (nonatomic) id<AWSDKTrackerTemplate> trackerTemplate;

@end
