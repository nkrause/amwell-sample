//
//  HealthKitTableViewController.m
//  AWSDKSample
//
//  Created by Jeremiah.Possion on 12/6/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "HealthKitTableViewController.h"

// SDK Imports
#import "HealthKitService.h"
#import "RefreshControl.h"

#import <AWSDK/AWSDKHealthTrackerRecordForm.h>
#import <AWSDK/AWSDKHealthTrackerType.h>
#import <AWSDK/AWSDKLogService.h>
#import <HealthKit/HealthKit.h>

@interface HealthKitTableViewController ()

@property (weak, nonatomic) IBOutlet UIBarButtonItem *uploadButton;

@property (nonatomic, nonnull) HealthKitService *service;
@property (nonatomic, nonnull) NSMutableArray<NSDictionary *> *healthData;
@property (nonatomic, nonnull) NSMutableDictionary *categoryImages;
@property (nonatomic, nonnull) UIImage *categoryNotFoundImage;
@property (nonatomic, nullable) NSString *sectionHeader;

@end

@implementation HealthKitTableViewController

#pragma mark - AWSDK Interaction
- (void)upload {
    [MBProgressHUD showUpdatingOn:self.view];
    [self.service upload:^(BOOL success, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        [self presentAlertWithMessageKey:(success ? @"healthkit.alert.upload.success.message" : @"healthkit.alert.upload.failed.message") okHandler:nil];
    }];
}

#pragma mark - Sample App UI

//-----------------------------------------------------------------------------------------------------//
//---------------Everything here is UI for the sample app, no more API calls here ---------------------//
//-----------------------------------------------------------------------------------------------------//

- (void)viewDidLoad {
    [super viewDidLoad];

    self.healthData = [NSMutableArray new];
    self.categoryImages = [NSMutableDictionary new];
    [self prepareCategoryImages];
    self.uploadButton.enabled = NO;
    self.sectionHeader = nil;

    self.service = [[HealthKitService alloc] init];

    self.refreshControl = [[RefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(handleRefresh) forControlEvents:UIControlEventValueChanged];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadFromBackground) name:UIApplicationWillEnterForegroundNotification object:nil];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    [self prepareTableData];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Load Data
- (void)handleRefresh {
    [self prepareTableData];
}

- (void)loadFromBackground {
    UIViewController *vc = [UIViewController topMostMainVC];
    if ([vc isKindOfClass:[HealthKitTableViewController class]]) {
        [self prepareTableData];
    }
}

- (void)prepareTableData {
    // Make sure there is nothing in the health data array
    [self.healthData removeAllObjects];

    // Make sure the currently logged in user can even see the HK data.
    if ([self.service canSeeHealthKitData]) {
        // Get all the HealthKit data
        if (![self.refreshControl isRefreshing]) {
            [MBProgressHUD showLoadingOn:self.view];
        }
        [self.service getHealthKitData:^(NSArray *data, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view];
            if (data == nil || data.count < 1) {
                AWSDKLogInfo(@"No HealthKit data found.");
                self.sectionHeader = NSLocalizedString(@"healthkit.nodata", @"Placeholder cell - You have no health kit data tracked.");
                self.uploadButton.enabled = NO;
            } else {
                self.sectionHeader = nil;

                // Now that we have the data, we want to pull out the blood pressure data and combine it into a single item.
                NSMutableArray *tempData = [NSMutableArray new];

                NSNumber *systolic = nil;
                NSNumber *diastolic = nil;
                NSDate *date = nil;
                for (NSDictionary *item in data) {
                    id<AWSDKHealthTrackerType> type = item[@"type"];
                    if ([type.typeString isEqualToString:HKQuantityTypeIdentifierBloodPressureSystolic]) {
                        systolic = item[@"value"];
                        date = item[@"date"];
                    } else if ([type.typeString isEqualToString:HKQuantityTypeIdentifierBloodPressureDiastolic]) {
                        diastolic = item[@"value"];
                        date = item[@"date"];
                    } else {
                        [tempData addObject:item];
                    }
                }

                if (systolic && diastolic && date) {
                    // We have blood pressure data. Lets add it to the data array.
                    id<AWSDKHealthTrackerType> tracker = [self.service getBloodPressureSystolicTracker];
                    NSMutableDictionary *bp = @{
                        @"title" : NSLocalizedString(@"healthkit.bloodpressure", @"Vitals - Blood pressure"),
                        @"value" : [NSString stringWithFormat:@"%@/%@", systolic, diastolic],
                        @"systolic" : systolic,
                        @"diastolic" : diastolic,
                        @"date" : date
                    }
                                                  .mutableCopy;

                    if (tracker) {
                        bp[@"type"] = tracker;
                    }
                    [tempData addObject:bp];
                }

                self.healthData = tempData;
                self.uploadButton.enabled = YES;
            }

            [self.refreshControl endRefreshing];
            [self.tableView reloadData];
        }];
    } else {
        self.sectionHeader = NSLocalizedString(@"healthkit.cannotshare", @"Can't link to HealthKit since another user has already linked on this device");
        [self.refreshControl endRefreshing];
        [self.tableView reloadData];
    }
}

#pragma mark - IB Actions
- (IBAction)uploadToServer:(UIBarButtonItem *)sender {
    [self presentViewController:[UIAlertController alertControllerWithMessageKey:@"healthkit.alert.upload.confirm.message"
                                                                      yesHandler:^(UIAlertAction *action) {
                                                                          [self upload];
                                                                      }]
                       animated:YES
                     completion:nil];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [(RefreshControl *)self.refreshControl scrollViewDidScroll:scrollView];
}

#pragma mark - Tableview Datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.healthData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *tracker = self.healthData[indexPath.row];
    if (tracker == nil) {
        return [UITableViewCell new];
    }

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"trackerCell" forIndexPath:indexPath];
    cell.textLabel.text = tracker[@"title"];
    cell.imageView.image = tracker[@"type"] != nil ? [self imageForType:tracker[@"type"]] : self.categoryNotFoundImage;

    id<AWSDKHealthTrackerType> trackerType = tracker[@"type"];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ %@", tracker[@"value"], trackerType.unitString];

    return cell;
}

#pragma mark - Tableview Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (self.sectionHeader) {
        UILabel *label = [[UILabel alloc] init];
        label.numberOfLines = 0;
        label.text = self.sectionHeader;
        label.textAlignment = NSTextAlignmentCenter;

        return label;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return self.sectionHeader ? 76.0 : 0.0;
}

#pragma mark - Private Methods
- (void)prepareCategoryImages {
    self.categoryImages[@"nutrition"] = [UIImage imageNamed:@"HKNutrition"];
    self.categoryImages[@"bodyMeasurements"] = [UIImage imageNamed:@"HKBodyMeasurement"];
    self.categoryImages[@"fitness"] = [UIImage imageNamed:@"HKFitness"];
    self.categoryImages[@"labResults"] = [UIImage imageNamed:@"HKLabResults"];
    self.categoryImages[@"vitals"] = [UIImage imageNamed:@"HKVitals"];
    self.categoryNotFoundImage = [UIImage imageNamed:@"HKNoImage"];
}

- (UIImage *)imageForType:(id<AWSDKHealthTrackerType>)type {
    if (self.categoryImages[type.category]) {
        return self.categoryImages[type.category];
    }

    // If we get here just return the no category image
    return self.categoryNotFoundImage;
}

@end
