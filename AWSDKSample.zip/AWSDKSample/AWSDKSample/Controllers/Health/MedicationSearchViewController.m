//
//  MedicationSearchViewController.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/18/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MedicationSearchViewController.h"

#import "UITableView+Sample.h"

#import <AWSDK/AWSDKMedication.h>
#import <AWSDK/AWSDKMedicationService.h>

@interface MedicationSearchViewController ()

@property (nonatomic) NSArray *results;

@end

@implementation MedicationSearchViewController

#pragma mark AWSDK Method Calls
/**
 *  Search medications based on a string and return results to display
 *
 *  @param string NSString Search Text
 */
- (void)searchMedicationWithString:(NSString *)string {
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD showSearchingOn:self.view];
    [AWSDKMedicationService searchMedicationsWithString:string
                                             completion:^(NSArray *results, NSError *error) {
                                                 [MBProgressHUD hideHUDForView:self.view];
                                                 if (error) {
                                                     [weakSelf presentAlertWithError:error okHandler:nil];
                                                 } else {
                                                     weakSelf.results = results;
                                                     [weakSelf.resultsTable reloadDataAnimated:YES];
                                                 }
                                             }];
}

//-----------------------------------------------------------------------------------------------------//
//---------------Everything beyond here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = NSLocalizedString(@"addMedication.title", @"Navigation title - Add mediation");

    [self.searchBar setPlaceholder:NSLocalizedString(@"addMedication.prompt", @"Navigation prompt - type the name of the medication")];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidChangeFrame:) name:UIKeyboardDidChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillBeHidden:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];

    [super viewWillDisappear:animated];
}

#pragma mark UIKeyboardNotifications
// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardDidChangeFrame:(NSNotification *)aNotification {
    NSDictionary *info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;

    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    self.resultsTable.contentInset = contentInsets;
    self.resultsTable.scrollIndicatorInsets = contentInsets;
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification *)aNotification {
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    self.resultsTable.contentInset = contentInsets;
    self.resultsTable.scrollIndicatorInsets = contentInsets;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.results.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *results = [tableView dequeueReusableCellWithIdentifier:@"resultsCell"];

    results.textLabel.text = [(id<AWSDKMedication>)self.results[indexPath.row] displayName];

    return results;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    id<AWSDKMedication> medication = [self.results objectAtIndex:indexPath.row];
    AWSDKLogInfo(@"Selected %@", medication.displayName);
    [self.delegate medicationSelected:medication];
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UISearchBarDelegate
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    AWSDKLogInfo(@"Search text changed to %@", searchText);
    // Without this check you would see an error message every time the search is performed
    // Medication search has a minimum length of 3
    if (searchText.length > 2) {
        // Perform the medication search
        [self searchMedicationWithString:searchText];
    } else {
        // Clear table view
        self.results = @[];
        [self.resultsTable reloadDataAnimated:YES];
    }
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    if (searchBar.text.length > 2) {
        // Perform the medication search
        [self searchMedicationWithString:searchBar.text];
    } else {
        [self presentAlertWithMessageKey:@"myHealth.medications.search.short.message" okHandler:nil];
    }
}

#pragma mark - IBAction
- (IBAction)cancelTapped:(id)sender {
    AWSDKLogInfo(@"Cancel tapped");
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
