//
//  ConditionsTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/10/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ConditionsTableViewController.h"

#import "UITableView+Sample.h"

#import <AWSDK/AWSDKCondition.h>
#import <AWSDK/AWSDKConsumer.h>

/**
 *  Displays all conditions to add and remove from the Consumer
 */
@implementation ConditionsTableViewController

#pragma mark AWSDK Method Calls
/**
 *  Fetches all conditions, and filters our current conditions for the consumer
 */
- (void)fetch {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    if (![self.refreshControl isRefreshing]) {
        [MBProgressHUD showLoadingOn:self.view];
    }
    [consumer fetchConditionsWithCompletion:^void(NSArray *results, NSError *error) {
        // Stop refreshing if called by refresh
        [MBProgressHUD hideHUDForView:self.view];
        if ([self.refreshControl isRefreshing]) {
            [self.refreshControl endRefreshing];
        }
        if (error) {
            [self presentAlertWithError:error okHandler:nil];
        } else {
            // Filter current conditions
            NSPredicate *predicate = [NSPredicate predicateWithBlock:^BOOL(id object, NSDictionary *bindings) {
                return [object isCurrent];
            }];
            // Save all listed conditions
            self.allData = [NSMutableArray arrayWithArray:results];
            // Save current consumer conditions
            [self.selectedData addObjectsFromArray:[self.allData filteredArrayUsingPredicate:predicate]];
            // Sort the conditions alphabetically with selected at the top
            [self.allData sortUsingDescriptors:self.sortDescriptors];
            // Reload and display
            [self.tableView reloadDataAnimated:YES];
        }
    }];
}

/**
 *  Updates the consumer with a list of current conditions
 */
- (void)update {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    if (![self.refreshControl isRefreshing]) {
        [MBProgressHUD showUpdatingOn:self.view];
    }
    [consumer updateConditions:self.selectedData
                withCompletion:^(BOOL success, NSError *error) {
                    [MBProgressHUD hideHUDForView:self.view];
                    if (error) {
                        [self presentAlertWithError:error okHandler:nil];
                    }
                    // Reload if conditions are stil
                    if ([self.refreshControl isRefreshing]) {
                        [self.selectedData removeAllObjects];
                        [self fetch];
                    }
                }];
}

//-----------------------------------------------------------------------------------------------------//
//------------Everything past here is UI for the sample app, no more API calls here -------------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Set Sort Descriptors
    NSSortDescriptor *nameDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"displayName" ascending:YES];
    [self.sortDescriptors addObject:nameDescriptor];
}
@end
