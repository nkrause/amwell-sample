//
//  AllergiesTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/10/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AllergiesTableViewController.h"

#import "UITableView+Sample.h"

#import <AWSDK/AWSDKAllergy.h>
#import <AWSDK/AWSDKConsumer.h>

/**
 *  Displays Allergies to add and remove from the Consumer
 */
@implementation AllergiesTableViewController

/**
 *  Fetches all allergies, and consumer's allergies
 */
- (void)fetch {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    if (![self.refreshControl isRefreshing]) {
        [MBProgressHUD showLoadingOn:self.view];
    }
    [consumer fetchAllergiesWithCompletion:^void(NSArray *results, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        // Stop refreshing if called by refresh
        if ([self.refreshControl isRefreshing]) {
            [self.refreshControl endRefreshing];
        }
        if (error) {
            [self presentAlertWithError:error okHandler:nil];
        } else {
            // Create a filter for the consumer's saved allergies
            NSPredicate *predicate = [NSPredicate predicateWithBlock:^BOOL(id object, NSDictionary *bindings) {
                return [object isCurrent];
            }];
            // Retain all the allergies in a mutable array for the dataSource
            self.allData = [NSMutableArray arrayWithArray:results];
            // Filter the data for current saved allergies
            [self.selectedData addObjectsFromArray:[self.allData filteredArrayUsingPredicate:predicate]];
            // Sort the data
            [self.allData sortUsingDescriptors:self.sortDescriptors];
            // Reload and display
            [self.tableView reloadDataAnimated:YES];
        }
    }];
}

/**
 *  Updates the consumer with an array of new allergies
 */
- (void)update {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    if (![self.refreshControl isRefreshing]) {
        [MBProgressHUD showUpdatingOn:self.view];
    }
    [consumer updateAllergies:self.selectedData
               withCompletion:^(BOOL success, NSError *error) {
                   [MBProgressHUD hideHUDForView:self.view];
                   if (error) {
                       [self presentAlertWithError:error okHandler:nil];
                   }
                   // Reload if a refresh is started
                   if ([self.refreshControl isRefreshing]) {
                       [self.selectedData removeAllObjects];
                       [self fetch];
                   }
               }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything below here is UI for the sample app, no more API calls here -------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Set Sort Descriptors
    NSSortDescriptor *nameDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"displayName" ascending:YES];
    [self.sortDescriptors addObject:nameDescriptor];
}

@end
