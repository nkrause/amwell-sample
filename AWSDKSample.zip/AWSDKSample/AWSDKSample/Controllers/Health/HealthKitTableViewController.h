//
//  HealthKitTableViewController.h
//  AWSDKSample
//
//  Created by Jeremiah.Possion on 12/6/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface HealthKitTableViewController : UITableViewController

@end
