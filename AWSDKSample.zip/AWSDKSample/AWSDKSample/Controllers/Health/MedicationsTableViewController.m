//
//  MedicationsTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/10/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MedicationsTableViewController.h"

#import "MedicationSearchViewController.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKMedication.h>

/**
 *  Displays the current medications for the user to remove
 */

@interface MedicationsTableViewController () <MedicationSearchDelegate>
@end

@implementation MedicationsTableViewController

/**
 *  Fetches the list of current medications for the user
 */
- (void)fetch {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    if (![self.refreshControl isRefreshing]) {
        [MBProgressHUD showLoadingOn:self.view];
    }
    [consumer fetchMedicationsWithCompletion:^void(NSArray *results, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        // Stop refreshing if called by refresh
        if ([self.refreshControl isRefreshing]) {
            [self.refreshControl endRefreshing];
        }
        if (error) {
            [self presentAlertWithError:error okHandler:nil];
        } else {
            self.allData = [NSMutableArray arrayWithArray:results];
            [self.selectedData addObjectsFromArray:self.allData];

            [self.allData sortUsingDescriptors:self.sortDescriptors];

            [self.tableView reloadDataAnimated:YES];
        }
    }];
}

/**
 *  Updates the list of medications for the current consumer
 */
- (void)update {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    if (![self.refreshControl isRefreshing]) {
        [MBProgressHUD showUpdatingOn:self.view];
    }
    [consumer updateMedications:self.selectedData
                 withCompletion:^(BOOL success, NSError *error) {
                     [MBProgressHUD hideHUDForView:self.view];
                     if (error) {
                         [self presentAlertWithError:error okHandler:nil];
                     }
                     if ([self.refreshControl isRefreshing]) {
                         [self.selectedData removeAllObjects];
                         [self fetch];
                     }
                 }];
}

//-----------------------------------------------------------------------------------------------------//
//------------Everything past here is UI for the sample app, no more API calls here -------------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Set Sort Descriptors
    NSSortDescriptor *nameDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"displayName" ascending:YES];
    [self.sortDescriptors addObject:nameDescriptor];
}

#pragma mark - MedicationSearchDelegate
- (void)medicationSelected:(id<AWSDKMedication>)medication {
    // Add the medication selected to the dataSource
    [self.allData addObject:medication];
    [self.selectedData addObject:medication];

    [self.tableView reloadDataAnimated:YES];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    AWSDKLogInfo(@"Add medication button tapped");
    UIViewController *destinationViewController = [(UINavigationController *)segue.destinationViewController viewControllers][0];
    [(MedicationSearchViewController *)destinationViewController setDelegate:self];
}

@end
