//
//  HealthDocumentsTableViewController.m
//  AWSDKSample
//
//  Created by Steven Uy on 7/26/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "HealthDocumentsTableViewController.h"

#import "AttachmentViewController.h"
#import "FollowUpItemTableViewCell.h"
#import "NSDateFormatter+CommonFormats.h"
#import "RefreshControl.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKHealthDocument.h>
#import <AWSDK/AWSDKAttachment.h>
#import <AWSDKSample-Swift.h>
#import <MobileCoreServices/MobileCoreServices.h>

@interface HealthDocumentsTableViewController ()

@property (nonatomic, nullable) NSArray<id<AWSDKHealthDocument>> *documents;
@property (nonatomic) EmptyContentView *emptyView;
@property (nonatomic, nullable) id<AWSDKPaginatedHealthDocuments> paginatedHealthDocuments;
@property (nonatomic, nullable) NSArray<PopupAction *> *popupActions;
@property (nonatomic, nullable) id<AWSDKHealthDocument> selectedDocument;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *addButton;
@property (nonatomic, weak) IBOutlet UIButton *loadMoreButton;

@end

@implementation HealthDocumentsTableViewController

#pragma mark - AWSDKMethodCalls
- (void)fetchDocumentsAndClearResults:(BOOL)clearResults {
    __weak typeof(self) weakSelf = self;
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    if (![self.refreshControl isRefreshing]) {
        [MBProgressHUD showLoadingOn:self.view];
    }

    id<AWSDKHealthDocumentSearchRequest> thisRequest;
    if (clearResults) {
        thisRequest = [[HealthDocumentSearchRequest alloc] init];
    } else {
        thisRequest = self.paginatedHealthDocuments.nextPage;
    }

    BOOL shouldAppendItems = self.paginatedHealthDocuments.nextPage;

    [consumer fetchPaginatedHealthDocuments:thisRequest completion:^(id<AWSDKPaginatedHealthDocuments>  _Nullable paginatedHealthDocuments, NSError * _Nullable error) {
        [MBProgressHUD hideHUDForView:self.view];
        [self.refreshControl endRefreshing];

        if (paginatedHealthDocuments) {
            if (clearResults) {
                weakSelf.documents = paginatedHealthDocuments.list;
            } else if (shouldAppendItems) {
                weakSelf.documents = [weakSelf.documents arrayByAddingObjectsFromArray:paginatedHealthDocuments.list];
            }

            weakSelf.paginatedHealthDocuments = paginatedHealthDocuments;

            weakSelf.emptyView.alpha = weakSelf.isEmpty ? 1.0 : 0.0;
            [weakSelf.loadMoreButton setHidden:paginatedHealthDocuments.nextPage == nil];

            [weakSelf.tableView reloadDataAnimated:YES];
        } else if (error) {
            [weakSelf presentAlertWithError:error okHandler:nil];
        }
    }];
}

- (void)addDocumentData:(NSData *)data withMimeType:(NSString *)type withFilename:(NSString *)name {
    __weak typeof(self) weakSelf = self;
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];

    [MBProgressHUD showUpdatingOn:self.view];
    [consumer addHealthDocument:data
                   withMimeType:type
                   withFilename:name
                     completion:^(id<AWSDKHealthDocument> _Nullable document, NSError *error) {
                         [MBProgressHUD hideHUDForView:self.view];

                         if (document) {
                             [weakSelf refresh:nil];
                         } else if (error) {
                             // Handle error
                             [weakSelf presentAlertWithError:error okHandler:nil];
                         }
                     }];
}

- (void)deleteDocument:(id<AWSDKHealthDocument>)document {
    // Delete first
    [MBProgressHUD showDeletingOn:self.view];
    [document removeHealthDocumentWithCompletion:^(BOOL success, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view];
        if (success) {
            [self refresh:nil];
        } else if (error) {
            [self presentAlertWithError:error okHandler:nil];
        }
    }];
}

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything below here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

#pragma mark - UIViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    self.tableView.estimatedRowHeight = 70;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.backgroundColor = UIColor.bkgdGreyColor;
    self.tableView.contentInset = UIEdgeInsetsMake(22.0, 0, 0, 0);

    UIImage *emptyImage = [UIImage imageNamed:@"noAttachments"];
    self.emptyView = [[EmptyContentView alloc] initWithImage: emptyImage message:NSLocalizedString(@"attachments.empty", @"Attachments empty") buttonTitle:NSLocalizedString(@"attachments.add", @"Add Attachment")];
    [self.emptyView addTarget:self action:@selector(addTapped:) forControlEvents:UIControlEventTouchUpInside];
    self.emptyView.alpha = 0;
    self.tableView.backgroundView = self.emptyView;

    [self assembleDocumentActions];

    [self fetchDocumentsAndClearResults:YES];
}

#pragma mark - Private Methods
- (BOOL)isEmpty
{
    return self.documents.count == 0;
}

- (void)assembleDocumentActions
{
    UIImage *viewIcon = [UIImage imageNamed:@"iconView"];
    PopupAction *viewAction = [[PopupAction alloc] initWithIcon:viewIcon title:NSLocalizedString(@"attachments.view", @"View Attachment") action:^{
        [self handlePopupSelection:@"View"];
    }];

    UIImage *printIcon = [UIImage imageNamed:@"iconPrint"];
    PopupAction *printAction = [[PopupAction alloc] initWithIcon:printIcon title:NSLocalizedString(@"attachments.print", @"Print Attachment") action:^{
        [self handlePopupSelection:@"Print"];
    }];

    UIImage *deleteIcon = [UIImage imageNamed:@"iconDelete"];
    PopupAction *deleteAction = [[PopupAction alloc] initWithIcon:deleteIcon title:NSLocalizedString(@"attachments.delete", @"Delete Attachment") action:^{
        [self handlePopupSelection:@"Delete"];
    }];
    deleteAction.hasDisclosureIndicator = NO;

    self.popupActions = @[viewAction, printAction, deleteAction];
}

- (void)ellipsisButtonTapped:(UIButton *)sender
{
    FollowUpItemTableViewCell *cell = (FollowUpItemTableViewCell *)sender.superview;

    if (cell) {
        NSInteger row = [self.tableView indexPathForCell:cell].row;
        self.selectedDocument = self.documents[row];

        OptionsTableViewController *optionsController = [[OptionsTableViewController alloc] initWithActions:self.popupActions];
        optionsController.modalPresentationStyle = UIModalPresentationOverCurrentContext;
        optionsController.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;

        [self presentViewController:optionsController animated:YES completion:nil];
    }
}

- (void)handlePopupSelection:(NSString *)selection
{
    id<AWSDKHealthDocument> document = self.selectedDocument;
    id<AWSDKAttachment> attachment = document.attachment;

    if ([selection isEqualToString:@"View"] || [selection isEqualToString:@"Print"]) {
        AWSDKLogInfo(@"Selected attachment named: %@", attachment.name);
        [self performSegueWithIdentifier:@"showAttachment" sender:attachment];
    } else if ([selection isEqualToString:@"Delete"]) {
        [self deleteDocument:document];
    }

    // Clear selected document
    self.selectedDocument = nil;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.documents.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FollowUpItemTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"myDocumentsCell" forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;

    cell.title.text = self.documents[indexPath.row].name;

    NSString *dateString = [[NSDateFormatter longDateMonthDayTimeFormatter] stringFromDate:self.documents[indexPath.row].uploadDate];
    cell.dateLabel.text = dateString;

    [cell.ellipsisButton addTarget:self action:@selector(ellipsisButtonTapped:) forControlEvents:UIControlEventTouchUpInside];

    return cell;
}

#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *, id> *)info {
    [picker dismissViewControllerAnimated:YES completion:^{
        UIImage *selectedImage = [info objectForKey:UIImagePickerControllerEditedImage];

        if (!selectedImage) {
            selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
        }

        // Retrieves the image as a JPEG representation of NSData
        NSData *data = UIImageJPEGRepresentation(selectedImage, 1.0);

        NSURL *imagePath = [info objectForKey:@"UIImagePickerControllerReferenceURL"];

        NSString *imageName = [imagePath lastPathComponent];

        NSString *fileExtension = [imagePath pathExtension];
        NSString *UTI = (__bridge_transfer NSString *)UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, (__bridge CFStringRef)fileExtension, NULL);
        NSString *contentType = (__bridge_transfer NSString *)UTTypeCopyPreferredTagWithClass((__bridge CFStringRef)UTI, kUTTagClassMIMEType);

        if (contentType) {
            [self addDocumentData:data withMimeType:contentType withFilename:imageName];
        } else {
            // Unexpected type
        }
    }];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [(RefreshControl *)self.refreshControl scrollViewDidScroll:scrollView];
}

#pragma mark - IBActions
- (IBAction)addTapped:(id)sender {
    AWSDKLogInfo(@"Add document button tapped");
    __block HealthDocumentsTableViewController *weakSelf = self;
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        UIImagePickerController *image = [[UIImagePickerController alloc] init];

        [image setDelegate:weakSelf];

        [image setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];

        [self presentViewController:image animated:YES completion:nil];
    };
}

- (IBAction)refresh:(id)sender {
    [self fetchDocumentsAndClearResults:YES];
}

- (IBAction)loadMoreAttachmentsPressed:(UIButton *)sender {
    [self fetchDocumentsAndClearResults:NO];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    [((AttachmentViewController *)segue.destinationViewController) setAttachment:sender];
}

@end
