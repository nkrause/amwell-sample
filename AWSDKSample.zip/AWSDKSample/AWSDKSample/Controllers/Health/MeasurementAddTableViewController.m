//
//  MeasurementAddTableViewController.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/16/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MeasurementAddTableViewController.h"

#import "DatePickerCell.h"
#import "MeasurementComponentTableViewCell.h"
#import "NSDateFormatter+CommonFormats.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKTrackerComponentTemplate.h>
#import <AWSDK/AWSDKTrackerTemplate.h>

const double SectionComponentHeight = 16.0;

typedef NS_ENUM(NSUInteger, MeasurementAddSection) {
    MeasurementAddSectionComponent,
    MeasurementAddSectionDate,
    MeasurementAddSectionTime,
};

@interface MeasurementAddTableViewController () <MeasurementAddTableViewDelegate>

@property (weak, nonatomic) IBOutlet UIBarButtonItem *saveButton;

@property (nonatomic) NSDate *selectedDate;
@property (nonatomic) BOOL isDateEditing;
@property (nonatomic) BOOL isTimeEditing;
@property (nonatomic) NSDateFormatter *dateFormatter;
@property (nonatomic) ErrorService *errorService;
@property (nonatomic) id<AWSDKTrackerEntryRequest> trackerEntryRequest;

@end

@implementation MeasurementAddTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = NSLocalizedString(self.trackerTemplate.title, @"Template Title");
    self.dateFormatter = [NSDateFormatter shortDateFormatter];
    self.selectedDate = [NSDate new];
    self.errorService = [[ErrorService alloc] initWithSender:self];
    self.trackerEntryRequest = [self.trackerTemplate newTrackerEntryRequest];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case MeasurementAddSectionComponent:
            return self.trackerTemplate.components.count;
        case MeasurementAddSectionDate:
            return 2;
        case MeasurementAddSectionTime:
            return 2;
        default:
            return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == MeasurementAddSectionComponent) {
        MeasurementComponentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"componentCell" forIndexPath:indexPath];
        cell.tag = indexPath.row;
        cell.delegate = self;
        cell.trackerComponentTemplate = self.trackerTemplate.components[indexPath.row];
        [self.errorService addObserver:cell forKeyPath:@"componentCell"];
        return cell;
    } else if (indexPath.section == MeasurementAddSectionDate) {
        if (indexPath.row == 0) {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"dateTimeCell" forIndexPath:indexPath];
            cell.textLabel.text = [[NSDateFormatter shortDateFormatter] stringFromDate:self.selectedDate];
            return cell;
        } else if (indexPath.row == 1) {
            DatePickerCell *cell = [tableView dequeueReusableCellWithIdentifier:@"dateCell"];
            cell.datePicker.date = self.selectedDate;
            cell.datePicker.minimumDate = [NSDate distantPast];
            cell.datePicker.maximumDate = [NSDate new];
            cell.datePicker.timeZone = [NSTimeZone localTimeZone];
            cell.datePicker.datePickerMode = UIDatePickerModeDate;
            [cell layoutIfNeeded];
            return cell;
        }
    } else if (indexPath.section == MeasurementAddSectionTime) {
        if (indexPath.row == 0) {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"dateTimeCell" forIndexPath:indexPath];
            cell.textLabel.text = [[NSDateFormatter shortTimeFormatter] stringFromDate:self.selectedDate];
            return cell;
        } else if (indexPath.row == 1) {
            DatePickerCell *cell = [tableView dequeueReusableCellWithIdentifier:@"dateCell"];
            cell.datePicker.date = self.selectedDate;
            cell.datePicker.minimumDate = [NSDate distantPast];
            cell.datePicker.maximumDate = [NSDate distantFuture];
            cell.datePicker.timeZone = [NSTimeZone localTimeZone];
            cell.datePicker.datePickerMode = UIDatePickerModeTime;
            [cell layoutIfNeeded];
            return cell;
        }
    }
    return nil;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    switch (section) {
        case MeasurementAddSectionComponent:
            return nil;
        case MeasurementAddSectionDate:
            return NSLocalizedString(@"myHealth.trackerAddSection.date", @"Date");
        case MeasurementAddSectionTime:
            return NSLocalizedString(@"myHealth.trackerAddSection.time", @"Time");
        default:
            return @"";
    }
}

#pragma mark - UITableView Delegate

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == MeasurementAddSectionComponent) {
        return SectionComponentHeight;
    }
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat height = UITableViewAutomaticDimension;
    if (indexPath.section == MeasurementAddSectionComponent) {
    } else if (indexPath.section == MeasurementAddSectionDate) {
        if (indexPath.row == 1) {
            height = (self.isDateEditing) ? UITableViewAutomaticDimension : CGFLOAT_MIN;
        }
    } else if (indexPath.section == MeasurementAddSectionTime) {
        if (indexPath.row == 1) {
            height = (self.isTimeEditing) ? UITableViewAutomaticDimension : CGFLOAT_MIN;
        }
    }
    return height;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == MeasurementAddSectionDate) {
        if (indexPath.row == 0) {
            self.isDateEditing = !self.isDateEditing;
            if (!self.isDateEditing) {
                [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
            } else {
                self.isTimeEditing = NO;
            }
        }
    } else if (indexPath.section == MeasurementAddSectionTime) {
        if (indexPath.row == 0) {
            self.isTimeEditing = !self.isTimeEditing;
            if (!self.isTimeEditing) {
                [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
            } else {
                self.isDateEditing = NO;
            }
        }
    }
    [self.tableView reloadDataAnimated:YES];
}

#pragma mark -  MeasurementAddTableViewDelegate

- (void)trackerValidationChanged:(BOOL)isValid value:(NSNumber *)value position:(NSInteger)position error:(NSError *)error {
    self.trackerEntryRequest.data[position].value = isValid ? value : nil;
    for (id<AWSDKTrackerDataPointRequestEntry> entry in self.trackerEntryRequest.data) {
        if (!entry.value) {
            isValid = NO;
            break;
        }
    }
    self.saveButton.enabled = isValid;
}

#pragma mark - IBAction

- (IBAction)cancelButtonTapped:(id)sender {
    AWSDKLogInfo(@"Cancel button tapped");
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)saveButtonTapped:(id)sender {
    AWSDKLogInfo(@"Save button tapped");

    AWSDKTrackersRequest *trackersRequest = [AWSDKTrackersRequest trackersRequest];
    trackersRequest.measurementDateTime = self.selectedDate;
    trackersRequest.timeZone = [NSTimeZone localTimeZone];
    trackersRequest.entries = @[ self.trackerEntryRequest ];
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    self.saveButton.enabled = NO;
    [MBProgressHUD showUpdatingOn:self.view];
    [consumer addGeneralTrackersForRequest:trackersRequest
                                completion:^(BOOL success, NSError *error) {
                                    [MBProgressHUD hideHUDForView:self.view];
                                    self.saveButton.enabled = YES;
                                    if (success) {
                                        [self dismissViewControllerAnimated:YES completion:nil];
                                    } else if (error) {
                                        if (error.code == AWSDKErrorCodeInvalidValue) {
                                            [self presentAlertWithMessageKey:@"vitals.invalid" okHandler:nil];
                                        } else {
                                            [self presentAlertWithError:error okHandler:nil];
                                        }
                                    }
                                }];
}

- (IBAction)datePickerChanged:(id)sender {
    UIDatePicker *picker = sender;
    AWSDKLogInfo(@"datePickerChanged: called. date =>%@<", picker.date);

    self.selectedDate = picker.date;
    [self.tableView reloadDataAnimated:YES];
}

@end
