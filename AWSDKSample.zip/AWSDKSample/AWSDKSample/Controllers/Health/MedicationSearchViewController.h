//
//  MedicationSearchViewController.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/18/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKMedication;

@protocol MedicationSearchDelegate <NSObject>

- (void)medicationSelected:(id<AWSDKMedication>)medication;

@end

@interface MedicationSearchViewController : UIViewController <UISearchBarDelegate, UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) id<MedicationSearchDelegate> delegate;

@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UITableView *resultsTable;

- (IBAction)cancelTapped:(id)sender;

@end
