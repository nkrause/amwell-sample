//
//  MeasurementDetailViewController.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/14/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MeasurementDetailViewController.h"

#import "DatePickerCell.h"
#import "MeasurementAddTableViewController.h"
#import "MeasurementDetailTableViewCell.h"
#import "NSDateFormatter+CommonFormats.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKTrackerEntry.h>
#import <AWSDK/AWSDKTrackerTemplate.h>

typedef NS_ENUM(NSUInteger, TableViewRow) {
    TableViewRowDatePicker,
};

@interface MeasurementDetailViewController () <UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UIButton *startDateButton;
@property (weak, nonatomic) IBOutlet UIButton *endDateButton;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *footerLabel;
@property (weak, nonatomic) IBOutlet UIButton *deleteButton;

@property (nonatomic) NSArray<id<AWSDKTrackerEntry>> *trackerEntries;
@property (nonatomic) NSDate *startDate;
@property (nonatomic) NSDate *endDate;
@property (nonatomic) NSDateFormatter *dateFormatter;
@property (nonatomic) BOOL isEditingDate;

@end

@implementation MeasurementDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Set initial state, in case this VC gets instantiated in code rather than storyboard
    [self setTrackerEntries:self.trackerEntries];
    self.title = NSLocalizedString(self.trackerTemplate.title, @"Template Title");
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [self setupStartEndDate];
    [self loadTrackers];
}

#pragma mark - UITableView Datasource

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1 + self.trackerEntries.count; // pickerView + trackers
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    if (indexPath.row == TableViewRowDatePicker) {
        DatePickerCell *cell = [tableView dequeueReusableCellWithIdentifier:@"dateCell"];
        if (self.startDateButton.selected) {
            cell.datePicker.tag = 0;
            cell.datePicker.date = self.startDate;
            cell.datePicker.minimumDate = [NSDate distantPast];
            cell.datePicker.maximumDate = [self.endDate dateByAddingTimeInterval:-1];
        } else if (self.endDateButton.selected) {
            cell.datePicker.tag = 1;
            cell.datePicker.date = self.endDate;
            cell.datePicker.minimumDate = [self.startDate dateByAddingTimeInterval:-1];
            cell.datePicker.maximumDate = [NSDate new];
        }
        cell.datePicker.timeZone = [NSTimeZone localTimeZone];
        cell.backgroundColor = [UIColor whiteColor];
        [cell layoutIfNeeded];
        return cell;
    } else {
        MeasurementDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"detailCell"];
        cell.trackerTemplate = self.trackerTemplate;
        cell.trackerEntry = self.trackerEntries[indexPath.row - 1];
        return cell;
    }
}

#pragma mark - UITableView Delegate

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat height = UITableViewAutomaticDimension;
    if (indexPath.row == TableViewRowDatePicker) {
        height = (self.startDateButton.selected || self.endDateButton.selected) ? UITableViewAutomaticDimension : CGFLOAT_MIN;
    }
    return height;
}

#pragma mark - IBAction

- (IBAction)dateButtonTapped:(id)sender {
    AWSDKLogInfo(@"Date Button Tapped");
    ((UIButton *)sender).selected = !((UIButton *)sender).selected;
    if (sender == self.startDateButton) {
        self.startDateButton.backgroundColor = (self.startDateButton.selected) ? [UIColor whiteColor] : [UIColor buttonOrangeColor];
        if (self.endDateButton.selected) {
            [self toggleButton:self.endDateButton];
        }
    } else if (sender == self.endDateButton) {
        self.endDateButton.backgroundColor = (self.endDateButton.selected) ? [UIColor whiteColor] : [UIColor buttonOrangeColor];
        if (self.startDateButton.selected) {
            [self toggleButton:self.startDateButton];
        }
    }

    if (!self.startDateButton.selected && !self.endDateButton.selected) {
        [self loadTrackers];
    } else {
        [self.tableView reloadDataAnimated:YES];
        [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
    }
    [self updateHeader];
}

- (IBAction)datePickerChanged:(id)sender {
    UIDatePicker *picker = sender;
    AWSDKLogInfo(@"datePickerChanged: called. date =>%@<", picker.date);
    NSDateComponents *components = [NSCalendar.currentCalendar components:NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitYear|NSCalendarUnitHour|NSCalendarUnitMinute fromDate:picker.date];
    components.calendar = NSCalendar.currentCalendar;
    if (picker.tag == 0) {
        components.hour = 1;
        components.minute = 1;
        self.startDate = components.date;
    } else {
        components.hour = 23;
        components.minute = 59;
        self.endDate = components.date;
    }
    [self checkStartEndDate];
    [self updateHeader];
}

- (IBAction)deleteMeasurementsButtonTapped:(UIButton *)sender {
    AWSDKLogInfo(@"deleteMeasurementsButtonTapped");
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"myHealth.trackerDelete.title", @"Delete trackers alert title") message:NSLocalizedString(@"myHealth.trackerDelete.message", @"Delete trackers alert message") preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *deleteAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"message.delete", @"Delete alert action") style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        AWSDKLogInfo(@"Confirmed delete action");
        [ConsumerService.sharedInstance.consumer deleteTrackersWithTemplate:self.trackerTemplate dateInterval:[[NSDateInterval alloc] initWithStartDate:self.startDate endDate:self.endDate] timeZone:self.dateFormatter.timeZone completion:^(BOOL success, NSError * _Nullable error) {
            self.trackerEntries = @[];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.navigationController popViewControllerAnimated:YES];
            });
        }];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.cancel", @"Cancel alert action") style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        AWSDKLogInfo(@"Cancel delete action");
    }];
    [alert addAction:deleteAction];
    [alert addAction:cancelAction];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)toggleButton:(UIButton *)button {
    button.selected = !button.selected;
    button.backgroundColor = (button.selected) ? [UIColor whiteColor] : [UIColor buttonOrangeColor];
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"measurementAddSegue"]) {
        AWSDKLogInfo(@"Measurement add");
        MeasurementAddTableViewController *destinationViewController = (MeasurementAddTableViewController *)[(UINavigationController *)segue.destinationViewController viewControllers][0];
        destinationViewController.trackerTemplate = self.trackerTemplate;
    }
}

// MARK: - Setter Override

- (void)setTrackerEntries:(NSArray<id<AWSDKTrackerEntry>> *)trackerEntries {
    self.deleteButton.hidden = trackerEntries.count < 1;
    _trackerEntries = trackerEntries;
}

#pragma mark - Private Methods

- (void)setupStartEndDate {
    self.dateFormatter = [NSDateFormatter shortDateFormatter];
    NSDate *today = [NSDate new];
    NSDate *monthAgo = [today dateByAddingTimeInterval:-86400.0 * 30];
    self.startDate = monthAgo;
    self.endDate = today;
    [self updateHeader];

    [self.startDateButton setBackgroundColor:[UIColor buttonOrangeColor]];
    [self.endDateButton setBackgroundColor:[UIColor buttonOrangeColor]];
}

- (void)loadTrackers {
    __weak typeof(self) weakSelf = self;
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    [MBProgressHUD showLoadingOn:self.view];
    NSDateInterval *dateInterval = [[NSDateInterval alloc] initWithStartDate:self.startDate endDate:self.endDate];
    [consumer fetchTrackersWithTemplate:self.trackerTemplate
                           dateInterval:dateInterval
                               timeZone:[NSTimeZone localTimeZone]
                             completion:^(NSArray<id<AWSDKTrackerEntry>> *results, NSError *error) {
                                 [MBProgressHUD hideHUDForView:self.view];
                                 if (results) {
                                     weakSelf.trackerEntries = results;
                                     [self updateFooter];
                                     [weakSelf.tableView reloadDataAnimated:YES];
                                 }
                             }];
}

- (NSAttributedString *)formatAttributedTrailerNote:(NSString *)title message:(NSString *)message {
    UIFont *titleFont = [UIFont systemFontOfSize:14.0f weight:UIFontWeightSemibold];
    UIFont *messageFont = [UIFont systemFontOfSize:14.0f weight:UIFontWeightRegular];
    UIColor *foregroundColor = [UIColor blackColor];
    CGFloat paragraphSpacing = 0.45;
    NSString *string = (message.length) ? [NSString stringWithFormat:@"%@ %@", title, message] : [NSString stringWithFormat:@"%@", title];
    NSAttributedString *attributedText = [self applyAttributedInString:string
                                                                 title:title
                                                               message:message
                                                             titleFont:titleFont
                                                           messageFont:messageFont
                                                       foregroundColor:foregroundColor
                                                      paragraphSpacing:paragraphSpacing];
    return attributedText;
}

- (NSAttributedString *)formatAttributedTrailerMessage:(NSString *)message {
    NSRange messageRange = (message.length) ? NSMakeRange(0, message.length) : NSMakeRange(0, 0);
    UIFont *messageFont = [UIFont systemFontOfSize:16.0f weight:UIFontWeightRegular];
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
    paragraphStyle.paragraphSpacing = 0.45 * messageFont.lineHeight;
    paragraphStyle.alignment = NSTextAlignmentCenter;
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:message];
    if (message.length) {
        [attributedText addAttribute:NSFontAttributeName value:messageFont range:messageRange];
    }
    [attributedText addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(0, attributedText.length)];
    [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attributedText.length)];
    return attributedText;
}

- (NSAttributedString *)applyAttributedInString:(NSString *)string
                                          title:(NSString *)title
                                        message:(NSString *)message
                                      titleFont:(UIFont *)titleFont
                                    messageFont:(UIFont *)messageFont
                                foregroundColor:(UIColor *)foregroundColor
                               paragraphSpacing:(CGFloat)paragraphSpacing {
    NSRange titleRange = (title.length) ? NSMakeRange(0, title.length) : NSMakeRange(0, 0);
    NSRange messageRange = (message.length) ? NSMakeRange(title.length, message.length + 1) : NSMakeRange(0, 0);
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
    paragraphStyle.paragraphSpacing = paragraphSpacing * titleFont.lineHeight;

    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:string];
    if (title.length) {
        [attributedText addAttribute:NSFontAttributeName value:titleFont range:titleRange];
    }
    if (message.length) {
        [attributedText addAttribute:NSFontAttributeName value:messageFont range:messageRange];
    }
    if (foregroundColor) {
        [attributedText addAttribute:NSForegroundColorAttributeName value:foregroundColor range:NSMakeRange(0, attributedText.length)];
    }
    [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attributedText.length)];
    return attributedText;
}

- (void)updateHeader {
    UIFont *titleFont = [UIFont systemFontOfSize:12.0f weight:UIFontWeightSemibold];
    UIFont *messageFont = [UIFont systemFontOfSize:18.0f weight:UIFontWeightBold];
    CGFloat paragraphSpacing = 0.20;

    UIColor *foregroundColor = (self.startDateButton.selected) ? [UIColor blackColor] : [UIColor whiteColor];
    NSString *title = NSLocalizedString(@"misc.from", @"From Date");
    NSString *message = [self.dateFormatter stringFromDate:self.startDate];
    NSString *string = (message.length) ? [NSString stringWithFormat:@"%@\n%@", title, message] : [NSString stringWithFormat:@"%@", title];
    NSAttributedString *startDateAttrString = [self applyAttributedInString:string
                                                                      title:title
                                                                    message:message
                                                                  titleFont:titleFont
                                                                messageFont:messageFont
                                                            foregroundColor:foregroundColor
                                                           paragraphSpacing:paragraphSpacing];

    foregroundColor = (self.endDateButton.selected) ? [UIColor blackColor] : [UIColor whiteColor];
    title = NSLocalizedString(@"misc.to", @"To Date");
    message = [self.dateFormatter stringFromDate:self.endDate];
    string = (message.length) ? [NSString stringWithFormat:@"%@\n%@", title, message] : [NSString stringWithFormat:@"%@", title];
    NSAttributedString *endDateAttrString = [self applyAttributedInString:string
                                                                    title:title
                                                                  message:message
                                                                titleFont:titleFont
                                                              messageFont:messageFont
                                                          foregroundColor:foregroundColor
                                                         paragraphSpacing:paragraphSpacing];

    [self.startDateButton setAttributedTitle:startDateAttrString forState:self.startDateButton.selected ? UIControlStateSelected : UIControlStateNormal];
    [self.endDateButton setAttributedTitle:endDateAttrString forState:self.endDateButton.selected ? UIControlStateSelected : UIControlStateNormal];
}

- (void)updateFooter {
    if (self.trackerEntries.count) {
        self.footerLabel.attributedText = [self formatAttributedTrailerNote:NSLocalizedString(@"misc.note", @"Note") message:NSLocalizedString(@"myHealth.measurements.trailerNote", @"Trailer Note")];
    } else {
        self.footerLabel.attributedText = [self formatAttributedTrailerMessage:NSLocalizedString(@"myHealth.measurements.none.message", @"No Measurements Added")];
    }
    [self.deleteButton setTitle:NSLocalizedString(@"myHealth.trackerDelete.title", @"Delete Measurements") forState:UIControlStateNormal];
}

- (void)checkStartEndDate {
    if ([self.startDate compare:self.endDate] >= NSOrderedSame) {
        self.endDate = [self.startDate dateByAddingTimeInterval:1];
    }
}

@end
