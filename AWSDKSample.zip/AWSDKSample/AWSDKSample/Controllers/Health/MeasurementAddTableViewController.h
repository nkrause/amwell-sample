//
//  MeasurementAddTableViewController.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/16/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

// clang-format off
@protocol AWSDKTrackerTemplate, AWSDKTrackerComponentTemplate;
// clang-format on

@protocol MeasurementAddTableViewDelegate <NSObject>

- (void)trackerValidationChanged:(BOOL)isValid value:(NSNumber *)value position:(NSInteger)position error:(NSError *)error;

@end

@interface MeasurementAddTableViewController : UITableViewController

@property (nonatomic) id<AWSDKTrackerTemplate> trackerTemplate;

@end
