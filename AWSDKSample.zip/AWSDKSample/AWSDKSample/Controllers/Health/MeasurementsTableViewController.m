//
//  MeasurementsTableViewController.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/10/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MeasurementsTableViewController.h"

#import "MeasurementDetailViewController.h"
#import "MeasurementTableViewCell.h"
#import "TrackerTemplateSearchViewController.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKErrorCode.h>
#import <AWSDK/AWSDKErrorKeys.h>
#import <AWSDK/AWSDKService.h>
#import <AWSDK/AWSDKTrackerEntry.h>
#import <AWSDK/AWSDKTrackerTemplate.h>

@interface MeasurementsTableViewController ()

@property (nonatomic) NSArray<id<AWSDKTrackerTemplate>> *allTrackerTemplates;
@property (atomic) NSArray<id<AWSDKTrackerEntry>> *trackerEntries;
@property (nonatomic) id<AWSDKTrackerTemplate> selectedTrackerTemplate;
@property (atomic, assign) BOOL isLoading;

@end

@implementation MeasurementsTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = NSLocalizedString(@"myHealth.measurements.title", @"Navigation title - Measurements");
    // Shorten the Back button title to nothing since it may be too long to fit the navigation bar
    UIBarButtonItem *newBackButton = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationItem.backBarButtonItem = newBackButton;
    self.definesPresentationContext = YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self loadTrackers];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger rows = (self.trackerEntries.count > 0) ? self.trackerEntries.count : 1;
    return rows;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (!self.trackerEntries.count || self.isLoading) {
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"noDataCell" forIndexPath:indexPath];
        cell.textLabel.text = self.isLoading ? @"" : NSLocalizedString(@"myHealth.measurements.none.message", @"No Measurements Added");
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        return cell;
    }

    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    MeasurementTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"itemCell" forIndexPath:indexPath];
    cell.trackerEntry = self.trackerEntries[indexPath.row];
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    self.selectedTrackerTemplate = self.trackerEntries[indexPath.row].trackerTemplate;
    AWSDKLogInfo(@"Selected %@", self.selectedTrackerTemplate.title);
    [self performSegueWithIdentifier:@"measurementDetailSegue" sender:self];
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    AWSDKLogInfo(@"Measurement detail row");
    if ([segue.identifier isEqualToString:@"measurementDetailSegue"]) {
        MeasurementDetailViewController *destinationViewController = (MeasurementDetailViewController *)((UINavigationController *)segue.destinationViewController);
        destinationViewController.trackerTemplate = self.selectedTrackerTemplate;
    }
}

#pragma mark - Private Methods

- (void)loadTrackers {
    self.isLoading = YES;
    __weak typeof(self) weakSelf = self;
    __block NSInteger processedCount = 0;
    NSMutableArray<id<AWSDKTrackerEntry>> *trackerEntries = [NSMutableArray new];
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    [MBProgressHUD showLoadingOn:self.view];
    [AWSDKService searchTrackerTemplatesWithString:@""
                                        completion:^(NSArray<id<AWSDKTrackerTemplate>> *results, NSError *error) {
                                            if (!results.count) {
                                                [MBProgressHUD hideHUDForView:self.view];
                                            }
                                            weakSelf.allTrackerTemplates = results;
                                            [weakSelf.allTrackerTemplates enumerateObjectsUsingBlock:^(id<AWSDKTrackerTemplate> _Nonnull obj, NSUInteger idx, BOOL *_Nonnull stop) {
                                                
                                                NSDateInterval *dateInterval = [[NSDateInterval alloc] initWithStartDate:[NSDate distantPast] endDate:[NSDate new]];
                                                [consumer fetchTrackersWithTemplate:obj
                                                                       dateInterval:dateInterval
                                                                           timeZone:[NSTimeZone localTimeZone]
                                                                         completion:^(NSArray<id<AWSDKTrackerEntry>> *results, NSError *error) {
                                                                             processedCount++;
                                                                             if (results && results.count) {
                                                                                 [trackerEntries addObject:[[self sortTrackerEntries:results shouldReverse:YES] firstObject]];
                                                                             }
                                                                             if (processedCount == weakSelf.allTrackerTemplates.count) {
                                                                                 [MBProgressHUD hideHUDForView:self.view];
                                                                                 weakSelf.isLoading = NO;
                                                                                 weakSelf.trackerEntries = [self sortTrackerEntries:trackerEntries shouldReverse:YES];
                                                                                 [weakSelf.tableView reloadDataAnimated:YES];
                                                                             }
                                                                         }];
                                            }];
                                        }];
}

- (NSArray<id<AWSDKTrackerEntry>> *)sortTrackerEntries:(NSArray<id<AWSDKTrackerEntry>> *)entries shouldReverse:(BOOL)shouldReverse {
    NSArray<id<AWSDKTrackerEntry>> *array;
    array = [entries sortedArrayUsingComparator:^NSComparisonResult(id<AWSDKTrackerEntry> obj1, id<AWSDKTrackerEntry> obj2) {
        return [obj1.date compare:obj2.date];
    }];
    if (shouldReverse) {
        array = [[array reverseObjectEnumerator] allObjects];
    }
    return array;
}

@end
