//
//  TrackerTemplateSearchViewController.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/10/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "TrackerTemplateSearchViewController.h"

#import "MeasurementDetailViewController.h"
#import "MeasurementTableViewCell.h"
#import "UITableView+Sample.h"

#import <AWSDK/AWSDKErrorCode.h>
#import <AWSDK/AWSDKTrackerTemplate.h>
#import <AWSDK/AWSDKErrorKeys.h>
#import <AWSDK/AWSDKService.h>

@interface TrackerTemplateSearchViewController () <UISearchBarDelegate, UISearchControllerDelegate, UISearchResultsUpdating>

@property (nonatomic) NSArray<id<AWSDKTrackerTemplate>> *trackerTemplates;
@property (nonatomic) NSArray<id<AWSDKTrackerTemplate>> *filteredTrackerTemplates;

@property (weak, nonatomic) IBOutlet UITableView *filteredTableView;
@property (nonatomic) UITableViewController *resultsViewController;
@property (nonatomic) UISearchController *searchViewController;
@property (nonatomic) id<TrackerTemplateSearchDelegate> delegate;
@property (nonatomic) NSTimer *searchTimer;

- (IBAction)cancelTapped:(id)sender;

@end

@implementation TrackerTemplateSearchViewController

#pragma mark AWSDK Method Calls

/**
 *  Search tracker template based on a string and return results to display
 *
 *  @param string NSString Search Text
 */
- (void)searchTrackerTemplatesWithString:(NSString *)string completion:(void (^)(NSError *error))completion {
    __weak typeof(self) weakSelf = self;
    BOOL isFiltered = string.length > 0;
    [MBProgressHUD showSearchingOn:self.view];
    [AWSDKService searchTrackerTemplatesWithString:string
                                        completion:^(NSArray<id<AWSDKTrackerTemplate>> *results, NSError *error) {
                                            [MBProgressHUD hideHUDForView:self.view];
                                            if (error) {
                                                [weakSelf presentAlertWithError:error okHandler:nil];
                                            } else {
                                                if (isFiltered) {
                                                    weakSelf.filteredTrackerTemplates = results;
                                                    [weakSelf.resultsViewController.tableView reloadDataAnimated:YES];
                                                } else {
                                                    weakSelf.trackerTemplates = results;
                                                    [weakSelf.tableView reloadDataAnimated:YES];
                                                }
                                            }
                                            if (completion) {
                                                completion(error);
                                            }
                                        }];
}

//-----------------------------------------------------------------------------------------------------//
//---------------Everything beyond here is UI for the sample app, no more API calls here --------------//
//-----------------------------------------------------------------------------------------------------//

- (void)viewDidLoad {
    [super viewDidLoad];

    [self setupSearchController];
    self.title = NSLocalizedString(@"myHealth.trackerSearch.title", @"Navigation title - Measurements");
    // Shorten the Back button title to nothing since it may be too long to fit the navigation bar
    UIBarButtonItem *newBackButton = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationItem.backBarButtonItem = newBackButton;
    self.definesPresentationContext = YES;

    // Skip to next screen
    if (self.selectedTrackerTemplate) {
        AWSDKLogInfo(@"Selected %@", self.selectedTrackerTemplate.title);
        [self performSegueWithIdentifier:@"measurementDetailSegue" sender:self];
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    [self searchTrackerTemplatesWithString:self.selectedTrackerTemplate.title ?: @""
                                completion:^(NSError *error) {
                                    if (self.selectedTrackerTemplate) {
                                        self.searchViewController.searchBar.text = self.selectedTrackerTemplate.title;
                                    }
                                }];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return (tableView == self.tableView) ? self.trackerTemplates.count : self.filteredTrackerTemplates.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"basicCell"];
    id<AWSDKTrackerTemplate> trackerTemplate = [self trackerTemplateForTableView:tableView indexRow:indexPath];
    cell.textLabel.text = trackerTemplate.title;
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    self.selectedTrackerTemplate = [self trackerTemplateForTableView:tableView indexRow:indexPath];
    AWSDKLogInfo(@"Selected %@", self.selectedTrackerTemplate.title);
    [self performSegueWithIdentifier:@"measurementDetailSegue" sender:self];
}

#pragma mark - UISearchBarDelegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    AWSDKLogInfo(@"Search text changed to %@", searchText);
    // Add 2 seconds delay before starting search to allow user to type earch characters
    __weak typeof(self) weakSelf = self;
    [self.searchTimer invalidate];
    self.searchTimer = [NSTimer scheduledTimerWithTimeInterval:2.0
                                                       repeats:NO
                                                         block:^(NSTimer *timer) {
                                                             [weakSelf searchTrackerTemplatesWithString:searchText completion:nil];
                                                             weakSelf.searchTimer = nil;
                                                         }];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [self searchTrackerTemplatesWithString:searchBar.text completion:nil];
}

#pragma mark - UISearchResultsUpdating

- (void)updateSearchResultsForSearchController:(UISearchController *)searchController {
}

#pragma mark - IBAction

- (IBAction)cancelTapped:(id)sender {
    AWSDKLogInfo(@"Cancel tapped");
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    AWSDKLogInfo(@"Search tracker button tapped");
    if ([segue.identifier isEqualToString:@"measurementDetailSegue"]) {
        MeasurementDetailViewController *destinationViewController = (MeasurementDetailViewController *)segue.destinationViewController;
        destinationViewController.trackerTemplate = self.selectedTrackerTemplate;
    }
}

#pragma mark - Private Methods

- (void)setupSearchController {
    self.resultsViewController = [UITableViewController new];
    self.resultsViewController.tableView = self.filteredTableView;
    self.resultsViewController.tableView.delegate = self;

    self.searchViewController = [[UISearchController alloc] initWithSearchResultsController:self.resultsViewController];
    self.searchViewController.delegate = self;
    self.searchViewController.searchResultsUpdater = self;
    self.searchViewController.searchBar.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.searchViewController.searchBar.delegate = self;
    self.searchViewController.searchBar.placeholder = NSLocalizedString(@"myHealth.trackerSearch.prompt", @"Navigation prompt - type the name of the tracker");
    self.searchViewController.searchBar.backgroundColor = [UIColor whiteColor];
    self.searchViewController.dimsBackgroundDuringPresentation = false;
    self.navigationItem.searchController = self.searchViewController;
    // Make the search bar always visible.
    self.navigationItem.hidesSearchBarWhenScrolling = false;
}

- (id<AWSDKTrackerTemplate>)trackerTemplateForTableView:(UITableView *)tableView indexRow:(NSIndexPath *)indexPath {
    return (tableView == self.tableView) ? self.trackerTemplates[indexPath.row] : self.filteredTrackerTemplates[indexPath.row];
}

@end
