//
//  LanguageSelectionTableViewController.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 11/6/17.
//  Copyright © 2017 American Well. All rights reserved.
//

#import "LanguageSelectionTableViewController.h"

#import "AppDelegate.h"

#import <AWSDK/AWSDKLanguage.h>
#import <AWSDK/AWSDKLocale.h>
#import <AWSDK/AWSDKService.h>
#import <AWSDK/AWSDKSystemConfiguration.h>

/**
 *  LanguageSelectionTableViewController displays a list of languages in a tableview to override systems language
 */
@interface LanguageSelectionTableViewController ()

@property (nonatomic, readonly) NSArray<NSLocale *> *locales;
@property (nonatomic, nullable) NSLocale *defaultLocale;
@property (nonatomic, nullable) NSLocale *selectedLocale;

@end

@implementation LanguageSelectionTableViewController

#pragma mark - UIViewController Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];

    [self loadDefaultLocale];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    [self setupDefaultSelection];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.locales.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    NSLocale *locale = self.locales[indexPath.row];
    NSString *language = [[NSLocale currentLocale] localizedStringForLanguageCode:locale.languageCode];
    NSString *languageDetail = [locale localizedStringForLanguageCode:locale.languageCode];
    [cell.textLabel setText:language];
    [cell.detailTextLabel setText:languageDetail];
    [self setSelection:(locale == self.selectedLocale) forCell:cell];
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    AWSDKLogInfo(@"Selected %@ cell", cell.textLabel.text);
    NSLocale *locale = self.locales[indexPath.row];
    BOOL selection = (locale != self.selectedLocale);
    [self updateLocale:selection ? locale : nil];
    [self setSelection:selection forCell:cell];
}

#pragma mark - Private Methods

- (void)setSelection:(BOOL)selection forCell:(UITableViewCell *)cell {
    [cell setAccessoryType:(selection) ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone];
    [cell setSelected:selection];
}
- (void)loadDefaultLocale {
    _locales = [AWSDKSystemConfiguration supportedLocales];
    NSString *localeIdentifier = [NSUserDefaults.standardUserDefaults objectForKey:APP_LOCALE_OVERRIDE];
    if (!localeIdentifier) {
        NSLocale *locale = AWSDKLocale.preferredLocale;
        localeIdentifier = [locale objectForKey:NSLocaleIdentifier];
    }
    [NSUserDefaults.standardUserDefaults setObject:localeIdentifier forKey:APP_LOCALE_OVERRIDE];
    [NSUserDefaults.standardUserDefaults synchronize];
    self.defaultLocale = [NSLocale localeWithLocaleIdentifier:localeIdentifier];
    self.selectedLocale = self.defaultLocale;
}

- (void)updateLocale:(NSLocale *)locale {
    [NSUserDefaults.standardUserDefaults setObject:locale.localeIdentifier forKey:APP_LOCALE_OVERRIDE];
    [NSUserDefaults.standardUserDefaults synchronize];
    self.selectedLocale = locale;
    [AWSDKLocale setPreferredLocale:locale];
}

- (void)setupDefaultSelection {
    int row = 0;
    for (NSLocale *locale in self.locales) {
        if (self.defaultLocale == locale) {
            self.selectedLocale = nil;
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];
            [self.tableView selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionTop];
            break;
        }
        row++;
    }
}

@end
