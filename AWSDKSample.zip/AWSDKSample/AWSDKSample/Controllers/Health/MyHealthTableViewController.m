//
//  MyHealthTableViewController.m
//  AWSDKSample
//
//  Created by Jeremiah.Possion on 1/9/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MyHealthTableViewController.h"

#import "HealthKitService.h"

#import <AWSDK/AWSDKBiologicalSex.h>

/**
 Displays options related to the My Health section
 */
@interface MyHealthTableViewController ()

@property (nonatomic) NSArray<NSDictionary *> *healthItems;
@property (nonatomic) BOOL showHealthKitOption;

@end

@implementation MyHealthTableViewController

#pragma mark - Sample App UI

//-----------------------------------------------------------------------------------------------------//
//---------------Everything here is UI for the sample app, no more API calls here ---------------------//
//-----------------------------------------------------------------------------------------------------//

- (void)viewDidLoad {
    [super viewDidLoad];
    self.showHealthKitOption = NO;
    [self setupTableData];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    HealthKitService *hkService = [[HealthKitService alloc] init];
    if (![hkService isHealthDataAvailable] && !HealthKitService.healthKitUnavailableMessageShown) {
        [self presentViewController:[UIAlertController alertControllerWithMessageKey:@"healthkit.alert.unavailable.message" okHandler:nil] animated:YES completion:nil];
        HealthKitService.healthKitUnavailableMessageShown = YES;
    } else {
        // Check for permissions to use Health Kit
        [hkService requestAuthorization:^(BOOL success, NSError *error) {
            if (!success) {
                AWSDKLogInfo(@"Error prompting the user for authorization for reading and writing the requested health kit types. Error: %@", error);
                self.showHealthKitOption = NO;
            } else {
                AWSDKLogInfo(@"Successfully prompted the user for authorization for reading and writing the requested health kit types.");
                self.showHealthKitOption = YES;
            }

            dispatch_async(dispatch_get_main_queue(), ^{
                [self setupTableData];
            });
        }];
    }
}

#pragma mark - Private
- (void)setupTableData {
    NSMutableArray *tableData =
        @[
            @{ @"title" : NSLocalizedString(@"myHealth.medicalHistory.title", @"Cell title - Medical history"), @"segue" : @"conditionsSeque", @"image" : [UIImage imageNamed:@"medicalHistory"] },
            @{ @"title" : NSLocalizedString(@"myHealth.allergies.title", @"Cell title - Allergies"), @"segue" : @"allergiesSegue", @"image" : [UIImage imageNamed:@"allergies"] },
            @{ @"title" : NSLocalizedString(@"myHealth.medications.title", @"Cell title - Medications"), @"segue" : @"medicationsSegue", @"image" : [UIImage imageNamed:@"medications"] },
            @{ @"title" : NSLocalizedString(@"myHealth.measurements.title", @"Cell title - Measurements"), @"segue" : @"measurementsSegue", @"image" : [UIImage imageNamed:@"vitals"] },
            @{
                @"title" : NSLocalizedString(@"myHealth.healthDocuments.title", @"Cell title - Attachments"),
                @"segue" : @"healthDocumentsSegue",
                @"image" : [UIImage imageNamed:@"healthDocuments"]
            }
        ]
            .mutableCopy;

    if (self.showHealthKitOption) {
        [tableData addObject:@{ @"title" : NSLocalizedString(@"myHealth.healthKit.title", @"Cell title - HealthKit"), @"segue" : @"healthKitSegue", @"image" : [UIImage imageNamed:@"HealthKit"] }];
    }

    self.healthItems = [tableData copy];
    [self.tableView reloadData];
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.healthItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *item = self.healthItems[indexPath.row];

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"healthOptionCell" forIndexPath:indexPath];

    cell.textLabel.text = item[@"title"];
    cell.imageView.image = item[@"image"];

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *item = self.healthItems[indexPath.row];
    AWSDKLogInfo(@"%@ cell tapped", item[@"title"]);
    [self performSegueWithIdentifier:item[@"segue"] sender:self];
}

@end
