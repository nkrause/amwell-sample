//
//  HealthDocumentsTableViewController.h
//  AWSDKSample
//
//  Created by Steven Uy on 7/26/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface HealthDocumentsTableViewController : UITableViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@end
