//
//  ConsumerService.h
//  AWSDKSample
//
//  Created by Steven Uy on 3/21/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

// clang-format off
@protocol AWSDKConsumer, AWSDKPartialConsumer, AWSDKAppointment;
// clang-format on

typedef void (^ConsumerBlock)(BOOL success, id _Nullable result);
typedef void (^AppointmentBlock)(id<AWSDKAppointment> _Nullable result);
typedef void (^ActiveVisitBlock)(id<AWSDKVisit> _Nullable result);

extern NSString *const _Nonnull ConsumerUpdatedNotification;

/**
 ConsumerService is a singleton class that retains the current consumer information
 and handles authentication and checking for appointments
 */
@interface ConsumerService : NSObject

/**
 Always holds a reference to the parent consumer who has no dependents
 */
@property (nonatomic, strong, nullable) id<AWSDKConsumer> parentConsumer;

/**
 The current consumer, may == parentConsumer or may be a dependent of parent consumer
 */
@property (nonatomic, strong, nullable) id<AWSDKConsumer> consumer;

/**
 Authenticationkey for the entire account
 */
@property (nonatomic, strong, nullable) NSString *authenticationKey;

/**
 UserName for the account
 */
@property (nonatomic, strong, nullable) NSString *userName;

/**
 True if logged in and consumer exists, false otherwise
 */
@property (nonatomic, assign) BOOL isloggedIn;

@property (nonatomic, assign) BOOL isParent;

/**
 Singleton class holding references to AWSDKConsumers and associated methods
 *
 @return A ConsumerService shared instance of the single class
 */
+ (nonnull instancetype)sharedInstance;

/**
 Returns true if the current consumer is a feed consumer, false otherwise

 @return BOOL where true if the current consumer is a feed consumer
 */
+ (BOOL)isFeedMember;

/**
 Refeshes the saved consumers and authentication key

 @param completion returns the current consumer post refresh
 */
- (void)refreshConsumerWithCompletion:(nullable ConsumerBlock)completion;

/**
 Fetches authenticationKey if none exists from user defaults
 */
- (nullable NSString *)fetchAuthenticationKey;

/**
 Fetches UserName if none exists from user defaults
 */
- (nullable NSString *)fetchUserName;

/**
 Sets the authentication key with the option to persist to disk
 */
- (void)clearAuthenticationKey;

/**
 Sets the userName with the option to persist to disk
 */
- (void)clearUserName;

/**
 Authenticates a consumer based on a username and password. If succesful returns the consumer
 object and saves it


 @param username   NSString containing a username
 @param password   NSString constaining a password
 @param autoLogin  BOOL determining if the authentication key should be saved to automatically login
 @param completion AWSDKConsumer if succesfull, false otherwise
 */
- (void)authenticateConsumerWithUsername:(nonnull NSString *)username withPassword:(nonnull NSString *)password enableAutoLogin:(BOOL)autoLogin withCompletion:(nullable ConsumerBlock)completion;

/**
 Authenticates a consumer using server to server communication. If successful returns the consumer
 object and saves it

 @param token        The auth token to send to the server
 @param completion   AWSDKConsumer if succesfull, false otherwise
 */
- (void)authenticateConsumerMutualAuthToken:(nonnull NSString *)token withCompletion:(nullable ConsumerBlock)completion;

/**
 Clears a user and all its associated references.
 */
- (void)deauthenticateConsumer;

/**
 Checks if a URL exists for a current appointment

 @param completion Returns an appointment if one is available
 */
- (void)checkForAppointmentWithCompletion:(nullable AppointmentBlock)completion;

/**
 Checks if the consumer has an active visit

 @param completion Returns the active visit if one exists
 */
- (void)checkForActiveVisitWithCompletion:(nullable ActiveVisitBlock)completion;

@end
