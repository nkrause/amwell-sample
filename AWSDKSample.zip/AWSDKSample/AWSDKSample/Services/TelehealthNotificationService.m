//
//  TelehealthNotificationService.m
//  AWSDKSample
//
//  Created by Stephen Ciauri on 7/24/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import "TelehealthNotificationService.h"

#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKConsumerNotifications.h>

@implementation TelehealthNotificationService

+ (void)checkNotificationsForConsumer:(id<AWSDKConsumer>)consumer completion:(NotificationStatusCompletionBlock)completion {
    __block NotificationsBitmask notificationMask = NoNotifications;
    [MBProgressHUD show];
    [consumer fetchActionableNotificationsWithCompletion:^(AWSDKConsumerNotifications *notifications, NSError *error) {
        [MBProgressHUD hide];
        if (notifications.unreadInboxCount) {
            notificationMask |= SecureMessageNotification;
        }
        if (notifications.dependentAccessRequestCount) {
            notificationMask |= ChildAccessNotification;
        }
        if (notifications.isTimeForNextAppointment) {
            notificationMask |= UpcomingAppointmentNotification;
        }
        completion(notificationMask);
    }];
}

@end
