//
//  ErrorService.h
//  AWSDKSample
//
//  Created by Steven Uy on 5/26/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

/**
 Error Service handles more complex error handling for forms with parameters with individual errors

 */
@interface ErrorService : NSObject

/**
 Init with a view controller to present alerts to

 @param sender UIViewController allocating ErrorService

 @return ErrorService instance
 */
- (nonnull id)initWithSender:(nonnull UIViewController *)sender;

/**
 Adds a unique observer on a view for a keyPath string, a match may occur in the userInfo of an
 error

 @param view    UIView to observe
 @param keyPath keyPath as a key in userInfo for an individual error
 */
- (void)addObserver:(nonnull UIView *)view forKeyPath:(nonnull NSString *)keyPath;

/**
 Presenting an error alert with an ok button.

 @note Calls handleError with nil okHandler

 @param error NSError
 */
- (void)handleError:(nullable NSError *)error;

/**
 Present an error alert with an ok button to call the provided handler. If error is nil clears errors for observered views and does not present an error alert.

 @param error   NSError
 @param handler handler called when ok is pressed
 */
- (void)handleError:(nullable NSError *)error okHandler:(nullable void (^)(UIAlertAction *_Nullable action))handler;

/**
 Clears all error displayed on the form.

 */
- (void)clearErrors;

+ (nonnull NSString *)messageKeyForEndReason:(AWCoreVisitEndReason)reason;

@end

@protocol CanShowErrorText <NSObject>
- (nullable NSString *)errorText;
@end
