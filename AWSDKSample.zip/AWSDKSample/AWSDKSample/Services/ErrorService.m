//
//  ErrorService.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/26/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ErrorService.h"

#import "BottomBorderTextField.h"
#import "ErrorButton.h"
#import "ErrorPopoverBackgroundView.h"
#import "ErrorViewController.h"
#import "FieldTableViewCell.h"

#import <AWSDK/AWSDKErrorCode.h>
#import <AWSDK/AWSDKErrorKeys.h>
#import <AWSDK/AWSDKLogService.h>

/**
 *  Error Service handles more complex error handling for forms with parameters with individual errors
 *
 */
@interface ErrorService () <UIPopoverPresentationControllerDelegate>

/**
 *  Maps property to a UIView to handle the error
 */
@property (nonatomic) NSMutableDictionary<NSString *, UIView *> *views;

@property (weak, nonatomic) UIViewController *senderViewController;

@end

@implementation ErrorService

//-----------------------------------------------------------------------------------------------------//
//-----------------Everything here is other logic for the sample app, no more API calls here ----------//
//-----------------------------------------------------------------------------------------------------//

- (id)initWithSender:(UIViewController *)sender {
    self = [super init];
    if (self) {
        self.senderViewController = sender;
        self.views = [NSMutableDictionary new];
    }
    return self;
}

- (void)dealloc {
    if (!self.views || ![self.views isKindOfClass:[NSDictionary class]]) {
        return;
    }
    [self.views enumerateKeysAndObjectsUsingBlock:^(NSString *property, UIView *view, BOOL *stop) {
        if ([view isKindOfClass:[UITableViewCell class]]) {
            @try {
                [((UITableViewCell *)view).detailTextLabel removeObserver:self forKeyPath:@"text"];
            } @catch (id anException) {
            }
        }
    }];
}

- (void)addObserver:(UIView *)view forKeyPath:(NSString *)keyPath {
    if (view) {
        [self.views setObject:view forKey:keyPath];
    }
}

- (void)handleError:(NSError *)error okHandler:(void (^)(UIAlertAction *))handler {
    if (error.userInfo) {
        NSDictionary *valueErrors = [self flattenedDictionaryWithDictionary:[error.userInfo objectForKey:AWSDKValidationErrorsKey]];

        // Enumerate through views to update with current error
        [self.views enumerateKeysAndObjectsUsingBlock:^(id key, UIView *view, BOOL *stop) {
            NSNumber *errorCode;
            if ((errorCode = valueErrors[key])) {
                ErrorButton *button = [self errorButtonInView:view showError:(errorCode != nil)];
                // Update error message
                if ([view respondsToSelector:@selector(errorText)]) {
                    NSString *keyInfo = NSLocalizedString(key, @"Generic Error Title");
                    NSString *displayableErr = error.userInfo[NSLocalizedDescriptionKey];
                    if (keyInfo) {
                        displayableErr = [NSString stringWithFormat:@"%@ - %@", error.userInfo[NSLocalizedDescriptionKey], keyInfo];
                    }
                    [button setErrorMessage:((id<CanShowErrorText>)view).errorText ?: displayableErr];
                } else {
                    [button setErrorMessage:error.userInfo[NSLocalizedDescriptionKey]];
                }
            }
        }];
    }

    if (error) {
        NSString *message = error.localizedFailureReason ?: error.localizedDescription;

        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"alert.error", @"Generic Alert Error Title") message:message];

        UIAlertAction *ok = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.ok", @"Generic Alert Okay Title") style:UIAlertActionStyleDefault handler:[alert defaultAlertHandler:handler]];
        [alert addAction:ok];

        // NOTE: (NSError).localizedDescription is not client facing!
        //       Please create a list of client facing erorr messages to pair with the associated
        //       error code and developer error messagess.
        AWSDKLogError(@"Error: #%@: %@", error.localizedDescription, error.userInfo);

        [self.senderViewController presentAlertController:alert];
    }
}

- (void)handleError:(NSError *)error {
    [self handleError:error okHandler:nil];
}

- (ErrorButton *)errorButtonInView:(UIView *)view showError:(BOOL)show {
    ErrorButton *iconButton;

    if ([view isKindOfClass:[BottomBorderTextField class]]) {
        [((BottomBorderTextField *)view) setError:show ? @"dummy" : nil];
        iconButton = ((BottomBorderTextField *)view).errorButton;

    } else if ([view isKindOfClass:[UITableViewCell class]]) {
        UITableViewCell *cell = (UITableViewCell *)view;

        ErrorButton *button = [[ErrorButton alloc] initWithError:nil];
        [cell setAccessoryView:show ? button : nil];
        [cell setEditingAccessoryView:show ? button : nil];

        // Handle Subviews
        if ([cell isKindOfClass:[FieldTableViewCell class]]) {
            UITextField *textField = ((FieldTableViewCell *)cell).textField;

            if ([textField isKindOfClass:[BottomBorderTextField class]]) {
                [((BottomBorderTextField *)textField) setError:show ? @"Dummy" : nil];
                [((BottomBorderTextField *)textField) setErrorButton:show ? (ErrorButton *)cell.accessoryView : nil];
                if (show) {
                    [textField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
                }
            }

        } else if (cell.detailTextLabel) {
            [cell.detailTextLabel setTextColor:show ? [UIColor redColor] : [UIColor darkTextColor]];
            if (show) {
                [cell.detailTextLabel addObserver:self forKeyPath:@"text" options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld context:(__bridge void *_Nullable)(cell)];
            }
        }

        iconButton = (ErrorButton *)cell.accessoryView;
        [iconButton setErrorCell:cell];
    } else if ([view isKindOfClass:[ErrorButton class]]) {
        iconButton = (ErrorButton *)view;
    }

    [iconButton addTarget:self action:@selector(errorButtonTapped:) forControlEvents:UIControlEventTouchUpInside];

    return iconButton;
}

- (void)clearErrors {
    // Enumerate through views to clear current errors
    [self.views enumerateKeysAndObjectsUsingBlock:^(id key, UIView *view, BOOL *stop) {
        [self errorButtonInView:view showError:NO];
    }];
}

#pragma mark - Recursive Flatten Dictionary
- (NSDictionary *)flattenedDictionaryWithDictionary:(NSDictionary *)dictionary {
    NSMutableArray *flattendedObjects = @[].mutableCopy;
    NSMutableDictionary *newDict = dictionary.mutableCopy;
    if ([dictionary isKindOfClass:[NSDictionary class]]) {
        [dictionary enumerateKeysAndObjectsUsingBlock:^(id key, id value, BOOL *stop) {
            if ([value isKindOfClass:[NSMutableDictionary class]]) {
                // Adds flattened dictionary to temporary dictionary
                [newDict addEntriesFromDictionary:[self flattenedDictionaryWithDictionary:value]];
                // Add flattended object to removal list
                [flattendedObjects addObject:key];
            }
        }];
    }
    return [NSDictionary dictionaryWithDictionary:newDict];
}

#pragma mark - Present ErrorButton Popover
- (IBAction)errorButtonTapped:(id)sender {
    ErrorViewController *errorViewController = [[ErrorViewController alloc] initWithNibName:@"ErrorViewController" bundle:nil];
    [errorViewController setModalPresentationStyle:UIModalPresentationPopover];
    [errorViewController setErrorMessage:((ErrorButton *)sender).errorMessage];
    [errorViewController setPreferredContentSize:CGSizeMake(100, 100)];

    UIPopoverPresentationController *popoverController = errorViewController.popoverPresentationController;
    [popoverController setDelegate:self];
    [popoverController setPermittedArrowDirections:0];
    [popoverController setSourceRect:((ErrorButton *)sender).bounds];
    [popoverController setSourceView:(ErrorButton *)sender];
    [popoverController setCanOverlapSourceViewRect:YES];
    [popoverController setPopoverBackgroundViewClass:[ErrorPopoverBackgroundView class]];

    [self.senderViewController presentViewController:errorViewController animated:YES completion:nil];
}

#pragma mark - IBAction and observers
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ([keyPath isEqualToString:@"text"]) {
        if ([change[@"new"] isEqualToString:change[@"old"]]) {
            return;
        }
        @try {
            [object removeObserver:self forKeyPath:keyPath];
        } @catch (id anException) {
        }
        if ([object isKindOfClass:[UILabel class]]) {
            [((UILabel *)object) setTextColor:[UIColor darkTextColor]];
        }
        if ([(__bridge UIView *)context isKindOfClass:[UITableViewCell class]]) {
            UITableViewCell *cell = (__bridge UITableViewCell *)context;
            [cell setAccessoryView:nil];
        }
    }
}

- (void)textFieldDidChange:(id)sender {
    [sender removeTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    BottomBorderTextField *textField = (BottomBorderTextField *)sender;
    [textField setError:nil];
    [textField.errorButton.errorCell setAccessoryView:nil];
    [textField.errorButton.errorCell setEditingAccessoryView:nil];
}

#pragma mark - UIPopoverPresentationDelegate
- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController {
    return YES;
}

- (UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

#pragma mark - MessageKey mapping to AWCoreVisitEndReason
+ (NSString *)messageKeyForEndReason:(AWCoreVisitEndReason)reason {
    switch (reason) {
        case AWCoreVisitEndReasonUnknown:
            return @"visitEnd.unknown";
        case AWCoreVisitEndReasonVisitEnded:
            return @"visitEnd.visitEnded";
        case AWCoreVisitEndReasonConsumerEnd:
            return @"visitEnd.consumerEnded";
        case AWCoreVisitEndReasonProviderEnd:
            return @"visitEnd.providerEnded";
        case AWCoreVisitEndReasonVisitExpired:
            return @"visitEnd.visitExpired";
        case AWCoreVisitEndReasonProviderDeclined:
        case AWCoreVisitEndReasonAssistantDecline:
            return @"visitEnd.providerDeclined";
        case AWCoreVisitEndReasonConsumerCancel:
            return @"visitEnd.consumerCancel";
        case AWCoreVisitEndReasonProviderBail:
            return @"visitEnd.providerCancel";
        case AWCoreVisitEndReasonConsumerOutdialFailed:
            return @"visitEnd.connectionFailed";
        case AWCoreVisitEndReasonPermissionsError:
            return @"visitEnd.noAccess";
        case AWCoreVisitEndReasonProviderDeclineAndTransfer:
        case AWCoreVisitEndReasonAssistantDeclineAndTransfer:
            // This is handled in the declineTransfer method
            return @"visitEnd.providerDeclinedAndTransferDeclined";
        case AWCoreVisitEndReasonConsumerDisconnectPostThreshold:
        case AWCoreVisitEndReasonConsumerDisconnectPreThreshold:
        case AWCoreVisitEndReasonConsumerForcedDisconnect:
            return @"visitEnd.consumerDisconnect";
        case AWCoreVisitEndReasonProviderDisconnect:
            return @"visitEnd.providerDisconnected";
        case AWCoreVisitEndReasonProviderLogout:
            return @"visitEnd.provierUnavailable";
        default:
            AWSDKLogError(@"Undefined AWCoreVisitEndReason %ld", (long)reason);
            return nil;
    }
}

@end
