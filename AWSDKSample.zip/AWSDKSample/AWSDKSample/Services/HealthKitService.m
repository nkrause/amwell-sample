//
//  HealthKitService.m
//  AWSDKSample
//
//  Created by Jeremiah.Possion on 12/21/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.

#import "HealthKitService.h"

#import <HealthKit/HealthKit.h>

// SDK Imports
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKHealthTrackerRecordForm.h>
#import <AWSDK/AWSDKHealthTrackerType.h>

static BOOL _healthKitUnavailableMessageShown;
@interface HealthKitService ()

@property BOOL failedToAuthenticateHealthKit;
@property (nonatomic) NSNumberFormatter *numberFormatter;

- (void)getMostRecentSampleDateOfTrackerType:(id<AWSDKHealthTrackerType>)type withCompletion:(void (^)(NSDate *date, NSError *error))completion;
- (NSNumber *)getSystolic:(HKCorrelation *)bloodPressure;
- (NSNumber *)getDiastolic:(HKCorrelation *)bloodPressure;
- (NSString *_Nullable)calculateValueForDouble:(double)value withDecimalPlaces:(NSInteger)decimalPlaces forUnit:(HKUnit *)hkUnit;

@end

@implementation HealthKitService

#pragma mark - Initialization
- (instancetype)init {
    if (self = [super init]) {
        self.healthStore = [[HKHealthStore alloc] init];
        self.numberFormatter = [NSNumberFormatter new];
    }
    return self;
}
// getter and setter for healthKitUnavailableMessageShown property
+ (BOOL)healthKitUnavailableMessageShown {
    return _healthKitUnavailableMessageShown;
}
+ (void)setHealthKitUnavailableMessageShown:(BOOL)arg {
    _healthKitUnavailableMessageShown = arg;
}

- (BOOL)isHealthDataAvailable {
    return [HKHealthStore isHealthDataAvailable];
}

- (BOOL)canSeeHealthKitData {
    // If we failed to authenticate with HK we want to return NO
    if (![HKHealthStore isHealthDataAvailable] || self.failedToAuthenticateHealthKit) {
        return NO;
    }

    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    NSString *hkHash = [self healthKitUserHash];
    return (!hkHash || [hkHash isEqualToString:consumer.consumerAuthKey]);
}

- (void)linkHealthKit {
    id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
    // Only link if we have not linked before.
    if (![self healthKitUserHash] && consumer.consumerAuthKey != nil) {
        [[NSUserDefaults standardUserDefaults] setObject:consumer.consumerAuthKey forKey:@"AWSDK_SAMPLE_USER_HASH"];
    }
}

- (NSString *)healthKitUserHash {
    return [[NSUserDefaults standardUserDefaults] stringForKey:@"AWSDK_SAMPLE_USER_HASH"];
}

#pragma mark - Sync
- (void)upload:(void (^)(BOOL success, NSError *error))completion {
    [MBProgressHUD show];
    [self getHealthKitData:^(NSArray *data, NSError *error) {
        [MBProgressHUD hide];
        AWSDKLogInfo(@"%@", data);

        if (data == nil) {
            AWSDKLogInfo(@"No data retrieved. Exit out and abandon the sync.");
            return;
        }

        id<AWSDKConsumer> consumer = [[ConsumerService sharedInstance] consumer];
        NSMutableArray<AWSDKHealthTrackerRecordForm *> *trackerFormData = [NSMutableArray new];
        
        ///////////////////////////////////////////////////////////////////////////////////////
        // FOR UNIT TESTING PURPOSES ONLY
        //
        // Dump HealthKit data to a local archive for stubbing purposes
        //
        // Uncomment the line below to dump the latest HealthKit data to a stub file
        // [AWSDKHealthTrackerRecordForm archiveHealthKitData:data];
        ///////////////////////////////////////////////////////////////////////////////////////

        // Loop through the _healthData array and create a record form for each object to send to the server.
        for (NSDictionary *item in data) {
            AWSDKHealthTrackerRecordForm *recordForm = [AWSDKHealthTrackerRecordForm form];
            recordForm.date = item[@"date"];
            recordForm.value = item[@"rawValue"];
            recordForm.type = item[@"type"];

            [trackerFormData addObject:recordForm];
        }

        if (trackerFormData.count) {
            [MBProgressHUD show];
            [consumer addHealthTrackerRecords:trackerFormData
                             withVisitContext:nil
                                   completion:^(BOOL success, NSError *error) {
                                       [MBProgressHUD hide];
                                       if (!success) {
                                           completion(NO, error);
                                       } else {
                                           completion(YES, nil);
                                       }
                                   }];
        } else {
            AWSDKLogWarn(@"There is no HealthKit data to upload.");
            completion(YES, nil);
        }
    }];
}

#pragma mark - Authorization
- (void)requestAuthorization:(void (^)(BOOL, NSError *_Nullable))completion {
    if (self.hkTypes.count > 0) {
        [self.healthStore requestAuthorizationToShareTypes:self.hkTypes
                                                 readTypes:self.hkTypes
                                                completion:^(BOOL success, NSError *error) {
                                                    // An error occured asking for permissions to read/write HK data. This could be due to the entitlements being turned off. Mark this so we do not
                                                    // allow any kind of interaction.
                                                    self.failedToAuthenticateHealthKit = !success;

                                                    if (success) {
                                                        [self linkHealthKit];
                                                    }

                                                    completion(success, error);
                                                }];
    } else {
        NSDictionary *userInfo = @{
            NSLocalizedDescriptionKey : NSLocalizedString(@"healthkit.error.noAvailableTypes.description", @"Health Kit Error No Available Types Description"),
            NSLocalizedFailureReasonErrorKey : NSLocalizedString(@"healthkit.error.noAvailableTypes.failureReason", @"Health Kit Error No Available Types Message")
        };
        NSError *error = [NSError errorWithDomain:@"com.americanwell.sampleapp.errordomain.healthkit" code:1000 userInfo:userInfo];
        completion(NO, error);
    }
}

#pragma mark - Health Kit Query Methods
- (void)getHealthKitData:(void (^)(NSArray *data, NSError *error))completion {
    __block NSMutableArray *__hkData = [NSMutableArray new];
    __block NSError *__error = nil;

    dispatch_group_t queryGroup = dispatch_group_create();
    for (id<AWSDKHealthTrackerType> type in [AWSDKHealthTrackerType supportedTrackerTypes]) {
        HKQuantityType *hkType = [HKQuantityType quantityTypeForIdentifier:type.typeString];
        HKUnit *hkUnit = [HKUnit unitFromString:type.unitString];
        switch (hkType.aggregationStyle) {
            case HKQuantityAggregationStyleCumulative: {
                [self getMostRecentSampleDateOfTrackerType:type
                                            withCompletion:^(NSDate *date, NSError *error) {
                                                if (error) {
                                                    AWSDKLogError(@"Error occured: %@", error);
                                                    return;
                                                }

                                                if (!date) {
                                                    AWSDKLogInfo(@"No result(s) found.");
                                                    return;
                                                }

                                                NSCalendar *calendar = [NSCalendar currentCalendar];
                                                NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:date];

                                                NSDate *startOfLastSampleDate = [calendar dateFromComponents:components];
                                                NSDate *startOfDayAfterLastSampleDate = [calendar dateByAddingUnit:NSCalendarUnitDay value:1 toDate:startOfLastSampleDate options:0];

                                                NSPredicate *today = [HKQuery predicateForSamplesWithStartDate:startOfLastSampleDate
                                                                                                       endDate:startOfDayAfterLastSampleDate
                                                                                                       options:HKQueryOptionStrictStartDate];
                                                HKStatisticsOptions sumOptions = HKStatisticsOptionCumulativeSum;

                                                dispatch_group_enter(queryGroup);
                                                HKStatisticsQuery *query =
                                                    [[HKStatisticsQuery alloc] initWithQuantityType:hkType
                                                                            quantitySamplePredicate:today
                                                                                            options:sumOptions
                                                                                  completionHandler:^(HKStatisticsQuery *_Nonnull query, HKStatistics *result, NSError *error) {
                                                                                      BOOL shouldProcess = YES;
                                                                                      __error = error;
                                                                                      if (error) {
                                                                                          shouldProcess = NO;
                                                                                      }

                                                                                      if (!result || result.sumQuantity == nil) {
                                                                                          shouldProcess = NO;
                                                                                      }

                                                                                      if (shouldProcess) {
                                                                                          HKQuantity *sum = [result sumQuantity];
                                                                                          double value = [sum doubleValueForUnit:hkUnit];
                                                                                          NSDictionary *data = @{
                                                                                              @"title" : type.displayName,
                                                                                              @"value" : [self calculateValueForDouble:value withDecimalPlaces:type.fractionDigits forUnit:hkUnit],
                                                                                              @"rawValue" : @(value),
                                                                                              @"date" : result.endDate,
                                                                                              @"type" : type
                                                                                          };
                                                                                          [__hkData addObject:data];
                                                                                      }

                                                                                      dispatch_group_leave(queryGroup);
                                                                                  }];

                                                [self.healthStore executeQuery:query];
                                            }];
            }

            break;

            case HKQuantityAggregationStyleDiscrete: {
                NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:HKSampleSortIdentifierEndDate ascending:NO];
                dispatch_group_enter(queryGroup);
                HKSampleQuery *query = [[HKSampleQuery alloc] initWithSampleType:hkType
                                                                       predicate:nil
                                                                           limit:1
                                                                 sortDescriptors:@[ sortDescriptor ]
                                                                  resultsHandler:^(HKSampleQuery *_Nonnull query, NSArray<__kindof HKSample *> *results, NSError *error) {
                                                                      BOOL shouldProcess = YES;
                                                                      __error = error;
                                                                      if (error) {
                                                                          shouldProcess = NO;
                                                                      }

                                                                      if (!results || results.count < 1) {
                                                                          shouldProcess = NO;
                                                                      }

                                                                      if (shouldProcess) {
                                                                          HKQuantitySample *sample = results.firstObject;
                                                                          double value = [sample.quantity doubleValueForUnit:hkUnit];
                                                                          NSDictionary *data = @{
                                                                              @"title" : type.displayName,
                                                                              @"value" : [self calculateValueForDouble:value withDecimalPlaces:type.fractionDigits forUnit:hkUnit],
                                                                              @"rawValue" : @(value),
                                                                              @"date" : sample.endDate,
                                                                              @"type" : type
                                                                          };
                                                                          [__hkData addObject:data];
                                                                      }

                                                                      dispatch_group_leave(queryGroup);
                                                                  }];

                [self.healthStore executeQuery:query];
            }

            break;

            default:
                // Do nothing
                break;
        }
    }

    dispatch_group_notify(queryGroup, dispatch_get_main_queue(), ^{
        completion([__hkData copy], __error);
    });
}

- (id<AWSDKHealthTrackerType>)getBloodPressureSystolicTracker {
    id<AWSDKHealthTrackerType> tracker = nil;
    for (id<AWSDKHealthTrackerType> type in [AWSDKHealthTrackerType supportedTrackerTypes]) {
        if ([type.typeString isEqualToString:HKQuantityTypeIdentifierBloodPressureSystolic]) {
            tracker = type;
            break;
        }
    }

    return tracker;
}

- (id<AWSDKHealthTrackerType>)getBloodPressureDiastolicTracker {
    AWSDKHealthTrackerType *tracker = nil;
    for (id<AWSDKHealthTrackerType> type in [AWSDKHealthTrackerType supportedTrackerTypes]) {
        if ([type.typeString isEqualToString:HKQuantityTypeIdentifierBloodPressureDiastolic]) {
            tracker = (AWSDKHealthTrackerType *)type;
            break;
        }
    }

    return tracker;
}

- (NSSet *)hkTypes {
    if ([AWSDKHealthTrackerType supportedTrackerTypes] == nil) {
        return nil;
    }

    NSMutableSet *types = [NSMutableSet setWithCapacity:[AWSDKHealthTrackerType supportedTrackerTypes].count];

    for (id<AWSDKHealthTrackerType> tracker in [AWSDKHealthTrackerType supportedTrackerTypes]) {
        HKQuantityType *hkType = [HKQuantityType quantityTypeForIdentifier:tracker.typeString];
        [types addObject:hkType];
    }

    return [types copy];
}

#pragma mark - Private Methods
- (void)getMostRecentSampleDateOfTrackerType:(id<AWSDKHealthTrackerType>)type withCompletion:(void (^)(NSDate *date, NSError *error))completion {
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:HKSampleSortIdentifierEndDate ascending:NO];
    HKQuantityType *hkType = [HKQuantityType quantityTypeForIdentifier:type.typeString];
    HKSampleQuery *query = [[HKSampleQuery alloc] initWithSampleType:hkType
                                                           predicate:nil
                                                               limit:1
                                                     sortDescriptors:@[ sortDescriptor ]
                                                      resultsHandler:^(HKSampleQuery *_Nonnull query, NSArray<__kindof HKSample *> *results, NSError *error) {
                                                          if (error) {
                                                              AWSDKLogError(@"An error occured: %@", error);
                                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                                  completion(nil, error);
                                                              });
                                                              return;
                                                          }

                                                          if (!results || results.count < 1) {
                                                              AWSDKLogInfo(@"No results found.") dispatch_async(dispatch_get_main_queue(), ^{
                                                                  completion(nil, error);
                                                              });
                                                              return;
                                                          }

                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              completion(results.firstObject.endDate, error);
                                                          });
                                                      }];

    [self.healthStore executeQuery:query];
}

- (NSString *)calculateValueForDouble:(double)value withDecimalPlaces:(NSInteger)decimalPlaces forUnit:(HKUnit *)hkUnit {
    if ([hkUnit.unitString isEqualToString:self.numberFormatter.percentSymbol]) {
        [self.numberFormatter setPositiveFormat:@"0.##"];
        return [self.numberFormatter stringFromNumber:@(value * 100.0)];
    } else {
        switch (decimalPlaces) {
            case 0:
                [self.numberFormatter setPositiveFormat:@"0"];
                break;
            case 1:
                [self.numberFormatter setPositiveFormat:@"0.#"];
                break;
            case 2:
                [self.numberFormatter setPositiveFormat:@"0.##"];
                break;
            case 3:
                [self.numberFormatter setPositiveFormat:@"0.###"];
                break;
            default:
                break;
        }
        return [self.numberFormatter stringFromNumber:@(value)];
    }
}

- (NSNumber *)getSystolic:(HKCorrelation *)bloodPressure {
    HKQuantityType *systolicType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBloodPressureSystolic];
    HKQuantitySample *systolicSample = [[bloodPressure objectsForType:systolicType] anyObject];
    HKQuantity *systolicQuantity = [systolicSample quantity];
    return @([systolicQuantity doubleValueForUnit:[HKUnit millimeterOfMercuryUnit]]);
}

- (NSNumber *)getDiastolic:(HKCorrelation *)bloodPressure {
    HKQuantityType *diastolicType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBloodPressureDiastolic];
    HKQuantitySample *diastolicSample = [[bloodPressure objectsForType:diastolicType] anyObject];
    HKQuantity *diastolicQuantity = [diastolicSample quantity];
    return @([diastolicQuantity doubleValueForUnit:[HKUnit millimeterOfMercuryUnit]]);
}

@end
