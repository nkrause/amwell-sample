//
//  TelehealthNotificationService.h
//  AWSDKSample
//
//  Created by Stephen Ciauri on 7/24/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AWSDKConsumer;

typedef NS_OPTIONS(NSUInteger, NotificationsBitmask) {
    NoNotifications = 0,
    ChildAccessNotification = 1 << 0,
    UpcomingAppointmentNotification = 1 << 1,
    SecureMessageNotification = 1 << 2,
};
typedef void (^NotificationStatusCompletionBlock)(NotificationsBitmask notificationMask);

@interface TelehealthNotificationService : NSObject

+ (void)checkNotificationsForConsumer:(id<AWSDKConsumer>)consumer completion:(NotificationStatusCompletionBlock)completion;

@end
