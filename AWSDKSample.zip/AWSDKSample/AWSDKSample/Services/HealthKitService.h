//
//  HealthKitService.h
//  AWSDKSample
//
//  Created by Jeremiah.Possion on 12/21/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.

#import <Foundation/Foundation.h>

@class HKHealthStore, HKCorrelation, HKSampleType, HKObjectType;
@protocol AWSDKHealthTrackerType;

@interface HealthKitService : NSObject

@property (nonatomic, nonnull) HKHealthStore *healthStore;
@property (class, nonatomic, assign) BOOL healthKitUnavailableMessageShown;

- (NSSet *_Nullable)hkTypes;

/**
 Requests authorization to read/write to the HealthKit DB.

 @param completion  Completion block called on success or failure.
 */
- (void)requestAuthorization:(nonnull void (^)(BOOL, NSError *_Nullable))completion;

/**
 Upload HealthKit data to the server.

 @param completion  Completion block called on success or failure.
 */
- (void)upload:(nonnull void (^)(BOOL success, NSError *_Nullable error))completion;

/**
 Retrieve all HealthKit data available.

 @param completion  Completion block called on success or failure.
 */
- (void)getHealthKitData:(nonnull void (^)(NSArray *_Nullable data, NSError *_Nullable error))completion;

/**
 Pull out the `diastolic` specific tracker from the list of available trackers if it is present.

 @return `AWSDKHealthTrackerType` or `nil`
 */
- (nullable id<AWSDKHealthTrackerType>)getBloodPressureDiastolicTracker;

/**
 Pull out the `systolic` specific tracker from the list of available trackers if it is present.

 @return `AWSDKHealthTrackerType` or `nil`
 */
- (nullable id<AWSDKHealthTrackerType>)getBloodPressureSystolicTracker;

/**
 This ensures HealthKit data is linked to a specific user, preventing other users from accessing
 the Healthkit data on the same device. If a user has already been linked this method will do nothing.
 */
- (void)linkHealthKit;

/**
 Checks whether or not the currently logged in user can see HealthKit data. If a previous user already
 linked their account this will reeturn `NO`.
 */
- (BOOL)canSeeHealthKitData;

/**
 Checks whether or not HealthKit is available on this device.
 */
- (BOOL)isHealthDataAvailable;

@end
