//
//  ConsumerService.m
//  AWSDKSample
//
//  Created by Steven Uy on 3/21/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ConsumerService.h"

#import "NSString+Sample.h"

#import <AWSDK/AWSDKAppointment.h>
#import <AWSDK/AWSDKAuthenticationService.h>
#import <AWSDK/AWSDKConsumer.h>
#import <AWSDK/AWSDKConsumerService.h>
#import <AWSDK/AWSDKLogService.h>
#import <AWSDK/AWSDKPartialConsumer.h>
#import <AWSDK/AWSDKService.h>
#import <AWSDK/AWSDKState.h>

/**
 *  ConsumerService is a singleton class that retains the current consumer information
 *  and handles authentication and checking for appointments
 */
@implementation ConsumerService

// UserDefaultsKey where AuthenticationKey may be saved
NSString *const UserDefaultsConsumerAuthKey = @"ConsumerAuthKey";
NSString *const UserDefaultsConsumerUserNameKey = @"ConsumerUserNameKey";
NSString *const ConsumerUpdatedNotification = @"ConsumerUpdated";

#pragma mark AWSDK Method Calls
- (void)refreshConsumerWithCompletion:(ConsumerBlock)completion {
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD show];
    /**
     *  Reloads the details of the consumer based on the account wide authentication key
     *
     *  @param result AWSDKParent consumer
     *  @param error  AWSDKErrors
     */
    [AWSDKConsumerService reloadDetailsForConsumer:self.authenticationKey
                                        completion:^(id _Nullable result, NSError *error) {
                                            [MBProgressHUD hide];
                                            if (error) {
                                                // Error handling
                                                [[UIViewController topMostAlertVC] presentAlertWithError:error
                                                                                               okHandler:^(UIAlertAction *action) {
                                                                                                   completion(NO, error);
                                                                                               }];
                                            } else {
                                                // Set parent and current consumer and reloaded consumer
                                                weakSelf.consumer = result;
                                                if (completion) {
                                                    completion(YES, result);
                                                }
                                            }
                                        }];
}

- (void)authenticateConsumerWithUsername:(NSString *)username withPassword:(NSString *)password enableAutoLogin:(BOOL)autoLogin withCompletion:(ConsumerBlock)completion {
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD show];
    /**
     *  Authenticate a consumer based on a username, password, and potential authentication key
     *
     *  @param result AWSDKConsumer as parent
     *  @param error  AWSDKErrors
     */
    [AWSDKAuthenticationService authenticateConsumerWithUsername:username
                                                        password:password
                                                 consumerAuthKey:nil
                                                      completion:^(id _Nullable result, NSError *error) {
                                                          [MBProgressHUD hide];
                                                          if (error) {
                                                              // Partially enrolled user, requires completing enrollment
                                                              if (error.code == AWSDKErrorCodePartiallyEnrolledUser && [result conformsToProtocol:@protocol(AWSDKPartialConsumer)]) {
                                                                  // User is partial enrolled, prompt enrollment
                                                                  // Passes the AWSDKPartialConsumer object as the result
                                                                  if (completion) {
                                                                      completion(YES, result);
                                                                  }
                                                                  return;
                                                              } else {
                                                                  // Other error handling
                                                                  if (completion) {
                                                                      completion(NO, error);
                                                                  }
                                                              }
                                                          } else {
                                                              // Set the current consumer as the result and save the authentication key
                                                              weakSelf.consumer = result;

                                                              // Save the consumerAuthenticationKey to automatically login next time unless the user
                                                              // logs out
                                                              [weakSelf setAuthenticationKey:weakSelf.consumer.consumerAuthKey savetoDefaults:autoLogin];
                                                              [weakSelf setUserName:username savetoDefaults:autoLogin];

                                                              if (completion) {
                                                                  completion(YES, result);
                                                              }
                                                          }
                                                      }];
}

- (void)authenticateConsumerMutualAuthToken:(NSString *)token withCompletion:(ConsumerBlock)completion {
    __weak typeof(self) weakSelf = self;
    [MBProgressHUD show];
    /**
     *  Authenticate a consumer based on an authentication token.
     *
     *  @param result AWSDKConsumer
     *  @param error  AWSDKErrors
     */
    [AWSDKAuthenticationService authenticateMutualAuthWithToken:token
                                                     completion:^(id _Nullable result, NSError *error) {
                                                         [MBProgressHUD hide];
                                                         if (error) {
                                                             // Partially enrolled user, requires completing enrollment
                                                             if (error.code == AWSDKErrorCodePartiallyEnrolledUser && [result conformsToProtocol:@protocol(AWSDKPartialConsumer)]) {
                                                                 // User is partial enrolled, prompt enrollment
                                                                 // Passes the AWSDKPartialConsumer object as the result
                                                                 if (completion) {
                                                                     completion(YES, result);
                                                                 }
                                                                 return;
                                                             } else {
                                                                 // Other error handling
                                                                 if (completion) {
                                                                     completion(NO, error);
                                                                 }
                                                             }
                                                         } else {
                                                             // Set the current consumer as the result and save the authentication key
                                                             weakSelf.consumer = result;
                                                             weakSelf.authenticationKey = weakSelf.consumer.consumerAuthKey;
                                                             if (completion) {
                                                                 completion(YES, result);
                                                             }
                                                         }
                                                     }];
}

/**
 *  Checks for appointment from a url
 *
 *  @param completion AWSDKAppointment object if one exists
 */
- (void)checkForAppointmentWithCompletion:(AppointmentBlock)completion {
    AWSDKLogDebug(@"Checking for an appointment");
    // Check AWSDKService if it contains a launchURL and verify if its for an appointment
    NSURL *url = [AWSDKService launchUrl];
    if (url && [AWSDKService supportedFeatureForUrl:url] == AWSDKFeatureAppointment) {
        AWSDKLogDebug(@"Found an appointment");

        [self.parentConsumer appointmentFromUrl:url
                                 withCompletion:^(id result, NSError *error) {
                                     // Handle error silently
                                     if (result) {
                                         AWSDKLogDebug(@"Got appointment object, posting notification");
                                         // Clear the URL
                                         [AWSDKService updateLaunchUrl:nil];

                                         if (completion) {
                                             completion(result);
                                         }
                                         [[NSNotificationCenter defaultCenter] postNotificationName:@"thnAppointment" object:result];
                                     }
                                 }];
    }
}

/**
 *  Checks if the consumer has an active visit
 *
 *  @param completion Returns the active visit if one exists
 */
- (void)checkForActiveVisitWithCompletion:(ActiveVisitBlock)completion {
    AWSDKLogDebug(@"Checking for active visit");
    [self.parentConsumer fetchActiveVisit:^(id<AWSDKVisit> _Nullable visit, NSError * _Nullable error) {
        if (completion != nil) {
            completion(visit);
        }
    }];
}


//-----------------------------------------------------------------------------------------------------//
//-----------------Everything past here is other logic for the sample app, no more API calls here -----//
//-----------------------------------------------------------------------------------------------------//

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark Singleton
/**
 *  Singleton class
 *
 *  @return sharedInstance to the ConsumerService
 */
+ (id)sharedInstance {
    static ConsumerService *sharedConsumer = nil;
    @synchronized(self) {
        if (sharedConsumer == nil)
            sharedConsumer = [[self alloc] init];
    }
    return sharedConsumer;
}

#pragma mark Other Service Calls
- (NSString *)fetchAuthenticationKey {
    // Fetch the key in UserDefaults
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    return [[userDefaults stringForKey:UserDefaultsConsumerAuthKey] copy];
}

- (NSString *)fetchUserName {
    // Fetch the key in UserDefaults
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    return [[userDefaults stringForKey:UserDefaultsConsumerUserNameKey] copy];
}

- (void)deauthenticateConsumer {
    // Clear the current user information
    self.consumer = nil;
    self.isloggedIn = NO;
    self.authenticationKey = nil;
    // Remove authentication key from UserDefaults
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:UserDefaultsConsumerAuthKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - Getters
+ (BOOL)isFeedMember {
    return [[[ConsumerService sharedInstance] consumer] wasFeedGenerated];
}

#pragma mark - Setters
// For simplicity, this is saved to standardUserDefaults. This is potentially insecure
// and should be saved within a database or the users keychain
- (void)setAuthenticationKey:(NSString *)authenticationKey savetoDefaults:(BOOL)save {
    // Save authenticationKey in userDefaults anytime it is set
    if (save) {
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        [userDefaults setObject:authenticationKey forKey:UserDefaultsConsumerAuthKey];
    }
    _authenticationKey = authenticationKey;
}

- (void)clearAuthenticationKey {
    [self setAuthenticationKey:nil savetoDefaults:YES];
}

// For simplicity, this is saved to standardUserDefaults
- (void)setUserName:(NSString *)userName savetoDefaults:(BOOL)save {
    // Save authenticationKey in userDefaults anytime it is set
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    if (save) {
        [userDefaults setObject:userName forKey:UserDefaultsConsumerUserNameKey];
    } else {
        [userDefaults setObject:nil forKey:UserDefaultsConsumerUserNameKey];
    }
    _userName = userName;
}

- (void)clearUserName {
    [self setUserName:nil savetoDefaults:YES];
}

- (void)setConsumer:(id<AWSDKConsumer>)consumer {
    // Set logged in bool depending on a valid consumer
    _isloggedIn = consumer != nil;
    // If the consumer has no parent, then save a reference to this consumer as parent
    _parentConsumer = consumer.authenticatedParent ?: consumer;
    _isParent = consumer.authenticatedParent == nil;

    _consumer = consumer;
    _authenticationKey = consumer.authenticatedParent ? consumer.authenticatedParent.consumerAuthKey : consumer.consumerAuthKey;

    if (consumer) {
        [self checkForAppointmentWithCompletion:nil];
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:ConsumerUpdatedNotification object:consumer];
}
@end
