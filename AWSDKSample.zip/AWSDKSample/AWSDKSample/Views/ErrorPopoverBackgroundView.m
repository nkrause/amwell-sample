//
//  ErrorPopoverBackgroundView.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/27/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ErrorPopoverBackgroundView.h"

@implementation ErrorPopoverBackgroundView

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.layer.borderColor = [UIColor redColor].CGColor;
        self.layer.borderWidth = 2.0f;
        self.layer.cornerRadius = frame.size.height / 2;
        self.backgroundColor = [UIColor whiteColor];
        self.layer.shadowColor = [UIColor clearColor].CGColor;
        self.layer.shadowOpacity = 0.0;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.layer.cornerRadius = self.frame.size.height / 2;
    self.layer.shadowColor = [UIColor clearColor].CGColor;
    self.layer.shadowOpacity = 0.0;
}

+ (UIEdgeInsets)contentViewInsets {
    return UIEdgeInsetsMake(3.0, 3.0, 5.0, 5.0);
}

+ (CGFloat)arrowHeight {
    return 0.0;
}

+ (CGFloat)arrowBase {
    return 0.0;
}

- (void)setArrowOffset:(CGFloat)arrowOffset {
}

- (void)setArrowDirection:(UIPopoverArrowDirection)arrowDirection {
}

- (CGFloat)arrowOffset {
    return 0.0;
}

- (UIPopoverArrowDirection)arrowDirection {
    return 0;
}

@end
