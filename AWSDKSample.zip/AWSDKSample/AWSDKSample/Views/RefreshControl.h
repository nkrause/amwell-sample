//
//  RefreshControl.h
//  AWSDKSample
//
//  Created by Steven Uy on 10/13/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface RefreshControl : UIRefreshControl

#pragma mark - ScrollView delegate calls
/**
 Call this method when the scrollviewDelegate scrolls to activate the animation and refresh states

 @param scrollView Scrollview containing the RefreshControl
 */
- (void)scrollViewDidScroll:(UIScrollView *)scrollView;

@end
