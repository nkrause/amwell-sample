//
//  HeaderInputControl.m
//  AWSDKSample
//
//  Created by Ed Chianese on 1/24/19.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "HeaderInputControl.h"

@interface HeaderInputControl ()
@property (nonatomic) IBOutlet UIView *contentView;

@end

@implementation HeaderInputControl

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    [self initialSetup];
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    [self initialSetup];
    return self;
}

- (void)setHeaderText:(NSString *)stringKey {
    _headerText = NSLocalizedString(stringKey, @"used in HeaderInputControl");
}

- (void)setPlaceholderText:(NSString *)stringKey {
    _placeholderText = NSLocalizedString(stringKey, @"used in HeaderInputControl");
}

// Defaults if we do not us Interface Builder
- (void)initialSetup {
    // defaults can be overwritten in IB
    [[NSBundle bundleForClass:self.class] loadNibNamed:@"HeaderInputControl" owner:self options:nil];
    [self addSubview:self.contentView];
    self.contentView.frame = self.bounds;

    // defaults
    self.headerTextColor = [UIColor toggletxtTealColor];
    self.headerFont = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    self.textFont = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
}

- (void)prepareForInterfaceBuilder {
    [super prepareForInterfaceBuilder];
    [self layoutSubviews];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.headerLabel.text = self.headerText;
    self.textField.placeholder = self.placeholderText;
    self.headerLabel.textColor = self.headerTextColor;
    self.headerLabel.backgroundColor = self.headerBackgroundColor;
    self.textField.backgroundColor = self.textFieldBackgroundColor;
    self.textField.accessibilityLabel = self.accessibilityLabel;
}

@end
