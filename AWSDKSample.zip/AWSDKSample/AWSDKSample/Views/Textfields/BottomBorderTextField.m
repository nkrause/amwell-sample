//
//  BottomBorderTextField.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/24/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//
#import "BottomBorderTextField.h"

@interface BottomBorderTextField ()

@property (nonatomic) CALayer *border;
@property (nonatomic) UIColor *lineColor;

@property (nonatomic) UIColor *fontColor;

@end

@implementation BottomBorderTextField

- (void)drawRect:(CGRect)rect {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 2.0f);
    // start at this point
    CGContextMoveToPoint(context, 0, self.frame.size.height);
    // draw to this point
    CGContextAddLineToPoint(context, self.frame.size.width, self.frame.size.height);
    self.lineColor = [self.textColor isEqual:[UIColor whiteColor]] ? [UIColor whiteFadedColor] : [UIColor lightGrayFadedUserIconColor];

    CGContextSetStrokeColorWithColor(context, self.lineColor.CGColor);
    // and now draw the Path!
    CGContextStrokePath(context);
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (self.keyboardType == UIKeyboardTypePhonePad || self.keyboardType == UIKeyboardTypeNumberPad) {
        UIToolbar *keyboardDoneButtonView = [[UIToolbar alloc] init];
        [keyboardDoneButtonView sizeToFit];
        UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"misc.done", @"Done barButtonItem")
                                                                       style:UIBarButtonItemStyleDone
                                                                      target:self
                                                                      action:@selector(doneClicked:)];
        UIBarButtonItem *flexibleItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        [keyboardDoneButtonView setItems:@[ flexibleItem, doneButton ]];
        [doneButton setTintColor:[UIColor aquaColor]];
        [self setInputAccessoryView:keyboardDoneButtonView];
    }
}

- (void)doneClicked:(id)sender {
    [self resignFirstResponder];
}

- (void)showError:(NSString *)error {
    [UIView transitionWithView:self
                      duration:0.2
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        [self.border setBorderColor:[UIColor redColor].CGColor];
                        [self setTextColor:[UIColor redColor]];
                    }
                    completion:^(BOOL finished){
                    }];
}

- (void)hideError {
    [UIView transitionWithView:self
                      duration:0.2
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        [self.border setBorderColor:self.lineColor.CGColor];
                        [self setTextColor:self.fontColor];
                    }
                    completion:^(BOOL finished){
                    }];
}

#pragma mark Setter
- (void)setError:(NSString *)error {
    if (error) {
        [self showError:error];
    } else {
        [self hideError];
    }
    _error = error;
}

@end
