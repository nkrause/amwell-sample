//
//  NoCursorTextField.m
//  AWSDKSample
//
//  Created by Stephen Ciauri on 10/31/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "NoCursorTextField.h"

@implementation NoCursorTextField

- (CGRect)caretRectForPosition:(UITextPosition *)position {
    return CGRectZero;
}

@end
