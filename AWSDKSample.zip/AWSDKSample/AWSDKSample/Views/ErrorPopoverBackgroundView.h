//
//  ErrorPopoverBackgroundView.h
//  AWSDKSample
//
//  Created by Steven Uy on 5/27/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

/**
 Used by the storyboard when presenting a popover only for an error
 */
@interface ErrorPopoverBackgroundView : UIPopoverBackgroundView

@end
