//
//  SpinnerControl.m
//  AWSDKSample
//
//  Created by Ed Chianese on 1/17/19.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "SpinnerControl.h"

@interface SpinnerControl ()
@property (weak, nonatomic) IBOutlet UIImageView *outerImageView;
@property (weak, nonatomic) IBOutlet UIImageView *innerImageView;
@end

@implementation SpinnerControl
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    [self initialSetup];
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    [self initialSetup];
    return self;
}

// Defaults if we do not us Interface Builder
- (void)initialSetup {
    /*  We do not use the NSBundle.mainBundle because at design time the main bundle is that of the IB so the custom control would not not render.

     This article describes:
     https://www.kuma.cloud/blog/ios-dev-how-to-solve-failed-to-render-and-update-autolayout-status-when-using-ibdesignable/
    */
    [[NSBundle bundleForClass:self.class] loadNibNamed:@"SpinnerControl" owner:self options:nil];
    [self addSubview:self.contentView];
    self.contentView.frame = self.bounds;
}

- (void)prepareForInterfaceBuilder {
    [super prepareForInterfaceBuilder];
    [self layoutSubviews];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.outerImageView.image = self.outerImage;
    self.innerImageView.image = self.innerImage;
}

- (void)pauseSpinner {
    [self.outerImageView.layer removeAnimationForKey:@"SpinAnimation"];
}

- (void)rotateSpinner {
    __weak typeof(self) weakSelf = self;
    [UIView animateWithDuration:2.0f
                     animations:^{
                         CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
                         animation.fromValue = @0.0;
                         animation.toValue = @(2 * M_PI);
                         animation.duration = 2.0f;
                         animation.repeatCount = INFINITY;
                         [weakSelf.outerImageView.layer addAnimation:animation forKey:@"SpinAnimation"];
                     }];
}

@end
