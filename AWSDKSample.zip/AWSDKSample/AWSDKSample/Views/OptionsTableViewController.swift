//
//  OptionsTableViewController.swift
//  AWSDKSample
//
//  Created by Caleb Lindsey on 7/14/20.
//  Copyright © 2020 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

import UIKit

class OptionsTableViewController: UIViewController {
    private let actions: [PopupAction]
    private let optionsCellId = "optionsCellId"

    private let tableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.layer.cornerRadius = 10
        tableView.isScrollEnabled = false
        return tableView
    }()

    @objc public init(actions: [PopupAction]) {
        self.actions = actions
        
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor.black.withAlphaComponent(0.4)

        setup()
    }

    private func setup() {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: optionsCellId)
        tableView.dataSource = self
        tableView.delegate = self
        view.addSubview(tableView)

        NSLayoutConstraint.activate([
            tableView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.centerYAnchor),
            tableView.widthAnchor.constraint(equalToConstant: 300),
        ])
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        dismiss(animated: true, completion: nil)
    }

    override func updateViewConstraints() {
        let contentHeight = tableView.contentSize.height
        tableView.heightAnchor.constraint(equalToConstant: contentHeight > 200 ? 200 : contentHeight).isActive = true
        tableView.isScrollEnabled = contentHeight > 200

        super.updateViewConstraints()
    }
}

extension OptionsTableViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return actions.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let popupAction = actions[indexPath.row]
        let cell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: optionsCellId, for: indexPath)
        cell.textLabel?.text = popupAction.title
        cell.imageView?.image = popupAction.icon
        cell.accessoryType = popupAction.hasDisclosureIndicator ? .disclosureIndicator : .none
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        dismiss(animated: true, completion: actions[indexPath.row].action)
    }
}

@objc class PopupAction: NSObject {
    public var icon: UIImage?
    public var title: String
    public var action: (() -> ())?
    @objc public var hasDisclosureIndicator = true

    @objc public init(icon: UIImage?, title: String, action: (() -> ())?) {
        self.icon = icon
        self.title = title
        self.action = action
    }
}
