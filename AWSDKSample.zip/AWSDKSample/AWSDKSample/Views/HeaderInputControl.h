//
//  HeaderInputControl.h
//  AWSDKSample
//
//  Created by Ed Chianese on 1/24/19.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "NoCursorTextField.h"

#import <UIKit/UIKit.h>
IB_DESIGNABLE
@interface HeaderInputControl : UIView

@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UILabel *headerLabel;

@property (nonatomic) IBInspectable NSString *headerText;
@property (nonatomic) IBInspectable NSString *placeholderText;
@property (nonatomic) IBInspectable UIColor *headerTextColor;
@property (nonatomic) IBInspectable UIColor *headerBackgroundColor;
@property (nonatomic) IBInspectable UIColor *textFieldBackgroundColor;
@property (nonatomic) IBInspectable UIFont *headerFont;
@property (nonatomic) IBInspectable UIFont *textFont;
@property (nonatomic) IBInspectable NSString *accessibilityLabel;
@end
