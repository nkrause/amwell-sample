//
//  ErrorButton.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/26/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//
#import "ErrorButton.h"

@interface ErrorButton ()

@property (atomic, assign) BOOL errorMessageHidden;

@end

@implementation ErrorButton

#pragma mark - Initial Setup

- (id)initWithError:(NSError *)error {
    self = [super init];
    if (self) {
        [self setErrorMessageHidden:YES];
        if (error)
            self.errorMessage = error.userInfo[NSLocalizedFailureReasonErrorKey];

        UIImage *image = [UIImage imageNamed:@"xCircle"];
        image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        [self setImage:image forState:UIControlStateNormal];
        [self.imageView setTintColor:[UIColor redColor]];
        [self setFrame:CGRectMake(0.0, 0.0, self.imageView.image.size.width, self.imageView.image.size.height)];
        [self.imageView setContentMode:UIViewContentModeScaleAspectFit];
        [self setTintColor:[UIColor redColor]];
        [self setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [self setBackgroundColor:[UIColor clearColor]];
    }
    return self;
}

#pragma mark - Animations
- (void)showErrorMessage:(NSString *)errorMessage {
    if (!self.errorMessageHidden) {
        return;
    }
}

- (void)hideErrorMessage {
    if (self.errorMessageHidden) {
        return;
    }
}

#pragma mark - Setter
- (void)setErrorMessage:(NSString *)errorMessage {
    // Todo
    _errorMessage = errorMessage;
}

@end
