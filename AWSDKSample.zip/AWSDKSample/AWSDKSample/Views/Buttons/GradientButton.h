//
//  GradientButton.h
//  AWSDKSample
//
//  Created by Ed Chianese on 1/11/19.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE
@interface GradientButton : UIButton

@property (nonatomic) IBInspectable UIColor *gradientTopColor;
@property (nonatomic) IBInspectable UIColor *gradientBottomColor;
@property (nonatomic) IBInspectable CGFloat cornerRadius;
@property (nonatomic) IBInspectable CGFloat lineWidth;

@end
