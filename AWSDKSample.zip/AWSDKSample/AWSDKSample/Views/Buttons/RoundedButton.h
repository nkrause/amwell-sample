//
//  RoundedButton.h
//  AWSDKSample
//
//  Created by Steven Uy on 12/19/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>
IB_DESIGNABLE
@interface RoundedButton : UIButton

@property (nonatomic) IBInspectable CGFloat cornerValue;
@property (nonatomic) IBInspectable UIColor *defaultBackground;
@property (nonatomic) IBInspectable UIColor *selectedBackground;
@property (nonatomic) IBInspectable CGFloat lineWidth;

// lower level access to the button's corners.
@property (assign, nonatomic) UIRectCorner corners;

@end
