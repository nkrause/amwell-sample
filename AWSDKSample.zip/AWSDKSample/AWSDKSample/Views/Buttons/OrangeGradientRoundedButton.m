//
//  OrangeGradientRoundedButton.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/24/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "OrangeGradientRoundedButton.h"

@implementation OrangeGradientRoundedButton

- (void)layoutSubviews {
    [super layoutSubviews];

    // Gradient
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    gradientLayer.frame = self.layer.bounds;

    gradientLayer.colors = @[ (id)[UIColor gradientLightOrangeColor].CGColor, (id)[UIColor gradientDarkOrangeColor].CGColor ];

    gradientLayer.cornerRadius = self.layer.cornerRadius;
    [self.layer insertSublayer:gradientLayer atIndex:0];

    // Font Color
    [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    // Rounded Corners
    self.layer.cornerRadius = 10;
    self.clipsToBounds = YES;
}

@end
