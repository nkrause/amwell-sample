//
//  ErrorButton.h
//  AWSDKSample
//
//  Created by Steven Uy on 5/26/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface ErrorButton : UIButton

@property (nonatomic, weak) UITableViewCell *errorCell;
@property (nonatomic, strong) NSString *errorMessage;

- (id)initWithError:(NSError *)error;

- (void)showErrorMessage:(NSString *)errorMessage;
- (void)hideErrorMessage;

@end
