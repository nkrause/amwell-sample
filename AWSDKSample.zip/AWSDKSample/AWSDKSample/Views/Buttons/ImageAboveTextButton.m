//
//  ImageAboveTextButton.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/23/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ImageAboveTextButton.h"

#import "AppDelegate.h"

const double SPACE_BETWEEN_TEXT_IMAGE = 6.0f;

@implementation ImageAboveTextButton

- (void)awakeFromNib {
    [super awakeFromNib];

    // Set ImageView to Scale
    [self.imageView setContentMode:UIViewContentModeScaleAspectFit];

    // Retrieve current language
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    NSString *languageCode = appDelegate.currentLanguageCode;

    // the space between the image and text
    CGFloat spacing = SPACE_BETWEEN_TEXT_IMAGE;
    CGSize imageSize = self.imageView.image.size;
    CGSize titleSize = [self.currentTitle sizeWithAttributes:@{ NSFontAttributeName : self.titleLabel.font }];

    // UIEdgeInsetsMake(top, left, bottom, right)
    if ([NSLocale characterDirectionForLanguage:languageCode] == NSLocaleLanguageDirectionRightToLeft) {
        self.titleLabel.textAlignment = NSTextAlignmentRight;
        self.titleEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, -(imageSize.height + spacing), -imageSize.width);
        self.imageEdgeInsets = UIEdgeInsetsMake(-(titleSize.height + spacing), -titleSize.width, 0.0, 0.0);
    } else {
        self.titleLabel.textAlignment = NSTextAlignmentLeft;
        // lower the text and push it left so it appears centered below the image
        self.titleEdgeInsets = UIEdgeInsetsMake(0.0, -imageSize.width, -(imageSize.height + spacing), 0.0);
        // raise the image and push it right so it appears centered above the text
        self.imageEdgeInsets = UIEdgeInsetsMake(-(titleSize.height + spacing), 0.0, 0.0, -titleSize.width);
    }
}

@end
