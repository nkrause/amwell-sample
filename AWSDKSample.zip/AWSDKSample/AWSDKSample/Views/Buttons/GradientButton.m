//
//  GradientButton.m
//  AWSDKSample
//
//  Created by Ed Chianese on 1/11/19.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "GradientButton.h"

@implementation GradientButton

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    [self initialSetup];
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    [self initialSetup];
    return self;
}

// Defaults if we do not us Interface Builder
- (void)initialSetup {
    // defaults can be overwritten in IB
    self.cornerRadius = 10;
    self.lineWidth = 2;
    self.gradientTopColor = [UIColor gradientLightOrangeColor];
    self.gradientBottomColor = [UIColor gradientDarkOrangeColor];
}

- (void)prepareForInterfaceBuilder {
    [super prepareForInterfaceBuilder];
    [self layoutSubviews];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    gradientLayer.frame = self.layer.bounds;
    gradientLayer.colors = @[ (id)self.gradientTopColor.CGColor, (id)self.gradientBottomColor.CGColor ];
    gradientLayer.cornerRadius = self.layer.cornerRadius;
    [self.layer insertSublayer:gradientLayer atIndex:0];
    self.layer.cornerRadius = self.cornerRadius;
    self.clipsToBounds = YES;
}
@end
