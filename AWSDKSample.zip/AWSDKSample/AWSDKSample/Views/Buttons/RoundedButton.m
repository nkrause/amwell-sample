//
//  RoundedButton.m
//  AWSDKSample
//
//  Created by Steven Uy on 12/19/16.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//
#import "RoundedButton.h"

@interface RoundedButton ()
@property (nonatomic) CAShapeLayer *border;
@end

@implementation RoundedButton

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    [self initialSetup];
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    [self initialSetup];
    return self;
}

// Defaults if we do not us Interface Builder
- (void)initialSetup {
    // defaults can be overwritten in IB
    self.cornerValue = 5;
    self.lineWidth = 2;
    self.selectedBackground = [UIColor aquaColor];
    self.defaultBackground = [UIColor whiteColor];
    self.corners = UIRectCornerAllCorners;
}

- (void)prepareForInterfaceBuilder {
    [super prepareForInterfaceBuilder];
    [self layoutSubviews];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    // Remove current border to resize
    if (self.border) {
        [self.border removeFromSuperlayer];
        self.border = nil;
    }

    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:self.bounds byRoundingCorners:self.corners cornerRadii:CGSizeMake(self.cornerValue, self.cornerValue)];

    CAShapeLayer *layer = [CAShapeLayer layer];
    [layer setFrame:self.bounds];
    [layer setPath:path.CGPath];

    self.border = [CAShapeLayer layer];
    [self.border setFrame:self.bounds];
    [self.border setPath:path.CGPath];
    [self.border setFillColor:[UIColor clearColor].CGColor];
    [self.border setStrokeColor:self.selectedBackground.CGColor];
    [self.border setLineWidth:self.lineWidth];

    [self.layer setMask:layer];
    [self.layer addSublayer:self.border];

    [self setSelected:self.selected];
}

- (void)setCorners:(UIRectCorner)corners {
    // if client wants to override the corners programically
    _corners = corners;

    // Always layout to apply UI changes when setting corners
    [self layoutSubviews];
}

- (void)setSelected:(BOOL)selected {
    if (selected && self.selectedBackground) {
        self.backgroundColor = self.selectedBackground;
    } else if (!selected && self.defaultBackground) {
        self.backgroundColor = self.defaultBackground;
    }
    [super setSelected:selected];
}
@end
