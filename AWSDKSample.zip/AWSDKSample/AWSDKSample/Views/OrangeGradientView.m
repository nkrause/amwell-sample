//
//  OrangeGradientView.m
//  AWSDKSample
//
//  Created by Steven Uy on 12/27/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "OrangeGradientView.h"

@implementation OrangeGradientView

- (void)layoutSubviews {
    [super layoutSubviews];

    // Gradient
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    gradientLayer.frame = self.layer.bounds;

    gradientLayer.colors = @[ (id)[UIColor gradientLightOrangeColor].CGColor, (id)[UIColor gradientDarkOrangeColor].CGColor ];

    [self.layer insertSublayer:gradientLayer atIndex:0];
}

@end
