//
//  SpinnerControl.h
//  AWSDKSample
//
//  Created by Ed Chianese on 1/17/19.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE
@interface SpinnerControl : UIView

// Container for the actual spinner that lives in the xib.
@property (nonatomic) IBOutlet UIView *contentView;
@property (nonatomic) IBInspectable UIImage *innerImage;
@property (nonatomic) IBInspectable UIImage *outerImage;

- (void)rotateSpinner;
- (void)pauseSpinner;
@end
