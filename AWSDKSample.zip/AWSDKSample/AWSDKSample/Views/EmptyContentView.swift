//
//  EmptyContentView.swift
//  AWSDKSample
//
//  Created by Caleb Lindsey on 6/28/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

import UIKit

class EmptyContentView: UIView {

    private var image: UIImage?
    private var message: String?
    private var buttonTitle: String?

    private lazy var imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = image
        return imageView
    }()

    private lazy var messageLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = message
        label.textColor = .gray
        label.textAlignment = .center
        return label
    }()

    private lazy var actionButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle(buttonTitle, for: .normal)
        button.tintColor = UIColor(named: "aqua")
        return button
    }()

    @objc public init(image: UIImage?, message: String, buttonTitle: String? = nil) {
        super.init(frame: .zero)

        self.image = image
        self.message = message
        self.buttonTitle = buttonTitle
        
        setup()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setup() {
        backgroundColor = UIColor(named: "bkgdGrey")

        addSubview(imageView)
        addSubview(messageLabel)

        NSLayoutConstraint.activate([
            // ImageView
            imageView.centerXAnchor.constraint(equalTo: centerXAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 175),
            imageView.heightAnchor.constraint(equalTo: imageView.widthAnchor),
            imageView.bottomAnchor.constraint(equalTo: centerYAnchor, constant: -15),

            // Message Label
            messageLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 30),
            messageLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            messageLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 15),
            messageLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -15),
        ])

        if buttonTitle != nil {
            addSubview(actionButton)

            NSLayoutConstraint.activate([
                // Action Button
                actionButton.topAnchor.constraint(equalTo: messageLabel.bottomAnchor, constant: 15),
                actionButton.centerXAnchor.constraint(equalTo: centerXAnchor),
                actionButton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 15),
                actionButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -15),
            ])
        }
    }

    @objc (addTarget:action:forControlEvents:)
    public func addTarget(target: Any?, action: Selector, for controlEvents: UIControl.Event) {
        actionButton.addTarget(target, action: action, for: controlEvents)
    }
}
