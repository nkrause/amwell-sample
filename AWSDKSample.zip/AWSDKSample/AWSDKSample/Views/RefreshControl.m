//
//  RefreshControl.m
//  AWSDKSample
//
//  Created by Steven Uy on 10/13/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "RefreshControl.h"

@interface RefreshControl ()

/**
 *  Retain a reference the scrollView that the refreshControl exists in
 */
@property (nonatomic, weak, readwrite) UIScrollView *scrollView;

@property (nonatomic, strong, readwrite) UIImageView *imageView;

@end

@implementation RefreshControl

- (void)layoutSubviews {
    [super layoutSubviews];

    [self setTintColor:[UIColor clearColor]];
    if (!self.imageView) {
        self.imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"outerSpinner"]];
        [self.imageView setContentMode:UIViewContentModeScaleAspectFill];
        [self.imageView setTintColor:[UIColor aquaColor]];
        [self.imageView setFrame:CGRectMake(0, 0, 40, 40)];
        [self.imageView setCenter:self.center];
        [self addTarget:self action:@selector(rotateContinuously) forControlEvents:UIControlEventValueChanged];

        [self addSubview:self.imageView];
    }
}

- (void)beginRefreshing {
    [super beginRefreshing];
    [self rotateContinuously];
}

- (void)endRefreshing {
    [super endRefreshing];
    [self.imageView.layer removeAllAnimations];
}

#pragma mark - Animations
- (void)rotateContinuously {
    if (!self.imageView.layer.animationKeys.count) {
        NSNumber *currentAngle = (NSNumber *)[self.imageView.layer valueForKeyPath:@"layer.transform.rotation"];
        [UIView animateWithDuration:1.25f
                         animations:^{
                             CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
                             animation.fromValue = currentAngle;
                             animation.byValue = @(2.0 * M_PI);
                             animation.duration = 1.25f;
                             animation.repeatCount = INFINITY;
                             [self.imageView.layer addAnimation:animation forKey:@"SpinAnimation"];
                         }];
    }
}

- (void)rotatePercentage:(CGFloat)percent {
    self.imageView.transform = CGAffineTransformIdentity;
    [self.imageView setTransform:CGAffineTransformRotate(self.imageView.transform, M_PI_2 * percent)];
}

#pragma mark UIScrollView Delegate Calls
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    // ScrollView
    if (!self.scrollView) {
        [self setScrollView:scrollView];
    }

    // Scrolling beyond top
    if (scrollView.contentOffset.y < 0 && self.imageView.layer.animationKeys.count == 0) {
        [self rotatePercentage:(-scrollView.contentOffset.y / CGRectGetHeight(self.frame))];
    }
}

@end
