//
//  SwitchTableViewCell.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/17/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "SwitchTableViewCell.h"

@implementation SwitchTableViewCell

- (void)prepareForReuse {
    [super prepareForReuse];

    // Reset targets for the value changed event as this will be customized per reuse.
    [self.toggle removeTarget:nil action:nil forControlEvents:UIControlEventValueChanged];
}

@end
