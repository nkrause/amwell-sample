//
//  MeasurementComponentTableViewCell.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/16/19.
//  Copyright © 2019 American Well. All rights reserved.
//

#import "MeasurementComponentTableViewCell.h"

#import "MeasurementAddTableViewController.h"

#import <AWSDK/AWSDKTrackerTemplate.h>

@implementation MeasurementComponentTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setTrackerComponentTemplate:(id<AWSDKTrackerComponentTemplate>)trackerComponentTemplate {
    _trackerComponentTemplate = trackerComponentTemplate;

    [self updateCell];
}

- (void)updateCell {
    self.componentValueTextField.placeholder = self.trackerComponentTemplate.title;

    UIFont *aFont = [UIFont systemFontOfSize:20.0f weight:UIFontWeightRegular];
    NSAttributedString *decodedString = [self convertHTMLCharacterEntityReferences:self.trackerComponentTemplate.unitOfMeasureShortDescription];
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithAttributedString:decodedString];
    [attributedText addAttribute:NSFontAttributeName value:aFont range:NSMakeRange(0, attributedText.length)];
    self.componentUOMLabel.attributedText = attributedText;
}

#pragma mark - UITextField Delegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    BOOL isValid = [self validateFieldString:newString];
    NSError *error = nil;
    NSNumber *newValue = [NSNumber numberWithDouble:newString.doubleValue];
    [self.delegate trackerValidationChanged:isValid value:newValue position:self.tag error:error];
    return YES;
}

- (BOOL)validateFieldString:(NSString *)fieldString {
    BOOL errorFound = NO;
    NSNumber *newValue = [NSNumber numberWithDouble:fieldString.doubleValue];
    if (self.trackerComponentTemplate.minimum) {
        errorFound |= ([newValue compare:self.trackerComponentTemplate.minimum] == NSOrderedAscending);
    }
    if (self.trackerComponentTemplate.maximum) {
        errorFound |= ([newValue compare:self.trackerComponentTemplate.maximum] == NSOrderedDescending);
    }
    self.errorButton.hidden = !errorFound;
    return !errorFound && fieldString.length;
}

- (NSAttributedString *)convertHTMLCharacterEntityReferences:(NSString *)htmlString {
    NSData *stringData = [htmlString dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *options = @{ NSDocumentTypeDocumentAttribute : NSHTMLTextDocumentType };
    NSAttributedString *decodedString = [[NSAttributedString alloc] initWithData:stringData options:options documentAttributes:nil error:nil];
    return decodedString;
}

@end
