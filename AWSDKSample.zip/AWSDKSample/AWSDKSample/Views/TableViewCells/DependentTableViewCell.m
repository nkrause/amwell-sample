//
//  DependentTableViewCell.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 4/3/18.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "DependentTableViewCell.h"

@implementation DependentTableViewCell

@end
