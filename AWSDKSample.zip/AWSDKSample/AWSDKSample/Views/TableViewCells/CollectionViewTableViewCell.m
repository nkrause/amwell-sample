//
//  CollectionViewTableViewCell.m
//  AWSDKSample
//
//  Created by Steven Uy on 12/23/16.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "CollectionViewTableViewCell.h"

@implementation CollectionViewTableViewCell

@end
