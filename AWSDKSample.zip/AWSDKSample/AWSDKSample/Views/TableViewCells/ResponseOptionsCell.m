//
//  ResponseOptionsCell.m
//  AWSDKSample
//
//  Created by Ed Chianese on 12/5/18.
//  Copyright © 2018 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ResponseOptionsCell.h"

@implementation ResponseOptionsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self setup];
}

- (void)setup {
    self.responseOptionsPicker = [UIPickerView new];
    self.textField.keyboardType = UIKeyboardTypeDefault;
    self.textField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.textField.placeholder = NSLocalizedString(@"misc.select", @"Select Placeholder");
    self.textField.inputView = self.responseOptionsPicker;
    self.textField.delegate = self;
    self.textField.font = [UIFont systemFontOfSize:19.0f weight:UIFontWeightLight];
    UIToolbar *keyboardToolbar = [UIToolbar new];
    [keyboardToolbar sizeToFit];
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"misc.done", @"Done barButtonItem")
                                                                   style:UIBarButtonItemStyleDone
                                                                  target:self
                                                                  action:@selector(dismissPicker)];
    UIBarButtonItem *flexibleItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardToolbar setItems:@[ flexibleItem, doneButton ]];

    self.textField.inputAccessoryView = keyboardToolbar;
}

- (void)dismissPicker {
    [self.textField resignFirstResponder];
}
@end
