//
//  NotificationsTableViewCell.h
//  AWSDKSample
//
//  Created by Stephen Ciauri on 7/24/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import "NotificationsTableViewController.h"

#import <UIKit/UIKit.h>

@interface NotificationsTableViewCell : UITableViewCell

- (void)configureWithTitle:(NSString *)title subtitle:(NSString *)subtitle;

@end
