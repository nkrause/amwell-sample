//
//  ChatItemCell.m
//  AWSDKSample
//
//  Created by Steven Uy on 9/19/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ChatItemCell.h"

@implementation ChatItemCell

@end
