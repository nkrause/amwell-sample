//
//  TitleTextFieldTableViewCell.m
//  AWSDKSample
//
//  Created by Stephen Ciauri on 3/20/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "TitleTextFieldTableViewCell.h"

@interface TitleTextFieldTableViewCell () <UITextFieldDelegate>
@end

@implementation TitleTextFieldTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.textField.delegate = self;
    [self setupHandleLabelTaps];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    [self.delegate textDidChange:newString inCell:self];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    [self.delegate textDidBeginEditing:textField];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    return [self.delegate textDidReturn:textField];
}

- (void)setupHandleLabelTaps {
    self.titleLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap)];
    [self.titleLabel addGestureRecognizer:gestureRecognizer];
}

- (void)handleTap {
    [self.textField becomeFirstResponder];
}

@end
