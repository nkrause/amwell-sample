//
//  InboxTableViewCell.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKInboxMessage;

@interface InboxTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *fromLabel;
@property (weak, nonatomic) IBOutlet UILabel *subjectLabel;
@property (weak, nonatomic) IBOutlet UILabel *previewLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *unreadImage;
@property (weak, nonatomic) IBOutlet UIImageView *attachmentIcon;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *attachmentIconTopConstraint;

- (void)handleMessage:(id<AWSDKInboxMessage>)message;

@end
