//
//  MeasurementDetailTableViewCell.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/11/19.
//  Copyright © 2019 American Well. All rights reserved.
//

#import "MeasurementDetailTableViewCell.h"

#import "NSDateFormatter+CommonFormats.h"

#import <AWSDK/AWSDKTrackerEntry.h>
#import <AWSDK/AWSDKTrackerTemplate.h>
#import <AWSDK/AWSDKTrackerDataPoint.h>

static NSDateFormatter *dateFormatter = nil;

@implementation MeasurementDetailTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];

    dateFormatter = [NSDateFormatter longDateTimeWithTimezoneFormatter];
}

- (void)setTrackerEntry:(id<AWSDKTrackerEntry>)trackerEntry {
    _trackerEntry = trackerEntry;

    [self updateCell];
}

- (void)updateCell {
    self.dateLabel.text = [dateFormatter stringFromDate:self.trackerEntry.date];
    self.dataPointLabel.attributedText = [self displayDataPoints];
}

- (NSAttributedString *)displayDataPoints {
    NSMutableAttributedString *fullAttributedText = [NSMutableAttributedString new];

    [self.trackerEntry.data enumerateObjectsUsingBlock:^(id<AWSDKTrackerDataPoint> _Nonnull obj, NSUInteger idx, BOOL *_Nonnull stop) {
        NSString *title = obj.title;
        NSString *message = [NSString stringWithFormat:@"%0.2lf ", obj.value.doubleValue];

        NSRange titleRange = (title.length) ? NSMakeRange(0, title.length) : NSMakeRange(0, 0);
        NSRange messageRange = (message.length) ? NSMakeRange(title.length, message.length + 1) : NSMakeRange(0, 0);
        UIFont *titleFont = [UIFont systemFontOfSize:16.0f weight:UIFontWeightSemibold];
        UIFont *messageFont = [UIFont systemFontOfSize:16.0f weight:UIFontWeightRegular];
        NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
        paragraphStyle.paragraphSpacing = 0.45 * titleFont.lineHeight;
        NSString *newLine = (fullAttributedText.length) ? @"\n" : @"";
        NSString *string = (message.length) ? [NSString stringWithFormat:@"%@%@ %@", newLine, title, message] : [NSString stringWithFormat:@"%@%@", newLine, title];

        NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:string];
        if (title.length) {
            [attributedText addAttribute:NSFontAttributeName value:titleFont range:titleRange];
        }
        if (message.length) {
            [attributedText addAttribute:NSFontAttributeName value:messageFont range:messageRange];
        }
        [attributedText addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(0, attributedText.length)];
        [attributedText addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attributedText.length)];

        UIFont *aFont = [UIFont systemFontOfSize:16.0f weight:UIFontWeightRegular];
        NSAttributedString *decodedString = [self convertHTMLCharacterEntityReferences:obj.unitOfMeasureShortDescription];
        NSMutableAttributedString *uomAttributedText = [[NSMutableAttributedString alloc] initWithAttributedString:decodedString];
        [uomAttributedText addAttribute:NSFontAttributeName value:aFont range:NSMakeRange(0, uomAttributedText.length)];
        [attributedText appendAttributedString:uomAttributedText];

        [fullAttributedText appendAttributedString:attributedText];
    }];

    return fullAttributedText;
}

- (NSAttributedString *)convertHTMLCharacterEntityReferences:(NSString *)htmlString {
    NSData *stringData = [htmlString dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *options = @{ NSDocumentTypeDocumentAttribute : NSHTMLTextDocumentType };
    NSAttributedString *decodedString = [[NSAttributedString alloc] initWithData:stringData options:options documentAttributes:nil error:nil];
    return decodedString;
}

@end
