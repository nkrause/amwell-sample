//
//  KeyboardFieldTableViewCell.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/17/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@class KeyboardFieldTableViewCell;

@protocol KeyboardFieldTableViewCellDelegate <NSObject>
@optional
- (void)textDidChange:(NSString *)text inCell:(KeyboardFieldTableViewCell *)cell;
- (void)textDidEndEditing:(NSString *)text inCell:(KeyboardFieldTableViewCell *)cell;
@end

@interface KeyboardFieldTableViewCell : UITableViewCell <CanShowErrorText>

@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UIButton *errorButton;
@property (weak, nonatomic) IBOutlet UIView *separatorLine;
@property (nonatomic) NSString *errorText;
@property (weak, nonatomic) id<KeyboardFieldTableViewCellDelegate> delegate;

- (void)toolbarDoneButtonTapped;

@end
