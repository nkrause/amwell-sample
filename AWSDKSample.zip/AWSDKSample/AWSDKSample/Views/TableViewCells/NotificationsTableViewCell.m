//
//  NotificationsTableViewCell.m
//  AWSDKSample
//
//  Created by Stephen Ciauri on 7/24/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import "NotificationsTableViewCell.h"

@interface NotificationsTableViewCell ()
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *subtitleLabel;
@end

@implementation NotificationsTableViewCell

- (void)configureWithTitle:(NSString *)title subtitle:(NSString *)subtitle {
    self.titleLabel.text = title;
    self.subtitleLabel.text = subtitle;
}

@end
