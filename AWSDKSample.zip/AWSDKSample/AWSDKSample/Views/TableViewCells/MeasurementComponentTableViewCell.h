//
//  MeasurementComponentTableViewCell.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/16/19.
//  Copyright © 2019 American Well. All rights reserved.
//

#import "MeasurementAddTableViewController.h"

#import <UIKit/UIKit.h>

// clang-format off
@protocol AWSDKTrackerTemplate, AWSDKTrackerComponentTemplate;
// clang-format on

@interface MeasurementComponentTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextField *componentValueTextField;
@property (weak, nonatomic) IBOutlet UILabel *componentUOMLabel;
@property (weak, nonatomic) IBOutlet UIButton *errorButton;

@property (nonatomic) id<AWSDKTrackerTemplate> trackerTemplate;
@property (nonatomic) id<AWSDKTrackerComponentTemplate> trackerComponentTemplate;
@property (weak, nonatomic) id<MeasurementAddTableViewDelegate> delegate;

@end
