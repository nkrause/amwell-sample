//
//  ProviderTableViewCell.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/24/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ProviderTableViewCell.h"

#import "AppDelegate.h"
#import "NSDateFormatter+CommonFormats.h"
#import "NSPersonNameComponents+Localizing.h"

#import <AWSDK/AWSDKAppointment.h>
#import <AWSDK/AWSDKAvailableProviderSearchResult.h>
#import <AWSDK/AWSDKLocale.h>
#import <AWSDK/AWSDKProviderSearchResult.h>
#import <AWSDK/AWSDKProviderType.h>
#import <AWSDK/AWSDKSchedule.h>
#import <AWSDK/AWSDKModality.h>
#import <AWSDK/AWSDKModalityCode.h>


static CGFloat availabilityLabelWidth = 60.0;

@interface ProviderTableViewCell ()

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *availabilityLabelWidthConstraint;

@end

@implementation ProviderTableViewCell

- (void)setProvider:(id<AWSDKProviderSearchResult>)provider {
    // Retrieve current language
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    NSString *languageCode = appDelegate.currentLanguageCode;

    [self.nameLabel setText:provider.nameComponents.localizedFullName];
    if ([NSLocale characterDirectionForLanguage:languageCode] == NSLocaleLanguageDirectionRightToLeft) {
        self.nameLabel.textAlignment = NSTextAlignmentRight;
        self.availabilityLabel.textAlignment = NSTextAlignmentRight;
        self.specialtyLabel.textAlignment = NSTextAlignmentRight;
    }

    NSString *key = [NSString stringWithFormat:@"providers.availability.%li", (long)provider.availability];
    [self.availabilityLabel setText:NSLocalizedString(key, @"Provider Availability Title")];
    self.availabilityLabelWidthConstraint.constant = availabilityLabelWidth;

    if ([provider conformsToProtocol:@protocol(AWSDKAvailableProviderSearchResult)]) {
        // Self scheduling detail
        NSInteger numSchedules = [(id<AWSDKAvailableProviderSearchResult>)provider availableAppointmentSchedules].count;
        [self.availabilityLabel setText:[NSString stringWithFormat:NSLocalizedString(@"providers.availability.appointments", @"Provider Availability Appointments Title"), numSchedules]];
        [self.availabilityLabel setTextColor:[UIColor mediumGreenColor]];
    } else {
        // Regular visit detail
        NSString *key = [NSString stringWithFormat:@"providers.availability.%li", (long)provider.availability];
        [self.availabilityLabel setText:NSLocalizedString(key, @"Providers Availability Title")];

        UIColor *fontColor;
        switch (provider.availability) {
            case VideoAvailable:
                fontColor = [UIColor mediumGreenColor];
                break;
            case VideoBusy:
            case OnCall:
                fontColor = [UIColor availabilityBusyColor];
                if (provider.waitingRoomCount <= 1) {
                    [self.availabilityLabel setText:NSLocalizedString(@"providers.availability.patient", @"Providers Availability 1 Patient Title")];
                } else {
                    [self.availabilityLabel
                        setText:[NSString stringWithFormat:NSLocalizedString(@"providers.availability.patients", @"Providers Availability Patients Title"), provider.waitingRoomCount]];
                }
                break;
            case Offline:
                fontColor = [UIColor availabilityOfflineColor];
                break;
        }

        [self.availabilityLabel setTextColor:fontColor];
    }

    [self.specialtyLabel setText:provider.specialty.name];

    if (provider.image) {
        [self.providerImageView setImage:provider.image];
    } else {
        UIImage *placeholderImage = [UIImage imageNamed:@"userIcon"];
        [self.providerImageView setImage:placeholderImage];
        [self.providerImageView setBackgroundColor:[UIColor lightGrayColor]];
    }

    // Circle image view
    [self.providerImageView.layer setCornerRadius:self.providerImageView.frame.size.width / 2];
    [self.providerImageView.layer setMasksToBounds:YES];
    [self.providerImageView setClipsToBounds:YES];
}

- (void)setAppointment:(id<AWSDKAppointment>)appointment {
    if (appointment.provider) {
        [self.nameLabel setText:[NSString stringWithFormat:@"%@, %@", appointment.provider.nameComponents.localizedFullName, appointment.provider.specialty.name]];
    } else {
        [self.nameLabel setText:[NSString stringWithFormat:NSLocalizedString(@"appointments.firstAvailable", @"Providers First Available Title"), appointment.providerType.name]];
    }

    self.modalityImageView.image = appointment.modality.code == AWSDKModalityCodePhone ? [UIImage imageNamed:@"iconPhoneVisit"] : [UIImage imageNamed:@"videoOnly"];

    self.availabilityLabel.hidden = YES;
    self.availabilityLabelWidthConstraint.constant = 0;

    if (appointment.provider.image) {
        [self.providerImageView setImage:appointment.provider.image];
    } else {
        UIImage *placeholderImage = [UIImage imageNamed:@"userIcon"];
        [self.providerImageView setImage:placeholderImage];
        [self.providerImageView setBackgroundColor:[UIColor lightGrayColor]];
    }

    // Circle image view
    [self.providerImageView.layer setCornerRadius:self.providerImageView.frame.size.width / 2];
    [self.providerImageView.layer setMasksToBounds:YES];
    [self.providerImageView setClipsToBounds:YES];

    NSDateFormatter *formatter = [NSDateFormatter shortLocalDateTimeFormatter];
    NSString *dateString = [formatter stringFromDate:appointment.schedule.scheduledStartTime];
    [self.specialtyLabel setText:dateString];
}

@end
