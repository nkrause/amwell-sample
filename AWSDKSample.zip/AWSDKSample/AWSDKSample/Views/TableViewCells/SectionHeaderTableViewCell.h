//
//  SectionHeaderTableViewCell.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 4/7/18.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

@interface SectionHeaderTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *headerLabel;

@end
