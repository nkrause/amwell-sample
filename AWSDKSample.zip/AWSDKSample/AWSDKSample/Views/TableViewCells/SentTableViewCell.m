//
//  SentTableViewCell.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "SentTableViewCell.h"

#import "NSDateFormatter+CommonFormats.h"

#import <AWSDK/AWSDKSentMessage.h>

@implementation SentTableViewCell

- (void)handleMessage:(id<AWSDKSentMessage>)message {
    self.toLabel.text = [message recipients].count > 1 ? NSLocalizedString(@"sent.multipleRecipients", @"Sent To Multiple Recipients Title") : [[message recipients] firstObject];
    self.subjectLabel.text = [message subject];
    self.previewLabel.text = [message bodyPreview];
    self.sentLabel.text = [[NSDateFormatter shortDateFormatter] stringFromDate:message.sent];
    [self.attachmentIcon setHidden:!message.hasAttachment];
}

@end
