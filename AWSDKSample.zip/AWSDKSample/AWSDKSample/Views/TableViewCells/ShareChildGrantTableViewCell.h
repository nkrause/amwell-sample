//
//  ShareChildGrantTableViewCell.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 4/5/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

@interface ShareChildGrantTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *messageLabel;
@property (weak, nonatomic) IBOutlet UIButton *grantAccessButton;
@property (weak, nonatomic) IBOutlet UIButton *dontGrantAccessButton;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *dontGrantAccessButtonHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *profileTypeSegmentCtrlHeightConstraint;

@end
