//
//  MeasurementTableViewCell.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/11/19.
//  Copyright © 2019 American Well. All rights reserved.
//

#import <UIKit/UIKit.h>

// clang-format off
@protocol AWSDKTrackerTemplate, AWSDKTrackerEntry;
// clang-format on

@interface MeasurementTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *messageLabel;
@property (weak, nonatomic) IBOutlet UILabel *measurementLabel;

@property (nonatomic) id<AWSDKTrackerEntry> trackerEntry;

@end
