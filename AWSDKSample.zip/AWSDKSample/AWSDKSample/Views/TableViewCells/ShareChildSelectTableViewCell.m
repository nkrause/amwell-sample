//
//  ShareChildSelectTableViewCell.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 4/5/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ShareChildSelectTableViewCell.h"

@implementation ShareChildSelectTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];

    // Initialization code
    [self.checkButton setImage:[UIImage imageNamed:@"iconUnchosen"] forState:UIControlStateNormal];
    [self.checkButton setImage:[UIImage imageNamed:@"iconChosenCheck"] forState:UIControlStateSelected];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
