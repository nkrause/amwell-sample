//
//  KeyboardFieldAndSwitchTableViewCell.h
//  AWSDKSample
//
//  Created by Christopher Majoros on 8/21/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "KeyboardFieldTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@class KeyboardFieldAndSwitchTableViewCell;

@protocol KeyboardFieldAndSwitchTableViewCellDelegate <NSObject>

@optional
- (void)toggleDidChange:(BOOL)setting inCell:(KeyboardFieldAndSwitchTableViewCell *)cell;

@end

@interface KeyboardFieldAndSwitchTableViewCell : KeyboardFieldTableViewCell

@property (weak, nonatomic) IBOutlet UISwitch *toggle;
@property (weak, nonatomic) id<KeyboardFieldAndSwitchTableViewCellDelegate> toggleDelegate;

@end

NS_ASSUME_NONNULL_END
