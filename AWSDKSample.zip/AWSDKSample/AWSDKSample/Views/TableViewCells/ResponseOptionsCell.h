//
//  ResponseOptionsCell.h
//  AWSDKSample
//
//  Created by Ed Chianese on 12/5/18.
//  Copyright © 2018 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.

#import <UIKit/UIKit.h>

@interface ResponseOptionsCell : UITableViewCell <UITextFieldDelegate>
@property (nonatomic, weak, nullable) IBOutlet UITextField *textField;
@property (nonatomic, strong, nullable) IBOutlet UIPickerView *responseOptionsPicker;
@property (nonatomic, weak, nullable) id<UIPickerViewDataSource> dataSource;
@property (nonatomic, weak, nullable) id<UIPickerViewDelegate> delegate;
@end
