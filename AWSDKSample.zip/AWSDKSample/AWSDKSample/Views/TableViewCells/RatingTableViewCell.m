//
//  RatingTableViewCell.m
//  AWSDKSample
//
//  Created by Steven Uy on 6/7/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "RatingTableViewCell.h"

@implementation RatingTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.rating = [[NSNumber alloc] initWithInt:0];
}

- (IBAction)starTapped:(id)sender {
    UIButton *star = (UIButton *)sender;
    self.rating = @(star.tag);
    AWSDKLogInfo(@"Rated %@ starts to '%@'", self.rating, self.label);

    [self.star5 setSelected:star.tag >= 5];
    [self.star4 setSelected:star.tag >= 4];
    [self.star3 setSelected:star.tag >= 3];
    [self.star2 setSelected:star.tag >= 2];
    [self.star1 setSelected:star.tag >= 1];
}

@end
