//
//  ProviderTableViewCell.h
//  AWSDKSample
//
//  Created by Steven Uy on 5/24/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

// clang-format off
@protocol AWSDKProviderSearchResult, AWSDKAppointment;
// clang-format on

@interface ProviderTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *specialtyLabel;
@property (weak, nonatomic) IBOutlet UILabel *availabilityLabel;
@property (weak, nonatomic) IBOutlet UIImageView *providerImageView;
@property (weak, nonatomic) IBOutlet UIImageView *modalityImageView;
- (void)setProvider:(id<AWSDKProviderSearchResult>)provider;
- (void)setAppointment:(id<AWSDKAppointment>)appointment;

@end
