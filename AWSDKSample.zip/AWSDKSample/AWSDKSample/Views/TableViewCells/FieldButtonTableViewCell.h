//
//  FieldButtonTableViewCell.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/21/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "FieldTableViewCell.h"

@interface FieldButtonTableViewCell : FieldTableViewCell

@property (weak, nonatomic) IBOutlet UIButton *button;

@end
