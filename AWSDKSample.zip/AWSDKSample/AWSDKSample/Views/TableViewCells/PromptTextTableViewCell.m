//
//  PromptTextTableViewCell.m
//  AWSDKSample
//
//  Created by Steven Uy on 2/18/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "PromptTextTableViewCell.h"

@implementation PromptTextTableViewCell

- (void)layoutSubviews {
    [super layoutSubviews];

    // Style font
    self.textLabel.font = [self.textLabel.font fontWithSize:13.0];
    self.textLabel.textColor = [UIColor darkGrayColor];
    self.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.textLabel.numberOfLines = 0;
}

@end
