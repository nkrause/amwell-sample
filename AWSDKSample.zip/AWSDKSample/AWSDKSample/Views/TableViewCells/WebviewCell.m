//
//  WebviewCell.m
//  AWSDKSample
//
//  Created by Steven Uy on 4/20/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "WebviewCell.h"

@implementation WebviewCell

@end
