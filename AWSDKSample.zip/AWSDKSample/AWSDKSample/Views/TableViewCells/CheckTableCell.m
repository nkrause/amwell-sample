//
//  CheckTableCell.m
//  AWSDKSample

//  Created by Ed Chianese on 11/28/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//
#import "CheckTableCell.h"

@implementation CheckTableCell

- (void)setIsChecked:(BOOL)check {
    _isChecked = check;
    if (check) {
        self.checkImage.image = [UIImage imageNamed:@"iconChosenCheck"];
    } else {
        self.checkImage.image = [UIImage imageNamed:@"iconCheckOff"];
    }
}
@end
