//
//  KeyboardFieldTableViewCell.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/17/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "KeyboardFieldTableViewCell.h"

@interface KeyboardFieldTableViewCell () <UITextFieldDelegate>
@end

@implementation KeyboardFieldTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.textField.delegate = self;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    if ([self.delegate respondsToSelector:@selector(textDidChange:inCell:)]) {
        [self.delegate textDidChange:newString inCell:self];
    }
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    textField.text = [textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([self.delegate respondsToSelector:@selector(textDidEndEditing:inCell:)]) {
        [self.delegate textDidEndEditing:textField.text inCell:self];
    }
}

- (void)toolbarDoneButtonTapped {
    [self textFieldDidEndEditing:self.textField];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)layoutSubviews {
    [super layoutSubviews];
}

#pragma mark - UIResponder
- (BOOL)canBecomeFirstResponder {
    return YES;
}

- (BOOL)becomeFirstResponder {
    [self.textField becomeFirstResponder];
    return YES;
}

@end
