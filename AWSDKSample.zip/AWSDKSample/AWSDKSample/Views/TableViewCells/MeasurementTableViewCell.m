//
//  MeasurementTableViewCell.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/11/19.
//  Copyright © 2019 American Well. All rights reserved.
//

#import "MeasurementTableViewCell.h"

#import <AWSDK/AWSDKTrackerEntry.h>
#import <AWSDK/AWSDKTrackerTemplate.h>
#import <AWSDK/AWSDKTrackerDataPoint.h>

@implementation MeasurementTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];

    self.messageLabel.text = NSLocalizedString(@"myHealth.measurements.itemMessage", @"Latest Measurement");
}

- (void)setTrackerEntry:(id<AWSDKTrackerEntry>)trackerEntry {
    _trackerEntry = trackerEntry;

    [self updateCell];
}

- (void)updateCell {
    self.nameLabel.text = self.trackerEntry.trackerTemplate.title;

    NSMutableAttributedString *displayAttributedText = [NSMutableAttributedString new];
    if (self.trackerEntry.data.count) {
        id<AWSDKTrackerDataPoint> dataPoint = [self.trackerEntry.data firstObject];

        NSString *valueString = [NSString stringWithFormat:@"%0.2lf ", [dataPoint.value doubleValue]];
        [displayAttributedText appendAttributedString:[[NSAttributedString alloc] initWithString:valueString]];

        UIFont *aFont = [UIFont systemFontOfSize:16.0f weight:UIFontWeightRegular];
        NSAttributedString *decodedString = [self convertHTMLCharacterEntityReferences:dataPoint.unitOfMeasureShortDescription];
        NSMutableAttributedString *uomAttributedText = [[NSMutableAttributedString alloc] initWithAttributedString:decodedString];
        [uomAttributedText addAttribute:NSFontAttributeName value:aFont range:NSMakeRange(0, uomAttributedText.length)];
        [displayAttributedText appendAttributedString:uomAttributedText];
    }
    if (self.trackerEntry.data.count > 1) {
        NSInteger index = 1;
        for (id<AWSDKTrackerDataPoint> dataPoint = self.trackerEntry.data[index]; dataPoint;) {
            NSString *valueString = [NSString stringWithFormat:@" / %0.2lf ", [dataPoint.value doubleValue]];
            [displayAttributedText appendAttributedString:[[NSAttributedString alloc] initWithString:valueString]];

            UIFont *aFont = [UIFont systemFontOfSize:16.0f weight:UIFontWeightRegular];
            NSAttributedString *decodedString = [self convertHTMLCharacterEntityReferences:dataPoint.unitOfMeasureShortDescription];
            NSMutableAttributedString *uomAttributedText = [[NSMutableAttributedString alloc] initWithAttributedString:decodedString];
            [uomAttributedText addAttribute:NSFontAttributeName value:aFont range:NSMakeRange(0, uomAttributedText.length)];
            [displayAttributedText appendAttributedString:uomAttributedText];

            dataPoint = (++index < self.trackerEntry.data.count) ? self.trackerEntry.data[index] : nil;
        }
    }
    self.measurementLabel.attributedText = displayAttributedText;
}

- (NSAttributedString *)convertHTMLCharacterEntityReferences:(NSString *)htmlString {
    NSData *stringData = [htmlString dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *options = @{ NSDocumentTypeDocumentAttribute : NSHTMLTextDocumentType };
    NSAttributedString *decodedString = [[NSAttributedString alloc] initWithData:stringData options:options documentAttributes:nil error:nil];
    return decodedString;
}

@end
