//
//  TitleTextFieldTableViewCell.h
//  AWSDKSample
//
//  Created by Stephen Ciauri on 3/20/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

@protocol TextFieldTableViewCellDelegate
- (void)textDidChange:(NSString *)text inCell:(UITableViewCell *)cell;
- (void)textDidBeginEditing:(UITextField *)textField;
- (BOOL)textDidReturn:(UITextField *)textField;

@end

@interface TitleTextFieldTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) id<TextFieldTableViewCellDelegate> delegate;

@end
