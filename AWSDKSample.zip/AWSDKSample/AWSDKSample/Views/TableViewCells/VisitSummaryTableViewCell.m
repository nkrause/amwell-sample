//
//  VisitSummaryTableViewCell.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 10/11/19.
//  Copyright © 2019 American Well. All rights reserved.
//

#import "VisitSummaryTableViewCell.h"

@implementation VisitSummaryTableViewCell

@end
