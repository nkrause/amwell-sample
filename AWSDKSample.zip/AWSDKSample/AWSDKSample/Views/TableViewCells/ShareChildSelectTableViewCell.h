//
//  ShareChildSelectTableViewCell.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 4/5/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

@interface ShareChildSelectTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *separator;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *dobLabel;
@property (weak, nonatomic) IBOutlet UIButton *checkButton;

@end
