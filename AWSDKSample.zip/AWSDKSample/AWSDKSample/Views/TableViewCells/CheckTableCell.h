//
//  CheckTableCell.h
//  AWSDKSample

//  Created by Ed Chianese on 11/28/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

@interface CheckTableCell : UITableViewCell
@property (nonatomic, weak, nullable) IBOutlet UIImageView *checkImage;
@property (nonatomic, weak, nullable) IBOutlet UILabel *modalityLabel;
@property (nonatomic) BOOL isChecked;
@end
