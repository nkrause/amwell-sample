//
//  PharmacyResultTableViewCell.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/17/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@protocol AWSDKPharmacy;

@interface PharmacyResultTableViewCell : UITableViewCell

- (void)handlePharmacy:(id<AWSDKPharmacy>)pharmacy;

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailLabel;
@property (weak, nonatomic) IBOutlet UILabel *phoneLabel;
@property (weak, nonatomic) IBOutlet UILabel *addressLabel;
@property (weak, nonatomic) IBOutlet UILabel *distanceLabel;

@end
