//
//  MeasurementDetailTableViewCell.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 1/11/19.
//  Copyright © 2019 American Well. All rights reserved.
//

#import <UIKit/UIKit.h>

// clang-format off
@protocol AWSDKTrackerTemplate, AWSDKTrackerEntry;
// clang-format on

@interface MeasurementDetailTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *dataPointLabel;

@property (nonatomic) id<AWSDKTrackerTemplate> trackerTemplate;
@property (nonatomic) id<AWSDKTrackerEntry> trackerEntry;

@end
