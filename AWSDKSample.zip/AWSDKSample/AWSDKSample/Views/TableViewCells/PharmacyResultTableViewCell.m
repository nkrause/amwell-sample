//
//  PharmacyResultTableViewCell.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/17/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "PharmacyResultTableViewCell.h"

#import <AWSDK/AWSDKAddress.h>
#import <AWSDK/AWSDKPharmacy.h>

@implementation PharmacyResultTableViewCell

- (void)handlePharmacy:(id<AWSDKPharmacy>)pharmacy {
    [self.nameLabel setText:pharmacy.name];
    [self.emailLabel setText:pharmacy.contactEmail];
    [self.phoneLabel setText:pharmacy.contactPhone];
    [self.addressLabel setText:pharmacy.address.displayString];

    // Display distance if not nil
    [self.distanceLabel setHidden:(pharmacy.distance == nil)];
    if (pharmacy.distance) {
        NSNumberFormatter *formatter = [NSNumberFormatter new];
        [formatter setPositiveFormat:@"0.##"];
        [self.distanceLabel setText:[[formatter stringFromNumber:pharmacy.distance] stringByAppendingString:NSLocalizedString(@"pharmacySearch.distance", @"Pharmacy Search Distance Title")]];
    }
}

@end
