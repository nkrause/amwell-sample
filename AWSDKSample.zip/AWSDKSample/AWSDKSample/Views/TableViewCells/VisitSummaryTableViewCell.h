//
//  VisitSummaryTableViewCell.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 10/11/19.
//  Copyright © 2019 American Well. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VisitSummaryTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *providerLabel;
@property (weak, nonatomic) IBOutlet UIButton *reconnectButton;

@end
