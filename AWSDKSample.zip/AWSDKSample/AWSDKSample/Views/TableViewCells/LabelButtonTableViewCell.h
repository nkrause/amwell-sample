//
//  LabelButtonTableViewCell.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 8/15/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "FieldTableViewCell.h"

@interface LabelButtonTableViewCell : FieldTableViewCell

@property (weak, nonatomic) IBOutlet UIButton *button;

@end
