//
//  InboxTableViewCell.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "InboxTableViewCell.h"

#import "NSDateFormatter+CommonFormats.h"

#import <AWSDK/AWSDKInboxMessage.h>

@implementation InboxTableViewCell

- (void)handleMessage:(id<AWSDKInboxMessage>)message {
    [self.fromLabel setText:message.senderName];
    [self.subjectLabel setText:message.subject];
    [self.previewLabel setText:message.bodyPreview];
    [self.timeLabel setText:[[NSDateFormatter shortDateFormatter] stringFromDate:message.sent]];
    [self.unreadImage setHidden:!message.isUnread];
    [self.attachmentIcon setHidden:!message.hasAttachment];
    self.attachmentIconTopConstraint.constant = self.unreadImage.hidden ? -(self.fromLabel.frame.size.height + 4) : 0;
    [self layoutIfNeeded];
}

@end
