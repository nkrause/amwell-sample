//
//  VisitReportTableViewCell.h
//  AWSDKSample
//
//  Created by Caleb Lindsey on 6/1/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <Foundation/Foundation.h>

@interface VisitReportTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) IBOutlet UILabel *practiceLabel;
@property (strong, nonatomic) IBOutlet UILabel *dateLabel;

@end
