//
//  main.m
//  AWSDKSample
//
//  Created by steven.uy on 2/12/16.
//  Copyright © 2016 American Well. All rights reserved.
//

#import "AppDelegate.h"

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
