//
//  UIViewController+Handlers.h
//  AWSDKSample
//
//  Created by Steven Uy on 3/21/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "ErrorService.h"

typedef void (^SuccessCompletionBlock)(BOOL success);
typedef void (^UIAlertDefaultHandlerBlock)(UIAlertAction *action);

@interface UIViewController (Handlers)

#pragma mark - Alert Handlers
/**
 Presents a UIAlertControlelr with a title and message depending on the error. Contains an ok
 alert action, which is called upon tapped.

 @param error   NSError in AWSDKError format.
 @param handler Block called when ok is tapped

 @return UIAlertController after present started
 */
- (UIAlertController *)presentAlertWithError:(NSError *)error okHandler:(void (^)(UIAlertAction *action))handler;
/**
 Presents a UIAlertController with a title and message depending on the error. Contains an ok
 alert action, which is called upon tapped.

 @param error NSError in AWSDKError format.

 @return UIAlertController after present started
 */
- (UIAlertController *)presentAlertWithError:(NSError *)error;

/**
 Presents a UIAlertController with a message key for Localizable.strings. Title is set depending on the mssage key;
 Contains an ok alert action, which calls handler upon tapped.

 @param key     NSString for message key
 @param handler Block called when ok is tapped

 @return UIAlertController after present started
 */
- (UIAlertController *)presentAlertWithMessageKey:(NSString *)key okHandler:(void (^)(UIAlertAction *action))handler;

/**
 Presents a UIAlertController with a message key for Localizable.strings. Title is set depending on the message key;
 Contains a yes alert action, which calls handler upon being tapped, and a no option which will just dismiss the alert
 controller.

 @param key     NSString for message key
 @param handler Block called when yes is tapped

 @return UIAlertController after present started
 */
- (UIAlertController *)presentAlertWithMessageKey:(NSString *)key yesHandler:(void (^)(UIAlertAction *))handler;

/**
 Presents a UIAlertController with a message key for Localizable.strings. Title is set depending on the message key;
 Contains a yes alert action, which calls handler upon being tapped, and a no action which calls a handler upon being
 tapped.

 @param key     NSString for message key
 @param handler Block called when yes is tapped

 @return UIAlertController after present started
 */
- (UIAlertController *)presentAlertWithMessageKey:(NSString *)key yesHandler:(void (^)(UIAlertAction *))yesHandler noHandler:(void (^)(UIAlertAction *))noHandler;

/**
Presents a UIAlertController with a message key for Localizable.strings. Title is set depending on the message key;
Contains a go back alert action, which calls handler upon being tapped, and a close action which calls a handler upon being
tapped.

@param key     NSString for message key
@param goBackHandler Block called when go back is tapped
@param closeHandler Block called when close is tapped

@return UIAlertController after present started
*/
- (UIAlertController *)presentAlertWithMessageKey:(NSString *)key goBackHandler:(void (^)(UIAlertAction *))goBackHandler closeHandler:(void (^)(UIAlertAction *))closeHandler;

/**
 Presents a UIAlertController with a message key for Localizable.strings. Title is set depending on the message key.
 For example if key = "login.sent", then the title key will be "login.title".

 @param key NSString for message key of alert in localizable.strings

 @return UIAlertController after present started
 */
- (UIAlertController *)presentAlertWithMessageKey:(NSString *)key;

/**
 Presents a UIAlertController with a title key for Localizable.strings. This does not dismiss automatically.

 @param key  NSString for NSLocalizableString(key) in Localizable.strings

 @return UIAlertController after present started
 */
- (UIAlertController *)presentAlertWithTitleKey:(NSString *)key;
- (UIAlertController *)presentAlertWithTitleKey:(NSString *)key okHandler:(void (^)(UIAlertAction *action))handler;

/**
 Presents a UIAlertController with a title and message. Alert has an ok action that will dismiss after
 pressed.

 @param title   NSString title of alert
 @param message NSString message of alert
 @param handler Block called when ok is tapped

 @return UIAlertController after present started
 */
- (UIAlertController *)presentAlertWithTitle:(NSString *)title message:(NSString *)message okHandler:(void (^)(UIAlertAction *action))handler;
/**
 Presents a UIAlertController with a title and message. UIAlertController does not dismiss automatically.

 @param title   Title of alert
 @param message Message of alert

 @return UIAlertController after present started
 */
- (UIAlertController *)presentAlertWithTitle:(NSString *)title message:(NSString *)message;

/**
 Present an alert controller and handle dismissing indicators or modals

 @param alertController UIAlertController

 @return UIAlertController
 */
- (UIAlertController *)presentAlertController:(UIAlertController *)alertController;

/**
 Present an alert controller and handle dismissing indicators or modals

 @param alertController UIAlertController
 @param shouldRemoveOnBackground BOOL indicator to specify if the alert should be dismissed when the app is sent to the background.

 @return UIAlertController
 */
- (UIAlertController *)presentAlertController:(UIAlertController *)alertController removeOnBackground:(BOOL)shouldRemoveOnBackground;

/**
 Ends editing of the current viewcontroller's view. This is commonly used as a selector
 */
- (void)dismissKeyboard;

/**
 Default alert handler to remove the alert from the alert uiwindow after an alert action is selected;

 Since Apple doesn't recommmend extending the UIAlertController, a wrapper function is provided as a default action.
 The wrapper accepts an UIAlertAction block or nil.

 @param handler Block for action

 @return handler Block
 */
- (UIAlertDefaultHandlerBlock)defaultAlertHandler:(UIAlertDefaultHandlerBlock)handler;

/**
 Provides a reference to the topMostMainVC Controller presented on the navigation stack on the main window

 @return UIViewController of the top viewcontroller
 */
+ (UIViewController *)topMostMainVC;

/**
 Provides a reference to the topMostAlertVC Controller on the alert window

 @return UIViewController of the top viewcontroller
 */
+ (UIViewController *)topMostAlertVC;

/**
 Provides a reference to the topMostMainVC Controller on the navigation stack on the main window

 @return UIViewController of the top viewcontroller
 */
+ (UIViewController *)topController;

@end
