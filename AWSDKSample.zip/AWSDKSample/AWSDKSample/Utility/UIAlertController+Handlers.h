//
//  UIAlertController+Handlers.h
//  AWSDKSample
//
//  Created by Steven Uy on 4/11/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface UIAlertController (Handlers)

/**
 Creates an UIAlertController with an ok action based on an NSError described in AWSDKErrors

 @param error   NSError in the format of an AWSDKError
 @param handler Block containing logic to run after ok is pressed. If handler is nil, the ok action
                will still show and dismiss the alert when presesd

 @return UIAlertController
 */
+ (UIAlertController *)alertControllerWithError:(NSError *)error okHandler:(void (^)(UIAlertAction *action))handler;

/**
 Creates an UIAlertController based on an NSError described in AWSDKErrors and requires a dismiss call

 @param error NSError in the format of an AWSDKError

 @return UIAlertController
 */
+ (UIAlertController *)alertControllerWithError:(NSError *)error;

/**
 Creates an UIAlertController with a NSLocalizedString key and an ok action

 @param key     NSLocalizedString key for Localizable.strings
 @param handler Block containing logic to run after ok is pressed

 @return UIAlertController
 */
+ (UIAlertController *)alertControllerWithMessageKey:(NSString *)key okHandler:(void (^)(UIAlertAction *action))handler;

/**
 Creates an UIAlertController with a NSLocalizedString key, a yes action and a no option

 @param key     NSLocalizedString key for Localizable.strings
 @param handler Block containing logic to run after yes is pressed

 @return UIAlertController
 */
+ (UIAlertController *)alertControllerWithMessageKey:(NSString *)key yesHandler:(void (^)(UIAlertAction *action))handler;

/**
 Creates an UIAlertController with a NSLocalizedString key, a yes action and a no action

 @param key     NSLocalizedString key for Localizable.strings
 @param yesHandler Block containing logic to run after yes is pressed
 @param noHandler Block containing logic to run after no is pressed

 @return UIAlertController
 */
+ (UIAlertController *)alertControllerWithMessageKey:(NSString *)key yesHandler:(void (^)(UIAlertAction *action))yesHandler noHandler:(void (^)(UIAlertAction *action))noHandler;

/**
Creates an UIAlertController with a NSLocalizedString key, a go back action and a close action, both default style

@param key     NSLocalizedString key for Localizable.strings
@param goBackHandler Block containing logic to run after go back is pressed
@param closeHandler Block containing logic to run after close is pressed

@return UIAlertController
*/
+ (UIAlertController *)alertControllerWithMessageKey:(NSString *)key goBackHandler:(void (^)(UIAlertAction *))goBackHandler closeHandler:(void (^)(UIAlertAction *))closeHandler;

/**
 Creates an UIAlertController with a message and an ok action

 @param message Message to show on the alert controller
 @param handler Block containing logic to run after ok is pressed

 @return UIAlertController
 */
+ (UIAlertController *)alertControllerWithMessage:(NSString *)message okHandler:(void (^)(UIAlertAction *action))handler;

/**
 Creates an UIAlertController with a NSLocalizedString key and requires a dismiss call

 @param key     NSLocalizedString key for Localizable.strings

 @return UIAlertController
 */
+ (UIAlertController *)alertControllerWithMessageKey:(NSString *)key;

/**
 Creates an UIAlertController with a NSLocalizedString key and requires a dismiss call.
 This is commonly used for loading and updating indicators

 @param key     NSLocalizedString key for Localizable.strings

 @return UIAlertController
 */
+ (UIAlertController *)alertControllerWithTitleKey:(NSString *)key;

/**
 Creates an UIAlertController with a given title and message. Contains an ok action with an
 optional block to execute after ok is pressed.

 @param title   Title string of the UIAlertController
 @param message Message string of the UIAlertController
 @param handler Block containing logic to run after ok is pressed. If handler is nil, the ok action
                will still show and dismiss the alert when presesd

 @return UIAlertController
 */
+ (UIAlertController *)alertControllerWithTitle:(NSString *)title message:(NSString *)message okHandler:(void (^)(UIAlertAction *action))handler;

/**
 Creates an UIAlertController with a given title and message. This requires a dismiss call.

 @param title   Title string of the UIAlertController
 @param message Message string of the UIAlertcontroller

 @return UIAlertController
 */
+ (UIAlertController *)alertControllerWithTitle:(NSString *)title message:(NSString *)message;

@end
