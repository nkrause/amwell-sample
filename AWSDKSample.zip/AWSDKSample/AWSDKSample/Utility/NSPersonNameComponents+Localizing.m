//
//  NSPersonNameComponents+Localizing.m
//  AWSDKSample
//
//  Created by Stephen Ciauri on 8/20/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import "NSPersonNameComponents+Localizing.h"

@implementation NSPersonNameComponents (Localizing)
- (NSString *)localizedFullName {
    return [NSPersonNameComponentsFormatter localizedStringFromPersonNameComponents:self style:NSPersonNameComponentsFormatterStyleLong options:0];
}
@end
