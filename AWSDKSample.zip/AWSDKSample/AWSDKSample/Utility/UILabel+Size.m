//
//  UILabel+Size.m
//  AWSDKSample
//
//  Created by Jeremiah.Possion on 3/13/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "UILabel+Size.h"

#import <AWSDK/AWSDKLogService.h>

@implementation UILabel (Size)

- (CGFloat)heightForLabel {
    return [self heightForLabelWithOffset:0.0];
}

- (CGFloat)heightForLabelWithOffset:(CGFloat)offset {
    return [self heightForLabelWithSize:CGSizeMake(CGRectGetWidth(self.frame) - offset, CGFLOAT_MAX)];
}

- (CGFloat)heightForLabelWithSize:(CGSize)size {
    CGSize boundingBox = [self.text boundingRectWithSize:size
                                                 options:(NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading | NSStringDrawingTruncatesLastVisibleLine)
                                              attributes:@{ NSFontAttributeName : self.font }
                                                 context:nil]
                             .size;
    return ceilf([self sizeThatFits:boundingBox].height);
}

@end
