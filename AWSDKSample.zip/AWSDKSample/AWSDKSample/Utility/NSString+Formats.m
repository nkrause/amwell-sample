//
//  NSString+Formats.m
//  AWSDKSample
//
//  Created by Jeremiah.Possion on 1/24/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "NSString+Formats.h"

@implementation NSString (Formats)

- (NSString *)phoneNumberFormat {
    static NSCharacterSet *set = nil;
    if (set == nil) {
        set = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    }
    NSString *phoneString = [[self componentsSeparatedByCharactersInSet:set] componentsJoinedByString:@""];
    switch (phoneString.length) {
        case 7:
            return [NSString stringWithFormat:@"%@-%@", [phoneString substringToIndex:3], [phoneString substringFromIndex:3]];
        case 10:
            return [NSString stringWithFormat:@"(%@) %@-%@", [phoneString substringToIndex:3], [phoneString substringWithRange:NSMakeRange(3, 3)], [phoneString substringFromIndex:6]];
        case 11:
            return [NSString stringWithFormat:@"%@ (%@) %@-%@",
                             [phoneString substringToIndex:1],
                             [phoneString substringWithRange:NSMakeRange(1, 3)],
                             [phoneString substringWithRange:NSMakeRange(4, 3)],
                             [phoneString substringFromIndex:7]];
        case 12:
            return [NSString stringWithFormat:@"+%@ (%@) %@-%@",
                             [phoneString substringToIndex:2],
                             [phoneString substringWithRange:NSMakeRange(2, 3)],
                             [phoneString substringWithRange:NSMakeRange(5, 3)],
                             [phoneString substringFromIndex:8]];
        default:
            return self;
    }
}

@end
