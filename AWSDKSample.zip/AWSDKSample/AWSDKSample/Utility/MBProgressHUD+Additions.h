//
//  MBProgressHUD+Additions.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 8/5/19.
//  Copyright © 2019 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MBProgressHUD.h"

@interface MBProgressHUD (Additions)

+ (void)show;

+ (void)showLoading;

+ (void)showUpdating;

+ (void)showSearching;

+ (void)showSending;

+ (void)showEnrolling;

+ (void)showRefreshing;

+ (void)showCreating;

+ (void)showScheduling;

+ (void)showCanceling;

+ (void)showDeleting;

+ (void)showLoadingOn:(UIView *)view;

+ (void)showUpdatingOn:(UIView *)view;

+ (void)showSearchingOn:(UIView *)view;

+ (void)showSendingOn:(UIView *)view;

+ (void)showEnrollingOn:(UIView *)view;

+ (void)showRefreshingOn:(UIView *)view;

+ (void)showCreatingOn:(UIView *)view;

+ (void)showSchedulingOn:(UIView *)view;

+ (void)showCancelingOn:(UIView *)view;

+ (void)showDeletingOn:(UIView *)view;

+ (MBProgressHUD *)showHUDAddedTo:(UIView *)view;

+ (void)hide;

+ (void)hideHUDForView:(UIView *)view;

@end
