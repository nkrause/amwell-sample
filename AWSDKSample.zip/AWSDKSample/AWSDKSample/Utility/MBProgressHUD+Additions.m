//
//  MBProgressHUD+Additions.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 8/5/19.
//  Copyright © 2019 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "MBProgressHUD+Additions.h"

@implementation MBProgressHUD (Additions)

+ (void)show {
    [MBProgressHUD showHUDAddedTo:nil];
}

+ (void)showLoading {
    [MBProgressHUD showLoadingOn:nil];
}

+ (void)showUpdating {
    [MBProgressHUD showUpdatingOn:nil];
}

+ (void)showSearching {
    [MBProgressHUD showSearchingOn:nil];
}

+ (void)showSending {
    [MBProgressHUD showSendingOn:nil];
}

+ (void)showEnrolling {
    [MBProgressHUD showEnrollingOn:nil];
}

+ (void)showRefreshing {
    [MBProgressHUD showRefreshingOn:nil];
}

+ (void)showCreating {
    [MBProgressHUD showCreatingOn:nil];
}

+ (void)showScheduling {
    [MBProgressHUD showSchedulingOn:nil];
}

+ (void)showCanceling {
    [MBProgressHUD showCancelingOn:nil];
}

+ (void)showDeleting {
    [MBProgressHUD showDeletingOn:nil];
}

+ (void)showLoadingOn:(UIView *)view {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view];
    hud.label.text = NSLocalizedString(@"alert.loading", @"Alert Displaying Loading");
}

+ (void)showUpdatingOn:(UIView *)view {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view];
    hud.label.text = NSLocalizedString(@"alert.updating", @"Alert Displaying Updating");
}

+ (void)showSearchingOn:(UIView *)view {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view];
    hud.label.text = NSLocalizedString(@"alert.searching", @"Alert Displaying Searching");
}

+ (void)showSendingOn:(UIView *)view {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view];
    hud.label.text = NSLocalizedString(@"alert.sending", @"Alert Displaying Sending");
}

+ (void)showEnrollingOn:(UIView *)view {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view];
    hud.label.text = NSLocalizedString(@"alert.enrolling", @"Alert Displaying Enrolling");
}

+ (void)showRefreshingOn:(UIView *)view {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view];
    hud.label.text = NSLocalizedString(@"alert.refreshing", @"Alert Displaying Refreshing");
}

+ (void)showCreatingOn:(UIView *)view {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view];
    hud.label.text = NSLocalizedString(@"alert.creating", @"Alert Displaying Creating");
}

+ (void)showSchedulingOn:(UIView *)view {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view];
    hud.label.text = NSLocalizedString(@"alert.scheduling", @"Alert Displaying Scheduling");
}

+ (void)showCancelingOn:(UIView *)view {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view];
    hud.label.text = NSLocalizedString(@"alert.canceling", @"Alert Displaying Canceling");
}

+ (void)showDeletingOn:(UIView *)view {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view];
    hud.label.text = NSLocalizedString(@"alert.deleting", @"Alert Displaying Deleting");
}

+ (MBProgressHUD *)showHUDAddedTo:(UIView *)view {
    MBProgressHUD *hud;
    if (view) {
        hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    } else {
        UIWindow *window = [[UIApplication sharedApplication] delegate].window;
        hud = [MBProgressHUD showHUDAddedTo:window animated:YES];
    }
    hud.minShowTime = 0.50;
    hud.animationType = MBProgressHUDAnimationZoom;
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.backgroundColor = [UIColor colorWithWhite:0.5f alpha:0.2f];
    hud.backgroundView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.backgroundView.color = [UIColor colorWithWhite:0.5f alpha:0.1f];
    hud.minSize = CGSizeMake(175.f, 125.f);
    hud.layer.zPosition = 100;
    return hud;
}

+ (void)hide {
    [MBProgressHUD hideHUDForView:nil];
}

+ (void)hideHUDForView:(UIView *)view {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (view) {
            [MBProgressHUD hideHUDForView:view animated:YES];
        } else {
            UIWindow *window = [[UIApplication sharedApplication] delegate].window;
            [MBProgressHUD hideHUDForView:window animated:YES];
        }
    });
}

@end
