//
//  UIApplication+AVAuthorization.m
//  AWSDKSample
//
//  Created by Stephen Ciauri on 6/22/17.
//  Copyright © 2017 American Well. All rights reserved.
//

#import "UIApplication+AVAuthorization.h"

#import <AVFoundation/AVFoundation.h>

@implementation UIApplication (AVAuthorization)

#pragma mark - Public

- (BOOL)cameraAuthorized {
    return [self checkPermissionType:AVMediaTypeVideo];
}

- (BOOL)microphoneAuthorized {
    return [self checkPermissionType:AVMediaTypeAudio];
}

- (void)requestCameraAuthorizationWithCompletion:(SuccessCompletionBlock)completion {
    [self requestPermissionType:AVMediaTypeVideo withCompletion:completion];
}

- (void)requestMicrophoneAuthorizationWithCompletion:(SuccessCompletionBlock)completion {
    [self requestPermissionType:AVMediaTypeAudio withCompletion:completion];
}

#pragma mark - Private

- (BOOL)checkPermissionType:(NSString *)type {
    [self validatePermissionType:type];
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:type];
    return authStatus == AVAuthorizationStatusAuthorized;
}

- (void)requestPermissionType:(NSString *)type withCompletion:(SuccessCompletionBlock)completion {
    [self validatePermissionType:type];
    [AVCaptureDevice requestAccessForMediaType:type
                             completionHandler:^(BOOL granted) {
                                 if (granted) {
                                     completion(YES);
                                 } else {
                                     completion(NO);
                                 }
                             }];
}

- (void)validatePermissionType:(NSString *)type {
    if (type == AVMediaTypeAudio) {
        return;
    } else if (type == AVMediaTypeVideo) {
        return;
    } else {
        [[NSException exceptionWithName:@"AWSDKInvalidArgumentException"
                                 reason:[NSString stringWithFormat:@"Unexpected media type: %@. Can only check AVMediaTypeAudio and AVMediaTypeVideo", type]
                               userInfo:nil] raise];
    }
}

@end
