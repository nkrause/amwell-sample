//
//  TTTAttributedLabel+Additions.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 10/5/17.
//  Copyright © 2017 American Well. All rights reserved.
//

#import "TTTAttributedLabel.h"

#define HTTP_LINK @"href"

@interface TTTAttributedLabel (Additions)

- (void)mapHTMLLinksForString:(NSString *)htmlString withAttributes:(NSDictionary *)attributes;

@end
