//
//  UITableViewController+CollapsiblePicker.h
//  AWSDKSample
//
//  Created by Steven Uy on 5/26/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface UITableViewController (CollapsiblePicker)

- (void)toggleCell:(BOOL)shown atIndexPath:(NSIndexPath *)indexPath withLabel:(UILabel *)label;

@end
