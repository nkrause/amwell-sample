//
//  UIImage+.m
//  AWSDKSample
//
//  Created by Stephen Ciauri on 4/14/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "UIImage+Rendered.h"

@implementation UIImage (Rendered)

+ (UIImage *)renderedFromView:(UIView *)view withRect:(CGRect)frame {
    // Create a new context the size of the frame
    UIGraphicsBeginImageContextWithOptions(frame.size, YES, 0.0f);

    // Render the view
    [view drawViewHierarchyInRect:view.bounds afterScreenUpdates:YES];

    // Get the image from the context
    UIImage *renderedImage = UIGraphicsGetImageFromCurrentImageContext();

    // Cleanup the context you created
    UIGraphicsEndImageContext();

    return renderedImage;
}

@end
