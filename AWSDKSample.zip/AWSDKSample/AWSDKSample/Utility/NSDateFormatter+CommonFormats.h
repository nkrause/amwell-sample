//
//  NSDateFormatter+CommonFormats.h
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface NSDateFormatter (CommonFormats)

+ (NSDateFormatter *)ccDateFormatter;

+ (NSDateFormatter *)shortTimeFormatter;

+ (NSDateFormatter *)shortDateFormatter;

+ (NSDateFormatter *)mediumDateFormatter;

+ (NSDateFormatter *)longDateFormatter;

+ (NSDateFormatter *)longerDateFormatter;

+ (NSDateFormatter *)longerUTCDateFormatter;

+ (NSDateFormatter *)longDateTimeFormatter;

+ (NSDateFormatter *)longDateMonthDayTimeFormatter;

+ (NSDateFormatter *)longDateNoTimeZoneFormatter;

+ (NSDateFormatter *)longDateTimeWithTimezoneFormatter;

+ (NSDateFormatter *)longLocalDateTimeFormatter;

+ (NSDateFormatter *)shortLocalDateTimeFormatter;

+ (NSDateFormatter *)shortUTCTimeFormatter;

+ (NSDateFormatter *)ISO8601StringFormatter;

+ (NSDateFormatter *)ISO8601DateTimeFormatter;

@end
