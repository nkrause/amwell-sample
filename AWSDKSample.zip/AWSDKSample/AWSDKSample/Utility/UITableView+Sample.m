//
//  UITableView+Sample.m
//  AWSDKSample
//
//  Created by Steven Uy on 10/5/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "UITableView+Sample.h"

@implementation UITableView (Sample)

- (void)reloadDataAnimated:(BOOL)animated {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (animated) {
            [UIView transitionWithView:self
                              duration:0.1f
                               options:UIViewAnimationOptionTransitionCrossDissolve
                            animations:^(void) {
                                [self reloadData];
                            }
                            completion:nil];
        } else {
            [self reloadData];
        }
    });
}

@end
