//
//  UIColor+Additions.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 8/27/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "UIColor+Additions.h"

@implementation UIColor (Additions)

// Imported from Zeplin
+ (UIColor * _Nonnull)white18Color { 
    return [UIColor colorNamed:@"white18"];
}

+ (UIColor * _Nonnull)bkgdGreyColor { 
    return [UIColor colorNamed:@"bkgdGrey"];
}

+ (UIColor * _Nonnull)aquaColor { 
    return [UIColor colorNamed:@"aqua"];
}

+ (UIColor * _Nonnull)hintGreyColor { 
    return [UIColor colorNamed:@"hintGrey"];
}

+ (UIColor * _Nonnull)mediumGreyColor {
    return [UIColor colorNamed:@"mediumGrey"];
}

+ (UIColor * _Nonnull)darkGreyColor {
    return [UIColor colorNamed:@"darkGrey"];
}

+ (UIColor * _Nonnull)buttonOrangeColor { 
    return [UIColor colorNamed:@"buttonOrange"];
}

+ (UIColor * _Nonnull)linkBlueColor { 
    return [UIColor colorNamed:@"linkBlue"];
}

+ (UIColor * _Nonnull)blackColor { 
    return [UIColor colorNamed:@"black"];
}

+ (UIColor * _Nonnull)whiteColor { 
    return [UIColor colorNamed:@"white"];
}

+ (UIColor * _Nonnull)toggletxtTealColor { 
    return [UIColor colorNamed:@"toggletxtTeal"];
}

+ (UIColor * _Nonnull)redColor { 
    return [UIColor colorNamed:@"red"];
}

// Manually Added
+ (UIColor * _Nonnull)availabilityBusyColor {
    return [UIColor colorNamed:@"availabilityBusy"];
}

+ (UIColor * _Nonnull)availabilityOfflineColor {
    return [UIColor colorNamed:@"availabilityOffline"];
}

+ (UIColor * _Nonnull)gradientDarkOrangeColor {
    return [UIColor colorNamed:@"gradientDarkOrange"];
}

+ (UIColor * _Nonnull)gradientDarkWaitingRoomGreenColor {
    return [UIColor colorNamed:@"gradientDarkWaitingRoomGreen"];
}

+ (UIColor * _Nonnull)gradientDarkWaitingRoomOrangeColor {
    return [UIColor colorNamed:@"gradientDarkWaitingRoomOrange"];
}

+ (UIColor * _Nonnull)gradientLightOrangeColor {
    return [UIColor colorNamed:@"gradientLightOrange"];
}

+ (UIColor * _Nonnull)gradientLightWaitingRoomGreenColor {
    return [UIColor colorNamed:@"gradientLightWaitingRoomGreen"];
}

+ (UIColor * _Nonnull)gradientLightWaitingRoomOrangeColor {
    return [UIColor colorNamed:@"gradientLightWaitingRoomOrange"];
}

+ (UIColor * _Nonnull)lightGrayFadedUserIconColor {
    return [UIColor colorNamed:@"lightGrayFadedUserIcon"];
}

+ (UIColor * _Nonnull)lightGrayUserIconColor {
    return [UIColor colorNamed:@"lightGrayUserIcon"];
}

+ (UIColor * _Nonnull)mediumGreenColor {
    return [UIColor colorNamed:@"mediumGreen"];
}

+ (UIColor * _Nonnull)sampleDarkPurpleColor {
    return [UIColor colorNamed:@"sampleDarkPurple"];
}

+ (UIColor * _Nonnull)sampleMediumGrayColor {
    return [UIColor colorNamed:@"sampleMediumGray"];
}

+ (UIColor * _Nonnull)samplePurpleColor {
    return [UIColor colorNamed:@"samplePurple"];
}

+ (UIColor * _Nonnull)whiteFadedColor {
    return [UIColor colorNamed:@"whiteFaded"];
}

@end
