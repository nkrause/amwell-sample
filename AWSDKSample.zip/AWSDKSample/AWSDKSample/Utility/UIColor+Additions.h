//
//  UIColor+Additions.h
//  AWSDKSample
//
//  Created by Rolin Nelson on 8/27/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <UIKit/UIKit.h>

@interface UIColor (Additions)

+ (UIColor * _Nonnull)white18Color;
+ (UIColor * _Nonnull)bkgdGreyColor;
+ (UIColor * _Nonnull)aquaColor;
+ (UIColor * _Nonnull)hintGreyColor;
+ (UIColor * _Nonnull)mediumGreyColor;
+ (UIColor * _Nonnull)darkGreyColor;
+ (UIColor * _Nonnull)buttonOrangeColor;
+ (UIColor * _Nonnull)linkBlueColor;
+ (UIColor * _Nonnull)blackColor;
+ (UIColor * _Nonnull)whiteColor;
+ (UIColor * _Nonnull)toggletxtTealColor;
+ (UIColor * _Nonnull)redColor;

+ (UIColor * _Nonnull)availabilityBusyColor;
+ (UIColor * _Nonnull)availabilityOfflineColor;
+ (UIColor * _Nonnull)gradientDarkOrangeColor;
+ (UIColor * _Nonnull)gradientDarkWaitingRoomGreenColor;
+ (UIColor * _Nonnull)gradientDarkWaitingRoomOrangeColor;
+ (UIColor * _Nonnull)gradientLightOrangeColor;
+ (UIColor * _Nonnull)gradientLightWaitingRoomGreenColor;
+ (UIColor * _Nonnull)gradientLightWaitingRoomOrangeColor;
+ (UIColor * _Nonnull)lightGrayFadedUserIconColor;
+ (UIColor * _Nonnull)lightGrayUserIconColor;
+ (UIColor * _Nonnull)mediumGreenColor;
+ (UIColor * _Nonnull)sampleDarkPurpleColor;
+ (UIColor * _Nonnull)sampleMediumGrayColor;
+ (UIColor * _Nonnull)samplePurpleColor;
+ (UIColor * _Nonnull)whiteFadedColor;

@end
