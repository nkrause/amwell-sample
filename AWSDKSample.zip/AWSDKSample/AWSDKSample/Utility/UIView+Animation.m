//
//  UIView+Animation.m
//  AWSDKSample
//
//  Created by stephenciauri on 6/22/17.
//  Copyright © 2017 American Well. All rights reserved.
//

#import "UIView+Animation.h"

@implementation UIView (Animation)

+ (void)fadeViews:(NSArray<UIView *> *)viewsToFade
       withDuration:(NSTimeInterval)fadeDuration
    notVisibleBlock:(CompletionBlock)notVisibleBlock
         completion:(CompletionBlock)completion {
    dispatch_async(dispatch_get_main_queue(), ^{
        float duration = MAX(fadeDuration, 0) / 2;
        [UIView animateWithDuration:duration
            animations:^{
                for (UIView *view in viewsToFade) {
                    view.alpha = 0;
                }
            }
            completion:^(BOOL finished) {
                if (notVisibleBlock) {
                    notVisibleBlock();
                }
                [UIView animateWithDuration:duration
                    animations:^{
                        for (UIView *view in viewsToFade) {
                            view.alpha = 1;
                        }
                    }
                    completion:^(BOOL finished) {
                        if (completion) {
                            completion();
                        }
                    }];
            }];
    });
}

@end
