//
//  NSString+Formats.h
//  AWSDKSample
//
//  Created by Jeremiah.Possion on 1/24/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <Foundation/Foundation.h>

@interface NSString (Formats)

- (NSString *)phoneNumberFormat;

@end
