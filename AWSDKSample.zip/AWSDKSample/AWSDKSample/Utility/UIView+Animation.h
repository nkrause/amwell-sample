//
//  UIView+Animation.h
//  AWSDKSample
//
//  Created by stephenciauri on 6/22/17.
//  Copyright © 2017 American Well. All rights reserved.
//

#import <AWSDK/AWSDKCompletionBlock.h>
#import <UIKit/UIKit.h>

@interface UIView (Animation)

/**
 Fades the views to alpha 0 then to alpha 1

 @param viewsToFade The views to be faded
 @param fadeDuration The total duration of the fade animation. Each fade direction will take fadeDuration/2 seconds to complete.
 @param notVisibleBlock The bock to execute when the alpha of the views is 0
 @param completion The block to execute when the alpha of the views has returned to 1
 */
+ (void)fadeViews:(nonnull NSArray<UIView *> *)viewsToFade
       withDuration:(NSTimeInterval)fadeDuration
    notVisibleBlock:(nullable CompletionBlock)notVisibleBlock
         completion:(nullable CompletionBlock)completion;

@end
