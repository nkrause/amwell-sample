//
//  NSString+Sample.h
//  AWSDKSample
//
//  Created by Steven Uy on 8/5/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface NSString (Sample)

#pragma mark - MD5 Hash
/**
 Converts an NSString to an MD5 hash of the string

 @param input nonnill NSString

 @return MD5 hash of the string
 */
+ (NSString *)md5HexDigest:(NSString *)input;

#pragma mark - Comparison Methods
/**
 Checks if string is not nil and isn't empty

 @return True if not nil and isn't empty, false otherwise
 */
- (BOOL)isPopulated;

#pragma mark - Conversion Methods
/**
 Returns the sentence case of a string

 @return NSString as a sentence cases
 */
- (NSString *)sentenceCase;

@end
