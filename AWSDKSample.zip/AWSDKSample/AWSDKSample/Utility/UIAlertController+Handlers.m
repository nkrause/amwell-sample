//
//  UIAlertController+Handlers.m
//  AWSDKSample
//
//  Created by Steven Uy on 4/11/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "UIAlertController+Handlers.h"
#import "UIViewController+Handlers.h"

#import <AWSDK/AWSDKErrorCode.h>
#import <AWSDK/AWSDKErrorKeys.h>

@implementation UIAlertController (Handlers)

+ (UIAlertController *)alertControllerWithError:(NSError *)error {
    NSString *errorKey = error.code ? [@(error.code) stringValue] : @"unknown";
    NSString *message = error.userInfo[NSLocalizedFailureReasonErrorKey];
    if (!message || [message isEqualToString:@""]) {
        message = error.localizedFailureReason ? error.localizedFailureReason : error.localizedDescription;
    }
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"alert.error", @"Alert Error Title") message:message];

    // NOTE: (NSError).localizedDescription is not client facing!
    //       Please create a list of client facing error messages to pair with the associated
    //       error code and developer error messagess.
    NSLog(@"Error: #%@: %@", errorKey, error);
    return alert;
}

+ (UIAlertController *)alertControllerWithError:(NSError *)error okHandler:(void (^__nullable)(UIAlertAction *action))handler {
    UIAlertController *alertController = [UIAlertController alertControllerWithError:error];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.ok", @"Alert Okay Title") style:UIAlertActionStyleDefault handler:[alertController defaultAlertHandler:handler]];
    [alertController addAction:ok];

    return alertController;
}

+ (UIAlertController *)alertControllerWithTitleKey:(NSString *)key {
    return [UIAlertController alertControllerWithTitle:NSLocalizedString(key, @"Generic Alert Title") message:nil preferredStyle:UIAlertControllerStyleAlert];
}

+ (UIAlertController *)alertControllerWithMessageKey:(NSString *)key {
    NSMutableArray *keyParts = [NSMutableArray arrayWithArray:[key componentsSeparatedByString:@"."]];
    [keyParts removeLastObject];
    NSString *baseKey = [keyParts componentsJoinedByString:@"."];
    NSString *titleKey = [NSString stringWithFormat:@"%@.%@", baseKey, @"title"];
    NSString *title = [NSLocalizedString(titleKey, @"Alert Title") isEqualToString:titleKey] ? nil : NSLocalizedString(titleKey, @"Alert Title");
    NSString *message = [NSLocalizedString(key, @"Alert Message") isEqualToString:key] ? nil : NSLocalizedString(key, @"Alert Message");

    return [UIAlertController alertControllerWithTitle:title message:message];
}

+ (UIAlertController *)alertControllerWithMessage:(NSString *)message okHandler:(void (^)(UIAlertAction *action))handler {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"alert.error", @"Alert Error Message") message:message];
    UIAlertAction *action = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.ok", @"Alert Okay Title") style:UIAlertActionStyleDefault handler:[alert defaultAlertHandler:handler]];
    [alert addAction:action];
    return alert;
}

+ (UIAlertController *)alertControllerWithMessageKey:(NSString *)key okHandler:(void (^)(UIAlertAction *action))handler {
    UIAlertController *alertController = [UIAlertController alertControllerWithMessageKey:key];

    UIAlertAction *ok = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.ok", @"Alert Okay Title") style:UIAlertActionStyleDefault handler:[alertController defaultAlertHandler:handler]];

    [alertController addAction:ok];

    return alertController;
}

+ (UIAlertController *)alertControllerWithMessageKey:(NSString *)key yesHandler:(void (^)(UIAlertAction *))handler {
    return [UIAlertController alertControllerWithMessageKey:key yesHandler:handler noHandler:nil];
}

+ (UIAlertController *)alertControllerWithMessageKey:(NSString *)key yesHandler:(void (^)(UIAlertAction *))yesHandler noHandler:(void (^)(UIAlertAction *))noHandler {
    UIAlertController *alertController = [UIAlertController alertControllerWithMessageKey:key];

    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.no", @"Alert Okay Title")
                                                        style:UIAlertActionStyleDefault
                                                      handler:[alertController defaultAlertHandler:noHandler]]];

    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.yes", @"Alert Yes Title")
                                                        style:UIAlertActionStyleDestructive
                                                      handler:[alertController defaultAlertHandler:yesHandler]]];
    return alertController;
}

+ (UIAlertController *)alertControllerWithMessageKey:(NSString *)key goBackHandler:(void (^)(UIAlertAction *))goBackHandler closeHandler:(void (^)(UIAlertAction *))closeHandler {
    UIAlertController *alertController = [UIAlertController alertControllerWithMessageKey:key];
    
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.goBack", @"Alert go back Title")
                                                        style:UIAlertActionStyleDefault
                                                      handler:[alertController defaultAlertHandler:goBackHandler]]];
    
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"misc.close", @"Alert Close Title")
                                                        style:UIAlertActionStyleDefault
                                                      handler:[alertController defaultAlertHandler:closeHandler]]];
    
    return alertController;
}

+ (UIAlertController *)alertControllerWithTitle:(NSString *)title message:(NSString *)message {
    return [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
}

+ (UIAlertController *)alertControllerWithTitle:(NSString *)title message:(NSString *)message okHandler:(void (^)(UIAlertAction *))handler {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:NSLocalizedString(@"misc.ok", @"Alert Okay Title") style:UIAlertActionStyleDefault handler:[alertController defaultAlertHandler:handler]];
    [alertController addAction:ok];

    return alertController;
}

@end
