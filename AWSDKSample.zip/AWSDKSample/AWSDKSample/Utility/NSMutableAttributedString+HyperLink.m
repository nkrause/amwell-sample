//
//  NSMutableAttributedString+HyperLink.m
//  AWSDKSample
//
//  Created by Roey Honig on 08/30/2020.
//  Copyright © 2020 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//


#import "NSMutableAttributedString+HyperLink.h"

@implementation NSMutableAttributedString (HyperLink)

- (void)set:(NSString *)subString asLinkURL:(NSString *)linkURL {
    NSRange foundRange = [self.mutableString rangeOfString:subString];
    if (foundRange.location != NSNotFound) {
        [self addAttribute:NSLinkAttributeName value:linkURL range:foundRange];
    }
}

@end
