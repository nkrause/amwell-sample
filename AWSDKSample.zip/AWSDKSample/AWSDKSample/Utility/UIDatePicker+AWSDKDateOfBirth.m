//
//  UIDatePicker+AWSDKDate.m
//  AWSDKSample
//
//  Created by steven.uy on 4/7/16.
//  Copyright © 2016 American Well. All rights reserved.
//

#import "NSDateFormatter+CommonFormats.h"
#import "UIDatePicker+AWSDKDate.h"

#import <AWSDK/AWSDKDate.h>

@implementation UIDatePicker (AWSDKDate)

- (AWSDKDateOfBirth *)selectedDateOfBirth {
    NSDateComponents *date = [[NSCalendar currentCalendar] components:NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear fromDate:self.date];
    return [AWSDKDate dateWithYear:[date year] monthIndex:[date month] dayOfMonth:[date day]];
}

- (void)setDate:(AWSDKDate *)date {
    NSDate *doB = [[NSDateFormatter ISO8601StringFormatter] dateFromString:[date toISO8601String]];
    [self setDate:doB];
}

@end
