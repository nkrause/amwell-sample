//
//  NSString+Validation.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 4/10/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "NSString+Validation.h"

@implementation NSString (Validation)

- (BOOL)isValidEmailAddress {
    if (self.length) {
        NSDataDetector *emailDataDetector = [[NSDataDetector alloc] initWithTypes:NSTextCheckingTypeLink error:nil];
        NSArray<NSTextCheckingResult *> *matches = [emailDataDetector matchesInString:self options:0 range:NSMakeRange(0, self.length)];
        for (NSTextCheckingResult *matchedLink in matches) {
            // Validates link is an email address and that it's the only contents of the string (no leading/trailing/newline whitespace)
            if ([matchedLink.URL.scheme isEqualToString:@"mailto"] && matchedLink.range.location == 0 && matchedLink.range.length == self.length) {
                return YES;
            }
        }
    }
    return NO;
}

@end
