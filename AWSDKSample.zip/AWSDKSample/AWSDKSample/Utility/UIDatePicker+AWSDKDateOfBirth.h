//
//  UIDatePicker+AWSDKDateOfBirth.h
//  AWSDKSample
//
//  Created by steven.uy on 4/7/16.
//  Copyright © 2016 American Well. All rights reserved.
//

@class AWSDKDate;

@interface UIDatePicker (AWSDKDate)

/**
 *  Returns an AWSDKDateOfBirth based upon a UIDatePicker
 *
 *  @return AWSDKDateOfBirth object
 */
- (AWSDKDate *)selectedDate;

- (void)setDateOfBirth:(AWSDKDate *)date;

@end
