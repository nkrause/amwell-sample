//
//  UITableViewController+CollapsiblePicker.m
//  AWSDKSample
//
//  Created by Steven Uy on 5/26/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "UITableViewController+CollapsiblePicker.h"

@implementation UITableViewController (CollapsiblePicker)

- (void)toggleCell:(BOOL)shown atIndexPath:(NSIndexPath *)indexPath withLabel:(UILabel *)label {
    NSArray *paths = @[ indexPath ];
    if (shown)
        [self.tableView insertRowsAtIndexPaths:paths withRowAnimation:UITableViewRowAnimationFade];
    else
        [self.tableView deleteRowsAtIndexPaths:paths withRowAnimation:UITableViewRowAnimationFade];
    if (label) {
        [UIView transitionWithView:label
                          duration:0.2
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^(void) {
                            [label setTextColor:(shown ? [UIColor toggletxtTealColor] : [UIColor darkTextColor])];
                        }
                        completion:nil];
    }
}
@end
