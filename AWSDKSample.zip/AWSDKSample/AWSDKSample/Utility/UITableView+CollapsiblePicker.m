//
//  UITableView+CollapsiblePicker.m
//  AWSDKSample
//
//  Created by steven.uy on 5/18/16.
//  Copyright © 2016 American Well. All rights reserved.
//

#import "UITableView+CollapsiblePicker.h"

@implementation UITableView (CollapsiblePicker)

- (void)showStatusPickerCell:(UIView *)picker {
    [self beginUpdates];
    [self endUpdates];
    [picker setHidden:NO];
    [picker setAlpha:0.0f];
    [UIView animateWithDuration:0.25
                     animations:^{
                         [picker setAlpha:1.0f];
                     }];
}

- (void)hideStatusPickerCell:(UIView *)picker {
    [self beginUpdates];
    [self endUpdates];
    [UIView animateWithDuration:0.25
        animations:^{
            [picker setAlpha:0.0f];
        }
        completion:^(BOOL finished) {
            [picker setHidden:YES];
        }];
}

@end
