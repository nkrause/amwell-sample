//
//  NSDateFormatter+CommonFormats.m
//  AWSDKSample
//
//  Created by Calvin Chestnut on 3/8/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "NSDateFormatter+CommonFormats.h"

static NSDateFormatter *ccDateFormatter;
static NSDateFormatter *shortTimeFormatter;
static NSDateFormatter *shortDateFormatter;
static NSDateFormatter *mediumDateFormatter;
static NSDateFormatter *longDateFormatter;
static NSDateFormatter *longerDateFormatter;
static NSDateFormatter *longerUTCDateFormatter;
static NSDateFormatter *longDateTimeFormatter;
static NSDateFormatter *longDateMonthDayTimeFormatter;
static NSDateFormatter *longDateNoTimeZoneFormatter;
static NSDateFormatter *longDateTimeWithTimezoneFormatter;
static NSDateFormatter *longLocalDateTimeFormatter;
static NSDateFormatter *shortLocalDateTimeFormatter;
static NSDateFormatter *ISO8601StringFormatter;
static NSDateFormatter *ISO8601DateTimeFormatter;

@implementation NSDateFormatter (CommonFormats)

+ (NSDateFormatter *)ccDateFormatter {
    // Example: en_US: 10/2017 | en_FR: 10/2017
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        ccDateFormatter = [[NSDateFormatter alloc] init];
        [ccDateFormatter setLocalizedDateFormatFromTemplate:@"MM/yyyy"];
    });
    return ccDateFormatter;
}

+ (NSDateFormatter *)shortTimeFormatter {
    // Example: en_US: 5:26 pm | en_FR: 17:26
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shortTimeFormatter = [[NSDateFormatter alloc] init];
        shortTimeFormatter.dateStyle = NSDateFormatterNoStyle;
        shortTimeFormatter.timeStyle = NSDateFormatterShortStyle;
    });
    return shortTimeFormatter;
}

+ (NSDateFormatter *)shortDateFormatter {
    // Example: en_US: 10/31/17 | en_FR: 31/10/17
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shortDateFormatter = [[NSDateFormatter alloc] init];
        shortDateFormatter.dateStyle = NSDateFormatterShortStyle;
        shortDateFormatter.timeStyle = NSDateFormatterNoStyle;
    });
    return shortDateFormatter;
}

+ (NSDateFormatter *)mediumDateFormatter {
    // Example: en_US: Oct 31, 2017 | en_FR: 31 Oct 2017
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        mediumDateFormatter = [[NSDateFormatter alloc] init];
        mediumDateFormatter.dateStyle = NSDateFormatterMediumStyle;
        mediumDateFormatter.timeStyle = NSDateFormatterNoStyle;
    });
    return mediumDateFormatter;
}

+ (NSDateFormatter *)longDateFormatter {
    // Example: en_US: Tue, Oct 31, 2017 | en_FR: Tue, 31 Oct 2017
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        longDateFormatter = [[NSDateFormatter alloc] init];
        [longDateFormatter setLocalizedDateFormatFromTemplate:@"EEE, MMM d, yyyy"];
    });
    return longDateFormatter;
}

+ (NSDateFormatter *)longerDateFormatter {
    // Example: en_US: October 31, 2017 | en_FR: 31 October 2017
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        longerDateFormatter = [[NSDateFormatter alloc] init];
        [longerDateFormatter setLocalizedDateFormatFromTemplate:@"MMMM d, yyyy"];
    });
    return longerDateFormatter;
}

+ (NSDateFormatter *)longerUTCDateFormatter {
    // Example: en_US: October 31, 2017 | en_FR: 31 October 2017
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        longerUTCDateFormatter = [[NSDateFormatter alloc] init];
        longerUTCDateFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        [longerUTCDateFormatter setLocalizedDateFormatFromTemplate:@"MMMM d, yyyy"];
    });
    return longerUTCDateFormatter;
}

+ (NSDateFormatter *)longDateTimeFormatter {
    // Example: en_US: Tue, October 31, 2017, 5:36 PM | en_FR: Tue 31 October 2017 17:26
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        longDateTimeFormatter = [[NSDateFormatter alloc] init];
        [longDateTimeFormatter setLocalizedDateFormatFromTemplate:@"EEE, MMMM d, yyyy, j:mm a"];
    });
    return longDateTimeFormatter;
}

+ (NSDateFormatter *)longDateMonthDayTimeFormatter {
    // Example: en_US: Oct 31, 2017, 5:36 PM EDT | en_FR: 31 Oct 2017 17:26 GMT-4
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        longDateMonthDayTimeFormatter = [[NSDateFormatter alloc] init];
        [longDateMonthDayTimeFormatter setLocalizedDateFormatFromTemplate:@"MMM d, yyyy, j:mm a z"];
    });
    return longDateMonthDayTimeFormatter;
}

+ (NSDateFormatter *)longDateNoTimeZoneFormatter {
    // Example: en_US: Oct 31, 2017, 5:36 PM | en_FR: 31 Oct 2017 17:26
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        longDateNoTimeZoneFormatter = [[NSDateFormatter alloc] init];
        [longDateNoTimeZoneFormatter setLocalizedDateFormatFromTemplate:@"MMM d, yyyy, j:mm a"];
    });
    return longDateNoTimeZoneFormatter;
}

+ (NSDateFormatter *)longDateTimeWithTimezoneFormatter {
    // Example: en_US: Tue, Oct 31, 2017, 5:36 PM EDT | en_FR: Tue, 31 Oct 2017 17:26 GMT-4
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        longDateTimeWithTimezoneFormatter = [[NSDateFormatter alloc] init];
        [longDateTimeWithTimezoneFormatter setLocalizedDateFormatFromTemplate:@"EEE, MMM d, yyyy, j:mm a z"];
    });
    return longDateTimeWithTimezoneFormatter;
}

+ (NSDateFormatter *)longLocalDateTimeFormatter {
    // Example: en_US: 10/31/2017, 5:36 PM | en_FR: 31/10/2017 17:26
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        longLocalDateTimeFormatter = [[NSDateFormatter alloc] init];
        [longLocalDateTimeFormatter setTimeZone:[NSTimeZone localTimeZone]];
        [longLocalDateTimeFormatter setLocalizedDateFormatFromTemplate:@"MM/dd/yyyy j:mm a"];
    });
    return longLocalDateTimeFormatter;
}

+ (NSDateFormatter *)shortLocalDateTimeFormatter {
    // Example: en_US: 10/31, 5:36 PM | en_FR: 31/10 17:26
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shortLocalDateTimeFormatter = [[NSDateFormatter alloc] init];
        [shortLocalDateTimeFormatter setTimeZone:[NSTimeZone localTimeZone]];
        [shortLocalDateTimeFormatter setLocalizedDateFormatFromTemplate:@"MM/dd j:mm a"];
    });
    return shortLocalDateTimeFormatter;
}

+ (NSDateFormatter *)shortUTCTimeFormatter {
    // Example: en_US: 5:36 PM GMT-4 | en_FR: 17:26 GMT-0
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shortLocalDateTimeFormatter = [[NSDateFormatter alloc] init];
        shortLocalDateTimeFormatter.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        shortLocalDateTimeFormatter.localizedDateFormatFromTemplate = @"j:mm a z";
    });
    return shortLocalDateTimeFormatter;
}

+ (NSDateFormatter *)ISO8601StringFormatter {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        ISO8601StringFormatter = [[NSDateFormatter alloc] init];
        [ISO8601StringFormatter setTimeZone:[NSTimeZone localTimeZone]];
        [ISO8601StringFormatter setDateFormat:@"yyyy-MM-dd"];
    });
    return ISO8601StringFormatter;
}

+ (NSDateFormatter *)ISO8601DateTimeFormatter {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        ISO8601DateTimeFormatter = [[NSDateFormatter alloc] init];
        [ISO8601DateTimeFormatter setTimeZone:[NSTimeZone localTimeZone]];
        [ISO8601DateTimeFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"];
    });
    return ISO8601DateTimeFormatter;
}

@end
