//
//  UITableView+CollapsiblePicker.h
//  AWSDKSample
//
//  Created by steven.uy on 5/18/16.
//  Copyright © 2016 American Well. All rights reserved.
//

@interface UITableView (CollapsiblePicker)

- (void)showStatusPickerCell:(UIView *)picker;
- (void)hideStatusPickerCell:(UIView *)picker;

@end
