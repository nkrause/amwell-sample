//
//  UIApplication+AVAuthorization.h
//  AWSDKSample
//
//  Created by Stephen Ciauri on 6/22/17.
//  Copyright © 2017 American Well. All rights reserved.
//

#import <AWSDK/AWSDKCompletionBlock.h>
#import <UIKit/UIKit.h>

@interface UIApplication (AVAuthorization)
- (BOOL)cameraAuthorized;
- (BOOL)microphoneAuthorized;
- (void)requestCameraAuthorizationWithCompletion:(SuccessCompletionBlock)completion;
- (void)requestMicrophoneAuthorizationWithCompletion:(SuccessCompletionBlock)completion;
@end
