//
//  NSPersonNameComponents+Localizing.h
//  AWSDKSample
//
//  Created by Stephen Ciauri on 8/20/18.
//  Copyright © 2018 American Well. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSPersonNameComponents (Localizing)
@property (readonly, nonnull) NSString *localizedFullName;
@end
