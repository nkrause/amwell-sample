//
//  TTTAttributedLabel+Additions.m
//  AWSDKSample
//
//  Created by Rolin Nelson on 10/5/17.
//  Copyright © 2017 American Well. All rights reserved.
//

#import "TTTAttributedLabel+Additions.h"

@implementation TTTAttributedLabel (Additions)

- (void)mapHTMLLinksForString:(NSString *)htmlString withAttributes:(NSDictionary *)attributes {
    NSError *error = NULL;

    // Regular expression to match text before href link and href link
    NSRegularExpression *outerRegex = [NSRegularExpression regularExpressionWithPattern:@"([-,\\?\\.\\s\\w.]+)(<a href=\"[-/\\w:\\.]+\">[-,\\?\\.\\s\\w.]+</a>)?"
                                                                                options:NSRegularExpressionCaseInsensitive
                                                                                  error:&error];
    // Regular expression to match href link and link display text
    __block NSRegularExpression *innerRegex = [NSRegularExpression regularExpressionWithPattern:@"<a href=\"([-/\\w:\\.]+)\">([-,\\?\\.\\s\\w.]+)</a>"
                                                                                        options:NSRegularExpressionCaseInsensitive
                                                                                          error:&error];

    __block NSMutableString *strippedLinks = [NSMutableString new];
    __block NSMutableArray *links = [NSMutableArray new];
    [outerRegex enumerateMatchesInString:htmlString
                                 options:0
                                   range:NSMakeRange(0, [htmlString length])
                              usingBlock:^(NSTextCheckingResult *match, NSMatchingFlags flags, BOOL *stop) {
                                  NSRange matchRange = [match range];
                                  NSRange beforeUrlRange = [match rangeAtIndex:1];

                                  NSString *beforeUrlRangeString = [htmlString substringWithRange:beforeUrlRange];
                                  [strippedLinks appendString:beforeUrlRangeString];
                                  NSString *urlRangeString = [htmlString substringWithRange:matchRange];

                                  // Enumerate thru link and display text
                                  [innerRegex
                                      enumerateMatchesInString:urlRangeString
                                                       options:0
                                                         range:NSMakeRange(0, [urlRangeString length])
                                                    usingBlock:^(NSTextCheckingResult *match, NSMatchingFlags flags, BOOL *stop) {
                                                        NSRange matchRange = [match range];
                                                        NSRange urlRange = [match rangeAtIndex:1];
                                                        NSRange clickTextRange = [match rangeAtIndex:2];

                                                        NSString *rangeString = [urlRangeString substringWithRange:matchRange];
                                                        NSString *modifiedString = [innerRegex stringByReplacingMatchesInString:rangeString
                                                                                                                        options:0
                                                                                                                          range:NSMakeRange(0, [rangeString length])
                                                                                                                   withTemplate:@"$2"];

                                                        // Concatenate display text to string; the display text will be tagged later
                                                        [strippedLinks appendString:modifiedString];
                                                        // Save display text and url for tagging with TTTAttributedLabel
                                                        [links addObject:@{ @"click" : [urlRangeString substringWithRange:clickTextRange], @"url" : [urlRangeString substringWithRange:urlRange] }];
                                                    }];
                              }];

    self.text = [[NSAttributedString alloc] initWithString:strippedLinks attributes:attributes];

    // Enumerate thru links and tag with TTTAttributedLabel
    [links enumerateObjectsUsingBlock:^(id _Nonnull obj, NSUInteger idx, BOOL *_Nonnull stop) {
        NSDictionary *dict = obj;
        NSRange range = [strippedLinks rangeOfString:dict[@"click"]];
        [self addLinkToURL:[NSURL URLWithString:dict[@"url"]] withRange:range];
    }];
}

@end
