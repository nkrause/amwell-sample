//
//  UIViewController+Handlers.m
//  AWSDKSample
//
//  Created by Steven Uy on 3/21/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AppDelegate.h"
#import "UIViewController+Handlers.h"

@implementation UIViewController (Handlers)

// presentAlertWithError
- (UIAlertController *)presentAlertWithError:(NSError *)error okHandler:(void (^)(UIAlertAction *action))handler {
    return [[UIViewController topMostAlertVC] presentAlertController:[UIAlertController alertControllerWithError:error okHandler:handler]];
}

- (UIAlertController *)presentAlertWithError:(NSError *)error {
    return [[UIViewController topMostAlertVC] presentAlertWithError:error okHandler:nil];
}

// presentAlertWithMessageKey
- (UIAlertController *)presentAlertWithMessageKey:(NSString *)key okHandler:(void (^)(UIAlertAction *action))handler {
    return [[UIViewController topMostAlertVC] presentAlertController:[UIAlertController alertControllerWithMessageKey:key okHandler:handler]];
}

- (UIAlertController *)presentAlertWithMessageKey:(NSString *)key {
    return [[UIViewController topMostAlertVC] presentAlertWithMessageKey:key okHandler:nil];
}

// presentAlertWithTitleKey
- (UIAlertController *)presentAlertWithTitleKey:(NSString *)key {
    return [[UIViewController topMostAlertVC] presentAlertWithTitleKey:key okHandler:nil];
}

- (UIAlertController *)presentAlertWithTitleKey:(NSString *)key okHandler:(void (^)(UIAlertAction *action))handler {
    return [[UIViewController topMostAlertVC] presentAlertWithTitle:NSLocalizedString(key, @"Generic Alert Title") message:nil okHandler:handler];
}

// presentAlertWithMessageKey
- (UIAlertController *)presentAlertWithMessageKey:(NSString *)key yesHandler:(void (^)(UIAlertAction *))handler {
    return [[UIViewController topMostAlertVC] presentAlertController:[UIAlertController alertControllerWithMessageKey:key yesHandler:handler]];
}

- (UIAlertController *)presentAlertWithMessageKey:(NSString *)key yesHandler:(void (^)(UIAlertAction *))yesHandler noHandler:(void (^)(UIAlertAction *))noHandler {
    return [[UIViewController topMostAlertVC] presentAlertController:[UIAlertController alertControllerWithMessageKey:key yesHandler:yesHandler noHandler:noHandler]];
}

- (UIAlertController *)presentAlertWithMessageKey:(NSString *)key goBackHandler:(void (^)(UIAlertAction *))goBackHandler closeHandler:(void (^)(UIAlertAction *))closeHandler {
    return [[UIViewController topMostAlertVC] presentAlertController:[UIAlertController alertControllerWithMessageKey:key goBackHandler:goBackHandler closeHandler:closeHandler]];
}

// presentAlertWithTitle
- (UIAlertController *)presentAlertWithTitle:(NSString *)title message:(NSString *)message okHandler:(void (^)(UIAlertAction *action))handler {
    return [[UIViewController topMostAlertVC] presentAlertController:[UIAlertController alertControllerWithTitle:title message:message okHandler:handler]];
}

- (UIAlertController *)presentAlertWithTitle:(NSString *)title message:(NSString *)message {
    return [[UIViewController topMostAlertVC] presentAlertWithTitle:(NSString *)title message:(NSString *)message okHandler:nil];
}

- (UIAlertController *)presentAlertController:(UIAlertController *)alertController {
    return [[UIViewController topMostAlertVC] presentAlertController:alertController removeOnBackground:YES];
}

- (UIAlertController *)presentAlertController:(UIAlertController *)alertController removeOnBackground:(BOOL)shouldRemoveOnBackground {
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hide];
        [MBProgressHUD hideHUDForView:self.view];
        UIWindow *alertWindow = [UIViewController alertWindow];
        [alertWindow makeKeyAndVisible];
        [[UIViewController topMostAlertVC] presentViewController:alertController
                                                        animated:YES
                                                      completion:^{
                                                          if (shouldRemoveOnBackground) {
                                                              [[NSNotificationCenter defaultCenter] addObserver:self
                                                                                                       selector:@selector(removeAlertsOnBackground:)
                                                                                                           name:UIApplicationDidEnterBackgroundNotification
                                                                                                         object:nil];
                                                          }
                                                      }];
    });
    return alertController;
}

- (void)removeAlertsWithDismiss:(BOOL)shouldDismiss completion:(SuccessCompletionBlock)completion {
    UIWindow *alertWindow = [UIViewController alertWindow];
    [alertWindow.rootViewController.view setAlpha:0.0];
    if (shouldDismiss) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    ((AppDelegate *)UIApplication.sharedApplication.delegate).alertWindow = nil;
    UIWindow *mainWindow = ((AppDelegate *)UIApplication.sharedApplication.delegate).window;
    [mainWindow makeKeyAndVisible];
    if (completion) {
        completion(YES);
    }
}

- (UIAlertDefaultHandlerBlock)defaultAlertHandler:(UIAlertDefaultHandlerBlock)handler {
    return ^(UIAlertAction *action) {
        [self removeAlertsWithDismiss:NO
                               completion:^(BOOL success) {
                                   if (handler) {
                                       handler(action);
                                   }
                               }];
    };
}

#pragma mark - Notification Handlers
- (void)removeAlertsOnBackground:(NSNotification *)notification {
    [self dismissViewControllerAnimated:YES
                             completion:^{
                                 [self removeAlertsWithDismiss:NO completion:nil];
                             }];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidEnterBackgroundNotification object:nil];
}

- (BOOL)isPresentingAlert {
    UIWindow *alertWindow = ((AppDelegate *)[UIApplication sharedApplication].delegate).alertWindow;
    return alertWindow.rootViewController != nil;
}

#pragma mark - Keyboard handlers
- (void)dismissKeyboard {
    [self.view resignFirstResponder];
    [self.view endEditing:YES];
}

#pragma mark - UIViewController Helpers
+ (UIViewController *)topMostMainVC {
    UIWindow *mainWindow = ((AppDelegate *)UIApplication.sharedApplication.delegate).window;
    return [UIViewController topMostController:mainWindow];
}

// Root view controller for the alert screen
+ (UIViewController *)topMostAlertVC {
    return [UIViewController topMostController:[self alertWindow]];
}

+ (UIWindow *)alertWindow {
    UIWindow *alertWindow = ((AppDelegate *)UIApplication.sharedApplication.delegate).alertWindow;
    if (!alertWindow) {
        alertWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        [alertWindow setWindowLevel:UIWindowLevelAlert];

        UIViewController *alertViewController = [[UIStoryboard storyboardWithName:@"LaunchScreen" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"blankScreen"];
        alertViewController.modalPresentationStyle = UIModalPresentationOverFullScreen;
        alertViewController.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [alertWindow setRootViewController:alertViewController];

        ((AppDelegate *)UIApplication.sharedApplication.delegate).alertWindow = alertWindow;
    }
    return ((AppDelegate *)UIApplication.sharedApplication.delegate).alertWindow;
}

+ (UIViewController *)topMostController:(UIWindow *)window {
    UIViewController *topController = window.rootViewController;
    while (topController.presentedViewController) {
        topController = topController.presentedViewController;
        if ([topController isKindOfClass:[UINavigationController class]]) {
            topController = [(UINavigationController *)topController viewControllers].firstObject;
        }
    }
    return topController;
}

+ (UIViewController *)topController {
    UIViewController *topController = [UIViewController topMostMainVC];
    if ([topController isKindOfClass:[UINavigationController class]]) {
        topController = topController.childViewControllers.firstObject;
    }
    return topController;
}

@end
