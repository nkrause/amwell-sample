//
//  UITextField+Compare.m
//  AWSDKSample
//
//  Created by Steven Uy on 4/27/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "NSString+Sample.h"
#import "UITextField+Compare.h"

@implementation UITextField (Compare)

- (BOOL)isPopulated {
    return [self.text isPopulated];
}

@end
