//
//  UILabel+Size.h
//  AWSDKSample
//
//  Created by Jeremiah.Possion on 3/13/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <Foundation/Foundation.h>

@interface UILabel (Size)

/**
 Returns the height for a label based on it's current frames width.

 @note Use this method when you are updating constraints after the view has already loaded
       and the labels width has been establised.
 */
- (CGFloat)heightForLabel;

/**
 Returns the height for a label based on it's current frames width minus an offset.

 @note Use this method if you need to provide an additional offset to give the label
 more height. This may be needed if you add more padding to the right or left of
 the label.

 @param offset The offset you want to give the labels current width.
 */
- (CGFloat)heightForLabelWithOffset:(CGFloat)offset;

/**
 Returns the height for a label based on the CGSize passed into the method.

 @note Use this method if you need to determine the height of the label before it's width has
 been established. For example in viewDidLoad: or viewWillAppear:.

 @param size The size you want to constrain the label to.
 */
- (CGFloat)heightForLabelWithSize:(CGSize)size;

@end
