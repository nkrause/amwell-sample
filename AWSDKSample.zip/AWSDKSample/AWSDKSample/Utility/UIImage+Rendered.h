//
//  UIImage+.h
//  AWSDKSample
//
//  Created by Stephen Ciauri on 4/14/17.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <Foundation/Foundation.h>

@interface UIImage (Rendered)

/**
 Renders a view into a UIImage

 @param view The view you would like to be rendered into a UIImage
 @param size The size of the desired UIImage
 @return A rendered UIImage representation of the given UIView
 */
+ (UIImage *)renderedFromView:(UIView *)view withRect:(CGRect)size;

@end
