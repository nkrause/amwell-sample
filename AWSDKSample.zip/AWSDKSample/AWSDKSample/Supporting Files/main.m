//
//  main.m
//  AWSDKSample
//
//  Created by Steven Uy on 2/12/16.
//  Copyright © 2017 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AppDelegate.h"

void setupLocalization(void);
void removeLocalization(void);

int main(int argc, char *argv[])
{
    @autoreleasepool {
        // When returning the app to foreground its possible to have a socket mismatch signal force close the app.
        // To ignore and handle the SIGPIPE signal globally, signal() is added. To debug a specific case, remove this statement and use the debugger.
        signal(SIGPIPE, SIG_IGN);
        setupLocalization();
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

// Allow localization to reset to a new language after an app restart.
// This occurs only if the "app_locale_override" NSUserDefault is set.
// The exit doesn't actually exit to the Home screen, it restarts the app.
void setupLocalization()
{
    // The currently overriden locale
    NSString *localeOverriden = [NSUserDefaults.standardUserDefaults objectForKey:APP_LOCALE_OVERRIDDEN];
    // The new locale to setup
    NSString *localeIdentifier = [NSUserDefaults.standardUserDefaults objectForKey:APP_LOCALE_OVERRIDE];
    AWSDKLogInfo(@"localeOverriden =>%@<", localeOverriden);
    AWSDKLogInfo(@"localeIdentifier =>%@<", localeIdentifier);

    // Were removing application locale override
    if (!localeIdentifier && localeOverriden) {
        removeLocalization();
        AWSDKLogInfo(@"RESTARTING Device.");
        exit(0); // Restart
    } else if (localeIdentifier && ![localeIdentifier isEqualToString:localeOverriden]) {
        AWSDKLogInfo(@"Setting up localization %@.", localeOverriden);
        NSLocale *locale = [NSLocale localeWithLocaleIdentifier:localeIdentifier];
        NSString *appleLanguage = [NSString stringWithFormat:@"%@-%@", locale.languageCode, locale.countryCode];

        // Insert new locale
        NSMutableArray<NSString *> *arr = [[[NSUserDefaults standardUserDefaults] objectForKey:APP_APPLE_LANGUAGES] mutableCopy];
        NSUInteger loc = [arr indexOfObject:appleLanguage];
        // Remove if already in the list
        if (loc != NSNotFound) {
            [arr removeObjectAtIndex:loc];
            [NSUserDefaults.standardUserDefaults setObject:[NSNumber numberWithInteger:loc] forKey:APP_LOCALE_RESTORE_POS];
        }
        // Insert at first position
        [arr insertObject:appleLanguage atIndex:0];
        [NSUserDefaults.standardUserDefaults setObject:localeIdentifier forKey:APP_LOCALE_OVERRIDDEN];

        // Update defaults and exit so that it can take effect
        [[NSUserDefaults standardUserDefaults] setObject:arr forKey:APP_APPLE_LANGUAGES];
        [[NSUserDefaults standardUserDefaults] synchronize];
        AWSDKLogInfo(@"RESTARTING Device.");
        exit(0); // Restart
    }
}

void removeLocalization()
{
    NSString *localeOverriden = [NSUserDefaults.standardUserDefaults objectForKey:APP_LOCALE_OVERRIDDEN];
    NSNumber *restoreLocalePos = [NSUserDefaults.standardUserDefaults objectForKey:APP_LOCALE_RESTORE_POS];

    if (localeOverriden) {
        AWSDKLogInfo(@"Removing localization %@.", localeOverriden);
        NSMutableArray *arr = [[[NSUserDefaults standardUserDefaults] objectForKey:APP_APPLE_LANGUAGES] mutableCopy];

        // Restore locale to previous position in list
        if (restoreLocalePos) {
            NSInteger loc = restoreLocalePos.integerValue;
            [arr insertObject:arr[0] atIndex:loc + 1];
            [NSUserDefaults.standardUserDefaults setObject:nil forKey:APP_LOCALE_RESTORE_POS];
        }

        // Remove override
        [arr removeObjectAtIndex:0];
        [[NSUserDefaults standardUserDefaults] setObject:arr forKey:APP_APPLE_LANGUAGES];

        [NSUserDefaults.standardUserDefaults setObject:nil forKey:APP_LOCALE_OVERRIDDEN];
        [NSUserDefaults.standardUserDefaults synchronize];
    }
}
